from math import radians
from pathlib import Path
import bpy
from bpy.types import PropertyGroup
from mathutils import Matrix

from ..constants import get_named_color

from ..tools.asset_types import asset_type_items
from ..managed_blam.scenario import ScenarioTag

from ..icons import get_icon_id
from .. import utils

script_object_types = ('WEAPON_TRIGGER_START', 'WEAPON_TRIGGER_STOP', 'SET_VARIANT', 'SET_PERMUTATION', 'SET_REGION_STATE', 'SET_MODEL_STATE_PROPERTY', 'HIDE', 'UNHIDE', 'DESTROY', 'OBJECT_CANNOT_DIE', 'OBJECT_CAN_DIE', 'OBJECT_PROJECTILE_COLLISION_ON', 'OBJECT_PROJECTILE_COLLISION_OFF', 'DAMAGE_OBJECT', 'PLAY_SOUND')

last_used_compo_leaf = {}

scene_specific_props = (
    'cinematic_anchor',
    'cinematic_events',
    'active_cinematic_event_index',
    'is_main_scene',
)

script_type_map = {
    "CUSTOM": "Custom",
    "WEAPON_TRIGGER_START": "Fire Weapon",
    "WEAPON_TRIGGER_STOP": "Stop Firing Weapon",
    "OBJECT_PROJECTILE_COLLISION_ON": "Projectiles Collide With Object",
    "OBJECT_PROJECTILE_COLLISION_OFF": "Projectiles Pass Through Object",
    "OBJECT_CANNOT_DIE": "Make Object Immortal",
    "OBJECT_CAN_DIE": "Make Object Mortal",
    "DAMAGE_OBJECT": "Damage Object",
    "DESTROY": "Destroy Object",
    "HIDE": "Hide Object",
    "UNHIDE": "Unhide Object",
    "SET_VARIANT": "Set Object Variant",
    "SET_PERMUTATION": "Set Object Permutation",
    "SET_REGION_STATE": "Set Region State",
    "SET_MODEL_STATE_PROPERTY": "Set Model State Property",
    "FADE_IN": "Fade in",
    "FADE_OUT": "Fade out",
    "SET_TITLE": "Set Cinematic Title",
    "SHOW_HUD": "Show Player HUD",
    "HIDE_HUD": "Hide Player HUD",
    "PLAY_SOUND": "Play Sound",
    "SOUND_CLASS_GAIN": "Set Sound Class Gain",
    "SOUND_ENABLE_DUCKER": "Enable Audio Ducker",
    "SOUND_DISABLE_DUCKER": "Disable Audio Ducker",
    "START_GLOBAL_EFFECT": "Start Global Sound Effect",
    "STOP_GLOBAL_EFFECT": "Stop Global Sound Effect",
    "SET_GRAVITY": "Set Gravity",
}

def poll_armature(self, object: bpy.types.Object):
    return object.type == 'ARMATURE'

def poll_empty(self, object: bpy.types.Object):
    return object.type == 'EMPTY'

def poll_cin_marker(self, object: bpy.types.Object):
    return (object.type == 'EMPTY' or object.type == 'ARMATURE') and bpy.context.scene.objects.get(object.name)

def animation_from_group(self, context):
    group = self.groups[self.groups_active_index]
    animation_from_leaf(group, context)
    
def animation_from_phase_set(self, context):
    phase_set = self.phase_sets[self.phase_sets_active_index]
    animation_from_leaf(phase_set, context)
    
def animation_from_blend_axis(self, context):
    axis = self.blend_axis[self.blend_axis_active_index]
    animation_from_leaf(axis, context)
    
def animation_from_leaf(self, context):
    if self.leaves and self.leaves_active_index > -1:
        leaf = self.leaves[self.leaves_active_index]
        animation_from_composite(leaf, context)
        
def animation_from_composite(self, context):
    previous_animation = None
    if self.id_data.nwo.active_animation_index > -1 and self.id_data.nwo.animations:
        current_animation = self.id_data.nwo.animations[self.id_data.nwo.active_animation_index]
        if current_animation.animation_type != 'composite':
            return
        global last_used_compo_leaf
        last_used_compo_leaf[current_animation] = self
        animation_name = self.animation
        previous_active_animation_index = self.id_data.nwo.previous_active_animation_index
        animations = self.id_data.nwo.animations
        animation = animations.get(animation_name)
        if animation is not None:
            if previous_active_animation_index > -1:
                if len(animations) > previous_active_animation_index:
                    previous_animation = animations[previous_active_animation_index]
                if previous_animation:
                    utils.clear_animation(previous_animation, save_pose=True, current_frame=context.scene.frame_current)
                    
            for track in animation.action_tracks:
                if track.object and track.action:
                    slot_id = ""
                    if track.action.slots:
                        if track.action.slots.active:
                            slot_id = track.action.slots.active.identifier
                        else:
                            slot_id = track.action.slots[0].identifier

                    if track.is_shape_key_action:
                        if track.object.type == 'MESH' and track.object.data.shape_keys and track.object.data.shape_keys.animation_data:
                            track.object.data.shape_keys.animation_data.last_slot_identifier = slot_id
                            track.object.data.shape_keys.animation_data.action = track.action
                    else:
                        if track.object.animation_data:
                            track.object.animation_data.last_slot_identifier = slot_id
                            track.object.animation_data.action = track.action
                        if track.object.data and track.object.data.animation_data:
                            track.object.data.animation_data.last_slot_identifier = slot_id
                            track.object.data.animation_data.action = track.action
                            
            self.id_data.nwo.previous_active_animation_index = animations.find(animation_name)
                            
            if utils.get_prefs().sync_timeline_range:
                self.id_data.frame_start = animation.frame_start
                if utils.get_prefs().ignore_final_frame and animation.animation_type in ('base', 'world'):
                    self.id_data.frame_end = animation.frame_end - 1
                else:
                    self.id_data.frame_end = animation.frame_end
            utils.set_animation_frame(animation, self.id_data)

            utils.restore_animation_pose(animation, context)

        

#############################################################
# ANIMATION COPIES
#############################################################

class NWO_AnimationCopiesItems(PropertyGroup):
    name: bpy.props.StringProperty(name="Copy Name", options=set())
    source_name: bpy.props.StringProperty(name="Source Name", options=set())

#############################################################
# ANIMATION COMPOSITES
#############################################################

class NWO_AnimationLeavesItems(PropertyGroup):
    animation: bpy.props.StringProperty(name="Animation", update=animation_from_composite)
    # animation: bpy.props.PointerProperty(name="Animation", type=bpy.types.Action)
    
    manual_blend_axis_0: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_1: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_2: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_3: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_4: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_5: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_6: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_7: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_8: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_9: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    blend_axis_0: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_1: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_2: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_3: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_4: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_5: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_6: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_7: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_8: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_9: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    
class NWO_AnimationGroupItems(PropertyGroup):
    name: bpy.props.StringProperty(name="Name", options=set())
    manual_blend_axis_0: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_1: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_2: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_3: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_4: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_5: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_6: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_7: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_8: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    manual_blend_axis_9: bpy.props.BoolProperty(
        name="Manual Blend Axis",
        description="Manually assign a value to this blend axix instead of allowing it to be calculated",
        options=set(),
    )
    blend_axis_0: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_1: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_2: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_3: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_4: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_5: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_6: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_7: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_8: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    blend_axis_9: bpy.props.FloatProperty(
        name="Blend Axis Value",
        description="Value of this blend axis",
        options=set(),
    )
    leaves_active_index: bpy.props.IntProperty(options=set(), update=animation_from_leaf)
    leaves: bpy.props.CollectionProperty(name="Animations", options=set(), type=NWO_AnimationLeavesItems)
            
    
class NWO_AnimationPhaseSetsItems(PropertyGroup):
    name: bpy.props.StringProperty(name="Name", options=set())
    priority: bpy.props.EnumProperty(
        name="Priority",
        options=set(),
        items=[
            ("default", "Default", ""),
            ("current", "Current", ""),
            ("cycle", "Cycle", ""),
            ("alternate", "Alternate", ""),
        ]
    )
    leaves_active_index: bpy.props.IntProperty(options=set(), update=animation_from_leaf)
    leaves: bpy.props.CollectionProperty(name="Animations", options=set(), type=NWO_AnimationLeavesItems)
    
    key_primary_keyframe: bpy.props.BoolProperty(name="Primary Keyframe", options=set())
    key_secondary_keyframe: bpy.props.BoolProperty(name="Secondary Keyframe", options=set())
    key_tertiary_keyframe: bpy.props.BoolProperty(name="Tertiary Keyframe", options=set())
    key_left_foot: bpy.props.BoolProperty(name="Left Foot", options=set())
    key_right_foot: bpy.props.BoolProperty(name="Right Foot", options=set())
    key_body_impact: bpy.props.BoolProperty(name="Body Impact", options=set())
    key_left_foot_lock: bpy.props.BoolProperty(name="Left Foot Lock", options=set())
    key_left_foot_unlock: bpy.props.BoolProperty(name="Left Foot Unlock", options=set())
    key_right_foot_lock: bpy.props.BoolProperty(name="Right Foot Lock", options=set())
    key_right_foot_unlock: bpy.props.BoolProperty(name="Right Foot Unlock", options=set())
    key_blend_range_marker: bpy.props.BoolProperty(name="Blend Range Marker", options=set())
    key_stride_expansion: bpy.props.BoolProperty(name="Stride Expansion", options=set())
    key_stride_contraction: bpy.props.BoolProperty(name="Stride Contraction", options=set())
    key_ragdoll_keyframe: bpy.props.BoolProperty(name="Ragdoll Keyframe", options=set())
    key_drop_weapon_keyframe: bpy.props.BoolProperty(name="Drop Weapon Keyframe", options=set())
    key_match_a: bpy.props.BoolProperty(name="Match A", options=set())
    key_match_b: bpy.props.BoolProperty(name="Match B", options=set())
    key_match_c: bpy.props.BoolProperty(name="Match C", options=set())
    key_match_d: bpy.props.BoolProperty(name="Match D", options=set())
    key_jetpack_closed: bpy.props.BoolProperty(name="Jetpack Closed", options=set())
    key_jetpack_open: bpy.props.BoolProperty(name="Jetpack Open", options=set())
    key_sound_event: bpy.props.BoolProperty(name="Sound Event", options=set())
    key_effect_event: bpy.props.BoolProperty(name="Effect Event", options=set())

class NWO_AnimationDeadZonesItems(PropertyGroup):
    name: bpy.props.StringProperty(name="Name")
    bounds: bpy.props.FloatVectorProperty(name="Dead Zone Bounds", options=set(), size=2, subtype='COORDINATES', min=0)
    rate: bpy.props.FloatProperty(name="Dead Zone Rate", options=set(), min=0, default=90)

class NWO_AnimationBlendAxisItems(PropertyGroup):
    name: bpy.props.EnumProperty(
        name="Type",
        options=set(),
        items=[
            ("movement_angles", "Movement Angles", ""), # linear_movement_angle get_move_angle
            ("movement_speed", "Movement Speed", ""), # linear_movement_speed get_move_speed
            ("turn_rate", "Turn Rate", ""), # average_angular_rate get_turn_rate
            ("turn_angle", "Turn Angle", ""), # total_angular_offset get_turn_angle
            ("vertical", "Vertical", ""), # translation_offset_z get_destination_vertical
            ("horizontal", "Horizontal", ""), # translation_offset_horizontal get_destination_forward
            ("aim_pitch", "Aim Pitch", ""), # none get_aim_pitch
            ("aim_yaw", "Aim Yaw", ""), # none get_aim_yaw
            ("aim_yaw_from_start", "Aim Yaw From Start", ""), # none get_aim_yaw_from_start
        ]
    )
    
    animation_source_bounds_manual: bpy.props.BoolProperty(name="Animation Manual Bounds", options=set(), description="Manually define the bounds of the animation axis")
    animation_source_bounds: bpy.props.FloatVectorProperty(name="Animation Source Bounds", options=set(), size=2, subtype='COORDINATES', description="Manual animation bounds")
    animation_source_limit: bpy.props.FloatProperty(name="Animation Source Limit", options=set(), description="The limit between each animation on an axis. For example on an angle axis with animtions for every 90 degrees, you'd use 90")
    
    runtime_source_bounds_manual: bpy.props.BoolProperty(name="Input Manual Bounds", options=set(), description="Define the input bounds manually")
    runtime_source_bounds: bpy.props.FloatVectorProperty(name="Input Source Bounds", options=set(), size=2, subtype='COORDINATES', description="Manual input bounds")
    runtime_source_clamped: bpy.props.BoolProperty(name="Input Source Clamped", options=set(), description="Clamps input to within this range")
    
    adjusted: bpy.props.EnumProperty(
        name="Adjustment",
        options=set(),
        items=[
            ("none", "None", ""),
            ("on_start", "On Start", ""),
            ("on_loop", "On Loop", ""),
            ("continuous", "Continuous", ""),
        ]
    )

    leaves_active_index: bpy.props.IntProperty(options=set(), update=animation_from_leaf)
    leaves: bpy.props.CollectionProperty(name="Animations", options=set(), type=NWO_AnimationLeavesItems)
    
    dead_zones_active_index: bpy.props.IntProperty(options=set())
    dead_zones: bpy.props.CollectionProperty(name="Blend Axis Dead Zones", options=set(), type=NWO_AnimationDeadZonesItems)
    
    phase_sets_active_index: bpy.props.IntProperty(options=set(), update=animation_from_phase_set)
    phase_sets: bpy.props.CollectionProperty(name="Animation Sets", options=set(), type=NWO_AnimationPhaseSetsItems)
    
    groups_active_index: bpy.props.IntProperty(options=set(), update=animation_from_group)
    groups: bpy.props.CollectionProperty(name="Animation Groups", options=set(), type=NWO_AnimationGroupItems)
    
    relationship: bpy.props.EnumProperty(
        name="Relationship",
        description="The relationship of this axis to the preceeding axis",
        options=set(),
        items=[
            ('CHILD', "Child", "Inherits the results of the input function of the blend axis above"),
            ('SIBLING', "Sibling", "Inherits the input function of its siblings parent axis"),
            ('PARENT', "Parent", "Inherits from no axis, but an axis proceeding this one may inherit from it")
        ]
    )

# class NWO_AnimationCompositesItems(PropertyGroup):
#     name: bpy.props.StringProperty(name="Name", options=set())
#     overlay: bpy.props.BoolProperty(name="Overlay", options=set())
    
#     timing_source: bpy.props.StringProperty(name="Timing Source", description="Name of the animation to use as the timing source")
#     blend_axis_active_index: bpy.props.IntProperty(options=set())
#     blend_axis: bpy.props.CollectionProperty(name="Blend Axis", options=set(), type=NWO_AnimationBlendAxisItems)
    
#############################################################
#############################################################

#############################################################
# ANIMATION NODES
#############################################################
class NWO_AnimationNodeData_ListItems(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Bone", options=set(),)
    
    node_type: bpy.props.EnumProperty(
        name="Node Type",
        options=set(),
        items=[
            ('fik_anchor_node', "Forward IK Anchor Node", "If you figure out what this does please let me know"),
            ('object_space_offset_node', "Object Space Offset Node", "Only valid for pose overlays. If you figure out what this does please let me know"),
            ('replacement_correction_node', "Replacement Correction Node", "Only valid for replacement animations. If you figure out what this does please let me know"),
        ]
    )

#############################################################
# ANIMATION RENAMES
#############################################################


class NWO_AnimationRenamesItems(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Name", options=set(),)

#############################################################
# ANIMATION EVENTS
#############################################################

# ANIMATION EVENT DATA

class NWO_AnimationEventData_ListItems(bpy.types.PropertyGroup):
    data_type: bpy.props.EnumProperty(
        name="Type",
        options=set(),
        items=[
            ('SOUND', "Sound", ""),
            ('EFFECT', "Effect", ""),
            ('DIALOGUE', "Dialogue", ""),
            ('MUSIC', "Music / Foley", ""),
            ('FUNCTION', "Function", ""),
        ]
    )
    
    frame_offset: bpy.props.IntProperty(
        name="Frame Offset",
        description="Number of frames this data event should be offset from the main event. Where the event is ranged, the offset is from the start frame",
        options=set(),
    )
    
    def sound_clean_tag_path(self, context):
        self["event_sound_tag"] = utils.clean_tag_path(self["event_sound_tag"], "sound").strip('"')
    
    event_sound_tag: bpy.props.StringProperty(
        name="Sound Tag",
        description="Path to the sound tag to play when this event is triggered",
        options=set(),
        update=sound_clean_tag_path,
    )
    
    def effect_clean_tag_path(self, context):
        self["event_effect_tag"] = utils.clean_tag_path(self["event_effect_tag"], "effect").strip('"')
    
    event_effect_tag: bpy.props.StringProperty(
        name="Effect Tag",
        description="Path to the effect tag that should play when this event is triggered",
        options=set(),
        update=effect_clean_tag_path,
    )
    
    dialogue_event: bpy.props.EnumProperty(
        name="Dialogue",
        description="Type of dialogue event that should play when this event is triggered",
        options=set(),
        items=[
            ("bump", "Bump", ""),
            ("dive", "Dive", ""),
            ('evade', "Evade", ""),
            ('lift', "Lift", ""),
            ('sigh', "Sigh", ""),
            ('contempt', "Contempt", ""),
            ('anger', "Anger", ""),
            ('fear', "Fear", ""),
            ('relief', "Relief", ""),
            ('sprint', "Sprint", ""),
            ('sprint_end', "Sprint End", ""),
            ('ass_grabber', "Assassination Grab (Attacker)", ""),
            ('kill_ass', "Assassination Kill (Attacker)", ""),
            ('ass_grabbed', "Assassination Grab (Victim)", ""),
            ('die_ass', "Assassination Kill (Victim)", ""),
        ]
    )
    
    marker: bpy.props.PointerProperty(
        type=bpy.types.Object,
        poll=poll_empty,
        name="Marker",
        options=set(),
        description="Marker that this sound / effect event should play on"
    )
    
    marker_name: bpy.props.StringProperty(
        name="Marker Name",
        description="Declare the marker name manually",
        options=set(),
    )
    
    damage_effect_reporting_type: bpy.props.EnumProperty(
        name="Damage Effect Type",
        description="If this effect event does damage, report the following damage type to the game engine. This list is a combined list of Reach, Halo 4, and Halo 2AMP damage reporting types. Please check the description of the type to ensure it is valid for the game you are working in",
        default="unknown",
        options=set(),
        items=[
            ('ai suicide', "AI Suicide", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('airstrike', "Airstrike", "Valid for: Halo Reach"),
            ('armor lock crush', "Armor Lock Crush", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('assault carbine', "Assault Carbine", "Valid for: Halo 2AMP, Halo 4"),
            ('assault rifle', "Assault Rifle", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('ball melee damage', "Ball Melee Damage", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('banshee', "Banshee", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('banshee bomb', "Banshee Bomb", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('battle rifle', "Battle Rifle", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('beam rifle', "Beam Rifle", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('birthday party explosion', "Birthday Party Explosion", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('bishop beam', "Bishop Beam", "Valid for: Halo 2AMP, Halo 4"),
            ('bolt pistol', "Bolt Pistol", "Valid for: Halo 2AMP, Halo 4"),
            ('bomb explosion damage', "Bomb Explosion Damage", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('bomb melee damage', "Bomb Melee Damage", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('broadsword', "Broadsword", "Valid for: Halo 4"),
            ('broadsword missile', "Broadsword Missile", "Valid for: Halo 4"),
            ('brute plasma rifle', "Brute Plasma Rifle", "Valid for: Halo 2AMP"),
            ('brute shot', "Brute Shot", "Valid for: Halo 2AMP, Halo Reach"),
            ('carbine', "Carbine", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('chopper', "Chopper", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('claymore grenade', "Claymore Grenade", "Valid for: Halo Reach"),
            ('concussion rifle', "Concussion Rifle", "Valid for: Halo 2AMP, Halo 4"),
            ('elephant turret', "Elephant Turret", "Valid for: Halo Reach"),
            ('energy sword', "Energy Sword", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('excavator', "Excavator", "Valid for: Halo Reach"),
            ('falcon driver', "Falcon Driver", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('falcon gunner', "Falcon Gunner", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('falling damage', "Falling Damage", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('fire damage', "Fire Damage", "Valid for: Halo 2AMP"),
            ('firebomb grenade', "Firebomb Grenade", "Valid for: Halo Reach"),
            ('flag melee damage', "Flag Melee Damage", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('flak cannon', "Flak Cannon", "Valid for: Halo Reach"),
            ('flame thrower', "Flame Thrower", "Valid for: Halo Reach"),
            ('flood prongs', "Flood Prongs", "Valid for: Halo 2AMP, Halo 4"),
            ('forerunner rifle', "Forerunner Rifle", "Valid for: Halo 2AMP, Halo 4"),
            ('forerunner smg', "Forerunner Smg", "Valid for: Halo 2AMP, Halo 4"),
            ('forerunner sniper', "Forerunner Sniper", "Valid for: Halo 2AMP, Halo 4"),
            ('forerunner turret', "Forerunner Turret", "Valid for: Halo 2AMP, Halo 4"),
            ('forklift', "Forklift", "Valid for: Halo Reach"),
            ('frag grenade', "Frag Grenade", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('fuel rod cannon', "Fuel Rod Cannon", "Valid for: Halo 2AMP, Halo 4"),
            ('fusion coil', "Fusion Coil", "Valid for: Halo 2AMP"),
            ('generic collision damage', "Generic Collision Damage", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('generic explosion', "Generic Explosion", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('generic melee damage', "Generic Melee Damage", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('ghost', "Ghost", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('gravity hammer', "Gravity Hammer", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('grenade launcher', "Grenade Launcher", "Valid for: Halo Reach"),
            ('gun goose', "Gun Goose", "Valid for: Halo 2AMP"),
            ('gun goose gun', "Gun Goose Gun", "Valid for: Halo 2AMP"),
            ('hornet', "Hornet", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('hornet gun', "Hornet Gun", "Valid for: Halo 2AMP"),
            ('hornet rocket', "Hornet Rocket", "Valid for: Halo 2AMP"),
            ('human turret', "Human Turret", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('incineration launcher', "Incineration Launcher", "Valid for: Halo 2AMP, Halo 4"),
            ('lich driver', "Lich Driver", "Valid for: Halo 2AMP, Halo 4"),
            ('lich gunner', "Lich Gunner", "Valid for: Halo 2AMP, Halo 4"),
            ('light machine gun', "Light Machine Gun", "Valid for: Halo 2AMP, Halo 4"),
            ('MAC cannon', "MAC Cannon", "Valid for: Halo 2AMP, Halo 4"),
            ('magnum pistol', "Magnum Pistol", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('magnum pistol ctf', "Magnum Pistol CTF", "Valid for: Halo 2AMP, Halo 4"),
            ('mantis', "Mantis", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('marksman rifle', "Marksman Rifle", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('mauler', "Mauler", "Valid for: Halo Reach"),
            ('mech cannon', "Mech Cannon", "Valid for: Halo 4"),
            ('mech chaingun', "Mech Chaingun", "Valid for: Halo 4"),
            ('mech melee', "Mech Melee", "Valid for: Halo 4"),
            ('mech rocket', "Mech Rocket", "Valid for: Halo 4"),
            ('missile launcher', "Missile Launcher", "Valid for: Halo Reach"),
            ('mongoose', "Mongoose", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('needle rifle', "Needle Rifle", "Valid for: Halo Reach"),
            ('needler', "Needler", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('Orbital cruise missile', "Orbital Cruise Missile", "Valid for: Halo 2AMP, Halo 4"),
            ('Ordnance drop pod', "Ordnance Drop Pod", "Valid for: Halo 2AMP, Halo 4"),
            ('Personal auto turret', "Personal Auto Turret", "Valid for: Halo 2AMP, Halo 4"),
            ('plasma cannon', "Plasma Cannon", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('plasma grenade', "Plasma Grenade", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('plasma launcher', "Plasma Launcher", "Valid for: Halo Reach"),
            ('plasma mortar', "Plasma Mortar", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('plasma pistol', "Plasma Pistol", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('plasma repeater', "Plasma Repeater", "Valid for: Halo Reach"),
            ('plasma rifle', "Plasma Rifle", "Valid for: Halo 2AMP, Halo Reach"),
            ('plasma shot', "Plasma Shot", "Valid for: Halo Reach"),
            ('plasma turret', "Plasma Turret", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('Portable shield', "Portable Shield", "Valid for: Halo 2AMP, Halo 4"),
            ('prox-mine', "Proximity Mine", "Valid for: Halo Reach"),
            ('pulse grenade', "Pulse Grenade", "Valid for: Halo 2AMP, Halo 4"),
            ('rail gun', "Rail Gun", "Valid for: Halo 2AMP, Halo 4"),
            ('revenant deux driver', "Revenant Deux Driver", "Valid for: Halo 2AMP, Halo 4"),
            ('revenant deux gunner', "Revenant Deux Gunner", "Valid for: Halo 2AMP, Halo 4"),
            ('revenant driver', "Revenant Driver", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('revenant gunner', "Revenant Gunner", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('rocket launcher', "Rocket Launcher", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('sabre', "Sabre", "Valid for: Halo Reach"),
            ('scorpion', "Scorpion", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('scorpion gunner', "Scorpion Gunner", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('scripting', "Scripting", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('sentinal gun', "Sentinel Gun", "Valid for: Halo Reach"),
            ('sentinel beam', "Sentinel Beam", "Valid for: Halo 2AMP, Halo Reach"),
            ('sentinel rpg', "Sentinel RPG", "Valid for: Halo Reach"),
            ('seraph', "Seraph", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('shade turret', "Shade Turret", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('shotgun', "Shotgun", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('smg', "SMG", "Valid for: Halo 2AMP, Halo Reach"),
            ('smgs', "Dual SMGs", "Valid for: Halo 2AMP"),
            ('sniper rifle', "Sniper Rifle", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('spartan laser', "Spartan Laser", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('spectre driver', "Spectre Driver", "Valid for: Halo Reach"),
            ('spectre gunner', "Spectre Gunner", "Valid for: Halo Reach"),
            ('spike rifle', "Spike Rifle", "Valid for: Halo Reach"),
            ('spread gun', "Spread Gun", "Valid for: Halo 2AMP, Halo 4"),
            ('stalactice', "Stalactite", "Valid for: Halo 2AMP"),
            ('sticky grenade launcher', "Sticky Grenade Launcher", "Valid for: Halo 2AMP, Halo 4"),
            ('tank', "Tank", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('Target designator', "Target Designator", "Valid for: Halo 2AMP, Halo 4"),
            ('Thruster pack', "Thruster Pack", "Valid for: Halo 2AMP, Halo 4"),
            ('teleporter', "Teleporter", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('teh guardians', "The Guardians", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('tortoise driver', "Tortoise Driver", "Valid for: Halo 4"),
            ('tortoise gunner', "Tortoise Gunner", "Valid for: Halo 4"),
            ('transfer damage', "Transfer Damage", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('unknown', "Unknown", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('warthog driver', "Warthog Driver", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('warthog gunner', "Warthog Gunner", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('warthog gunner gauss', "Warthog Gunner Gauss", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('warthog gunner rocket', "Warthog Gunner Rocket", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('wasp driver', "Wasp Driver", "Valid for: Halo 4"),
            ('wasp gunner', "Wasp Gunner", "Valid for: Halo 4"),
            ('wasp gunner heavy', "Wasp Gunner Heavy", "Valid for: Halo 4"),
            ('wraith', "Wraith", "Valid for: Halo 2AMP, Halo 4, Halo Reach"),
            ('wraith anti-infantry', "Wraith Anti-infantry", "Valid for: Halo 2AMP, Halo 4, Halo Reach")
        ]
    )
    
    
    flag_allow_on_player: bpy.props.BoolProperty(
        options=set(),
        name="Allow on Player"
    )
    flag_left_arm_only: bpy.props.BoolProperty(
        options=set(),
        name="Left Arm Only"
    )
    flag_right_arm_only: bpy.props.BoolProperty(
        options=set(),
        name="Right Arm Only"
    )
    flag_first_person_only: bpy.props.BoolProperty(
        options=set(),
        name="First Person Only"
    )
    flag_third_person_only: bpy.props.BoolProperty(
        options=set(),
        name="Third Person Only"
    )
    flag_forward_only: bpy.props.BoolProperty(
        options=set(),
        name="Forward Only"
    )
    flag_reverse_only: bpy.props.BoolProperty(
        options=set(),
        name="Reverse Only"
    )
    flag_fp_no_aged_weapons: bpy.props.BoolProperty(
        options=set(),
        name="Don't Play on Aged Weapons"
    )
    
    def model_clean_tag_path(self, context):
        self["event_model"] = utils.clean_tag_path(self["event_model"], "model").strip('"')
    
    event_model: bpy.props.StringProperty(
        options=set(),
        name="Limit to Model",
        description="Limits the data event to only play on the given model tag",
        update=model_clean_tag_path
    )
    variant: bpy.props.StringProperty(
        options=set(),
        name="Limit to Variant",
        description="Limits the data event to only play on the given variant"
    )

class NWO_Animation_ListItems(bpy.types.PropertyGroup):
    event_data: bpy.props.CollectionProperty(type=NWO_AnimationEventData_ListItems)
    active_event_data_index: bpy.props.IntProperty()
    
    event_id: bpy.props.IntProperty()

    multi_frame: bpy.props.EnumProperty(
        name="Usage",
        description="Toggle whether this animation event should trigger on a single frame, or occur over a range",
        default="single",
        options=set(),
        items=[("single", "Single", ""), ("range", "Range", "")],
    )
    
    def update_frame_range(self, context):
        if self.frame_range < self.frame_frame:
            self.frame_range = self.frame_frame

    frame_range: bpy.props.IntProperty(
        name="Frame Range",
        description="The frame this event is duplicated to",
        default=0,
        options=set(),
        update=update_frame_range,
    )
    
    def get_event_name(self):
        match self.event_type:
            case '_connected_geometry_animation_event_type_frame':
                return "frame_event"
            case '_connected_geometry_animation_event_type_object_function':
                return self.object_function_name
            case '_connected_geometry_animation_event_type_import':
                "import_event"
            case '_connected_geometry_animation_event_type_wrinkle_map':
                return self.wrinkle_map_face_region
            case '_connected_geometry_animation_event_type_ik_active':
                return f"{self.ik_target_usage}|{self.ik_chain}|{self.ik_game_marker_name}|active"
            case '_connected_geometry_animation_event_type_ik_passive':
                return f"{self.ik_target_usage}|{self.ik_chain}|{self.ik_game_marker_name}|passive"

        return "none"

    name: bpy.props.StringProperty(
        name="Event Name",
        default="new_event",
        get=get_event_name,
    )
    
    event_type: bpy.props.EnumProperty(
        name="Type",
        options=set(),
        items=[
            ("_connected_geometry_animation_event_type_frame", "Frame", ""),
            ("_connected_geometry_animation_event_type_object_function", "Object Function", ""),
            ("_connected_geometry_animation_event_type_import", "Pose Overlay Wrap", ""),
            ("_connected_geometry_animation_event_type_wrinkle_map", "Wrinkle Map", ""),
            ("_connected_geometry_animation_event_type_ik_active", "IK Active", ""),
            ("_connected_geometry_animation_event_type_ik_passive", "IK Passive", ""),
        ]
    )

    # event_type: bpy.props.EnumProperty(
    #     name="Type",
    #     default="_connected_geometry_animation_event_type_frame",
    #     options=set(),
    #     items=[
            # ("_connected_geometry_animation_event_type_custom", "Custom", ""),
            # ("_connected_geometry_animation_event_type_loop", "Loop", ""),
            # ("_connected_geometry_animation_event_type_sound", "Sound", ""),
            # ("_connected_geometry_animation_event_type_effect", "Effect", ""),
            # ("_connected_geometry_animation_event_type_text", "Text", ""),
            # (
            #     "_connected_geometry_animation_event_type_footstep",
            #     "Footstep",
            #     "",
            # ),
            # (
            #     "_connected_geometry_animation_event_type_cinematic_effect",
            #     "Cinematic Effect",
            #     "",
            # ),
            
    #     ],
    # )
    #     items=[
    #         ("frame", "Frame", ""),
    #         ("trigger", "Frame", ""),
    #         ("navigation", "Frame", ""),
    #         ("sync_action", "Frame", ""),
    #         ("sound", "Frame", ""),
    #         ("effect", "Frame", ""),
    #         ("cinematic_effect", "Frame", ""),
    #         ("object_function", "Frame", ""),
    #         ("wrinkle_map", "Frame", ""),
    #         ("ik_active", "Frame", ""),
    #         ("ik_passive", "Frame", ""),
    #     ]
    # )

    # TODO
    # Revised event list = sound, effect, import, trigger, navigation, sync action, ik active, ik passive, wrinkle map, object function, cinematic effect

    # non_sound_frame_types = ['primary keyframe', 
    #                'secondary keyframe', 
    #                'tertiary keyframe',                    
    #                'allow interruption',                   
    #                'blend range marker',
    #                'stride expansion',
    #                'stride contraction',
    #                'ragdoll keyframe',
    #                'drop weapon keyframe',
    #                'match a',
    #                'match b',
    #                'match c',
    #                'match d',
    #                'right foot lock',
    #                'right foot unlock',
    #                'left foot lock',
    #                'left foot unlock']
    # sound_frame_types = ['left foot', 'right foot', 'both-feet shuffle', 'body impact']
    # import_event_types = ['Wrapped Left', 'Wrapped Right']    
    # frame_event_types = { 'Trigger Events':['primary keyframe', 'secondary keyframe', 'tertiary keyframe'],
    #                       'Navigation Events':['match a', 'match b', 'match c', 'match d', 'stride expansion',
    #                                            'stride contraction', 'right foot lock', 'right foot unlock', 'left foot lock',
    #                                            'left foot unlock'],
    #                       'Sync Action Events':['ragdoll keyframe', 'drop weapon keyframe', 'allow interruption', 'blend range marker'],
    #                       'Sound Events':['left foot', 'right foot', 'body impact', 'both-feet shuffle'],
    #                       'Import Events':['Wrapped Left', 'Wrapped Right']}

    frame_start: bpy.props.IntProperty(
        name="Frame Start",
        default=1,
        options=set(),
    )

    frame_end: bpy.props.IntProperty(
        name="Frame End",
        default=30,
        options=set(),
    )

    wrinkle_map_face_region: bpy.props.EnumProperty(
        name="Wrinkle Map Face Region",
        options=set(),
        items=[
            ('Upper Brow', 'Upper Brow', ''),
            ('Center Brow', 'Center Brow', ''),
            ('Left Squint', 'Left Squint', ''),
            ('Right Squint', 'Right Squint', ''),
            ('Right Smile', 'Right Smile', ''),
            ('Left Smile', 'Left Smile', ''),
            ('Right Sneer', 'Right Sneer', ''),
            ('Left Sneer', 'Left Sneer', ''),
        ]
    )

    # wrinkle_map_effect: bpy.props.FloatProperty(
    #     name="Wrinkle Map Effect",
    #     default=1,
    #     options=set(),
    # )

    # footstep_type: bpy.props.StringProperty(
    #     name="Footstep Type",
    #     default="",
    #     options=set(),
    # )

    # footstep_effect: bpy.props.IntProperty(
    #     name="Footstep Effect",
    #     default=0,
    #     options=set(),
    # )
    
    def ik_chain_items(self, context):
        items = []
        items.append(("none", "None", ''))
        valid_chains = [chain for chain in utils.get_scene_props().ik_chains if chain.start_node and chain.effector_node]
        for chain in valid_chains:
            items.append((chain.name, chain.name, ''))
            
        return items

    ik_chain: bpy.props.EnumProperty(
        name="IK Chain",
        options=set(),
        items=ik_chain_items,
    )

    # ik_active_tag: bpy.props.StringProperty(
    #     name="IK Active Tag",
    #     default="",
    #     options=set(),
    # )

    # ik_target_tag: bpy.props.StringProperty(
    #     name="IK Target Tag",
    #     default="",
    #     options=set(),
    # )
    
    ik_target_marker: bpy.props.PointerProperty(
        name="IK Offset Target",
        type=bpy.types.Object,
        options=set(),
        description="Animation of this target is used to offset the animated IK. Leave this blank for no offset. No offset would also be achieved by using a target empty which is using copy transforms to the effector bone"
    )
    
    ik_target_marker_bone: bpy.props.StringProperty(
        name="IK Offset Target Bone",
        description="Optional bone if the IK Offset Target is an armature"
    )
    
    ik_game_marker_name: bpy.props.StringProperty(
        name="Target Marker Name",
        description="Name of the in game marker to use as the IK target",
        options=set(),
    )

    ik_target_usage: bpy.props.EnumProperty(
        name="Target Usage",
        options=set(),
        items=[
            # ('world', 'World', ''),
            ('self', 'Self', ''),
            ('primary_weapon', 'Primary Weapon', ''),
            ('secondary_weapon', 'Secondary Weapon', ''),
            ('parent', 'Parent', ''),
            ('assassination', 'Assassination', ''),
        ]
    )
    
    # ik_influence: bpy.props.FloatProperty(
    #     name="Influence",
    #     options=set(),
    #     default=1,
    #     min=0,
    #     max=1,
    #     subtype='FACTOR',
    # )

    # ik_proxy_target_id: bpy.props.IntProperty(
    #     name="IK Proxy Target ID",
    #     default=0,
    #     options={'HIDDEN'},
    # )

    # ik_pole_vector_id: bpy.props.IntProperty(
    #     name="IK Pole Vector ID",
    #     default=0,
    #     options={'HIDDEN'},
    # )

    # ik_effector_id: bpy.props.IntProperty(
    #     name="IK Effector ID",
    #     default=0,
    #     options={'HIDDEN'},
    # )
    
    ik_pole_vector: bpy.props.PointerProperty(
        name="Pole Target",
        type=bpy.types.Object,
        description="Pole target for this IK to use. Optional",
        options=set(),
    )

    ik_pole_vector_bone: bpy.props.StringProperty(
        name="Pole Target Bone",
        description="Optional bone if the Pole Target is an armature"
    )

    # cinematic_effect_tag: bpy.props.StringProperty(
    #     name="Cinematic Effect Tag",
    #     default="",
    #     options=set(),
    # )

    # cinematic_effect_effect: bpy.props.IntProperty(
    #     name="Cinematic Effect",
    #     default=0,
    #     options=set(),
    # )

    # cinematic_effect_marker: bpy.props.StringProperty(
    #     name="Cinematic Effect Marker",
    #     default="",
    #     options=set(),
    # )

    object_function_name: bpy.props.EnumProperty(
        name="Object Function",
        options=set(),
        items=[
            ('animation_event_function_a', 'A', ''),
            ('animation_event_function_b', 'B', ''),
            ('animation_event_function_c', 'C', ''),
            ('animation_event_function_d', 'D', ''),
            ('animation_event_function_e', 'E', 'Halo 4+ only'),
            ('animation_event_function_f', 'F', 'Halo 4+ only'),
            ('animation_event_function_g', 'G', 'Halo 4+ only'),
            ('animation_event_function_h', 'H', 'Halo 4+ only'),
            ('animation_event_function_i', 'I', 'Halo 4+ only'),
            ('animation_event_function_j', 'J', 'Halo 4+ only'),
            ('animation_event_function_k', 'K', 'Halo 4+ only'),
            ('animation_event_function_l', 'L', 'Halo 4+ only'),
            ('animation_event_function_m', 'M', 'Halo 4+ only'),
            ('animation_event_function_n', 'N', 'Halo 4+ only'),
            ('animation_event_function_o', 'O', 'Halo 4+ only'),
            ('animation_event_function_p', 'P', 'Halo 4+ only'),
            ('animation_event_function_q', 'Q', 'Halo 4+ only'),
            ('animation_event_function_r', 'R', 'Halo 4+ only'),
            ('animation_event_function_s', 'S', 'Halo 4+ only'),
            ('animation_event_function_t', 'T', 'Halo 4+ only'),
            ('animation_event_function_u', 'U', 'Halo 4+ only'),
            ('animation_event_function_v', 'V', 'Halo 4+ only'),
            ('animation_event_function_w', 'W', 'Halo 4+ only'),
            ('animation_event_function_x', 'X', 'Halo 4+ only'),
            ('animation_event_function_y', 'Y', 'Halo 4+ only'),
            ('animation_event_function_z', 'Z', 'Halo 4+ only'),
            ('animation_event_function_left_grip', 'Left Grip', 'Halo 4+ only'),
            ('animation_event_function_right_grip', 'Right Grip', 'Halo 4+ only'),
        ]
    )

    event_value: bpy.props.FloatProperty(
        name="Default Event Value",
        default=1,
        soft_min=0,
        soft_max=1,
        subtype='FACTOR',
        options=set(),
    )

    frame_frame: bpy.props.IntProperty(
        name="Frame",
        description="The frame this event occurs on",
        default=0,
        options=set(),
        update=update_frame_range,
    )

    frame_name: bpy.props.EnumProperty(
        name="Frame Event",
        default="none",
        options=set(),
        items=[
            ("none", "None", "Doesn't trigger any special events in animation, but can be used to play sounds, effects, and dialogue"),
            ("primary keyframe", "Primary Keyframe", "Activates the primary function of an animation, for example:\nCompletes a weapon reload\nApplies damage on melee\nThrows a grenade\nKicks a vehicle occupant when boarding]\nLast frame a biped is on the ground in a ranged action\nPoint in an assassination at which the the victim will die if the animation is interrupted"),
            ("secondary keyframe", "Secondary Keyframe", "Activates the secondary function of an animation, for example:\nTaking over a vehicle seat after boarding and kicking out the occupant\nDoes something with melee strikes but I'm not sure\nApex of a ranged action"),
            ("tertiary keyframe", "Tertiary Keyframe", "Activates the tertiary function of an animation, for example:\nDoes something for sync action assassinations\nFirst frame when a biped lands in a ranged action"),
            ("left foot", "Left Foot", "Point in the animation where the biped's left foot impacts the ground. Used to create footstep effects"),
            ("right foot", "Right Foot", "Point in the animation where the biped's right foot impacts the ground. Used to create footstep effects"),
            ("allow interruption", "Allow Interruption", "Point at which an animation may be interrupted, for example it will allow the player to switch weapon when reloading, meleeing, or throwing a grenade"),
            ("do not allow interruption", "Do Not Allow Interruption", "Prevents an player animation from being interupted by player action... or should do. I haven't found any examples of it being used"),
            ("both-feet shuffle", "Both-Feet Shuffle", "Point in animation where both feet move along the ground"),
            ("body impact", "Body Impact", "Plays body impact effects"),
            ("left foot lock", "Left Foot Lock", "Locks the biped's left foot to the ground"),
            ("left foot unlock", "Left Foot Unlock", "Unlocks the biped's left foot from the ground"),
            ("right foot lock", "Right Foot Lock", "Locks the biped's right foot to the ground"),
            ("right foot unlock", "Right Foot Unlock", "Unlocks the biped's right foot from the ground"),
            ("blend range marker", "Blend Range Marker", "Necessary for ranged actions (where AI jump from point to point). A blend range marker must be added for the primary, secondary, and teritary events of a ranged action"),
            ("stride expansion", "Stride Expansion", "Used in walking/running animations to indicate when the biped's stride begins"),
            ("stride contraction", "Stride Contraction", "Used in walking/running animations to indicate when the biped's stride contracts"),
            ("ragdoll keyframe", "Ragdoll Keyframe", "Makes the biped ragdoll in death and assassination animations"),
            ("drop weapon keyframe", "Drop Weapon Keyframe", "Makes the biped drop their weapons in death and assassination animations"),
            ("match a", "Match A", "Important for walk/run cycles. The point at which the biped's legs are side by side"),
            ("match b", "Match B", "Important for walk/run cycles. After Match A, the point at which the leading foot touches the ground"),
            ("match c", "Match C", "Important for walk/run cycles. After Match B, the point at which the legs are side by side again"),
            ("match d", "Match D", "Important for walk/run cycles. After Match C, the point at which the new leading foot touches the ground"),
            # ("jetpack closed", "Jetpack Closed", ""),
            # ("jetpack open", "Jetpack Open", ""),
            # ("sound event", "Sound Event", ""),
            # ("effect event", "Effect Event", ""),
        ],
    )

    # frame_trigger: bpy.props.BoolProperty(
    #     name="Frame Trigger",
    #     default=False,
    #     options=set(),
    # )

    # import_frame: bpy.props.IntProperty(
    #     name="Wrap Frame",
    #     default=1,
    #     options=set(),
    #     description="Frame that a wrapped event occurs on",
    # )

    import_name: bpy.props.EnumProperty(
        name="Wrap Type",
        options=set(),
        description="Tells the game that the specified pose frame should be from a left/right irrespective of the yaw angle",
        items=[
            ("Wrapped Left", "Wrapped Left", "Tells the game that this pose frame is for a left turn irrespective of yaw angle"),
            ("Wrapped Right", "Wrapped Right", "Tells the game that this pose frame is for a right turn irrespective of yaw angle"),
        ]
    )

    # text: bpy.props.StringProperty(
    #     name="Text",
    #     default="",
    #     options=set(),
    # )

class NWO_ActionGroup(bpy.types.PropertyGroup):
    object: bpy.props.PointerProperty(type=bpy.types.Object)
    action: bpy.props.PointerProperty(type=bpy.types.Action)
    nla_uuid: bpy.props.StringProperty(options={'HIDDEN'})
    is_shape_key_action: bpy.props.BoolProperty(options={'HIDDEN'})

class NWO_AnimationPoseBoneSnapshot(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(options={'HIDDEN'})
    matrix_basis: bpy.props.FloatVectorProperty(size=16, options={'HIDDEN'})

class NWO_AnimationPoseControlSnapshot(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(options={'HIDDEN'})
    value_json: bpy.props.StringProperty(options={'HIDDEN'})

class NWO_AnimationArmatureSnapshot(bpy.types.PropertyGroup):
    armature: bpy.props.PointerProperty(type=bpy.types.Object, options={'HIDDEN'})
    bones: bpy.props.CollectionProperty(type=NWO_AnimationPoseBoneSnapshot, options={'HIDDEN'})
    pose_controls: bpy.props.CollectionProperty(type=NWO_AnimationPoseControlSnapshot, options={'HIDDEN'})

class NWO_AnimationPropertiesGroup(bpy.types.PropertyGroup):
    active_action_group_index: bpy.props.IntProperty()
    
    # animation_composites_expanded: bpy.props.BoolProperty(default=True, options=set())
    
    overlay: bpy.props.BoolProperty(
        name="Overlay",
        description="Composite is an overlay",
        options=set(),
    )
    
    external: bpy.props.BoolProperty(
        name="External",
        description="Animation data comes from separate GR2 file",
        options=set(),
    )
    
    gr2_path: bpy.props.StringProperty(
        name="GR2 Path",
        description="Data relative path to the file that contains animation data"
    )

    blend_path: bpy.props.StringProperty(
        name="Blend Path",
        description="Data relative path to the blend file that authors this external animation"
    )
    
    pose_overlay: bpy.props.BoolProperty(
        name="Pose Overlay",
        description="External animation is a pose overlay",
        options=set(),
    )
    
    has_pca: bpy.props.BoolProperty(
        name="PCA",
        description="External animation has PCA (shape key) data",
        options=set(),
    )
    
    action_tracks: bpy.props.CollectionProperty(type=NWO_ActionGroup)
    pose_snapshots: bpy.props.CollectionProperty(type=NWO_AnimationArmatureSnapshot, options={'HIDDEN'})
    
    def update_composite_names(self, context):
        old_name = self.name_old
        new_name = self.name
        self.name_old = new_name
        if not utils.is_corinth(context):
            return
        for anim in self.id_data.nwo.animations:
            if anim.animation_type != 'composite':
                continue
            
            for axis in anim.blend_axis:
                for leaf in axis.leaves:
                    if leaf.animation == old_name:
                        leaf.animation = new_name
                        
                for group in axis.groups:
                    for leaf in group.leaves:
                        if leaf.animation == old_name:
                            leaf.animation = new_name
                            
                for phase_set in axis.phase_sets:
                    for leaf in phase_set.leaves:
                        if leaf.animation == old_name:
                            leaf.animation = new_name
    
    name: bpy.props.StringProperty(
        name="Name",
        options=set(),
        update=update_composite_names,
    )
    
    name_old: bpy.props.StringProperty(options={'HIDDEN'})
    
    def get_actions(self) -> list[bpy.types.Action]:
        return [group.action for group in self.action_tracks if group.action is not None]
    
    def update_frame_end(self, context):
        if self.frame_end < self.frame_start:
            self.frame_start = self.frame_end
            
    def update_frame_start(self, context):
        if self.frame_start > self.frame_end:
            self.frame_end = self.frame_start

    frame_start: bpy.props.IntProperty(
        name="Frame Start",
        default=1,
        options=set(),
        min=0,
        update=update_frame_start,
    )

    frame_end: bpy.props.IntProperty(
        name="Frame End",
        default=30,
        options=set(),
        min=0,
        update=update_frame_end,
    )

    last_frame: bpy.props.IntProperty(default=-1, options={'HIDDEN'})

    export_this: bpy.props.BoolProperty(
        name="Export",
        default=True,
        description="Controls whether this animation is exported or not",
        options=set(),
    )

    compression : bpy.props.EnumProperty(
        name="Compression",
        description="Level of compression to apply to animations",
        options=set(),
        items=[
            ("Default", "Default", "Animation compression is determined by the value set in the asset editor panel"),
            ("Uncompressed", "Uncompressed", "No compression"),
            ("Medium", "Medium", "Medium compression"),
            ("Rough", "Rough", "Highest level of compression"),
        ],
    )
            
    animation_type: bpy.props.EnumProperty(
        name="Type",
        description="Set the type of Halo animation you want this action to be",
        options=set(),
        items=[
            ("base", "Base", "Defines a base animation. Allows for varying levels of root bone movement (or none). Useful for cinematic animations, idle animations, turn and movement animations"),
            ("overlay","Overlay", "Animations that overlay on top of a base animation (or none). Supports keyframe and pose overlays. Useful for animations that should overlay on top of base animations, such as vehicle steering or weapon aiming. Supports object functions to define how these animations blend with others\nLegacy format: JMO\nExamples: fire_1, reload_1, device position"),
            ("replacement", "Replacement", "Animations that fully replace base animated nodes, provided those bones are animated. Useful for animations that should completely overrule a certain set of bones, and don't need any kind of blending influence. Can be set to either object or local space"),
            ("world", "World", "Animations that play relative to the world rather than an objects current position"),
            ("composite", "Composite", "Composite animation. Has no animation data itself but references other animations. Halo 4 and Halo 2AMP only")
        ],
    )
    
    animation_movement_data: bpy.props.EnumProperty(
        name='Movement',
        description='Set how this animation moves the object in worldspace',
        default="none",
        options=set(),
        items=[
            (
                "none",
                "None",
                "Object will not physically move from its position. The standard for cinematic animation.\nLegacy format: JMM\nExamples: enter, exit, idle",
            ),
            (
                "xy",
                "Horizontal",
                "Object can move on the XY plane. Useful for horizontal movement animations.\nLegacy format: JMA\nExamples: move_front, walk_left, h_ping front gut",
            ),
            (
                "xyyaw",
                "Horizontal & Yaw",
                "Object can turn on its Z axis and move on the XY plane. Useful for turning movement animations.\nLegacy format: JMT\nExamples: turn_left, turn_right",
            ),
            (
                "xyzyaw",
                "Horizontal, Vertical & Yaw",
                "Object can turn on its Z axis and move in any direction. Useful for jumping animations.\nLegacy format: JMZ\nExamples: climb, jump_down_long, jump_forward_short",
            ),
            (
                "full",
                "Full (Vehicle Only)",
                "Full movement and rotation. Useful for vehicle animations that require multiple dimensions of rotation. Do not use on bipeds.\nLegacy format: JMV\nExamples: climb, vehicle roll_left, vehicle roll_right_short",
            ),
        ]
    )
    
    animation_space: bpy.props.EnumProperty(
        name="Space",
        description="Set whether the animation is in object or local space",
        options=set(),
        items=[
            ('object', 'Object', 'Replacement animation in object space.\nLegacy format: JMR\nExamples: revenant_p, sword put_away'),
            ('local', 'Local', 'Replacement animation in local space.\nLegacy format: JMRX\nExamples: combat pistol any grip, combat rifle sr grip'),
        ]
    )

    # animation_is_pose: bpy.props.BoolProperty(
    #     name='Pose Overlay',
    #     options=set(),
    #     description='Tells the exporter to compute aim node directions for this overlay. These allow animations to be affected by the aiming direction of the animated object. You must set the pedestal, pitch, and yaw usages in the Foundry armature properties to use this correctly\nExamples: aim_still_up, acc_up_down, vehicle steering'
    # )

    animation_nodes: bpy.props.CollectionProperty(
        type=NWO_AnimationNodeData_ListItems,
    )

    active_animation_node_index: bpy.props.IntProperty(
        name="Index for Animation Node",
        default=0,
        min=0,
        options=set(),
    )
    
    animation_events: bpy.props.CollectionProperty(
        type=NWO_Animation_ListItems,
    )

    active_animation_event_index: bpy.props.IntProperty(
        name="Index for Animation Event",
        default=0,
        min=0,
        options=set(),
    )

    animation_renames: bpy.props.CollectionProperty(
        type=NWO_AnimationRenamesItems,
    )

    active_animation_rename_index: bpy.props.IntProperty(
        name="Index for Animation Renames",
        default=0,
        options=set(),
        min=0,
    )
    
    # Suspension Settings, only visible when animation name is prefixed: suspension
    
    suspension_marker: bpy.props.PointerProperty(poll=poll_empty, type=bpy.types.Object, name="Suspension Point", description="Empty whose position marks the midpoint of the suspension (i.e. the midpoint of a wheel). This empty should be parented to the root bone of the armature")
    suspension_contact_marker: bpy.props.PointerProperty(poll=poll_empty, type=bpy.types.Object, name="Ground Point", description="Empty whose position marks the bottom of the object undergoing suspension (i.e. the bottom point of a wheel). This empty should be parented to the same bone that the suspension object is parented / vertex weighted to (usually a wheel or tread). This empty does not need to be exported")
    suspension_destroyed_region_name: bpy.props.StringProperty(name="Destroyed Region Name", description="Optional. Only necessary for suspension with a destroyed state")
    suspension_destroyed_contact_marker: bpy.props.PointerProperty(poll=poll_empty, type=bpy.types.Object, name="Destroyed Ground Point", description="Optional. Empty whose position marks the bottom of the object undergoing suspension (i.e. the bottom point of a wheel) when destroyed. This empty should be parented to the same bone that the suspension object is parented / vertex weighted to (usually a wheel or tread). This empty does not need to be exported")


    # Tag animation props
    def author_type_items(self, context):
        return [
            ('TAG', "Tag", "Properties must are set by directly editing the tag", get_icon_id('tags'), 0),
            ('BLENDER', "Blender", "Properties are set in Blender, and when exporting animations the properties set here will override the tag", 'BLENDER', 1),
        ]
    
    author_type: bpy.props.EnumProperty(
        name="Author Type",
        items=author_type_items,
    )
    
    weight: bpy.props.FloatProperty(
        name="Weight",
        options=set(),
        description="Weights the chance that this animation plays compared to other variants (denoted by an animation name ending in var[x] e.g. var2)\nThe chance that this animation plays depends on the weight of the other variants. The calculation is total weights / current animation weight.\nFor example given 3 animations with weights 4, 1, 1. The first has a 75% chance of playing, the other two each a 12.5% chance",
        min=0
    ) # when animation name has var only
    loop_frame_index: bpy.props.IntProperty(
        name="Loop Frame",
        options=set(),
        description="No clue"
    )
    # Flags
    disable_interpolation_in: bpy.props.BoolProperty(
        name="Disable Interpolation In",
        options=set(),
        description="Don't interpolate from the previous animation",
    )
    disable_interpolation_out: bpy.props.BoolProperty(
        name="Disable Interpolation Out",
        options=set(),
        description="Don't interpolate to the next animation",
    )
    disable_mode_ik: bpy.props.BoolProperty(
        name="Disable Mode IK",
        options=set(),
        description="Ignore the IK set for this animation's mode (e.g. combat), if one is set in the tag",
    )
    disable_weapon_ik: bpy.props.BoolProperty(
        name="Disable Weapon IK",
        options=set(),
        description="Ignore the IK set for this animation's weapon type (e.g. rifle) or weapon type (e.g. br), if one is set in the tag",
    )
    disable_weapon_aim: bpy.props.BoolProperty(
        name="Disable Weapon Aim",
        options=set(),
        description="Prevents weapon aim overlays from playing",
    )
    disable_look_screen: bpy.props.BoolProperty(
        name="Disable Look Screen",
        options=set(),
        description="Prevents look overlays from playing on this animation",
    )
    disable_transition_adjustment: bpy.props.BoolProperty(
        name="Disable Transition Adjustment",
        options=set(),
        description="Not sure",
    )
    force_weapon_ik_on: bpy.props.BoolProperty(
        name="Force Weapon IK On",
        options=set(),
        description="Forces this animation to use the weapon IK defined in the animation graph tag (weapon ik block)",
    )
    enable_animated_source_interpolation: bpy.props.BoolProperty(
        name="Enable Animated Source Interpolation",
        options=set(),
        description="Who can say"
    )
    disable_ik_sets: bpy.props.BoolProperty(
        name="Disable IK sets",
        options=set(),
        description="This animation will not use any IK sets",
    )
    disable_ik_chains: bpy.props.BoolProperty(
        name="Disable IK Chains",
        options=set(),
        description="This animation will not use IK chain events"
    )
    translate_and_scale_root_only: bpy.props.BoolProperty(
        name="Translate and Scale Root Only",
        options=set(),
        description="Ignore all transition and scale on all nodes except the root (i.e. pedestal)"
    )
    enable_blend_out_on_replacement_anims: bpy.props.BoolProperty(
        name="Enable Blend Out",
        options=set(),
        description="Fade out back to the current base animation as the animation reaches it end"
    )
    disable_subframe_interp_on_loop: bpy.props.BoolProperty(
        name="Disable Subframe interpolation on Loop",
        options=set(),
        description=""
    )
    override_player_input_with_motion: bpy.props.BoolProperty(
        name="Override Player Input with Motion",
        options=set(),
        description="Use the movement data in this animation instead of player physics (player only)"
    )
    
    # Production Flags
    do_not_monitor_changes: bpy.props.BoolProperty(
        name="Do Not Monitor Changes",
        options=set(),
        description="<- Clueless"
    )
    verify_sound_events: bpy.props.BoolProperty(
        name="Verify Sound Events",
        options=set(),
        description="?"
    )
    do_not_inherit_for_player_graphs: bpy.props.BoolProperty(
        name="Do Not Inherit For Player Graphs",
        options=set(),
        description="Animation graph tags using this graph as a parent won't be able to use this animation"
    )
    keep_raw_data_in_tag: bpy.props.BoolProperty( # H4
        name="Keep raw data in tag",
        options=set(),
        description="IDK, cache build only?"
    )
    allow_ball_roll_on_foot: bpy.props.BoolProperty( # H4
        name="Allow Ball Roll on Foot",
        options=set(),
        description="Prevents foot-ik from settling"
    )
    
    # PCA
    pca_group_name: bpy.props.StringProperty(
        name="PCA Group Name",
        options=set(),
        description="If this animation contains PCA (shape key) mesh animation, this is the PCA group it will belong to",
        default="default"
    )
    
    pca_best_quality: bpy.props.BoolProperty(
        name=f"PCA Best Quality",
        options=set(),
        description="If this animation contains PCA (shape key) mesh animation, assigns it a unique group and sets its blend shape count to the frame count minus 1. Don't use this if you care about filesizes, this can make a very large pca_animation tag"
    )
    
    # Blend
    
    override_blend_in_time: bpy.props.FloatProperty(
        name="Override Blend In Time",
        options=set(),
        default=0,
        min=0,
    )
    override_blend_out_time: bpy.props.FloatProperty(
        name="Override Blend Out Time",
        options=set(),
        description="Replacement animations only",
        default=0,
        min=0,
    )
    

    # Composites
    timing_source: bpy.props.StringProperty(name="Timing Source", description="Name of the animation to use as the timing source")
    blend_axis_active_index: bpy.props.IntProperty(options=set(), update=animation_from_blend_axis)
    blend_axis: bpy.props.CollectionProperty(name="Blend Axis", options=set(), type=NWO_AnimationBlendAxisItems)

    # NOT VISIBLE TO USER, USED FOR ANIMATION RENAMES
    state_type: bpy.props.EnumProperty(
        name="State Type",
        options=set(),
        items=[
            ("action", "Action / Overlay", ""),
            ("transition", "Transition", ""),
            ("damage", "Death & Damage", ""),
            ("custom", "Custom", ""),
        ],
    )

    mode: bpy.props.StringProperty(
        name="Mode",
        options=set(),
        description="""The mode the object must be in to use this animation. Use 'any' for all modes. Other valid
        inputs include but are not limited to: 'crouch' when a unit is crouching, 
        'combat' when a unit is in combat. Modes can also refer
        to vehicle seats. For example an animation for a unit driving a warthog would use 'warthog_d'. For more
        information refer to existing model_animation_graph tags. Can be empty""",
    )

    weapon_class: bpy.props.StringProperty(
        name="Weapon Class",
        options=set(),
        description="""The weapon class this unit must be holding to use this animation. Weapon class is defined
        per weapon in .weapon tags (under Group WEAPON > weapon labels). Can be empty""",
    )
    weapon_type: bpy.props.StringProperty(
        name="Weapon Name",
        options=set(),
        description="""The weapon type this unit must be holding to use this animation.  Weapon name is defined
        per weapon in .weapon tags (under Group WEAPON > weapon labels). Can be empty""",
    )
    set: bpy.props.StringProperty(
        name="Set", description="The set this animtion is a part of. Can be empty", options=set(),
    )
    state: bpy.props.StringProperty(
        name="State",
        options=set(),
        description="""The state this animation plays in. States can refer to hardcoded properties or be entirely
        custom. You should refer to existing model_animation_graph tags for more information. Examples include: 'idle' for 
        animations that should play when the object is inactive, 'move-left', 'move-front' for moving. 'put-away' for
        an animation that should play when putting away a weapon. Must not be empty""",
    )

    destination_mode: bpy.props.StringProperty(
        name="Destination Mode",
        options=set(),
        description="The mode to put this object in when it finishes this animation. Can be empty",
    )
    destination_state: bpy.props.StringProperty(
        name="Destination State",
        options=set(),
        description="The state to put this object in when it finishes this animation. Must not be empty",
    )

    damage_power: bpy.props.EnumProperty(
        name="Power",
        options=set(),
        items=[
            ("hard", "Hard", ""),
            ("soft", "Soft", ""),
        ],
    )
    damage_type: bpy.props.EnumProperty(
        name="Type",
        options=set(),
        items=[
            ("ping", "Ping", ""),
            ("kill", "Kill", ""),
        ],
    )
    damage_direction: bpy.props.EnumProperty(
        name="Direction",
        options=set(),
        items=[
            ("front", "Front", ""),
            ("left", "Left", ""),
            ("right", "Right", ""),
            ("back", "Back", ""),
        ],
    )
    damage_region: bpy.props.EnumProperty(
        name="Region",
        options=set(),
        items=[
            ("gut", "Gut", ""),
            ("chest", "Chest", ""),
            ("head", "Head", ""),
            ("leftarm", "Left Arm", ""),
            ("lefthand", "Left Hand", ""),
            ("leftleg", "Left Leg", ""),
            ("leftfoot", "Left Foot", ""),
            ("rightarm", "Right Arm", ""),
            ("righthand", "Right Hand", ""),
            ("rightleg", "Right Leg", ""),
            ("rightfoot", "Right Foot", ""),
        ],
    )

    variant: bpy.props.IntProperty(
        min=0,
        soft_max=3,
        options=set(),
        name="Variant",
        description="""The variation of this animation. Variations can have different weightings
            to determine whether they play. 0 = no variation
                                    """,
    )

    custom: bpy.props.StringProperty(name="Custom")

    created_with_foundry: bpy.props.BoolProperty(options={'HIDDEN'})
    
    gr2_path: bpy.props.StringProperty(
        name="GR2 Path",
        description="Path to a GR2 file containing animation data to use in place of an action in this scene",
    )

class NWO_CinematicShotActor(bpy.types.PropertyGroup):
    active: bpy.props.BoolProperty(
        name="Active",
        description="Actor is active for this shot"
    )
    pca: bpy.props.BoolProperty(
        name="PCA",
        description="Actor uses PCA animation for this shot. This will only have an effect if a mesh parented under this actor has shape keys"
    )
    actor: bpy.props.PointerProperty(
        name="Actor",
        description="The object representing an actor. Must be an armature object",
        type=bpy.types.Object,
        poll=poll_armature,
    )

class NWO_CinematicShot(bpy.types.PropertyGroup):
    frame_count: bpy.props.IntProperty(
        name="Shot Frame Count",
        description="Number of frames that this shot will play for"
    )
    actors: bpy.props.CollectionProperty(
        name="Actors",
        type=NWO_CinematicShotActor,
    )
    active_actor_index: bpy.props.IntProperty()

class NWO_ZoneSets_ListItems(PropertyGroup):
    name: bpy.props.StringProperty()
    bsp_0: bpy.props.BoolProperty()
    bsp_1: bpy.props.BoolProperty()
    bsp_2: bpy.props.BoolProperty()
    bsp_3: bpy.props.BoolProperty()
    bsp_4: bpy.props.BoolProperty()
    bsp_5: bpy.props.BoolProperty()
    bsp_6: bpy.props.BoolProperty()
    bsp_7: bpy.props.BoolProperty()
    bsp_8: bpy.props.BoolProperty()
    bsp_9: bpy.props.BoolProperty()
    bsp_10: bpy.props.BoolProperty()
    bsp_11: bpy.props.BoolProperty()
    bsp_12: bpy.props.BoolProperty()
    bsp_13: bpy.props.BoolProperty()
    bsp_14: bpy.props.BoolProperty()
    bsp_15: bpy.props.BoolProperty()
    bsp_16: bpy.props.BoolProperty()
    bsp_17: bpy.props.BoolProperty()
    bsp_18: bpy.props.BoolProperty()
    bsp_19: bpy.props.BoolProperty()
    bsp_20: bpy.props.BoolProperty()
    bsp_21: bpy.props.BoolProperty()
    bsp_22: bpy.props.BoolProperty()
    bsp_23: bpy.props.BoolProperty()
    bsp_24: bpy.props.BoolProperty()
    bsp_25: bpy.props.BoolProperty()
    bsp_26: bpy.props.BoolProperty()
    bsp_27: bpy.props.BoolProperty()
    bsp_28: bpy.props.BoolProperty()
    bsp_29: bpy.props.BoolProperty()
    bsp_30: bpy.props.BoolProperty()
    bsp_31: bpy.props.BoolProperty()
    # Adding more for structure designs
    bsp_32: bpy.props.BoolProperty()
    bsp_33: bpy.props.BoolProperty()
    bsp_34: bpy.props.BoolProperty()
    bsp_35: bpy.props.BoolProperty()
    bsp_36: bpy.props.BoolProperty()
    bsp_37: bpy.props.BoolProperty()
    bsp_38: bpy.props.BoolProperty()
    bsp_39: bpy.props.BoolProperty()
    
class NWO_MaterialOverrides(PropertyGroup):
    
    def poll_material(self, material: bpy.types.Material):
        return not material.is_grease_pencil
    
    source_material: bpy.props.PointerProperty(
        name="Source Material",
        type=bpy.types.Material,
        poll=poll_material,
        options=set(),
    )
    destination_material: bpy.props.PointerProperty(
        name="Destination Material",
        type=bpy.types.Material,
        poll=poll_material,
        options=set(),
    )
    
    enabled: bpy.props.BoolProperty(
        name="Enabled",
        default=True,
        options=set(),
    )
    
class NWO_PermutationClones(PropertyGroup):
    name: bpy.props.StringProperty(
        name="Name",
        options=set(),
    )
    
    material_overrides: bpy.props.CollectionProperty(
        name="Material Tag Overrides",
        description="Materials to override for this clone",
        type=NWO_MaterialOverrides,
        options=set(),
    )
    
    active_material_override_index: bpy.props.IntProperty(
        options=set(),
    )
    
    enabled: bpy.props.BoolProperty(
        name="Enabled",
        default=True,
        options=set(),
    )
    
set_type_items = [
    ('DEFAULT', "Default", ""),
    ('MODEL', "Model", ""),
    ('SCENARIO', "Scenario", ""),
]

class NWO_Permutations_ListItems(PropertyGroup):

    def update_name(self, context):
        if self.old != self.name:
            i = int(self.path_from_id().rpartition('[')[2].strip(']'))
            bpy.ops.nwo.permutation_rename(new_name=self.name, index=i)

    old: bpy.props.StringProperty(options=set())

    name: bpy.props.StringProperty(
        name="Name",
        update=update_name,
        options=set(),
        )

    def update_hidden(self, context):
        bpy.ops.nwo.permutation_hide(entry_name=self.name)

    hidden: bpy.props.BoolProperty(name="Hidden", update=update_hidden, options=set())

    def update_hide_select(self, context):
        bpy.ops.nwo.permutation_hide_select(entry_name=self.name)

    hide_select: bpy.props.BoolProperty(name="Hide Select", update=update_hide_select, options=set())

    active: bpy.props.BoolProperty(
        name="Active",
        description="If false, this region will not be active in the model tag except if added to a variant",
        default=True,
    )
    
    clones: bpy.props.CollectionProperty(
        name="Permutation Clones",
        description="Clones of this permutation. Tells the game to copy this permutation to the specified name and optionally replace material paths",
        type=NWO_PermutationClones,
    )
    
    active_clone_index: bpy.props.IntProperty(
        options=set(),
    )
    
    set_type: bpy.props.EnumProperty(
        name="Set Type",
        description="By default a permutation is treated as a model permutation and scenario layer. Setting this to model means the permutation is only visible in the UI in Model and Sky exports. Scenario means the permutation only shows in scenario assets",
        items=set_type_items,
        options=set(),
    )

class NWO_Regions_ListItems(PropertyGroup):

    def update_name(self, context):
        if self.old != self.name:
            i = int(self.path_from_id().rpartition('[')[2].strip(']'))
            bpy.ops.nwo.region_rename(new_name=self.name, index=i)

    old: bpy.props.StringProperty(options=set())

    name: bpy.props.StringProperty(
        name="Name",
        update=update_name,
        options=set(),
        )

    def update_hidden(self, context):
        bpy.ops.nwo.region_hide(entry_name=self.name)

    hidden: bpy.props.BoolProperty(name="Hidden", update=update_hidden, options=set())

    def update_hide_select(self, context):
        bpy.ops.nwo.region_hide_select(entry_name=self.name)

    hide_select: bpy.props.BoolProperty(name="Hide Select", update=update_hide_select, options=set())

    active: bpy.props.BoolProperty(
        name="Active",
        description="If false, this region will not be active in the model tag except if added to a variant",
        default=True,
    )
    
    set_type: bpy.props.EnumProperty(
        name="Set Type",
        description="By default a region is treated as a model region and scenario bsp. Setting this to model means the region is only visible in the UI in Model and Sky exports. Scenario means the region only shows in scenario assets",
        items=set_type_items,
        options=set(),
    )

class NWO_BSP_ListItems(PropertyGroup):
    name: bpy.props.StringProperty(name="BSP Table", options=set())

class NWO_GlobalMaterial_ListItems(PropertyGroup):
    name: bpy.props.StringProperty(name="Global Material Table", options=set())
    
class NWO_IKChain(PropertyGroup):
    name: bpy.props.StringProperty(name="Name", options=set())
    start_node: bpy.props.StringProperty(name="Start Bone", options=set())
    effector_node: bpy.props.StringProperty(name="Effector Bone", options=set())
    
class NWO_ControlObjects(PropertyGroup):
    ob: bpy.props.PointerProperty(type=bpy.types.Object, options=set())
    
def prefab_warning(self, context):
    self.layout.label(text=f"Halo Reach does not support prefab assets")

# class NWO_Asset_ListItems(PropertyGroup):
#     def GetSharedAssetName(self):
#         name = self.shared_asset_path
#         name = name.rpartition("\\")[2]
#         name = name.rpartition(".sidecar.xml")[0]

#         return name

#     shared_asset_name: bpy.props.StringProperty(
#         get=GetSharedAssetName,
#     )

#     shared_asset_path: bpy.props.StringProperty()

#     shared_asset_types = [
#         ("BipedAsset", "Biped", ""),
#         ("CrateAsset", "Crate", ""),
#         ("CreatureAsset", "Creature", ""),
#         ("Device_ControlAsset", "Device Control", ""),
#         ("Device_MachineAsset", "Device Machine", ""),
#         ("Device_TerminalAsset", "Device Terminal", ""),
#         ("Effect_SceneryAsset", "Effect Scenery", ""),
#         ("EquipmentAsset", "Equipment", ""),
#         ("GiantAsset", "Giant", ""),
#         ("SceneryAsset", "Scenery", ""),
#         ("VehicleAsset", "Vehicle", ""),
#         ("WeaponAsset", "Weapon", ""),
#         ("ScenarioAsset", "Scenario", ""),
#         ("Decorator_SetAsset", "Decorator Set", ""),
#         ("Particle_ModelAsset", "Particle Model", ""),
#     ]

#     shared_asset_type: bpy.props.EnumProperty(
#         name="Type",
#         default="BipedAsset",
#         options=set(),
#         items=shared_asset_types,
#     )

# class NWO_ChildAsset(PropertyGroup):
#     asset_path: bpy.props.StringProperty(options=set())
#     enabled: bpy.props.BoolProperty(name="Enabled", default=True, options=set())
    
def poll_actor(self, object):
    return object.type == 'ARMATURE' and object.nwo.cinematic_object and bpy.context.scene.objects.get(object.name)

def script_attachment_label(attachment, index: int) -> str:
    if attachment.marker_name:
        return attachment.marker_name
    if attachment.attachment_type:
        return Path(attachment.attachment_type).with_suffix("").name
    return f"Attachment {index + 1}"

def script_attachment_matches(value: str, attachment, index: int) -> bool:
    return (
        value == str(index + 1)
        or value == f"ATTACHMENT_{index}"
        or value == attachment.name
        or (value == "0" and index == 0)
    )

def cinematic_event_pointer_valid(ob: bpy.types.Object) -> bool:
    return ob is not None and bool(ob.name)
    
class NWO_CinematicEvent(PropertyGroup):
    def script_attachment_items(self, context):
        items = [("NONE", "Actor", "Apply this script to the actor", 0, 0)]
        if not cinematic_event_pointer_valid(self.actor):
            for index in range(1, 33):
                identifier = str(index)
                items.append((identifier, f"Attachment {index}", "Apply this script to this actor attachment", 0, index))
            return items

        for index, attachment in enumerate(self.actor.nwo.attachments):
            identifier = str(index + 1)
            items.append((identifier, script_attachment_label(attachment, index), "Apply this script to this actor attachment", 0, index + 1))

        return items

    def script_target_name(self):
        if not cinematic_event_pointer_valid(self.actor):
            return "NONE"

        attachment_value = self.script_attachment
        if attachment_value not in {"", "NONE"}:
            for index, attachment in enumerate(self.actor.nwo.attachments):
                if script_attachment_matches(attachment_value, attachment, index):
                    return script_attachment_label(attachment, index)

        return self.actor.name

    def cinematic_event_types(self, context):
        return [
            ("DIALOGUE", "Dialogue", "Play dialogue on a cinematic actor"),
            ("EFFECT", "Effect", "Play an effect on a cinematic actor, optionally on a particular marker"),
            ("SCRIPT", "Script", "Execute arbitary halo script at a frame"),
            ("MUSIC", "Music / Foley", "Start or stop a sound or sound_looping tag"),
            ("FUNCTION", "Function", "Set a function value on a cinematic actor at a given frame"),
        ]
        
    def get_name(self):
        start_stop = "Stop" if self.stop else "Start"
        match self.type:
            case 'DIALOGUE':
                # layout.prop(item, "name", icon='PLAY_SOUND', text="", emboss=False)
                if self.sound_tag.strip():
                    if cinematic_event_pointer_valid(self.actor):
                        return f"{Path(self.sound_tag).with_suffix('').name} -> {self.actor.name}"
                    else:
                        return f"{Path(self.sound_tag).with_suffix('').name} -> NONE"
                else:
                    return "NONE"
            case 'EFFECT':
                if self.effect.strip():
                    if self.marker is None:
                        return f"{Path(self.effect).with_suffix('').name} -> NONE"
                    else:
                        if self.marker.type == 'EMPTY':
                            arm = utils.ultimate_armature_parent(self.marker)
                            if arm is None:
                                return f"{Path(self.effect).with_suffix('').name} -> NONE -> {self.marker.name}"
                                layout.alert = True
                            else:
                                return f"{Path(self.effect).with_suffix('').name} -> {arm.name} -> {self.marker.name}"
                        else:
                            return f"{Path(self.effect).with_suffix('').name} -> {self.marker.name}"
                else:
                    return "NONE"
            case 'SCRIPT':
                ui_name = script_type_map.get(self.script_type)
                if ui_name is None:
                    return "INVALID"
                if self.script_type == 'CUSTOM':
                    if self.script_use_text:
                        return f"Using Text File -> {self.text.name}" if self.text else 'NONE'
                    else:
                        if self.script.strip():
                            return self.script
                        else:
                            return "NONE"
                elif self.script_type in script_object_types:
                    if not cinematic_event_pointer_valid(self.actor):
                        if self.script_type == 'PLAY_SOUND':
                            return f"{ui_name} on NONE with sound tag '{Path(self.sound_tag).with_suffix('').name}'"
                        else:
                            return f"{ui_name} -> NONE"
                    else:
                        target_name = self.script_target_name()
                        match self.script_type:
                            case 'SET_VARIANT':
                                return f"{ui_name} of {target_name} to '{self.script_variant}'"
                            case 'SET_PERMUTATION':
                                return f"{ui_name} of {target_name} with region '{self.script_region}' to permutation '{self.script_permutation}'"
                            case 'SET_REGION_STATE':
                                return f"{ui_name} of {target_name} with region '{self.script_region}' to state {self.script_state}"
                            case 'SET_MODEL_STATE_PROPERTY':
                                return f"{ui_name} of {target_name} with state property {self.script_state_property} to {'on' if self.script_bool else 'off'}"
                            case 'DAMAGE_OBJECT':
                                return f"{ui_name} -> {target_name} with region '{self.script_region}' by {round(self.script_damage, 2)}"
                            case 'PLAY_SOUND':
                                return f"{ui_name} on {target_name} with sound tag '{Path(self.sound_tag).with_suffix('').name}'"
                            case _:
                                return f"{ui_name} -> {target_name}"
                else:
                    match self.script_type:
                        case 'SET_TITLE':
                            return f"{ui_name} to '{self.script_text}'"
                        case 'SOUND_CLASS_GAIN':
                            return f"{ui_name} to {round(self.script_float, 2)} dB for {self.script_text}"
                        case 'SOUND_ENABLE_DUCKER' | 'SOUND_DISABLE_DUCKER':
                            return f"{ui_name} for sound classes matching '{self.script_text}'"
                        case 'START_GLOBAL_EFFECT':
                            if self.script_seconds > 0.0:
                                return f"{ui_name} using '{self.script_text}' with scale {round(self.script_factor, 2)} for {round(self.script_seconds, 2)} seconds"
                            else:
                                return f"{ui_name} using '{self.script_text}' with scale {round(self.script_factor, 2)}"
                        case 'STOP_GLOBAL_EFFECT':
                             return f"{ui_name} using '{self.script_text}'"
                        case 'SET_GRAVITY':
                            return f"{ui_name} to {round(self.script_float, 2)}"
                        case 'FADE_IN':
                            return f"{ui_name} from {get_named_color((self.script_color.r, self.script_color.g, self.script_color.b))} over {round(self.script_seconds, 2)} second{'s' if round(self.script_seconds, 2) != 1.0 else ''}"
                        case 'FADE_OUT':
                            return f"{ui_name} to {get_named_color((self.script_color.r, self.script_color.g, self.script_color.b))} over {round(self.script_seconds, 2)} second{'s' if round(self.script_seconds, 2) != 1.0 else ''}"
                        case _:
                            return f"{ui_name}"
                    
            case 'MUSIC':
                return f"{start_stop} {Path(self.music).with_suffix('').name if self.music.strip() else 'NONE'}"
            case 'FUNCTION':
                if cinematic_event_pointer_valid(self.actor):
                    return f"{self.actor.name} -> {Path(self.function_name)} -> {'CLEAR' if self.clear_function else self.value}"
                else:
                    return f"NONE -> {Path(self.function_name)} -> {'CLEAR' if self.clear_function else self.value}"
        
    name: bpy.props.StringProperty(
        name="Name",
        get=get_name,
    )
    
    type: bpy.props.EnumProperty(
        name="Type",
        description="Type of cinematic event",
        items=cinematic_event_types,
        options=set(),
    )
    
    frame: bpy.props.IntProperty(
        name="Frame",
        description="Frame on which this event plays",
        default=1,
        min=0,
        options=set(),
    )
    
    stop: bpy.props.BoolProperty(
        name="Stop",
        options=set(),
        description="Stop this event rather than starting it at the given frame",
    )
    
    def sound_tag_clean_tag_path(self, context):
        self["sound_tag"] = utils.clean_tag_path(self["sound_tag"], "sound").strip('"')
    
    # Dialogue
    sound_tag: bpy.props.StringProperty(
        name="Sound Tag",
        description="Tag relative path to the sound tag to play",
        update=sound_tag_clean_tag_path,
    )
    
    def female_tag_sound_clean_tag_path(self, context):
        self["female_sound_tag"] = utils.clean_tag_path(self["female_sound_tag"], "sound").strip('"')
    
    female_sound_tag: bpy.props.StringProperty(
        name="Female Sound Tag",
        description="Tag relative path to the sound tag to play instead of the default if the actor making the sound is female (such as a female player). If this is not set, the default sound will always be used",
        update=female_tag_sound_clean_tag_path,
    )
    
    sound_scale: bpy.props.FloatProperty(
        name="Scale",
        description="Scale to apply to the sound",
        default=1,
        min=0,
        max=1,
        subtype='FACTOR',
        options=set(),
    )
    
    actor: bpy.props.PointerProperty(
        name="Actor",
        description="The actor associated with this event",
        type=bpy.types.Object,
        poll=poll_actor,
        options=set(),
    )
    
    default_sound_effect: bpy.props.StringProperty(
        name="Sound Effect",
        description="The sound effect to play on top of the dialogue. Uses the sound effects defined in sound\\global_fx.sound_effect_collection",
        options=set(),
    )
    
    subtitle: bpy.props.StringProperty(
        name="Subtitle",
        description="Name of the subtitle to show for this dialogue",
        options=set(),
    )
    
    female_subtitle: bpy.props.StringProperty(
        name="Female Subtitle",
        description="Name of the subtitle to show for this dialogue if the female sound tag is used",
        options=set(),
    )
    
    subtitle_character: bpy.props.StringProperty(
        name="Subtitle Character",
        description="Reference to character name in globals\\globals.globals tag -> cinematic globals -> cinematic characters. Subtitles will use the color set here instead of the default",
        options=set(),
    )
    
    sound_strip: bpy.props.StringProperty(
        name="Sound Strip",
        description="Name of the sound strip to use for this dialogue. When this is set, the frame of this strip will be used instead of the frame declared above",
        options=set(),
    )
    
    # Effect
    
    def effect_clean_tag_path(self, context):
        self["effect"] = utils.clean_tag_path(self["effect"], "effect").strip('"')
    
    effect: bpy.props.StringProperty(
        name="Effect Tag",
        description="Tag relative path to the effect tag this event uses",
        options=set(),
        update=effect_clean_tag_path,
    )
    
    marker: bpy.props.PointerProperty(
        name="Marker Object",
        poll=poll_cin_marker,
        description="The object to play this effect on. Can be a marker directly or the cinematic actor",
        type=bpy.types.Object,
        options=set(),
    )
    
    marker_name: bpy.props.StringProperty(
        name="Marker Name",
        description="Declare the marker name manually",
        options=set(),
    )
    
    function_a: bpy.props.StringProperty(
        name="Function A",
        options=set(),
    )
    
    function_b: bpy.props.StringProperty(
        name="Function B",
        options=set(),
    )
    
    looping: bpy.props.BoolProperty(
        name="Looping",
        options=set(),
    )
    
    effect_state: bpy.props.EnumProperty(
        name="State",
        options=set(),
        items=[
            ("0", "Start", ""),
            ("1", "Stop", ""),
            ("2", "Kill", ""),
        ]
    )
    
    # script
    
    script: bpy.props.StringProperty(
        name="Script",
        description="The script that should be executed at the given frame"
    )
    
    text: bpy.props.PointerProperty(
        name="Script Text",
        type=bpy.types.Text,
        options=set(),
        description="Use the script located in the referenced blender text file"
    )
    
    script_use_text: bpy.props.BoolProperty(
        name="Use Script Text",
        description="Use a Blender text datablock for the header script instead of inline script text",
        options=set(),
    )
    
    script_type: bpy.props.EnumProperty(
        name="Script Type",
        description="Type of script to execute",
        options=set(),
        default="CUSTOM",
        items=[
            ("", "Custom", ""),
            ("CUSTOM", "Custom", "Custom script to execute"),
            ('', "Weapon", ""),
            ("WEAPON_TRIGGER_START", "Fire Weapon", "Causes a weapon to start shooting"),
            ("WEAPON_TRIGGER_STOP", "Stop Firing Weapon", "Causes a weapon to stop shooting"),
            ('', "Damage", ""),
            ('OBJECT_PROJECTILE_COLLISION_ON', "Projectiles Collide With Object", "The object becomes physical and can be damaged by projectiles, this has the knock on effect that the object will dissapear if the character's bounding box is not visible by the cinematic camera."),
            ('OBJECT_PROJECTILE_COLLISION_OFF', "Projectiles Pass Through Object", "The default state of cinematic objects, where they are non-physical"),
            ('OBJECT_CANNOT_DIE', "Make Object Immortal", ""),
            ('OBJECT_CAN_DIE', "Make Object Mortal", ""),
            ('DAMAGE_OBJECT', "Damage Object", ""),
            ('DESTROY', "Destroy Object", ""),
            ('', "Appearance", ""),
            ('HIDE', "Hide Object", "Hide an object from view"),
            ('UNHIDE', "Unhide Object", "Unhide an object from view"),
            ("SET_VARIANT", "Set Object Variant", "Sets an object variant to the named variant"),
            ("SET_PERMUTATION", "Set Object Permutation", "Sets an objects permutation(s). Leave the region blank for all regions"),
            ("SET_REGION_STATE", "Set Region State", "Sets a region(s) state. Leave region blank for all regions"),
            ("SET_MODEL_STATE_PROPERTY", "Set Model State Property", ""),
            ('', "Screen", ""),
            ('FADE_IN', "Fade In", "Screen starts with the chosen color and then fades into the cinematic over x seconds"),
            ('FADE_OUT', "Fade Out", "Screen starts with the cinematic and then fades into the chosen color over x seconds"),
            ('SET_TITLE', "Set Cinematic Title", "Set a cinematic title using a string ID. This must be setup in the scenario cutscene titles block and the relevant string to display must be imported if it does not already exist"),
            ('SHOW_HUD', "Show Player HUD", "Non functional in Halo 4"),
            ('HIDE_HUD', "Hide Player HUD", "Non functional in Halo 4"),
            ('', "Sound", ""),
            ('PLAY_SOUND', "Play Sound", "Plays a sound on the named object or none"),
            ('SOUND_CLASS_GAIN', "Set Sound Class Gain", "Changes the gain on the specified sound class(es) (using sub-string matching, matches all sound classes if left empty) to the specified gain in decibels over the specified number of seconds"),
            ('SOUND_ENABLE_DUCKER', "Enable Audio Ducker", "Enables the ducker on all sound classes matching the substring"),
            ('SOUND_DISABLE_DUCKER', "Disable Audio Ducker", "Disables the ducker on all sound classes matching the substring"),
            ('START_GLOBAL_EFFECT', "Start Global Sound Effect", "Starts a global sound effect with a scale (i.e. how much the effect is active with 1=fully active). Optionally with a duration. Leaving the duration at 0 means the effect will last until stopped"),
            ('STOP_GLOBAL_EFFECT', "Stop Global Sound Effect", "Stops a global sound effect"),
            ('', "Physics", ""),
            ('SET_GRAVITY', "Set Gravity", "Sets gravity relative to Halo gravity"),
        ]
    )

    script_attachment: bpy.props.EnumProperty(
        name="Attachment",
        description="Actor attachment this script should apply to. Choose Actor to apply the script to the actor itself",
        options=set(),
        items=script_attachment_items,
    )
    
    script_text: bpy.props.StringProperty(
        name="Script Text",
    )
    
    script_float: bpy.props.FloatProperty(
        name="Script Float",
        default=1.0,
    )
    
    script_variant: bpy.props.StringProperty(
        name="Script Variant",
    )
    script_region: bpy.props.StringProperty(
        name="Script Region",
    )
    script_permutation: bpy.props.StringProperty(
        name="Script Permutation",
    )
    script_state: bpy.props.EnumProperty(
        name="Script State",
        options=set(),
        items=[
            ("0", "Default", ""),
            ("1", "Minor Damage", ""),
            ("2", "Medium Damage", ""),
            ("3", "Major Damage", ""),
            ("4", "Destroyed", ""),
        ]
    )
    script_state_property: bpy.props.EnumProperty(
        name="Script State Property",
        options=set(),
        items=[
            ("0", "Blurred", ""),
            ("1", "Hella Blurred", ""),
            ("2", "Unshielded", ""),
            ("3", "Battery Depleted", ""),
        ]
    )
    script_color: bpy.props.FloatVectorProperty( # converted to 3 args of RGB float values
        name="Script Argument Color",
        subtype='COLOR',
        options=set(),
        size=3,
        default=(0.0, 0.0, 0.0),
        min=0,
        max=1,
    )
    script_seconds: bpy.props.FloatProperty( # converted to ticks with seconds * 30 for scripts
        name="Script Argument Seconds",
        options=set(),
        subtype='TIME_ABSOLUTE',
        default=0,
        min=0,
    )
    script_damage: bpy.props.FloatProperty(
        name="Script Damage",
        default=50,
        options=set(),
    )
    
    script_bool: bpy.props.BoolProperty(options=set(),)
    
    script_factor: bpy.props.FloatProperty(
        name="Factor",
        min=0,
        max=1,
        default=1,
        subtype='FACTOR',
        options=set(),
    )
    
    # Music
    
    def music_clean_tag_path(self, context):
        self["music"] = utils.clean_tag_path(self["music"]).strip('"')
    
    music: bpy.props.StringProperty(
        name="Music / Foley",
        description="Tag path to a .sound or .sound_looping tag",
        update=music_clean_tag_path,
    )
    
    # Function
    clear_function: bpy.props.BoolProperty(
        name="Clear Function",
        description="Reset a function to its default value immediately",
        options=set(),
    )
    function_name: bpy.props.StringProperty(
        name="Function Name",
        description="Name of the function to set the value of. Select from the object tag functions or input a built in function name"
    )
    value: bpy.props.FloatProperty(
        name="Value",
        subtype='FACTOR',
        options=set(),
        soft_min=0,
        soft_max=1,
        description="Value of the function at the given frame. If interpolation time is 0, this value is set instantly, otherwise the will interpolate at the given frame to its new value over the given number of seconds"
    )
    interpolation_time: bpy.props.FloatProperty(
        name="Interpolation Time",
        options=set(),
        subtype='TIME_ABSOLUTE',
        min=0,
        description="Time to go from the current function value to the new one, in seconds"
    )
    
class NWO_CinematicScene(PropertyGroup):
    
    name: bpy.props.StringProperty(
        name="Scene ID",
        default="010",
        options=set(),
        maxlen=3,
    )
    
    scene: bpy.props.PointerProperty(
        type=bpy.types.Scene,
        name="Blender Scene",
        options=set(),
    )
    
    reset_object_lighting: bpy.props.EnumProperty( # scene specific
        name="Reset Object Lighting",
        options=set(),
        items=[
            ('0', "Default", ""),
            ('1', "Don't Reset Lighting", ""),
            ('2', "Reset Lighting", ""),
        ]
    )
    
    header: bpy.props.StringProperty(
        name="Header",
        options=set(),
        description="Halo script to execute before this cinematic scene starts"
    )
    header_use_text: bpy.props.BoolProperty(
        name="Use Header Text",
        description="Use a Blender text datablock for the header script instead of inline script text",
        options=set(),
    )
    
    footer: bpy.props.StringProperty(
        name="Footer",
        options=set(),
        description="Halo script to execute after this cinematic scene ends"
    )
    footer_use_text: bpy.props.BoolProperty(
        name="Use Footer Text",
        description="Use a Blender text datablock for the footer script instead of inline script text",
        options=set(),
    )
    header_text: bpy.props.PointerProperty(
        name="Header Text",
        options=set(),
        type=bpy.types.Text,
        description="Use the script located in the referenced blender text file. Executed before this cinematic scene starts"
    )
    
    footer_text: bpy.props.PointerProperty(
        name="Footer Text",
        options=set(),
        type=bpy.types.Text,
        description="Use the script located in the referenced blender text file. Executed after this cinematic scene ends"
    )

class NWO_ScenePropertiesGroup(PropertyGroup):
    # CINEMATIC EVENTS
    cinematic_events: bpy.props.CollectionProperty( # scene specific
        name="Cinematic Events",
        options=set(),
        type=NWO_CinematicEvent,
    )
    
    active_cinematic_event_index: bpy.props.IntProperty( # scene specific
        name="Active Cinematic Event Index",
        options=set(),
    )
    
    export_version: bpy.props.StringProperty(options={'HIDDEN'})
    
    is_main_scene: bpy.props.BoolProperty(options={'HIDDEN'}) # scene specific
    
    def get_game_frame(self):
        return self.id_data.frame_current - self.id_data.frame_start + int(utils.is_corinth(bpy.context))
    
    def set_game_frame(self, value):
        # self.id_data.frame_set(value + self.id_data.frame_start)
        self.id_data.frame_current = value + self.id_data.frame_start 
    
    # CINEMATIC SCENE
    game_frame: bpy.props.IntProperty(
        name="Game Frame",
        description="The current blender frame represented as the frame index the game uses",
        get=get_game_frame,
        set=set_game_frame,
        min=0,
    )

    def _cinematic_shot_starts(self, scene):
        shot_starts = [scene.frame_start]
        for marker in utils.get_timeline_markers(scene):
            if marker.frame <= scene.frame_start:
                continue
            if marker.frame != shot_starts[-1]:
                shot_starts.append(marker.frame)

        return shot_starts

    def _current_cinematic_shot_index(self, scene, shot_starts=None):
        if shot_starts is None:
            shot_starts = self._cinematic_shot_starts(scene)

        shot_index = 0
        for idx, shot_start in enumerate(shot_starts):
            if scene.frame_current < shot_start:
                break
            shot_index = idx

        return shot_index
    
    def get_current_shot(self):
        scene = self.id_data
        return self._current_cinematic_shot_index(scene) + 1
    
    def set_current_shot(self, value):
        scene = self.id_data
        shot_starts = self._cinematic_shot_starts(scene)
        shot_index = value - 1
        if shot_index < 0 or shot_index >= len(shot_starts):
            scene.frame_current = scene.frame_start
            return

        scene.frame_current = shot_starts[shot_index]
    
    current_shot: bpy.props.IntProperty(
        name="Current Shot",
        description="Current cinematic shot indicated by the current frame",
        get=get_current_shot,
        set=set_current_shot,
        min=1,
        max=65,
    )
    
    def get_shot_frame(self):
        scene = self.id_data
        shot_starts = self._cinematic_shot_starts(scene)
        shot_index = self._current_cinematic_shot_index(scene, shot_starts)
        frame_base = int(utils.is_corinth(bpy.context))
        return max(scene.frame_current - shot_starts[shot_index], 0) + frame_base
        
    def set_shot_frame(self, value):
        scene = self.id_data
        shot_starts = self._cinematic_shot_starts(scene)
        shot_index = self._current_cinematic_shot_index(scene, shot_starts)
        frame_base = int(utils.is_corinth(bpy.context))
        frame = max(shot_starts[shot_index], shot_starts[shot_index] + value - frame_base)
            
        # check that frame is in current shot
        if len(shot_starts) > shot_index + 1:
            next_marker_frame = shot_starts[shot_index + 1]
            if frame >= next_marker_frame:
                scene.frame_current = next_marker_frame - 1
                return
            
        scene.frame_current = min(frame, scene.frame_end)
    
    shot_frame: bpy.props.IntProperty(
        name="Shot Frame",
        description="Current game frame of the current shot",
        get=get_shot_frame,
        set=set_shot_frame,
        min=0,
    )
    
    # CHILD ASSET
    # child_assets: bpy.props.CollectionProperty(
    #     name="Child Assets",
    #     type=NWO_ChildAsset,
    #     options=set(),
    # )
    
    # active_child_asset_index: bpy.props.IntProperty(
    #     name="Active Child Asset Index",
    #     options=set(),
    # )
    
    def get_intensity_multiplier(self):
        if utils.is_corinth(bpy.context):
            return 0.1
        else:
            return 1
    
    intensity_multiplier: bpy.props.FloatProperty(
        options={'HIDDEN'},
        get=get_intensity_multiplier
    )
    
    is_child_asset: bpy.props.BoolProperty(
        name="Child Asset",
        description="Mark if this asset is a child of another. Setting this will prevent this file from building tags, instead only building intermediary data for use by its parent file"
    )
    
    parent_asset: bpy.props.StringProperty(
        name="Parent Blend",
        description="Data relative filepath to the parent blend"
    )
    parent_sidecar: bpy.props.StringProperty(
        name="Parent Sidecar",
        description="Data relative filepath to the parent sidecar"
    )

    mod_name: bpy.props.StringProperty(options={'HIDDEN'}, default="")
    
    def cinematic_scenario_clean_tag_path(self, context):
        self["cinematic_scenario"] = utils.clean_tag_path(self["cinematic_scenario"], "scenario").strip('"')
    
    cinematic_scenario: bpy.props.StringProperty(
        name="Scenario",
        description="The tag relative path to the scenario which this cinematic should be added to",
        options=set(),
        update=cinematic_scenario_clean_tag_path,
    )
    
    cinematic_zone_set: bpy.props.StringProperty(
        name="Zone Set",
        description="The name of the zone set which this cinematic should be loaded in. If this zone set doesn't already exist, it will be created for you with all bsps active by default",
        options=set(),
    )
    
    cinematic_anchor: bpy.props.PointerProperty( # scene specific
        name="Cinematic Anchor",
        description="The object to use as the anchor point (or reference point) of the cinematic scene. On export this anchor point will be added to the specified scenario if you have set one. This anchor point should be used to move the level geometry to the cinematic scene (by parenting level geometry to the anchor). At export the inverse matrix of this anchor is calculated and added to the scenario tag",
        type=bpy.types.Object,
        options=set(),
    )
    
    cinematic_scenes: bpy.props.CollectionProperty(
        name="Extra Cinematic Scenes",
        description="Pointers to the additional cinematic scenes for this asset",
        type=NWO_CinematicScene,
    )
    
    active_cinematic_scene_index: bpy.props.IntProperty(options={'HIDDEN'})
    
    # cinematic tag settings
    
    
    cinematic_header: bpy.props.StringProperty(
        name="Header Script",
        options=set(),
        description="Halo script to execute before this cinematic starts"
    )
    cinematic_header_use_text: bpy.props.BoolProperty(
        name="Use Header Text",
        description="Use a Blender text datablock for the header script instead of inline script text",
        options=set(),
    )
    
    cinematic_footer: bpy.props.StringProperty(
        name="Footer Script",
        options=set(),
        description="Halo script to execute after this cinematic ends"
    )
    cinematic_footer_use_text: bpy.props.BoolProperty(
        name="Use Footer Text",
        description="Use a Blender text datablock for the footer script instead of inline script text",
        options=set(),
    )
    cinematic_header_text: bpy.props.PointerProperty(
        name="Header Text",
        options=set(),
        type=bpy.types.Text,
        description="Use the script located in the referenced blender text file. Executed before this cinematic starts"
    )
    
    cinematic_footer_text: bpy.props.PointerProperty(
        name="Footer Text",
        options=set(),
        type=bpy.types.Text,
        description="Use the script located in the referenced blender text file. Executed after this cinematic ends"
    )
    
    cinematic_skip_footer: bpy.props.StringProperty(
        name="Skip Script",
        options=set(),
        description="Halo script to execute if the player skips the cinematic"
    )
    cinematic_skip_footer_use_text: bpy.props.BoolProperty(
        name="Use Skip Text",
        description="Use a Blender text datablock for the skip script instead of inline script text",
        options=set(),
    )
    
    cinematic_skip_footer_text: bpy.props.PointerProperty(
        name="Skip Text",
        options=set(),
        type=bpy.types.Text,
        description="Use the script located in the referenced blender text file. Executed if the player skips this cinematic"
    )
    
    cinematic_channel_type: bpy.props.EnumProperty(
        name="Channel Type",
        options=set(),
        description="Type of cinematic to play",
        items=[
            ('0', "Letterbox", "The standard for cinematics"),
            ('1', "Briefing", "I wish I knew"),
            ('2', "Perspective", "You know what I'm craving? A little perspective. That's it. I'd like some fresh, clear, well-seasoned perspective\nIn gameplay cinematic, skipping the cinematic doesn't revert to the last checkpoint"),
            ('3', "Vignette", "Why don't you tell me what something does for once"),
            ('4', "Bink Briefing", "I imagine this works like briefing but plays a bink"),
            ('5', "Bink Full Screen", "Full screen bink movie. In game cinematics are overrated. Only works in H4+"),
        ]
    )
    
    cinematic_easing_in_time: bpy.props.FloatProperty(
        name="Easing In Time",
        options=set(),
        description="Time in seconds to ease into the cinematic from gameplay",
        subtype='TIME_ABSOLUTE'
    )
    cinematic_easing_out_time: bpy.props.FloatProperty(
        name="Easing Out Time",
        options=set(),
        description="Time in seconds to ease from the cinematic to gameplay",
        subtype='TIME_ABSOLUTE'
    )
    
    cinematic_transition_settings: bpy.props.StringProperty(
        name="Transition Settings",
        options=set(),
        description="Tag which defines the fade in / out colors and sounds and sound classes to stop/play/fade when this cinematic starts and ends\nIf you leave this empty on export, and new transition settings tag will be generated for you"
    )
    
    cinematic_bink_movie: bpy.props.StringProperty(
        name="Bink Movie Tag",
        description="Tag which contains a bink movie to play for this cinematic"
    )
    
    cinematic_outro: bpy.props.BoolProperty(
        name="Outro",
        options=set(),
        description="To mark that this cinematic plays at the of a level"
    )
    
    # H4 flags
    cinematic_extra_memory_bink: bpy.props.BoolProperty(
        name="Extra Memory Bink",
        options=set(),
        description="Check this if the bink is large and needs extra memory to run (not needed for opaque binks)"
    )
    
    cinematic_opaque_bink: bpy.props.BoolProperty(
        name="Opaque Bink",
        options=set(),
        description="This bink is full screen and opaque. It will make bink steal extra memory from the render targets. Don't ask me what render targets are"
    )
    
    cinematic_dont_stretch_bink: bpy.props.BoolProperty(
        name="Don't Stretch Bink",
        options=set(),
        description="Play full-screen bink at the authored size (i.e. don't stretch it to fill the screen)"
    )
    
    cinematic_dont_force_hologram_render: bpy.props.BoolProperty(
        name="Don't Force Hologram Render",
        options=set(),
        description="A mystery to be sure. Maybe something todo with cortana rendering"
    )
    
    cinematic_bink_movie_on_disc: bpy.props.StringProperty(
        name="Bink Movie",
        description="Plays a raw bink movie file. The directory and '_60.bik' are implied. '081_crash' will play the file bink\\081_crash_60.bik\n"
    )
    
    
    # ANIMATION
    def update_active_animation_index(self, context):
        previous_animation = None
        if self.active_animation_index > -1:
            animation = self.animations[self.active_animation_index]
            is_composite = animation.animation_type == 'composite'
            if is_composite:
                global last_used_compo_leaf
                last_used = last_used_compo_leaf.get(animation)
                if last_used is None:
                    blend_axis_index = animation.blend_axis_active_index
                    if blend_axis_index > -1 and blend_axis_index < len(animation.blend_axis):
                        axis = animation.blend_axis[blend_axis_index]
                        if axis.leaves:
                            leaf_index = axis.leaves_active_index
                            if leaf_index > -1 and leaf_index < len(axis.leaves):
                                return animation_from_composite(axis.leaves[leaf_index], context)
                        elif axis.groups:
                            group_index = axis.groups_active_index
                            if group_index > -1 and group_index < len(axis.groups):
                                group = axis.groups[group_index]
                                if group.leaves:
                                    leaf_index = group.leaves_active_index
                                    if leaf_index > -1 and leaf_index < len(group.leaves):
                                        return animation_from_composite(group.leaves[leaf_index], context)
                                        
                        elif axis.phase_sets:
                            phase_set_index = axis.phase_sets_active_index
                            if phase_set_index > -1 and phase_set_index < len(axis.phase_sets):
                                phase_set = axis.phase_sets[phase_set_index]
                                if phase_set.leaves:
                                    leaf_index = phase_set.leaves_active_index
                                    if leaf_index > -1 and leaf_index < len(phase_set.leaves):
                                        return animation_from_composite(phase_set.leaves[leaf_index], context)
                                
                else:
                    return animation_from_composite(last_used, context)
                
                if self.previous_active_animation_index > -1:
                    if len(self.animations) > self.previous_active_animation_index:
                        previous_animation = self.animations[self.previous_active_animation_index]
                    if previous_animation:
                        utils.clear_animation(previous_animation, save_pose=True, current_frame=context.scene.frame_current)
                last_used_compo_leaf[animation] = None
                return
                    
            if self.previous_active_animation_index > -1:
                if len(self.animations) > self.previous_active_animation_index:
                    previous_animation = self.animations[self.previous_active_animation_index]
                if previous_animation:
                    utils.clear_animation(previous_animation, save_pose=True, current_frame=context.scene.frame_current)
                    
            for track in animation.action_tracks:
                if track.object and track.action:
                    slot_id = ""
                    if track.action.slots:
                        if track.action.slots.active:
                            slot_id = track.action.slots.active.identifier
                        else:
                            slot_id = track.action.slots[0].identifier

                    if track.is_shape_key_action:
                        if track.object.type == 'MESH' and track.object.data.shape_keys and track.object.data.shape_keys.animation_data:
                            track.object.data.shape_keys.animation_data.last_slot_identifier = slot_id
                            track.object.data.shape_keys.animation_data.action = track.action
                    else:
                        if track.object.animation_data:
                            track.object.animation_data.last_slot_identifier = slot_id
                            track.object.animation_data.action = track.action
                        if track.object.data and track.object.data.animation_data:
                            track.object.data.animation_data.last_slot_identifier = slot_id
                            track.object.data.animation_data.action = track.action

            if utils.get_prefs().sync_timeline_range and not is_composite:
                bpy.ops.nwo.set_timeline(set_frame=False)
            utils.set_animation_frame(animation, context.scene)

            utils.restore_animation_pose(animation, context)
                
        self.previous_active_animation_index = self.active_animation_index
    
    active_animation_index: bpy.props.IntProperty(
        default=-1,
        options=set(),
        update=update_active_animation_index,
    )
    
    previous_active_animation_index: bpy.props.IntProperty(default=-1, options={'HIDDEN'})
    
    animations: bpy.props.CollectionProperty(type=NWO_AnimationPropertiesGroup)
    
    # exclude_first_frame: bpy.props.BoolProperty(options=set())
    # exclude_last_frame: bpy.props.BoolProperty(options=set())
    
    animation_copies_active_index: bpy.props.IntProperty(options=set())
    animation_copies: bpy.props.CollectionProperty(type=NWO_AnimationCopiesItems, options=set())
    
    # animation_composites_active_index: bpy.props.IntProperty(options=set())
    # animation_composites: bpy.props.CollectionProperty(type=NWO_AnimationCompositesItems, options=set())
    
    # zone_sets_active_index: bpy.props.IntProperty(options=set())
    # zone_sets: bpy.props.CollectionProperty(type=NWO_ZoneSets_ListItems, options=set())
    
    # user_removed_all_zone_set: bpy.props.BoolProperty()

    def items_mesh_type(self, context):
        """Function to handle context for mesh enum lists"""
        h4 = utils.is_corinth(context)
        items = []

        if utils.poll_ui("decorator_set"):
            items.append(
                (
                    "_connected_geometry_mesh_type_decorator",
                    "Decorator",
                    "Decorator mesh type. Supports up to 4 level of detail variants",
                    get_icon_id("decorator"),
                    0,
                )
            )
        elif utils.poll_ui(("model", "sky", "particle_model")):
            items.append(
                (
                    "_connected_geometry_mesh_type_render",
                    "Render",
                    "Render only geometry",
                    get_icon_id("render_geometry"),
                    0,
                )
            )
            if utils.poll_ui("model"):
                items.append(
                    (
                        "_connected_geometry_mesh_type_collision",
                        "Collision",
                        "Collision only geometry. Acts as bullet collision and for scenery also provides player collision",
                        get_icon_id("collider"),
                        1,
                    )
                )
                items.append(
                    (
                        "_connected_geometry_mesh_type_physics",
                        "Physics",
                        "Physics only geometry. Uses havok physics to interact with static and dynamic meshes",
                        get_icon_id("physics"),
                        2,
                    )
                )
                # if not h4: NOTE removing these for now until I figure out how they work
                #     items.append(('_connected_geometry_mesh_type_object_instance', 'Flair', 'Instanced mesh for models. Can be instanced across mutliple permutations', get_icon_id("flair"), 3))
        elif utils.poll_ui("scenario"):
            items.append(
                (
                    "_connected_geometry_mesh_type_structure",
                    "Structure",
                    "Structure bsp geometry. By default provides render and bullet/player collision",
                    get_icon_id("structure"),
                    0,
                )
            )
            items.append(
                (
                    "_connected_geometry_mesh_type_poop",
                    "Instance",
                    "Instanced geometry. Geometry capable of cutting through structure mesh",
                    get_icon_id("instance"),
                    1,
                )
            )
            items.append(
                (
                    "_connected_geometry_mesh_type_poop_collision",
                    "Collision",
                    "Non rendered geometry which provides collision only",
                    get_icon_id("collider"),
                    2,
                )
            )
            items.append(
                (
                    "_connected_geometry_mesh_type_plane",
                    "Plane",
                    "Non rendered geometry which provides various utility functions in a bsp. The planes can cut through bsp geometry. Supports portals, fog planes, and water",
                    get_icon_id("surface"),
                    3,
                )
            )
            items.append(
                (
                    "_connected_geometry_mesh_type_volume",
                    "Volume",
                    "Non rendered geometry which defines regions for special properties",
                    get_icon_id("volume"),
                    4,
                )
            )
        elif utils.poll_ui("prefab"):
            items.append(
                (
                    "_connected_geometry_mesh_type_poop",
                    "Instance",
                    "Instanced geometry. Geometry capable of cutting through structure mesh",
                    get_icon_id("instance"),
                    0,
                )
            )
            items.append(
                (
                    "_connected_geometry_mesh_type_poop_collision",
                    "Collision",
                    "Non rendered geometry which provides collision only",
                    get_icon_id("collider"),
                    1,
                )
            )
            items.append(
                (
                    "_connected_geometry_mesh_type_cookie_cutter",
                    "Cookie Cutter",
                    "Non rendered geometry which cuts out the region it defines from the pathfinding grid",
                    get_icon_id("cookie_cutter"),
                    2,
                )
            )

        return items

    def apply_props(self, context):
        for ob in context.scene.objects:
            ob_nwo = ob.data.nwo

            if ob_nwo.mesh_type == "":
                if self.asset_type == "decorator_set":
                    ob_nwo.mesh_type = "_connected_geometry_mesh_type_decorator"
                elif self.asset_type == "scenario":
                    ob_nwo.mesh_type = "_connected_geometry_mesh_type_structure"
                elif self.asset_type == "prefab":
                    ob_nwo.mesh_type = "_connected_geometry_mesh_type_poop"
                else:
                    ob_nwo.mesh_type = "_connected_geometry_mesh_type_render"
    
    def update_asset_type(self, context):
        if self.asset_type == 'animation':
            utils.get_launcher_props().open_model_animation_graph = True

    asset_type: bpy.props.EnumProperty(
        name="Asset Type",
        options=set(),
        description="The type of asset you are creating",
        items=asset_type_items,
        update=update_asset_type,
    )
    
    asset_animation_type: bpy.props.EnumProperty(
        name="Animation Type",
        options=set(),
        items=[
            ("first_person", "First Person", "For creating a first person animation graph"),
            ("standalone", "Standalone", "For creating a standalone animation graph, e.g. for use in a vingette"),
        ]
    )

    forward_direction: bpy.props.EnumProperty(
        name="Scene Forward",
        options=set(),
        description="The forward direction you are using for the scene. By default Halo uses X forward. Whichever option is set as the forward direction in Blender will be oriented to X forward in game i.e. a model facing -Y in Blender will face X in game",
        default="y-",
        items=[
            ("y-", "-Y", "Model is facing Y negative"),
            ("y", "Y", "Model is facing Y positive"),
            ("x-", "-X", "Model is facing X negative"),
            ("x", "X", "Model is facing X positive"),   
        ],
    )

    output_biped: bpy.props.BoolProperty(
        name="Biped",
        description="",
        default=False,
        options=set(),
    )
    output_crate: bpy.props.BoolProperty(
        name="Crate",
        description="",
        default=False,
        options=set(),
    )
    output_creature: bpy.props.BoolProperty(
        name="Creature",
        description="",
        default=False,
        options=set(),
    )
    output_device_control: bpy.props.BoolProperty(
        name="Device Control",
        description="",
        default=False,
        options=set(),
    )
    output_device_dispenser: bpy.props.BoolProperty(
        name="Device Dispenser",
        description="",
        default=False,
        options=set(),
    )
    output_device_machine: bpy.props.BoolProperty(
        name="Device Machine",
        description="",
        default=False,
        options=set(),
    )
    output_device_terminal: bpy.props.BoolProperty(
        name="Device Terminal",
        description="",
        default=False,
        options=set(),
    )
    output_effect_scenery: bpy.props.BoolProperty(
        name="Effect Scenery",
        description="",
        default=False,
        options=set(),
    )
    output_equipment: bpy.props.BoolProperty(
        name="Equipment",
        description="",
        default=False,
        options=set(),
    )
    output_giant: bpy.props.BoolProperty(
        name="Giant",
        description="",
        default=False,
        options=set(),
    )
    output_scenery: bpy.props.BoolProperty(
        name="Scenery",
        description="",
        default=True,
        options=set(),
    )
    output_vehicle: bpy.props.BoolProperty(
        name="Vehicle",
        description="",
        default=False,
        options=set(),
    )
    output_weapon: bpy.props.BoolProperty(
        name="Weapon",
        description="",
        default=False,
        options=set(),
    )
    
    use_as_fp_render_model: bpy.props.BoolProperty(
        name="Use Render Model for First Person",
        description="Sets the first person render model reference for this weapon tag to the render model exported by this file",
        default=True,
    )
    
    def template_model_clean_tag_path(self, context):
        self["template_model"] = utils.clean_tag_path(
            self["template_model"],
            "model"
        ).strip('"')
    def template_biped_clean_tag_path(self, context):
        self["template_biped"] = utils.clean_tag_path(
            self["template_biped"],
            "biped"
        ).strip('"')
    def template_crate_clean_tag_path(self, context):
        self["template_crate"] = utils.clean_tag_path(
            self["template_crate"],
            "crate"
        ).strip('"')
    def template_creature_clean_tag_path(self, context):
        self["template_creature"] = utils.clean_tag_path(
            self["template_creature"],
            "creature"
        ).strip('"')
    def template_device_control_clean_tag_path(self, context):
        self["template_device_control"] = utils.clean_tag_path(
            self["template_device_control"],
            "device_control"
        ).strip('"')
    def template_device_dispenser_clean_tag_path(self, context):
        self["template_device_dispenser"] = utils.clean_tag_path(
            self["template_device_dispenser"],
            "device_dispenser"
        ).strip('"')
    def template_device_machine_clean_tag_path(self, context):
        self["template_device_machine"] = utils.clean_tag_path(
            self["template_device_machine"],
            "device_machine"
        ).strip('"')
    def template_device_terminal_clean_tag_path(self, context):
        self["template_device_terminal"] = utils.clean_tag_path(
            self["template_device_terminal"],
            "device_terminal"
        ).strip('"')
    def template_effect_scenery_clean_tag_path(self, context):
        self["template_effect_scenery"] = utils.clean_tag_path(
            self["template_effect_scenery"],
            "effect_scenery"
        ).strip('"')
    def template_equipment_clean_tag_path(self, context):
        self["template_equipment"] = utils.clean_tag_path(
            self["template_equipment"],
            "equipment"
        ).strip('"')
    def template_giant_clean_tag_path(self, context):
        self["template_giant"] = utils.clean_tag_path(
            self["template_giant"],
            "giant"
        ).strip('"')
    def template_scenery_clean_tag_path(self, context):
        self["template_scenery"] = utils.clean_tag_path(
            self["template_scenery"],
            "scenery"
        ).strip('"')
    def template_vehicle_clean_tag_path(self, context):
        self["template_vehicle"] = utils.clean_tag_path(
            self["template_vehicle"],
            "vehicle"
        ).strip('"')
    def template_weapon_clean_tag_path(self, context):
        self["template_weapon"] = utils.clean_tag_path(self["template_weapon"], "weapon").strip('"')
    def template_scenario_clean_tag_path(self, context):
        self["template_scenario"] = utils.clean_tag_path(self["template_scenario"], "scenario").strip('"')
            
    
    template_model: bpy.props.StringProperty(
        name="Model Template",
        description="Tag relative path to the model tag to use as a base if this asset does not already have one",
        update=template_model_clean_tag_path,
        options=set(),
    )
    template_biped: bpy.props.StringProperty(
        name="Biped Template",
        description="Tag relative path to the biped tag to use as a base if this asset does not already have one",
        update=template_biped_clean_tag_path,
        options=set(),
    )
    template_crate: bpy.props.StringProperty(
        name="Crate Template",
        description="Tag relative path to the crate tag to use as a base if this asset does not already have one",
        update=template_crate_clean_tag_path,
        options=set(),
    )
    template_creature: bpy.props.StringProperty(
        name="Creature Template",
        description="Tag relative path to the creature tag to use as a base if this asset does not already have one",
        update=template_creature_clean_tag_path,
        options=set(),
    )
    template_device_control: bpy.props.StringProperty(
        name="Device Control Template",
        description="Tag relative path to the device_control tag to use as a base if this asset does not already have one",
        update=template_device_control_clean_tag_path,
        options=set(),
    )
    template_device_dispenser: bpy.props.StringProperty(
        name="Device Dispenser Template",
        description="Tag relative path to the device_dispenser tag to use as a base if this asset does not already have one",
        update=template_device_dispenser_clean_tag_path,
        options=set(),
    )
    template_device_machine: bpy.props.StringProperty(
        name="Device Machine Template",
        description="Tag relative path to the device_machine tag to use as a base if this asset does not already have one",
        update=template_device_machine_clean_tag_path,
        options=set(),
    )
    template_device_terminal: bpy.props.StringProperty(
        name="Device Terminal Template",
        description="Tag relative path to the device_terminal tag to use as a base if this asset does not already have one",
        update=template_device_terminal_clean_tag_path,
        options=set(),
    )
    template_effect_scenery: bpy.props.StringProperty(
        name="Effect Scenery Template",
        description="Tag relative path to the effect_scenery tag to use as a base if this asset does not already have one",
        update=template_effect_scenery_clean_tag_path,
        options=set(),
    )
    template_equipment: bpy.props.StringProperty(
        name="Equipment Template",
        description="Tag relative path to the equipment tag to use as a base if this asset does not already have one",
        update=template_equipment_clean_tag_path,
        options=set(),
    )
    template_giant: bpy.props.StringProperty(
        name="Giant Template",
        description="Tag relative path to the giant tag to use as a base if this asset does not already have one",
        update=template_giant_clean_tag_path,
        options=set(),
    )
    template_scenery: bpy.props.StringProperty(
        name="Scenery Template",
        description="Tag relative path to the scenery tag to use as a base if this asset does not already have one",
        update=template_scenery_clean_tag_path,
        options=set(),
    )
    template_vehicle: bpy.props.StringProperty(
        name="Vehicle Template",
        description="Tag relative path to the vehicle tag to use as a base if this asset does not already have one",
        update=template_vehicle_clean_tag_path,
        options=set(),
    )
    template_weapon: bpy.props.StringProperty(
        name="Weapon Template",
        description="Tag relative path to the weapon tag to use as a base if this asset does not already have one",
        update=template_weapon_clean_tag_path,
        options=set(),
    )
    template_scenario: bpy.props.StringProperty(
        name="Scenario Palettes Template",
        description="Tag relative path to the scenario tag to use as a base if this asset does not already have one. Only palettes and camera effects/globals will be copied from the referenced scenario",
        update=template_scenario_clean_tag_path,
        options=set(),
    )
    
    scenario_add_globals: bpy.props.BoolProperty(
        name="Add Camera/Atmosphere Globals",
        default=False,
        options=set(),
        description="Adds empty camera and atmosphere globals to the scenario if they do not exist. If a scenario template is in use then these will first be instead copied from the template scenario"
    )
    scenario_auto_bsp_by_origin: bpy.props.BoolProperty(
        name="Auto BSP by Object Origin",
        default=False,
        options=set(),
        description="On export, assigns non-BSP-defining scenario objects to the BSP that contains their origin. Objects outside all BSPs use the default BSP only when automatic structure is being generated"
    )
    
    

    light_tools_active: bpy.props.BoolProperty(options=set())
    light_tools_pinned: bpy.props.BoolProperty(options=set())
    light_tools_expanded: bpy.props.BoolProperty(default=True, options=set())

    object_properties_active: bpy.props.BoolProperty(options=set())
    object_properties_pinned: bpy.props.BoolProperty(options=set())
    object_properties_expanded: bpy.props.BoolProperty(default=True, options=set())

    material_properties_active: bpy.props.BoolProperty(options=set())
    material_properties_pinned: bpy.props.BoolProperty(options=set())
    material_properties_expanded: bpy.props.BoolProperty(default=True, options=set())

    animation_manager_active: bpy.props.BoolProperty(options=set())
    animation_manager_pinned: bpy.props.BoolProperty(options=set())
    animation_manager_expanded: bpy.props.BoolProperty(default=True, options=set())

    scene_properties_active: bpy.props.BoolProperty(default=False, options=set())
    scene_properties_pinned: bpy.props.BoolProperty(options=set())
    scene_properties_expanded: bpy.props.BoolProperty(default=True, options=set())

    asset_editor_active: bpy.props.BoolProperty(default=True, options=set())
    asset_editor_pinned: bpy.props.BoolProperty(options=set())
    output_tags_expanded: bpy.props.BoolProperty(default=True, options=set())
    asset_editor_expanded: bpy.props.BoolProperty(default=True, options=set())
    # model_overrides_expanded: bpy.props.BoolProperty(default=False, options=set())
    scenario_expanded: bpy.props.BoolProperty(default=False, options=set())
    lighting_expanded: bpy.props.BoolProperty(default=False, options=set())
    decorators_expanded: bpy.props.BoolProperty(default=False, options=set())
    airprobes_expanded: bpy.props.BoolProperty(default=False, options=set())
    # zone_sets_expanded: bpy.props.BoolProperty(default=False, options=set())
    objects_expanded: bpy.props.BoolProperty(default=False, options=set())
    prefabs_expanded: bpy.props.BoolProperty(default=False, options=set())
    model_expanded: bpy.props.BoolProperty(default=True, options=set())
    render_model_expanded: bpy.props.BoolProperty(default=False, options=set())
    collision_model_expanded: bpy.props.BoolProperty(default=False, options=set())
    animation_graph_expanded: bpy.props.BoolProperty(default=False, options=set())
    physics_model_expanded: bpy.props.BoolProperty(default=False, options=set())
    crate_expanded: bpy.props.BoolProperty(default=False, options=set())
    scenery_expanded: bpy.props.BoolProperty(default=False, options=set())
    effect_scenery_expanded: bpy.props.BoolProperty(default=False, options=set())
    device_control_expanded: bpy.props.BoolProperty(default=False, options=set())
    device_machine_expanded: bpy.props.BoolProperty(default=False, options=set())
    device_terminal_expanded: bpy.props.BoolProperty(default=False, options=set())
    device_dispenser_expanded: bpy.props.BoolProperty(default=False, options=set())
    biped_expanded: bpy.props.BoolProperty(default=False, options=set())
    creature_expanded: bpy.props.BoolProperty(default=False, options=set())
    giant_expanded: bpy.props.BoolProperty(default=False, options=set())
    vehicle_expanded: bpy.props.BoolProperty(default=False, options=set())
    weapon_expanded: bpy.props.BoolProperty(default=False, options=set())
    equipment_expanded: bpy.props.BoolProperty(default=False, options=set())
    
    model_rig_expanded: bpy.props.BoolProperty(default=True, options=set())
    rig_controls_expanded: bpy.props.BoolProperty(default=False, options=set())
    rig_object_controls_expanded: bpy.props.BoolProperty(default=False, options=set())
    rig_usages_expanded: bpy.props.BoolProperty(default=False, options=set())
    ik_chains_expanded: bpy.props.BoolProperty(default=False, options=set())
    animation_copies_expanded: bpy.props.BoolProperty(default=False, options=set())
    
    child_assets_expanded: bpy.props.BoolProperty(default=False, options=set())
    
    asset_shaders_expanded: bpy.props.BoolProperty(default=True, options=set())
    importer_expanded: bpy.props.BoolProperty(default=True, options=set())
    camera_sync_expanded: bpy.props.BoolProperty(default=True, options=set())
    rig_tools_expanded: bpy.props.BoolProperty(default=True, options=set())
    animation_tools_expanded: bpy.props.BoolProperty(default=True, options=set())
    game_animation_copy_settings_expanded: bpy.props.BoolProperty(default=True, options=set())
    bsp_tools_expanded: bpy.props.BoolProperty(default=True, options=set())
    scenario_tools_expanded: bpy.props.BoolProperty(default=True, options=set())
    cache_tools_expanded: bpy.props.BoolProperty(default=True, options=set())
    
    regions_table_expanded: bpy.props.BoolProperty(default=True, options=set())
    permutations_table_expanded: bpy.props.BoolProperty(default=True, options=set())
    object_visibility_expanded: bpy.props.BoolProperty(default=True, options=set())
    cinematic_lighting_expanded: bpy.props.BoolProperty(default=True, options=set())
    attachments_expanded: bpy.props.BoolProperty(default=True, options=set())
    custom_properties_expanded: bpy.props.BoolProperty(default=False, options=set())
    armature_controls_expanded: bpy.props.BoolProperty(default=True, options=set())
    bone_collections_expanded: bpy.props.BoolProperty(default=False, options=set())
    armature_pose_controls_expanded: bpy.props.BoolProperty(default=True, options=set())
    camera_shot_properties_expanded: bpy.props.BoolProperty(default=True, options=set())
    camera_screen_effect_expanded: bpy.props.BoolProperty(default=True, options=set())
    camera_user_input_expanded: bpy.props.BoolProperty(default=True, options=set())
    camera_actors_expanded: bpy.props.BoolProperty(default=True, options=set())
    camera_lights_expanded: bpy.props.BoolProperty(default=True, options=set())

    mesh_properties_expanded: bpy.props.BoolProperty(default=True, options=set())
    material_attributes_expanded: bpy.props.BoolProperty(default=True, options=set())
    instance_proxies_expanded: bpy.props.BoolProperty(default=True, options=set())
    
    image_properties_expanded: bpy.props.BoolProperty(default=True, options=set())

    sets_manager_active: bpy.props.BoolProperty(options=set())
    sets_manager_pinned: bpy.props.BoolProperty(options=set())
    sets_manager_expanded: bpy.props.BoolProperty(default=True, options=set())

    tools_active : bpy.props.BoolProperty(options=set())
    tools_pinned: bpy.props.BoolProperty(options=set())
    tools_expanded : bpy.props.BoolProperty(default=True, options=set())

    help_active : bpy.props.BoolProperty(options=set())
    help_pinned: bpy.props.BoolProperty(options=set())
    help_expanded : bpy.props.BoolProperty(default=True, options=set())

    settings_active : bpy.props.BoolProperty(options=set())
    settings_pinned: bpy.props.BoolProperty(options=set())
    settings_expanded : bpy.props.BoolProperty(default=True, options=set())

    toolbar_expanded : bpy.props.BoolProperty(
        name="Toggle Foundry Toolbar",
        default=True,
        options=set(),
    )
    
    animation_renames_expanded: bpy.props.BoolProperty(default=True, options=set())
    animation_events_expanded: bpy.props.BoolProperty(default=True, options=set())
    animation_event_data_expanded: bpy.props.BoolProperty(default=True, options=set())
    animation_nodes_expanded: bpy.props.BoolProperty(default=True, options=set())
    animation_tag_props_expanded: bpy.props.BoolProperty(default=False, options=set())

    def render_clean_tag_path(self, context):
        self["template_render_model"] = utils.clean_tag_path(self["template_render_model"],
            "render_model"
        ).strip('"')
    def collision_clean_tag_path(self, context):
        self["template_collision_model"] = utils.clean_tag_path(
            self["template_collision_model"],
            "collision_model"
        ).strip('"')
    def physics_clean_tag_path(self, context):
        self["template_physics_model"] = utils.clean_tag_path(
            self["template_physics_model"],
            "physics_model"
        ).strip('"')
    def animation_clean_tag_path(self, context):
        self["template_model_animation_graph"] = utils.clean_tag_path(
            self["template_model_animation_graph"],
            "model_animation_graph"
        ).strip('"')
    def render_model_clean_tag_path(self, context):
        self["render_model_path"] = utils.clean_tag_path(
            self["render_model_path"],
            "render_model"
        ).strip('"')

    # render_model_from_blend : bpy.props.BoolProperty(name="Render Model built from Blend", default=True)
    template_render_model : bpy.props.StringProperty(
        name="Render Model Template",
        description="Path to an existing render model tag. If a render model does not already exist for this asset, the specified tag will be copied over prior to export",
        update=render_clean_tag_path,
        options=set(),
        )
    
    # collision_model_from_blend : bpy.props.BoolProperty(name="Collision Model built from Blend", default=True)
    template_collision_model : bpy.props.StringProperty(
        name="Collision Model Template",
        description="Path to an existing collision model tag. If a collison model does not already exist for this asset, the specified tag will be copied over prior to export",
        update=collision_clean_tag_path,
        options=set(),
        )
    
    # physics_model_from_blend : bpy.props.BoolProperty(name="Physics Model built from Blend", default=True)
    template_physics_model : bpy.props.StringProperty(
        name="Physics Model Template",
        description="Path to an existing physics model tag. If a physics model does not already exist for this asset, the specified tag will be copied over prior to export",
        update=physics_clean_tag_path,
        options=set(),
        )
    
    # animation_graph_from_blend : bpy.props.BoolProperty(name="Animation Graph built from Blend", default=True)
    template_model_animation_graph : bpy.props.StringProperty(
        name="Animation Graph Template",
        description="Path to an existing model animation graph tag. If an animation graph does not already exist for this asset, the specified tag will be copied over prior to export. This also ensures that the imported node order for your render model (and collision/physics) matches that of the nodes in the given graph",
        update=animation_clean_tag_path,
        options=set(),
        )
    
    render_model_path : bpy.props.StringProperty(
        name="Render Model Path",
        description="Path to the render model used by this animation. Ensures bone order matches the specified model",
        update=render_model_clean_tag_path,
        options=set(),
        )
    
    instance_proxy_running : bpy.props.BoolProperty(options=set())

    # shader_sync_active : bpy.props.BoolProperty(
    #     name="Shader Sync",
    #     description="Sync's the active material with the corresponding Halo Shader/Material tag. Only active when the material has been marked as linked to game",
    #     options=set()
    # )
    
    # material_sync_rate : bpy.props.FloatProperty(
    #     name="Sync Rate",
    #     description="How often Halo Material Sync should refresh",
    #     min=0.001,
    #     default=0.01,
    #     max=3,
    #     subtype='TIME_ABSOLUTE',
    #     options=set(),
    # )
    
    # light_sync_active : bpy.props.BoolProperty(
    #     name="Light Sync",
    #     description="",
    #     options=set()
    # )
    
    # light_sync_rate : bpy.props.FloatProperty(
    #     name="Sync Rate",
    #     description="How often Light Sync should refresh",
    #     min=0.001,
    #     default=0.1,
    #     max=3,
    #     subtype='TIME_ABSOLUTE',
    #     options=set(),
    # )
    
    lights_export_on_save : bpy.props.BoolProperty(
        name="Export Lights on Blender Save",
        description="Exports all lights from Blender whenever the Blend file is saved",
    )
    
    prefabs_export_on_save : bpy.props.BoolProperty(
        name="Export Prefabs on Blender Save",
        description="Exports all prefabs from Blender whenever the Blend file is saved",
    )
    
    decorators_export_on_save : bpy.props.BoolProperty(
        name="Export Decorators on Blender Save",
        description="Exports all decorators from Blender whenever the Blend file is saved",
    )

    airprobes_export_on_save: bpy.props.BoolProperty(
        name="Export Airprobes on Blender Save",
        description="Exports all airprobes from Blender whenever the Blend file is saved",
        default=False,
    )
    
    # object_sync_active : bpy.props.BoolProperty(
    #     name="Object Sync",
    #     description="",
    #     options=set()
    # )
    
    # object_sync_rate : bpy.props.FloatProperty(
    #     name="Sync Rate",
    #     description="How often Object Sync should refresh",
    #     min=0.001,
    #     default=0.01,
    #     max=3,
    #     subtype='TIME_ABSOLUTE',
    #     options=set(),
    # )
    
    camera_sync_active : bpy.props.BoolProperty(
        name="Camera Sync",
        description="",
        options=set()
    )

    scene_project : bpy.props.StringProperty(
        name="Project",
        options=set(),
    )

    # TABLES

    regions_table: bpy.props.CollectionProperty(type=NWO_Regions_ListItems, options=set())
    regions_table_active_index: bpy.props.IntProperty(options=set())
    permutations_table: bpy.props.CollectionProperty(type=NWO_Permutations_ListItems, options=set())
    permutations_table_active_index: bpy.props.IntProperty(options=set())
    bsp_table: bpy.props.CollectionProperty(type=NWO_BSP_ListItems, options=set())
    bsp_active_index: bpy.props.IntProperty(options=set())
    global_material_table: bpy.props.CollectionProperty(type=NWO_GlobalMaterial_ListItems, options=set())
    global_material_active_index: bpy.props.IntProperty(options=set())
    
    # Rig Validation
    
    armature_has_parent: bpy.props.BoolProperty(options=set())
    armature_bad_transforms: bpy.props.BoolProperty(options=set())
    multiple_root_bones: bpy.props.BoolProperty(options=set())
    invalid_root_bone: bpy.props.BoolProperty(options=set())
    # needs_pose_bones: bpy.props.BoolProperty(options=set())
    too_many_bones: bpy.props.BoolProperty(options=set())
    bone_names_too_long: bpy.props.BoolProperty(options=set())
    pose_bones_bad_transforms: bpy.props.BoolProperty(options=set())
    
    # RIG PROPS
    main_armature: bpy.props.PointerProperty(
        name="Main Armature",
        description="",
        type=bpy.types.Object,
        poll=poll_armature,
        options=set(),
    )
    # support_armature_a: bpy.props.PointerProperty(
    #     name="Support Armature",
    #     description="",
    #     type=bpy.types.Object,
    #     poll=poll_armature,
    #     options=set(),
    # )
    # support_armature_a_parent_bone : bpy.props.StringProperty(name='Parent Bone', description='Specify the bone from the main armature which the root bone of this support armature should join to at export', options=set())

    
    # support_armature_b: bpy.props.PointerProperty(
    #     name="Support Armature",
    #     description="",
    #     type=bpy.types.Object,
    #     poll=poll_armature,
    #     options=set(),
    # )
    # support_armature_b_parent_bone : bpy.props.StringProperty(name='Parent Bone', description='Specify the bone from the main armature which the root bone of this support armature should join to at export', options=set())

    
    # support_armature_c: bpy.props.PointerProperty(
    #     name="Support Armature",
    #     description="",
    #     type=bpy.types.Object,
    #     poll=poll_armature,
    #     options=set(),
    # )
    # support_armature_c_parent_bone : bpy.props.StringProperty(name='Parent Bone', description='Specify the bone from the main armature which the root bone of this support armature should join to at export', options=set())
    
    node_usage_physics_control : bpy.props.StringProperty(name="Physics Control", options=set())
    node_usage_camera_control : bpy.props.StringProperty(name="Camera Control", options=set())
    node_usage_origin_marker : bpy.props.StringProperty(name="Origin Marker", options=set())
    node_usage_left_clavicle : bpy.props.StringProperty(name="Left Clavicle", options=set())
    node_usage_left_upperarm : bpy.props.StringProperty(name="Left Upperarm", options=set())
    node_usage_pose_blend_pitch : bpy.props.StringProperty(name="Pose Blend Pitch", options=set())
    node_usage_pose_blend_yaw : bpy.props.StringProperty(name="Pose Blend Yaw", options=set())
    node_usage_pedestal : bpy.props.StringProperty(name="Pedestal", options=set())
    node_usage_pelvis : bpy.props.StringProperty(name="Pelvis", options=set())
    node_usage_left_foot : bpy.props.StringProperty(name="Left Foot", options=set())
    node_usage_right_foot : bpy.props.StringProperty(name="Right Foot", options=set())
    node_usage_damage_root_gut : bpy.props.StringProperty(name="Damage Root Gut", options=set())
    node_usage_damage_root_chest : bpy.props.StringProperty(name="Damage Root Chest", options=set())
    node_usage_damage_root_head : bpy.props.StringProperty(name="Damage Root Head", options=set())
    node_usage_damage_root_left_shoulder : bpy.props.StringProperty(name="Damage Root Left Shoulder", options=set())
    node_usage_damage_root_left_arm : bpy.props.StringProperty(name="Damage Root Left Arm", options=set())
    node_usage_damage_root_left_leg : bpy.props.StringProperty(name="Damage Root Left Leg", options=set())
    node_usage_damage_root_left_foot : bpy.props.StringProperty(name="Damage Root Left Foot", options=set())
    node_usage_damage_root_right_shoulder : bpy.props.StringProperty(name="Damage Root Right Shoulder", options=set())
    node_usage_damage_root_right_arm : bpy.props.StringProperty(name="Damage Root Right Arm", options=set())
    node_usage_damage_root_right_leg : bpy.props.StringProperty(name="Damage Root Right Leg", options=set())
    node_usage_damage_root_right_foot : bpy.props.StringProperty(name="Damage Root Right Foot", options=set())
    node_usage_left_hand : bpy.props.StringProperty(name="Left Hand", options=set())
    node_usage_right_hand : bpy.props.StringProperty(name="Right Hand", options=set())
    node_usage_weapon_ik : bpy.props.StringProperty(name="Weapon IK", options=set())
    
    # Scale
    def scale_update(self, context):
        scene_scale = 1
        world_units = self.scale_display == 'world_units'
        match self.scale:
            case 'blender':
                scene_scale = 1 / 3.048 if world_units else 1
                factor = 0.03048
            case 'max':
                scene_scale = 0.01 if world_units else 0.03048
                factor = 1 / 0.03048
        scale_val = self.get("scale")
        if scale_val is not None and scale_val != self.old_scale:
            self.old_scale = self["scale"]
            for workspace in bpy.data.workspaces:
                for screen in workspace.screens:
                    for area in screen.areas:
                        if area.type == "VIEW_3D":
                            for space in area.spaces:
                                if space.type == "VIEW_3D":
                                    space.clip_start *= factor
                                    space.clip_end *= factor
        
        
        if self.scale_display == 'world_units':
            context.scene.unit_settings.system = 'METRIC'
            context.scene.unit_settings.length_unit = 'METERS'
        context.scene.unit_settings.scale_length = scene_scale
    
    def scale_items(self, context):
        items = []
        items.append(('blender', 'Blender Scale', "For working at a Blender friendly scale. Scene will be appropriately scaled at export to account for Halo's scale", 'BLENDER', 0))
        items.append(('max', 'Halo Scale', "Scene is exported without scaling. Use this if you're working with imported 3DS Max Files, or legacy assets such as JMS/ASS files which have not been scaled down for Blender", get_icon_id("halo_scale"), 1))
        return items
    
    def scale_display_items(self, context):
        items = []
        unit_length: str = context.scene.unit_settings.length_unit
        items.append(('meters', unit_length, "Meters displayed in Blender are equal to 0.328 in game world units", 'DRIVER_DISTANCE', 0))
        items.append(('world_units', 'World Units'.upper(), "Meters displayed in Blender are equal to in game world units i.e. 1 Meter = 1 World Unit. Use this when you want the units displayed in blender to match the units shown in Sapien", get_icon_id('wu_scale'), 1))
        return items
    
    scale: bpy.props.EnumProperty(
        name="Scale",
        default=0,
        options=set(),
        description="Select the scaling for this asset. Scale is applied at export to ensure units displayed in Blender match with in game units",
        items=scale_items,
        update=scale_update,
    )
    
    old_scale: bpy.props.IntProperty(options={'HIDDEN'})
    
    scale_display: bpy.props.EnumProperty(
        name="Scale Display",
        options=set(),
        description="Select whether to display scale as meters or world units. This has no affect on the scale of the exported asset",
        items=scale_display_items,
        update=scale_update,
    )
    
    maintain_marker_axis: bpy.props.BoolProperty(
        name="Maintain Marker Axis",
        options=set(),
        default=True,
        description="Maintains the forward direction of markers when the scene coordinate system is transformed. Use this if you're working with mesh markers and want their orientation in Blender to match their in game orientation",
    )
    
    export_in_progress: bpy.props.BoolProperty(options=set())
    transforming: bpy.props.BoolProperty(options=set())
        
    def poll_camera_track_camera(self, object: bpy.types.Object):
        return object.type == 'CAMERA'
    
    camera_track_camera: bpy.props.PointerProperty(type=bpy.types.Object, poll=poll_camera_track_camera, options=set())
    
    ik_chains: bpy.props.CollectionProperty(
        type=NWO_IKChain,
    )
    
    ik_chains_active_index: bpy.props.IntProperty(options=set())
    
    object_controls: bpy.props.CollectionProperty(
        type=NWO_ControlObjects,
        options=set(),
    )
    
    object_controls_active_index: bpy.props.IntProperty(options=set())
    
    keyframe_sync_active: bpy.props.BoolProperty(options=set())
    
    
    default_animation_compression: bpy.props.EnumProperty(
        name="Default Animation Compression",
        description="The default animation the game applies to animations",
        options=set(),
        items=[
            ("Automatic", "Automatic", "Compression is determined by the game during animation import"),
            ("Uncompressed", "Uncompressed", "No compression"),
            ("Medium", "Medium", "Medium compression"),
            ("Rough", "Rough", "Highest level of compression"),
        ]
    )
    
    forced_animation_compression: bpy.props.EnumProperty(
        name="Forced Animation Compression",
        description="The forced animation the game applies to animations. Overrides any per animation compression setting",
        options=set(),
        items=[
            ("none", "None", "No override"),
            ("uncompressed", "Uncompressed", "Force no compression for all animations"),
            ("medium", "Medium", "Force medium compression for all animations"),
            ("rough", "Rough", "Force rough compression for all animations"),
        ]
    )
    
    # def get_parent_animation_graph(self):
    #     asset_graph = get_asset_animation_graph()
    #     if asset_graph:
    #         with AnimationTag(path=asset_graph) as animation:
    #             parent_graph = animation.get_parent_graph()
    #             if parent_graph:
    #                 return parent_graph
    #             else:
    #                 return self.parent_animation_graph_helper
    #     else:
    #         return self.parent_animation_graph_helper
                
    # def set_parent_animation_graph(self, value):
    #     asset_graph = get_asset_animation_graph()
    #     if asset_graph and Path(asset_graph).exists():
    #         with AnimationTag(path=asset_graph) as animation:
    #             animation.set_parent_graph(value)
        
    def parent_animation_clean_tag_path(self, context):
        self["parent_animation_graph"] = utils.clean_tag_path(
            self["parent_animation_graph"],
            "model_animation_graph"
        ).strip('"')
        self.parent_animation_graph_helper = self["parent_animation_graph"]
    
    parent_animation_graph: bpy.props.StringProperty(
        name="Parent Animation Graph",
        description="The parent graph of the animations exported from this scene. Allows your animation graph to use and override animations from the parent",
        update=parent_animation_clean_tag_path,
        # get=get_parent_animation_graph,
        # set=set_parent_animation_graph,
        options=set(),
    )
    
    parent_animation_graph_helper: bpy.props.StringProperty(options=set())
    
    scenario_type: bpy.props.EnumProperty( # this is only used at asset creation
        name="Scenario Type",
        description="Select whether this is a Solo, Multiplayer, or Main Menu scenario",
        options=set(),
        items=[
            ("solo", "Singleplayer", "For campaign levels, but also valid for Firefight & Spartan Ops scenarios"),
            ("multiplayer", "Multiplayer", "For multiplayer maps"),
            ("main menu", "Main Menu", "For main menu maps"),
        ]
    )
    
    def update_connected_geometry_mesh_type_default_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_default')
    def update_connected_geometry_mesh_type_collision_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_collision')
    def update_connected_geometry_mesh_type_physics_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_physics')
    def update_connected_geometry_mesh_type_object_instance_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_object_instance')
    def update_connected_geometry_mesh_type_structure_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_structure')
    def update_connected_geometry_mesh_type_seam_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_seam')
    def update_connected_geometry_mesh_type_portal_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_portal')
    def update_connected_geometry_mesh_type_water_surface_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_water_surface')
    def update_connected_geometry_mesh_type_poop_vertical_rain_sheet_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_poop_vertical_rain_sheet')
    def update_connected_geometry_mesh_type_planar_fog_volume_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_planar_fog_volume')
    def update_connected_geometry_mesh_type_lightmap_region_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_lightmap_region')
    def update_connected_geometry_mesh_type_boundary_surface_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_boundary_surface')
    def update_connected_geometry_mesh_type_obb_volume_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_obb_volume')
    def update_connected_geometry_mesh_type_cookie_cutter_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_cookie_cutter')
    def update_connected_geometry_mesh_type_poop_rain_blocker_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_mesh_type_poop_rain_blocker')
    
    def update_connected_geometry_marker_type_model_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_marker_type_model')
    def update_connected_geometry_marker_type_effects_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_marker_type_effects')
    def update_connected_geometry_marker_type_garbage_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_marker_type_garbage')
    def update_connected_geometry_marker_type_hint_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_marker_type_hint')
    def update_connected_geometry_marker_type_pathfinding_sphere_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_marker_type_pathfinding_sphere')
    def update_connected_geometry_marker_type_physics_constraint_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_marker_type_physics_constraint')
    def update_connected_geometry_marker_type_target_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_marker_type_target')
    def update_connected_geometry_marker_type_game_instance_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_marker_type_game_instance')
    def update_connected_geometry_marker_type_airprobe_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_marker_type_airprobe')
    def update_connected_geometry_marker_type_envfx_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_marker_type_envfx')
    def update_connected_geometry_marker_type_lightCone_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_marker_type_lightCone')

    def update_connected_geometry_object_type_frame_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_object_type_frame')
    def update_connected_geometry_object_type_light_visible(self, context): bpy.ops.nwo.hide_object_type(object_type = '_connected_geometry_object_type_light')
    
    connected_geometry_mesh_type_default_visible: bpy.props.BoolProperty(default=True, options=set(), name="Default", update=update_connected_geometry_mesh_type_default_visible)
    connected_geometry_mesh_type_collision_visible: bpy.props.BoolProperty(default=True, options=set(), name="Collision", update=update_connected_geometry_mesh_type_collision_visible)
    connected_geometry_mesh_type_physics_visible: bpy.props.BoolProperty(default=True, options=set(), name="Physics", update=update_connected_geometry_mesh_type_physics_visible)
    connected_geometry_mesh_type_object_instance_visible: bpy.props.BoolProperty(default=True, options=set(), name="Object Instance", update=update_connected_geometry_mesh_type_object_instance_visible)
    connected_geometry_mesh_type_structure_visible: bpy.props.BoolProperty(default=True, options=set(), name="Structure", update=update_connected_geometry_mesh_type_structure_visible)
    connected_geometry_mesh_type_seam_visible: bpy.props.BoolProperty(default=True, options=set(), name="Seam", update=update_connected_geometry_mesh_type_seam_visible)
    connected_geometry_mesh_type_portal_visible: bpy.props.BoolProperty(default=True, options=set(), name="Portal", update=update_connected_geometry_mesh_type_portal_visible)
    connected_geometry_mesh_type_water_surface_visible: bpy.props.BoolProperty(default=True, options=set(), name="Water", update=update_connected_geometry_mesh_type_water_surface_visible)
    connected_geometry_mesh_type_poop_vertical_rain_sheet_visible: bpy.props.BoolProperty(default=True, options=set(), name="Rain Sheet", update=update_connected_geometry_mesh_type_poop_vertical_rain_sheet_visible)
    connected_geometry_mesh_type_planar_fog_volume_visible: bpy.props.BoolProperty(default=True, options=set(), name="Fog", update=update_connected_geometry_mesh_type_planar_fog_volume_visible)
    connected_geometry_mesh_type_lightmap_region_visible: bpy.props.BoolProperty(default=True, options=set(), name="Lightmap Region", update=update_connected_geometry_mesh_type_lightmap_region_visible)
    connected_geometry_mesh_type_boundary_surface_visible: bpy.props.BoolProperty(default=True, options=set(), name="Soft Ceiling", update=update_connected_geometry_mesh_type_boundary_surface_visible)
    connected_geometry_mesh_type_obb_volume_visible: bpy.props.BoolProperty(default=True, options=set(), name="Lightmap Exclusion Volume", update=update_connected_geometry_mesh_type_obb_volume_visible)
    connected_geometry_mesh_type_cookie_cutter_visible: bpy.props.BoolProperty(default=True, options=set(), name="Cookie Cutter", update=update_connected_geometry_mesh_type_cookie_cutter_visible)
    connected_geometry_mesh_type_poop_rain_blocker_visible: bpy.props.BoolProperty(default=True, options=set(), name="Rain Blocker", update=update_connected_geometry_mesh_type_poop_rain_blocker_visible)
    
    connected_geometry_marker_type_model_visible: bpy.props.BoolProperty(default=True, options=set(), name="Model Marker", update=update_connected_geometry_marker_type_model_visible)
    connected_geometry_marker_type_effects_visible: bpy.props.BoolProperty(default=True, options=set(), name="Effects", update=update_connected_geometry_marker_type_effects_visible)
    connected_geometry_marker_type_garbage_visible: bpy.props.BoolProperty(default=True, options=set(), name="Garbage", update=update_connected_geometry_marker_type_garbage_visible)
    connected_geometry_marker_type_hint_visible: bpy.props.BoolProperty(default=True, options=set(), name="Hint", update=update_connected_geometry_marker_type_hint_visible)
    connected_geometry_marker_type_pathfinding_sphere_visible: bpy.props.BoolProperty(default=True, options=set(), name="Pathfinding Sphere", update=update_connected_geometry_marker_type_pathfinding_sphere_visible)
    connected_geometry_marker_type_physics_constraint_visible: bpy.props.BoolProperty(default=True, options=set(), name="Physics Constraint", update=update_connected_geometry_marker_type_physics_constraint_visible)
    connected_geometry_marker_type_target_visible: bpy.props.BoolProperty(default=True, options=set(), name="Target", update=update_connected_geometry_marker_type_target_visible)
    connected_geometry_marker_type_game_instance_visible: bpy.props.BoolProperty(default=True, options=set(), name="Game Object", update=update_connected_geometry_marker_type_game_instance_visible)
    connected_geometry_marker_type_airprobe_visible: bpy.props.BoolProperty(default=True, options=set(), name="Airpobe", update=update_connected_geometry_marker_type_airprobe_visible)
    connected_geometry_marker_type_envfx_visible: bpy.props.BoolProperty(default=True, options=set(), name="Environment Effect", update=update_connected_geometry_marker_type_envfx_visible)
    connected_geometry_marker_type_lightCone_visible: bpy.props.BoolProperty(default=True, options=set(), name="Lightcone", update=update_connected_geometry_marker_type_lightCone_visible)
    
    connected_geometry_object_type_frame_visible: bpy.props.BoolProperty(default=True, options=set(), name="Frame", update=update_connected_geometry_object_type_frame_visible)
    connected_geometry_object_type_light_visible: bpy.props.BoolProperty(default=True, options=set(), name="Light", update=update_connected_geometry_object_type_light_visible)

    sidecar_path: bpy.props.StringProperty()
    
    def get_asset_name(self):
        if not self.sidecar_path.strip(): return ""
        return Path(self.sidecar_path).parent.name

    asset_name: bpy.props.StringProperty(
        get=get_asset_name,
    )
    
    def get_asset_directory(self):
        if not self.sidecar_path.strip(): return ""
        return str(Path(self.sidecar_path).parent)
    
    asset_directory: bpy.props.StringProperty(
        get=get_asset_directory,
    )
    
    def get_is_valid_asset(self):
        if not bpy.data.filepath:
            return False
        project = utils.get_project(self.scene_project)
        return project and bool(self.sidecar_path.strip())
    
    is_valid_asset: bpy.props.BoolProperty(
        get=get_is_valid_asset,
    )
    
    particle_uses_custom_points: bpy.props.BoolProperty(
        name="Has Custom Emitter Shape",
        description="Generates a particle_emitter_custom_points tag for this particle model. This can be referenced in an effect tag as a custom emitter shape",
    )
    
    # Animation command stuff
    
    animation_cmd_object_type: bpy.props.EnumProperty(
        name="Object Type",
        options=set(),
        items=[
            ('player', "Player", ""),
            ('unit', "Unit", ""),
            ('scenery', "Scenery", ""),
        ]
    )
    
    animation_cmd_loop: bpy.props.BoolProperty(
        name="Loop Animation",
        options=set(),
    )
    
    def animation_cmd_path_clean_tag_path(self, context):
        self["animation_cmd_path"] = utils.clean_tag_path(self["animation_cmd_path"], "model_animation_graph").strip('"')
    
    animation_cmd_path: bpy.props.StringProperty(
        name="Animation Graph Path",
        description="Path to the animation graph to get animations from. If left empty, defaults to the expected animation graph from this asset",
        update=animation_cmd_path_clean_tag_path,
        options=set(),
    )
    
    animation_cmd_name: bpy.props.StringProperty(
        name="Animation Name",
    )
    
    animation_cmd_expression: bpy.props.StringProperty(
        name="Object Expression",
        description="A halo script expression which evaluates to the object you wish to animate. This might be the object name directly in the scenario or something like (player_get 2)",
    )

    sky_gen_settings_initialized: bpy.props.BoolProperty(options={'HIDDEN'})
    sky_gen_build_sky_from_map: bpy.props.EnumProperty(
        items=[
            ("NONE", "None", ""),
            ("WORLD", "Scene World Image", ""),
            ("FILE", "Image File", ""),
        ],
        default="NONE",
        options={'HIDDEN'},
    )
    sky_gen_input_sky_map_name: bpy.props.StringProperty(subtype="FILE_PATH", options={'HIDDEN'})
    sky_gen_generate_type: bpy.props.EnumProperty(
        items=[
            ("BOTH", "Skylights & Skydome", ""),
            ("SKYLIGHT", "Skylights Only", ""),
            ("SKYDOME", "Skydome Only", ""),
        ],
        default="BOTH",
        options={'HIDDEN'},
    )
    sky_gen_lit_objects_by_sky: bpy.props.BoolProperty(default=False, options={'HIDDEN'})
    sky_gen_generate_light_count: bpy.props.IntProperty(default=32, min=1, max=1024, options={'HIDDEN'})
    sky_gen_lattitude_slices: bpy.props.IntProperty(default=24, min=2, max=256, options={'HIDDEN'})
    sky_gen_longitude_slices: bpy.props.IntProperty(default=48, min=2, max=512, options={'HIDDEN'})
    sky_gen_horizontal_fov: bpy.props.FloatProperty(default=360.0, min=1.0, max=360.0, options={'HIDDEN'})
    sky_gen_vertical_fov: bpy.props.FloatProperty(default=180.0, min=1.0, max=180.0, options={'HIDDEN'})
    sky_gen_sun_theta: bpy.props.FloatProperty(default=45.0, min=-180.0, max=180.0, options={'HIDDEN'})
    sky_gen_sun_phi: bpy.props.FloatProperty(default=0.0, min=0.0, max=360.0, options={'HIDDEN'})
    sky_gen_turpidity: bpy.props.FloatProperty(default=3.0, min=2.0, max=6.0, options={'HIDDEN'})
    sky_gen_sky_type: bpy.props.EnumProperty(
        items=[
            ("PREETHAM", "Preetham", ""),
            ("CIE", "CIE", ""),
            ("CUSTOM", "Custom", ""),
        ],
        default="PREETHAM",
        options={'HIDDEN'},
    )
    sky_gen_cie_sky_number: bpy.props.IntProperty(default=12, min=0, max=14, options={'HIDDEN'})
    sky_gen_sky_intensity: bpy.props.FloatProperty(default=1.0, min=0.0, options={'HIDDEN'})
    sky_gen_sun_intensity: bpy.props.FloatProperty(default=1.0, min=0.0, options={'HIDDEN'})
    sky_gen_luminance_only: bpy.props.BoolProperty(default=False, options={'HIDDEN'})
    sky_gen_exposure: bpy.props.FloatProperty(default=1.0, min=0.0, options={'HIDDEN'})
    sky_gen_sun_cone_angle: bpy.props.FloatProperty(default=1.0, min=0.0, options={'HIDDEN'})
    sky_gen_custom_sun_color_override: bpy.props.BoolProperty(default=False, options={'HIDDEN'})
    sky_gen_sun_color: bpy.props.FloatVectorProperty(
        subtype="COLOR",
        default=(1.0, 0.95, 0.9),
        min=0.0,
        max=1.0,
        size=3,
        options={'HIDDEN'},
    )
    sky_gen_sky_dome_radius: bpy.props.FloatProperty(default=200.0, min=10.0, options={'HIDDEN'})
    sky_gen_zenith_color: bpy.props.FloatVectorProperty(
        subtype="COLOR",
        default=(0.22, 0.35, 1.0),
        min=0.0,
        max=1.0,
        size=3,
        options={'HIDDEN'},
    )
    sky_gen_haze_color: bpy.props.FloatVectorProperty(
        subtype="COLOR",
        default=(1.0, 0.65, 0.3),
        min=0.0,
        max=1.0,
        size=3,
        options={'HIDDEN'},
    )
    sky_gen_override_zenith_color: bpy.props.BoolProperty(default=False, options={'HIDDEN'})
    sky_gen_override_horizon_color: bpy.props.BoolProperty(default=False, options={'HIDDEN'})
    sky_gen_horizon_haze_height: bpy.props.FloatProperty(default=1.0, min=0.0, max=4.0, options={'HIDDEN'})
    sky_gen_sun_blur: bpy.props.FloatProperty(default=1.0, min=0.01, max=4.0, options={'HIDDEN'})
    
    sun_size: bpy.props.FloatProperty(
        name="Sun Size",
        default=1.0,
        min=0.0,
        options=set(),
    )
    
    sun_as_vmf_light: bpy.props.BoolProperty(
        name="Sun as VMF Light",
        description="When true, the sun acts like another skylight and will not provide pre-lightmapping ambient map lighting",
        options=set(),
    )
    
    sun_bounce_scale: bpy.props.FloatProperty(
        name="Sunlight Bounce Scale",
        default=1.0,
        min=0,
        options=set(),
    )
    
    skylight_bounce_scale: bpy.props.FloatProperty(
        name="Skylight Bounce Scale",
        default=1.0,
        min=0,
        options=set(),
    )
    
    show_water_direction: bpy.props.BoolProperty(options={'HIDDEN'})
    
    animation_overlay: bpy.props.BoolProperty(
        name="Overlay",
        description="This animation is meant to be an overlay"
    )
    
    animation_nodes: bpy.props.CollectionProperty(
        type=NWO_AnimationNodeData_ListItems,
    )

    active_animation_node_index: bpy.props.IntProperty(
        name="Index for Animation Node",
        default=0,
        min=0,
        options=set(),
    )
    
    animation_events: bpy.props.CollectionProperty(
        type=NWO_Animation_ListItems,
    )

    active_animation_event_index: bpy.props.IntProperty(
        name="Index for Animation Event",
        default=0,
        min=0,
        options=set(),
    )
    
    decorators_from_blender: bpy.props.BoolProperty(
        name="Decorators Authored From Blender",
        options=set(),
        description="On export the scenario decorators block will be overwritten and generated using the decorators present in Blender. Don't enable this if you intend to paint decorators in Sapien"
    )

    airprobes_from_blender: bpy.props.BoolProperty(
        name="Airprobes Authored From Blender",
        options=set(),
        description="On export the scenario airprobes block will be overwritten and generated using the airprobes present in Blender",
        default=False,
    )
    
    decorators_from_blender_child_scenario: bpy.props.StringProperty(
        name="Decorators Child Scenario",
        options=set(),
        description="The name (not path) of the child scenario to write decorators to. If empty, defaults to the main asset scenario"
    )
    
    frame_events_from_blender: bpy.props.BoolProperty(
        name="Frame Events Authored From Blender",
        options=set(),
        description="On export the frame event list will be cleared and rebuilt from Blender",
        default=True,
    )
    
    last_bsp_split_was_layer: bpy.props.BoolProperty(
        options={'HIDDEN'},
    )
