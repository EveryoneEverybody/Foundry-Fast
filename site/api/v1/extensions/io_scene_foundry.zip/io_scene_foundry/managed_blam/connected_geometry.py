"""Classes to help with importing geometry from tags"""

from enum import Enum
from math import radians
import math
from pathlib import Path
import re
import struct
import bmesh
import bpy
from mathutils import Matrix, Quaternion, Vector, bvhtree
import numpy as np

from ..constants import LIGHTMAP_ADDITIVE_TRANSPARENCY_COLOR, LIGHTMAP_ANALYTICAL_LIGHT_ABSORB, LIGHTMAP_CHART_GROUP_INDEX, LIGHTMAP_IGNORE_DEFAULT_RESOLUTION_SCALE, LIGHTMAP_LIGHTING_FROM_BOTH_SIDES, LIGHTMAP_NORMAL_LIGHT_ABSORD, LIGHTMAP_RESOLUTION_SCALE, LIGHTMAP_TRANSLUCENCY_TINT_COLOR, LIGHTMAP_TRANSPARENCY_OVERRIDE, WU_SCALAR

from ..tools.append_foundry_materials import add_special_materials

from ..tools.property_apply import apply_props_material

from .material import MaterialTag
from .shader import ShaderTag
from ..tools import materials as special_materials

from .. import utils
from . import import_transform
from .Tags import TagFieldBlock, TagFieldBlockElement
from mathutils.geometry import tessellate_polygon

mat_props_cache = {}

mesh_cache = {}
armature_cache = {}
raw_mesh_data_cache = {}

def clear_cache():
    global mesh_cache
    global armature_cache
    global raw_mesh_data_cache
    mesh_cache = {}
    armature_cache = {}
    raw_mesh_data_cache = {}

class PartType(Enum): # Thank you Halo 2!
    not_drawn = 0
    opaque_shadow_only = 1
    opaque_shadow_casting = 2
    opaque_non_shadowing = 3
    transparent = 4
    lightmap_only = 5

class BSPSeam:
    def __init__(self, element: TagFieldBlockElement):
        self.index = element.ElementIndex
        self.bsps = []
        self.origin = Vector()
                
    def update(self, element: TagFieldBlockElement, bsp):
        clusters = element.SelectField("Block:cluster mapping")
        for cluster_element in clusters.Elements:
            if cluster_element.Fields[0].Data > -1:
                if not self.bsps:
                    self.origin = Vector((p for p in cluster_element.Fields[1].Data))
                self.bsps.append(bsp)
                break

class PortalType(Enum):
    _connected_geometry_portal_type_no_way = 0
    _connected_geometry_portal_type_one_way = 1
    _connected_geometry_portal_type_two_way = 2

class Portal:
    def __init__(self, element: TagFieldBlockElement):
        self.index = element.ElementIndex
        self.type = PortalType._connected_geometry_portal_type_two_way
        flags = element.SelectField("flags")
        if flags.TestBit("one-way") or flags.TestBit("one-way-reversed"):
            self.type = PortalType._connected_geometry_portal_type_one_way
        elif flags.TestBit("no-way"):
            self.type = PortalType._connected_geometry_portal_type_no_way
            
        self.ai_deafening = flags.TestBit("ai can't hear through this shit")
        self.blocks_sounds = flags.TestBit("no one can hear through this")
        self.is_door = flags.TestBit("door")
            
        vertices_block = element.SelectField("Block:vertices")
        self.vertices = []
        for e in vertices_block.Elements:
            self.vertices.append(Vector(n for n in e.Fields[0].Data) * 100)
            
    def create(self) -> bpy.types.Object:
        mesh = bpy.data.meshes.new(f"portal:{self.index}")
        mesh.from_pydata(vertices=self.vertices, edges=[], faces=[list(range(len(self.vertices)))])
        mesh.transform(import_transform.mesh_matrix())
        mesh.nwo.mesh_type = "_connected_geometry_mesh_type_portal"
        ob = bpy.data.objects.new(mesh.name, mesh)
        ob.matrix_world = import_transform.rotation_matrix()
        apply_props_material(ob, "Portal")
        nwo = ob.nwo
        
        nwo.portal_ai_deafening = self.ai_deafening
        nwo.portal_blocks_sounds = self.blocks_sounds
        nwo.portal_is_door = self.is_door
        
        return ob
    
class BSPMarkerType(Enum):
    none = 0
    cheap_light = 1
    falling_leaf_generator = 2
    light = 3
    sky = 4
    model = 5
    
class PathfindingPolicy(Enum):
    cutout = 0
    static = 1
    none = 2
    
class LightmappingPolicy(Enum):
    per_pixel = 0
    per_vertex = 1
    single_probe = 2
    _connected_geometry_poop_lighting_exclude = 3
    per_pixel_ao = 4
    per_vertex_ao = 5
    
class ImposterPolicy(Enum):
    polygon_default = 0
    polygon_high = 1
    card_default = 2
    card_high = 3
    _connected_poop_instance_imposter_policy_none = 4
    never = 5

class CinemaType(Enum):
    _connected_geometry_poop_cinema_default = 0
    _connected_geometry_poop_cinema_only = 1
    _connected_geometry_poop_cinema_exclude = 2
    
class StreamingPriority(Enum):
    _connected_geometry_poop_streamingpriority_default = 0
    _connected_geometry_poop_streamingpriority_higher = 1
    _connected_geometry_poop_streamingpriority_highest = 2
    
class Cluster:
    def __init__(self, element: TagFieldBlockElement, mesh_block: TagFieldBlock, render_materials: list['Material']):
        self.index = element.ElementIndex
        self.mesh_index = element.SelectField("mesh index").Data
        self.mesh = Mesh(mesh_block.Elements[self.mesh_index], materials=render_materials)
        # self.sky_index = -1
        # sky_index_field = element.SelectField("CharInteger:scenario sky index")
        # if sky_index_field is not None:
        #     self.sky_index = sky_index_field.Data
        
    def create(self, render_model, temp_meshes, cluster_surface_triangle_mapping=[], section_index=0, collision_info: 'BSP | None' = None) -> bpy.types.Object:
        return self.mesh.create(render_model, temp_meshes, name=f"cluster:{self.index}", surface_triangle_mapping=cluster_surface_triangle_mapping, section_index=section_index, collision_info=collision_info)
        
class TriangleMapping:
    def __init__(self, value: int):
        self.tri = int(((value >> 12) + 1) / 3 - 1)
        self.section = value & 0xFFF
        # print(self.tri, self.section)

class DirectTriangleMapping:
    def __init__(self, tri: int, section: int):
        self.tri = tri
        self.section = section
        
class SurfaceMapping:
    def __init__(self, first: int, count: int, surface: 'CollisionSurface', surf_to_tri_block: TagFieldBlock):
        self.surface = surface
        self.triangle_indices: list[TriangleMapping] = []
        self.collision_only = False
        if count:
            for i in range(first, first + count):
                value = surf_to_tri_block.Elements[i].Fields[0].Data
                mapping = TriangleMapping(value)
                self.triangle_indices.append(mapping)
        else:
            self.collision_only = True

    @classmethod
    def from_render_triangles(cls, surface, triangle_indices: list[DirectTriangleMapping]):
        mapping = cls.__new__(cls)
        mapping.surface = surface
        mapping.triangle_indices = triangle_indices
        mapping.collision_only = False
        return mapping

class HavokCollisionSurface:
    def __init__(self, index: int, material, collision_type: str):
        self.index = index
        self.material = material
        self.collision_type = collision_type
        self.ladder = False
        self.breakable = False
        self.slip_surface = False
        self.invisible = False
        self.two_sided = False
        self.negated = False
        self.invalid = False
            
class InstanceDefinition:
    def __init__(self, element: TagFieldBlockElement, mesh_block: TagFieldBlock, compression_bounds: list['CompressionBounds'], render_materials: list['Material'], collision_materials: list['BSPCollisionMaterial'], for_cinematic = False):
        self.index = element.ElementIndex
        self.mesh_index = element.SelectField("mesh index").Data
        self.compression_index = element.SelectField("compression index").Data
        self.compression = compression_bounds[self.compression_index]
        self.mesh = Mesh(mesh_block.Elements[self.mesh_index], self.compression, materials=render_materials)
        self.has_collision = False
        self.collision_is_proxy = False
        self.surface_triangle_mapping = []
        self.collision_info = None
        self.collision_only_surface_indices = []
        self.has_cookie = False
        self.cookie_info = None
        self.blender_collision = None
        self.blender_cookie = None
        self.has_physics = False
        self.blender_physics = []
        self.blender_render = None
        if not utils.is_corinth() and not for_cinematic:
            self.has_collision = element.SelectField("Struct:collision info[0]/Block:surfaces").Elements.Count > 0
            self.collision_is_proxy = self.has_collision and (element.SelectField("Block:surfaces").Elements.Count == 0 or element.SelectField("Block:render bsp").Elements.Count > 0)
            if self.has_collision:
                self.collision_info = InstanceCollision(element.SelectField("Struct:collision info").Elements[0], f"instance_collision:{self.index}", collision_materials)
                if not self.collision_is_proxy:
                    surf_to_tri_block = element.SelectField("Block:surface to triangle mapping")
                    self.surface_triangle_mapping = [SurfaceMapping(e.Fields[0].Data, e.Fields[1].Data, self.collision_info.surfaces[e.ElementIndex], surf_to_tri_block) for e in element.SelectField("Block:surfaces").Elements]
                    self.collision_only_surface_indices = [idx for idx, mapping in enumerate(self.surface_triangle_mapping) if mapping.collision_only]
            self.has_cookie = element.SelectField("Struct:poopie cutter collision[0]/Block:surfaces").Elements.Count > 0
            if self.has_cookie:
                self.cookie_info = InstanceCollision(element.SelectField("Struct:poopie cutter collision").Elements[0], f"instance_cookie_cutter:{self.index}", collision_materials)
            
            self.has_physics = element.SelectField("Block:polyhedra_with_materials").Elements.Count > 0
            if self.has_physics:
                self.physics_info = InstancePhysics(element, f"instance_physics:{self.index}", collision_materials)
    
    def create(self, render_model, temp_meshes) -> list[bpy.types.Object]:
        objects = []
        
        collision_info = self.collision_info if self.has_collision and not self.collision_is_proxy else None
        result = self.mesh.create(render_model, temp_meshes, name=f"instance_definition:{self.index}", surface_triangle_mapping=self.surface_triangle_mapping, collision_info=collision_info)
        self.blender_render = None
        if result:
            self.blender_render = result[0]
            if self.surface_triangle_mapping:
                self.collision_only_surface_indices = [idx for idx, mapping in enumerate(self.surface_triangle_mapping) if mapping.collision_only]
            
        render_valid = self.blender_render and self.blender_render.type == 'MESH'
        merged_collision = False
            
        if not utils.is_corinth():
            if self.has_collision:
                if render_valid:
                    if self.collision_is_proxy:
                        self.blender_collision = self.collision_info.to_object()
                        if self.blender_render and self.blender_render.type == 'MESH':
                            self.blender_collision.name = f"{self.blender_render.name}_proxy_collision"
                            # self.blender_collision.nwo.proxy_parent = self.blender_render.data
                            self.blender_collision.nwo.proxy_type = "collision"
                            self.blender_render.data.nwo.proxy_collision = self.blender_collision
                    elif self.collision_only_surface_indices:
                        collision_mesh = self.collision_info.to_object(mesh_only=True, surface_indices=self.collision_only_surface_indices)
                        self.mesh.remove_render_duplicate_faces(collision_mesh, self.blender_render.data)
                        merged_collision = len(collision_mesh.polygons) > 0

                        if merged_collision:
                            mat_to_idx = {m: i for i, m in enumerate(collision_mesh.materials)}
                            for mat in self.blender_render.data.materials:
                                if mat not in mat_to_idx:
                                    mat_to_idx[mat] = len(collision_mesh.materials)
                                    collision_mesh.materials.append(mat)

                            idx_map = np.asarray([mat_to_idx[m] for m in self.blender_render.data.materials])
                            material_indices = np.empty(len(self.blender_render.data.polygons), dtype=np.int32)
                            self.blender_render.data.polygons.foreach_get("material_index", material_indices)
                            remap = idx_map[material_indices]

                            self.blender_render.data.materials.clear()
                            for mat in collision_mesh.materials:
                                self.blender_render.data.materials.append(mat)

                            self.blender_render.data.polygons.foreach_set("material_index", remap)

                            if self.collision_info.some_sphere_collision:
                                sphere_coll_face_props = [prop for prop in collision_mesh.nwo.face_props if prop.name == "Sphere Collision Only"]
                                if sphere_coll_face_props:
                                    sphere_coll_face_prop = sphere_coll_face_props[0]
                                    sphere_coll_attribute = collision_mesh.attributes.get(sphere_coll_face_prop.attribute_name)
                                    array = np.zeros(len(collision_mesh.polygons), dtype=np.int8)
                                    sphere_coll_attribute.data.foreach_get("value", array)
                                    coll_only_array = array ^ 1
                                    utils.add_face_prop(collision_mesh, "face_mode", coll_only_array).face_mode = 'collision_only'
                                else:
                                    utils.add_face_prop(collision_mesh, "face_mode").face_mode = 'sphere_collision_only'

                            elif not self.collision_info.sphere_collision_only:
                                utils.add_face_prop(collision_mesh, "face_mode").face_mode = 'collision_only'

                            utils.save_loop_normals_mesh(self.blender_render.data)
                            bm = bmesh.new()
                            bm.from_mesh(self.blender_render.data)
                            bm.from_mesh(collision_mesh)
                            bm.to_mesh(self.blender_render.data)
                            bm.free()

                            utils.apply_loop_normals(self.blender_render.data)
                            utils.set_two_sided(self.blender_render.data, False)

                            for prop in collision_mesh.nwo.face_props:
                                new_prop = self.blender_render.data.nwo.face_props.add()
                                for k, v in prop.items():
                                    new_prop[k] = v
                        else:
                            bpy.data.meshes.remove(collision_mesh)
                else:
                    self.blender_render = self.collision_info.to_object()
                    self.blender_render.name = f"instance_definition:{self.index}"
                    if self.collision_info.sphere_collision_only:
                        utils.add_face_prop(self.blender_render.data, "face_mode").face_mode = 'sphere_collision_only'
                    else:
                        utils.add_face_prop(self.blender_render.data, "face_mode").face_mode = 'collision_only'
                    render_valid = True
                    
            elif self.blender_render and self.blender_render.data:
                utils.add_face_prop(self.blender_render.data, "face_mode").face_mode = 'render_only'
                
            if self.has_physics:
                for idx, polyhedra in enumerate(self.physics_info.polyhedra):
                    phys = polyhedra.to_object()
                    phys.data.materials.append(polyhedra.material.blender_material)
                    if self.blender_render and self.blender_render.type == 'MESH':
                        phys.name = f"{self.blender_render.name}_proxy_physics{idx}"
                        # phys.nwo.proxy_parent = self.blender_render.data
                        phys.nwo.proxy_type = "physics"
                        setattr(self.blender_render.data.nwo, f"proxy_physics{idx}", phys)
                        
                    elif self.blender_collision and (utils.test_face_prop_all(self.blender_collision.data, "Collision Only") or utils.test_face_prop_all(self.blender_collision.data, "Sphere Collision Only")):
                        phys.name = f"{self.blender_collision.name}_proxy_physics{idx}"
                        # phys.nwo.proxy_parent = self.blender_collision.data
                        phys.nwo.proxy_type = "physics"
                        setattr(self.blender_collision.data.nwo, f"proxy_physics{idx}", phys)
                    else:
                        utils.print_warning("Found physics but no render or collision!!!")
                    self.blender_physics.append(phys)
                    
            if self.has_cookie:
                self.blender_cookie = self.cookie_info.to_object()
                self.blender_cookie.name = f"{self.blender_render.name}_proxy_cookie_cutter"
                # self.blender_cookie.nwo.proxy_parent = self.blender_render.data
                self.blender_cookie.nwo.proxy_type = "cookie_cutter"
                self.blender_render.data.nwo.proxy_cookie_cutter = self.blender_cookie

        if self.blender_render:
            objects.append(self.blender_render)
        if self.blender_collision:
            utils.connect_verts_on_edge(self.blender_collision.data)
            objects.append(self.blender_collision)
        if self.blender_cookie:
            objects.append(self.blender_cookie)
        if self.blender_physics:
            objects.extend(self.blender_physics)
            
        return objects
            
    
class Instance:
    def __init__(self, element: TagFieldBlockElement, definitions: list[InstanceDefinition]):
        self.index = element.ElementIndex
        self.mesh_index = element.SelectField("ShortInteger:mesh_index").Data
        self.definition = definitions[self.mesh_index]
        self.scale = element.SelectField("scale").Data
        forward = element.SelectField("forward").Data
        left = element.SelectField("left").Data
        up = element.SelectField("up").Data
        position = element.SelectField("position").Data
        
        self.matrix = Matrix((
            (forward[0], left[0], up[0], position[0] * 100),
            (forward[1], left[1], up[1], position[1] * 100),
            (forward[2], left[2], up[2], position[2] * 100),
            (0, 0, 0, 1),
        ))
        
        flags = element.SelectField("flags")
        self.not_in_lightprobes = flags.TestBit("not in lightprobes")
        self.render_only = flags.TestBit("render only")
        self.not_block_aoe = flags.TestBit("does not block aoe damage")
        self.decal = flags.TestBit("decal spacing")
                
        self.imposter_transition = element.SelectField("imposter transition complete distance").Data
        
        self.pathfinding = PathfindingPolicy(element.SelectField("pathfinding policy").Value)
        self.lightmapping = LightmappingPolicy(element.SelectField("lightmapping policy").Value)
        self.imposter = ImposterPolicy(element.SelectField("imposter policy").Value)
        
        self.lightmap_res = element.SelectField("lightmap resolution scale").Data
        
        self.name = element.SelectField("name").Data
        
        self.remove_from_shadow = False
        self.cinema_type = CinemaType._connected_geometry_poop_cinema_default
        self.imposter_brightness = 0
        self.disallow_lighting_samples = False
        self.streaming = StreamingPriority._connected_geometry_poop_streamingpriority_default
        if utils.is_corinth():
            self.imposter_brightness = element.SelectField("imposter brightness").Data
            self.streaming = StreamingPriority(element.SelectField("streaming priority").Value)
            self.remove_from_shadow = flags.TestBit("remove from shadow geometry")
            self.disallow_lighting_samples = flags.TestBit("disallow object lighting samples")
            if flags.TestBit("cinema only"):
                self.cinema_type = CinemaType._connected_geometry_poop_cinema_only
            elif flags.TestBit("exclude from cinema"):
                self.cinema_type = CinemaType._connected_geometry_poop_cinema_exclude
                
        self.world_bound_sphere_radius = element.SelectField("Real:world bounding sphere radius").Data
        
        
    def create(self) -> list[bpy.types.Object]:
        if (not self.definition.blender_render or self.definition.blender_render.type == 'EMPTY') and self.definition.blender_collision:
            ob = self.definition.blender_collision.copy()
        else:
            ob = self.definition.blender_render.copy()
        ob.name = utils.any_partition(self.name, "__(")
        ob.matrix_world = import_transform.object_matrix(self.matrix)
        ob.scale = Vector.Fill(3, self.scale)
        nwo = ob.nwo
        nwo.poop_excluded_from_lightprobe = self.not_in_lightprobes
        nwo.poop_render_only = self.render_only
        nwo.poop_does_not_block_aoe = self.not_block_aoe
        nwo.poop_decal_spacing = self.decal
        nwo.poop_remove_from_shadow_geometry = self.remove_from_shadow
        nwo.poop_disallow_lighting_samples = self.disallow_lighting_samples
        nwo.poop_cinematic_properties = self.cinema_type.name
        if self.lightmapping.value > 2:
            if self.lightmapping == LightmappingPolicy.per_pixel_ao:
                nwo.poop_ao = True
                nwo.poop_lighting = "per_pixel"
            elif self.lightmapping == LightmappingPolicy.per_vertex_ao:
                nwo.poop_ao = True
                nwo.poop_lighting = "per_vertex"
        else:
            nwo.poop_lighting = self.lightmapping.name
            
        nwo.poop_pathfinding = self.pathfinding.name
        if self.imposter == ImposterPolicy._connected_poop_instance_imposter_policy_none:
            nwo.poop_imposter_policy = "never"
        else:
            nwo.poop_imposter_policy = self.imposter.name
        nwo.poop_streaming_priority = self.streaming.name
        nwo.poop_imposter_brightness = self.imposter_brightness
        nwo.poop_imposter_transition_distance = self.imposter_transition * (1 / WU_SCALAR)
        nwo.poop_imposter_transition_distance_auto = self.imposter_transition <= 0
        nwo.poop_lightmap_resolution_scale = self.lightmap_res
        
        # Check that object origin is not too far away from instance
        # This can cause the plane builder to fail
        if False and self.world_bound_sphere_radius > 500:
            ob.data = ob.data.copy() # so we don't break any other instances
            utils.set_origin_to_centre(ob)
            # utils.set_origin_to_floor(ob)
        
        
        return ob

    @staticmethod
    def build_collection_lookup():
        lookup = {"exact": {}, "base": {}}
        for collection in bpy.data.collections:
            lookup["exact"][collection.name] = collection
            lookup["base"].setdefault(collection.name.rsplit(".", 1)[0], collection)

        return lookup

    @staticmethod
    def _remember_collection(collection_lookup, collection):
        if collection_lookup is None:
            return

        collection_lookup.setdefault("exact", {})[collection.name] = collection
        collection_lookup.setdefault("base", {}).setdefault(collection.name.rsplit(".", 1)[0], collection)

    def get_collection(self, ig_collection, permitted_collections, bsp_name: str, collection_lookup=None) -> bpy.types.Collection:
        def base_name(name: str) -> str:
            base, _, suffix = name.rpartition(".")
            return base if suffix.isdigit() else name

        def find_child_collection(parent_collection: bpy.types.Collection, name: str) -> bpy.types.Collection | None:
            base = base_name(name)
            for collection in parent_collection.children:
                if collection.name == name or base_name(collection.name) == base:
                    return collection
            return None

        def new_child_collection(parent_collection: bpy.types.Collection, name: str) -> bpy.types.Collection:
            collection = bpy.data.collections.new(name=name)
            parent_collection.children.link(collection)
            permitted_collections.add(collection)
            self._remember_collection(collection_lookup, collection)
            return collection

        if "(" in self.name and ")" in self.name.rpartition("(")[2]:
            collection_part = re.findall(r'\((.*?)\)', self.name)[0]
            if ":" in collection_part:
                sub_collection_name, _, main_collection_name_main = collection_part.rpartition(":")
                main_collection_name_main = main_collection_name_main.strip("_")
                sub_collection_name = sub_collection_name.strip("_")
            else:
                sub_collection_name = None
                main_collection_name_main = collection_part

            main_collection_name = main_collection_name_main
            if main_collection_name == bsp_name:
                main_collection_name = f"layer_{main_collection_name}"

            main_collection = find_child_collection(ig_collection, main_collection_name)
            if main_collection is None:
                main_collection = new_child_collection(ig_collection, main_collection_name)
                utils.add_permutation(main_collection_name_main, utils.SetType.SCENARIO)
                main_collection.nwo.type = 'permutation'
                main_collection.nwo.permutation = main_collection_name_main

            if sub_collection_name is not None:
                if sub_collection_name == bsp_name:
                    sub_collection_name = f"sublayer_{main_collection_name}"

                sub_collection = find_child_collection(main_collection, sub_collection_name)
                if sub_collection is None:
                    sub_collection = new_child_collection(main_collection, sub_collection_name)

                return sub_collection
            else:
                return main_collection

        return ig_collection

class StructureMarker:
    def __init__(self, element: TagFieldBlockElement):
        self.name = element.SelectField("String:marker parameter").GetStringData()
        self.rotation: Quaternion = utils.ijkw_to_wxyz([n for n in element.SelectField("rotation").Data])
        self.position: Vector = ([n * 100 for n in element.SelectField("position").Data])
        
    def to_object(self):
        ob = bpy.data.objects.new(name=self.name, object_data=None)
        ob.empty_display_type = "ARROWS"
        ob.empty_display_size *= (1 / 0.03048) * import_transform.scale_factor()
        ob.matrix_world = import_transform.marker_matrix(Matrix.LocRotScale(self.position, self.rotation, Vector.Fill(3, 1)))
        return ob
        
class EnvironmentObjectReference:
    def __init__(self, element: TagFieldBlockElement):
        self.definition = None
        def_path = element.Fields[0].Path
        if def_path is not None:
            if Path(def_path.Filename).exists():
                self.definition = def_path.RelativePathWithExtension
    
class EnvironmentObject:
    def __init__(self, element: TagFieldBlockElement, palette: list[EnvironmentObjectReference]):
        self.name = element.SelectField("name").GetStringData()
        self.rotation: Quaternion = utils.ijkw_to_wxyz([n for n in element.SelectField("rotation").Data])
        self.translation: Vector = ([n * 100 for n in element.SelectField("translation").Data])
        self.scale = element.SelectField("scale").Data
        palette_index = element.SelectField("ShortBlockIndex:palette_index").Value
        self.reference = palette[palette_index] if palette_index > -1  and palette_index < len(palette) else None
        self.variant = element.SelectField("StringId:variant name").GetStringData()
        
    def to_object(self):
        if self.reference is None or self.reference.definition is None:
            return utils.print_warning(f"Found environment object named {self.name} but it has no valid tag reference")
            
        ob = bpy.data.objects.new(name=self.name, object_data=None)
        ob.empty_display_type = "ARROWS"
        ob.matrix_world = import_transform.marker_matrix(Matrix.LocRotScale(self.translation, self.rotation, Vector.Fill(3, self.scale)))
        
        ob.nwo.marker_type = '_connected_geometry_marker_type_game_instance'
        ob.nwo.marker_game_instance_tag_name = self.reference.definition
        ob.nwo.marker_game_instance_tag_variant_name = self.variant
        
        return ob
         
#     index: int
#     palette_index: int
#     palette: EnvironmentObjectPalette
#     name: str
#     rotation: Quaternion
#     translation: Vector
#     scale: float
#     variant: str

class Face:
    def __init__(self,indices: list[int], subpart: 'MeshSubpart', index: int):
        self.indices = indices
        self.subpart = subpart
        self.index = index

class Node:
    def __init__(self, name):
        self.name = name
        self.parent = None
        self.parent_name = None
        self.index = -1
        self.translation: Vector = None
        self.rotation: Quaternion = None
        self.inverse_forward: Vector = None
        self.inverse_left: Vector = None
        self.inverse_up: Vector = None
        self.inverse_position: Vector = None
        self.inverse_scale: float = 1
        self.bone = None

class Permutation: 
    def __init__(self, element: TagFieldBlockElement, region: 'Region'):
        self.region = region
        self.index = element.ElementIndex
        self.name = element.SelectField("name").GetStringData()
        self.mesh_index = element.SelectField("mesh index").Data
        self.mesh_count = element.SelectField("mesh count").Data
        self.clone_name = ""
        self.instance_indices = []
        if utils.is_corinth():
            self.clone_name = element.SelectField("clone name").GetStringData()
        flags_1 = element.SelectField("instance mask 0-31")
        for i in range(32):
            if flags_1.TestBit(str(i)):
                self.instance_indices.append(i)
        flags_2 = element.SelectField("instance mask 32-63")
        for i in range(32):
            if flags_2.TestBit(str(i)):
                self.instance_indices.append(i + 32)
        flags_3 = element.SelectField("instance mask 64-95")
        for i in range(32):
            if flags_3.TestBit(str(i)):
                self.instance_indices.append(i + 64)
        flags_4 = element.SelectField("instance mask 96-127")
        for i in range(32):
            if flags_4.TestBit(str(i)):
                self.instance_indices.append(i + 96)
    
class Region:
    def __init__(self, element: TagFieldBlockElement):
        self.index = element.ElementIndex
        self.name = element.SelectField("name").GetStringData()
        self.permutations_block = element.SelectField("permutations")
        self.permutations = []
        for element in self.permutations_block.Elements:
            self.permutations.append(Permutation(element, self))

class RenderArmature():
    def __init__(self, name, existing_armature=None, tag_path=None):
        if existing_armature is None:
            data = None
            if tag_path is not None:
                data = armature_cache.get(tag_path)
                if data is not None and data in frozenset(bpy.data.armatures):
                    self.data = data
                else:
                    self.data = bpy.data.armatures.new(name)
            else:
                self.data = bpy.data.armatures.new(name)
                
            self.ob = bpy.data.objects.new(name, self.data)
        else:
            self.ob = existing_armature
            self.data = existing_armature.data
        self.bones: Node = []
        
    def create_bone(self, node: Node):
        bone = self.data.edit_bones.new(node.name)
        bone.length = 5 * import_transform.scale_factor()
        
        loc = (node.inverse_position)
        rot = Matrix((node.inverse_forward, node.inverse_left, node.inverse_up))
        scale = Vector.Fill(3, node.inverse_scale)
        transform_matrix = Matrix.LocRotScale(loc, rot, scale)
        
        try:
            transform_matrix.invert()
        except:
            transform_matrix.identity()
        
        transform_matrix = Matrix.Translation(node.translation) @ node.rotation.to_matrix().to_4x4()
        transform_matrix = import_transform.armature_bone_matrix(transform_matrix, root=node.parent is None)
        node.transform_matrix = transform_matrix
        bone.matrix = transform_matrix
        node.bone = bone
        
    def parent_bone(self, node: Node):
        if node.parent:
            parent = node.parent.bone
            node.bone.parent = parent
            transform_matrix = parent.matrix @ node.transform_matrix
            node.bone.matrix = transform_matrix
            
class ConstraintType(Enum):
    hinge = 0
    limited_hinge = 1
    ragdoll = 2
    stiff_spring = 3
    ball_and_socket = 4
    prismatic = 5
    powered_chain = 6
    
class Constraint:
    def __init__(self, element: TagFieldBlockElement, nodes: list[str]):
        self.constraint_body = element.SelectField("Struct:constraint bodies").Elements[0]
        self.index = element.ElementIndex
        self.name = self.constraint_body.Fields[0].Data
        self.node_a_index = self.constraint_body.Fields[1].Value
        self.node_b_index = self.constraint_body.Fields[2].Value
        self.bone_parent = nodes[self.node_a_index]
        self.bone_child = nodes[self.node_b_index]
        
        afi, afj, afk = self.constraint_body.SelectField("a forward").Data
        ali, alj, alk = self.constraint_body.SelectField("a left").Data
        aui, auj, auk = self.constraint_body.SelectField("a up").Data
        api, apj, apk = self.constraint_body.SelectField("a position").Data
        
        bfi, bfj, bfk = self.constraint_body.SelectField("b forward").Data
        bli, blj, blk = self.constraint_body.SelectField("b left").Data
        bui, buj, buk = self.constraint_body.SelectField("b up").Data
        bpi, bpj, bpk = self.constraint_body.SelectField("b position").Data
        
        # self.matrix_a = Matrix((
        #     (afi, afj, afk, 0.0),
        #     (ali, alj, alk, 0.0),
        #     (aui, auj, auk, 0.0),
        #     (api, apj, apk, 1.0),
        # ))
        # self.matrix_b = Matrix((
        #     (bfi, bfj, bfk, 0.0),
        #     (bli, blj, blk, 0.0),
        #     (bui, buj, buk, 0.0),
        #     (bpi, bpj, bpk, 1.0),
        # ))
        
        self.matrix_a = Matrix((
            (afi, ali, aui, api * 100),
            (afj, alj, auj, apj * 100),
            (afk, alk, auk, apk * 100),
            (0, 0, 0, 1),
        ))
        
        self.matrix_b = Matrix((
            (bfi, bli, bui, bpi * 100),
            (bfj, blj, buj, bpj * 100),
            (bfk, blk, buk, apk * 100),
            (0, 0, 0, 1),
        ))
        
    def to_object(self, armature) -> bpy.types.Object:
        ob = bpy.data.objects.new(self.name, None)
        ob.empty_display_type = 'ARROWS'
        nwo = ob.nwo
        nwo.marker_type = "_connected_geometry_marker_type_physics_constraint"
        nwo.physics_constraint_parent = armature
        nwo.physics_constraint_parent_bone = self.bone_parent
        nwo.physics_constraint_child = armature
        nwo.physics_constraint_child_bone = self.bone_child
        self._set_constraint_props(nwo)
        
        return ob
    
    def _set_constraint_props(self, nwo):
        nwo.physics_constraint_type = "_connected_geometry_marker_type_physics_hinge_constraint"
    
    
class LimitedHinge(Constraint):
    def __init__(self, element: TagFieldBlockElement, nodes: list[str]):
        super().__init__(element, nodes)
        self.limit_min_angle = element.SelectField("limit min angle").Data
        self.limit_max_angle = element.SelectField("limit max angle").Data
        
    def _set_constraint_props(self, nwo):
        nwo.physics_constraint_type = "_connected_geometry_marker_type_physics_hinge_constraint"
        nwo.physics_constraint_uses_limits = True
        nwo.hinge_constraint_minimum = radians(self.limit_min_angle)
        nwo.hinge_constraint_maximum = radians(self.limit_max_angle)

class Ragdoll(Constraint):
    def __init__(self, element: TagFieldBlockElement, nodes: list[str]):
        super().__init__(element, nodes)
        self.min_twist = element.SelectField("min twist").Data
        self.max_twist = element.SelectField("max twist").Data
        self.cone = element.SelectField("max cone").Data
        self.min_plane = element.SelectField("min plane").Data
        self.max_plane = element.SelectField("max plane").Data
            
    def _set_constraint_props(self, nwo):
        nwo.physics_constraint_type = "_connected_geometry_marker_type_physics_socket_constraint"
        nwo.havok_constraint_type = 'hkNodeRagDollConstraint'
        nwo.physics_constraint_uses_limits = True
        nwo.cone_angle = radians(self.cone)
        nwo.plane_constraint_minimum = radians(self.min_plane)
        nwo.plane_constraint_maximum = radians(self.max_plane)
        nwo.twist_constraint_start = radians(self.min_twist)
        nwo.twist_constraint_end = radians(self.max_twist)
        
class StiffSpring(Constraint):
    def __init__(self, element: TagFieldBlockElement, nodes: list[str]):
        super().__init__(element, nodes)
        self.spring_length = element.SelectField("Real:spring_length").Data
        
    def _set_constraint_props(self, nwo):
        nwo.rigid_body_type = 'HAVOK'
        nwo.havok_constraint_type = "hkNodeStiffSpringConstraint"
        nwo.point_rest_length = self.spring_length
        
class BallAndSocket(Constraint):
    def __init__(self, element: TagFieldBlockElement, nodes: list[str]):
        super().__init__(element, nodes)
        
    def _set_constraint_props(self, nwo):
        nwo.rigid_body_type = 'HAVOK'
        nwo.havok_constraint_type = "hkNodeBallAndSocketConstraint"
        
class Prismatic(Constraint):
    def __init__(self, element: TagFieldBlockElement, nodes: list[str]):
        super().__init__(element, nodes)
        self.min_limit = element.SelectField("Real:min_limit").Data
        self.max_limit = element.SelectField("Real:min_limit").Data
        self.max_friction_force = element.SelectField("Real:max_friction_force").Data
        
    def _set_constraint_props(self, nwo):
        nwo.rigid_body_type = 'HAVOK'
        nwo.havok_constraint_type = "hkNodePrismaticConstraint"
        nwo.prismatic_change_min = self.min_limit != 0.0
        nwo.prismatic_change_max = self.max_limit != 0.0
        nwo.prismatic_limit_min = self.min_limit
        nwo.prismatic_limit_max = self.max_limit
        nwo.prismatic_limit_friction = self.max_friction_force
            
class Constraint:
    def to_object(self) -> bpy.types.Object:
        pass
    
class ShapeType(Enum):
    sphere = 0
    pill = 1
    box = 2
    triangle = 3
    polyhedron = 4
    multi_sphere = 5
    unused_0 = 6
    unused_1 = 7
    unused_2 = 8
    unused_3 = 9
    unused_4 = 10
    unused_5 = 11
    unused_6 = 12
    unused_7 = 13
    _list = 14
    mopp = 15
    
class Shape:
    def __init__(self, element: TagFieldBlockElement, materials: list[str], for_bsp=False):
        self.friction = 0
        self.restitution = 0
        if for_bsp:
            self.name = "instance_physics"
            self.material_index = element.SelectField("LongInteger:material index").Data
            self.material = materials[self.material_index]
        else:
            base = element.SelectField("Struct:base").Elements[0]
            self.name = base.SelectField("name").Data
            self.material_index = base.SelectField("material").Value
            self.material = materials[self.material_index]
            
            self.friction = element.SelectField("Struct:base[0]/RealFraction:friction").Data
            self.restitution = element.SelectField("Struct:base[0]/RealFraction:restitution").Data
    
class Sphere(Shape):
    def __init__(self, element: TagFieldBlockElement, materials):
        super().__init__(element, materials)
        self.radius = element.SelectField("Struct:translate shape[0]/Struct:convex[0]/Real:radius").Data * 100
        self.translation = Vector([n for n in element.SelectField("Struct:translate shape[0]/RealVector3d:translation").Data]) * 100
        self.matrix = Matrix.Translation(self.translation)
        
    def to_object(self) -> bpy.types.Object:
        mesh = bpy.data.meshes.new(self.name)
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.create_uvsphere(bm, u_segments=32, v_segments=16, radius=self.radius)
        bm.to_mesh(mesh)
        bm.free()
        mesh.transform(import_transform.mesh_matrix())
        self.ob = bpy.data.objects.new(self.name, mesh)
        self.ob.matrix_world = import_transform.rotation_matrix()
        self.ob.nwo.mesh_primitive_type = "_connected_geometry_primitive_type_sphere"

class Pill(Shape):
    def __init__(self, element: TagFieldBlockElement, materials):
        super().__init__(element, materials)
        radius = element.SelectField("Struct:capsule shape[0]/Real:radius").Data
        bottom = Vector([n for n in element.SelectField("bottom").Data])
        top = Vector([n for n in element.SelectField("top").Data])
        self.radius = radius * 100
        self.bottom = bottom * 100
        self.top = top * 100
        difference_vector = top - bottom
        self.rotation = difference_vector.normalized().to_track_quat('Z', 'X')
        height = difference_vector.length * 100
        inverse = (self.bottom - self.top).normalized() * self.radius
        self.translation = self.bottom + inverse
        self.matrix = Matrix.LocRotScale(self.translation, self.rotation, Vector((self.radius, self.radius, (self.radius + (height / 2)))))
        
    def to_object(self) -> bpy.types.Object:
        mesh = bpy.data.meshes.new(self.name)
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=32, radius1=1, radius2=1, depth=2)
        bm.transform(Matrix.Translation((0, 0, 1)))
        bm.to_mesh(mesh)
        bm.free()
        mesh.transform(import_transform.mesh_matrix())
        self.ob = bpy.data.objects.new(self.name, mesh)
        self.ob.matrix_world = import_transform.rotation_matrix()
        self.ob.nwo.mesh_primitive_type = "_connected_geometry_primitive_type_pill"

class Box(Shape):
    def __init__(self, element: TagFieldBlockElement, materials, corinth: bool):
        super().__init__(element, materials)
        self.translation = Vector([n for n in element.SelectField("Struct:convex transform shape[0]/RealVector3d:translation").Data]) * 100
        radius = element.SelectField("Struct:box shape[0]/Real:radius").Data
        self.width, self.length, self.height = ((n + radius) * 2 * 100 for n in element.SelectField("RealVector3d:half extents").Data)
        ii, ij, ik = element.SelectField("Struct:convex transform shape[0]/RealVector3d:rotation i").Data
        ji, jj, jk = element.SelectField("Struct:convex transform shape[0]/RealVector3d:rotation j").Data
        ki, kj, kk = element.SelectField("Struct:convex transform shape[0]/RealVector3d:rotation k").Data
        # iw = element.SelectField("Struct:convex transform shape[0]/Real:havok w rotation i").Data
        # jw = element.SelectField("Struct:convex transform shape[0]/Real:havok w rotation j").Data
        # kw = element.SelectField("Struct:convex transform shape[0]/Real:havok w rotation k").Data
        
        rotation = self.calculate_box_rotation(ii, ik, ij, ji, jj, jk, ki, kj, kk)
            
        self.matrix = Matrix.LocRotScale(self.translation, rotation, Vector((self.width, self.length, self.height)))
    
    @staticmethod
    def calculate_box_rotation(ii, ik, ij, ji, jj, jk, ki, kj, kk):
        #TODO this doesn't quite work right for corinth, need to figure this out
        qw = math.sqrt(max(0, 1 + ii + jj + kk)) / 2
        qx = math.sqrt(max(0, 1 + ii - jj - kk)) / 2
        qy = math.sqrt(max(0, 1 - ii + jj - kk)) / 2
        qz = math.sqrt(max(0, 1 - ii - jj + kk)) / 2

        qx = math.copysign(qx, ki - ik)
        qy = math.copysign(qy, kj - jk)
        qz = math.copysign(qz, ji - ij)

        return Quaternion((qw, qx, qy, qz))
        
    def to_object(self):
        mesh = bpy.data.meshes.new(self.name)
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.create_cube(bm, size=1)
        bm.to_mesh(mesh)
        bm.free()
        mesh.transform(import_transform.mesh_matrix())
        self.ob = bpy.data.objects.new(self.name, mesh)
        self.ob.matrix_world = import_transform.rotation_matrix()
        self.ob.nwo.mesh_primitive_type = "_connected_geometry_primitive_type_box"
        
class PolyhedronFourVectors:
    def __init__(self, element: TagFieldBlockElement):
        a = element.SelectField("four vectors x").Data
        b = element.SelectField("four vectors y").Data
        c = element.SelectField("four vectors z").Data
        d = element.SelectField("havok w four vectors x").Data, element.SelectField("havok w four vectors y").Data, element.SelectField("havok w four vectors z").Data
        
        self.xi, self.yi, self.zi = a[0], b[0], c[0]
        self.xj, self.yj, self.zj = a[1], b[1], c[1]
        self.xk, self.yk, self.zk = a[2], b[2], c[2]
        self.xw, self.yw, self.zw = d
        
    def to_vectors(self) -> list[Vector]:
        vectors = []
        vectors.append(Vector((self.xi, self.yi, self.zi)) * 100)
        vectors.append(Vector((self.xj, self.yj, self.zj)) * 100)
        vectors.append(Vector((self.xk, self.yk, self.zk)) * 100)
        vectors.append(Vector((self.xw, self.yw, self.zw)) * 100)
        
        return vectors
        
class Polyhedron(Shape):
    def __init__(self, element: TagFieldBlockElement, materials, vectors_block: TagFieldBlockElement, four_vectors_map: list, for_bsp=False):
        super().__init__(element, materials, for_bsp)
        if for_bsp:
            four_vectors_size = element.SelectField("Struct:polyhedron[0]/LongInteger:four vectors size").Data
        else:
            four_vectors_size = element.SelectField("four vectors size").Data
        self.vertices = []
        self.offset = four_vectors_map[element.ElementIndex] - four_vectors_size
        for i in range(self.offset, self.offset + four_vectors_size):
            four_vectors = PolyhedronFourVectors(vectors_block.Elements[i])
            self.vertices.extend(four_vectors.to_vectors())
            
        self.matrix = Matrix.Identity(4)
        if for_bsp:
            self.radius = element.SelectField("Struct:polyhedron[0]/Struct:polyhedron shape[0]/Real:radius").Data
        else:
            self.radius = element.SelectField("Struct:polyhedron shape[0]/Real:radius").Data
            
    def to_object(self) -> bpy.types.Object:
        mesh = bpy.data.meshes.new(self.name)
        mesh.from_pydata(vertices=self.vertices, edges=[], faces=[])
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.convex_hull(bm, input=bm.verts)
        # scale_factor = self.radius * 2 + 1
        # bmesh.ops.scale(bm, vec=Vector((scale_factor, scale_factor, scale_factor)), verts=bm.verts)
        bm.to_mesh(mesh)
        bm.free()
        mesh.transform(import_transform.mesh_matrix())
        self.ob = bpy.data.objects.new(self.name, mesh)
        self.ob.matrix_world = import_transform.rotation_matrix()
        return self.ob
    
class HavokRigidBody:
    def __init__(self, element: TagFieldBlockElement):
        self.change_mass = element.SelectField("flags").TestBit("explicit mass")
        self.mass = element.SelectField("Real:mass").Data
        
        self.change_center_of_mass = element.SelectField("flags").TestBit("absolute center of mass")
        self.center_of_mass = element.SelectField("RealVector3d:center off mass offset").Data
        
        self.inertia_tensor = element.SelectField("Real:inertia tensor scale x").Data, element.SelectField("Real:inertia tensor scale y").Data, element.SelectField("Real:inertia tensor scale z").Data
        self.change_inertia_tensor = any(n != 1.0 for n in self.inertia_tensor)
        
        self.inertia_tensor_scale = element.SelectField("Real:inertia tensor scale").Data
        self.scale_inertia_tensor = self.inertia_tensor_scale != 1.0
        
        self.linear_damping = element.SelectField("Real:linear damping").Data
        self.change_linear_damping = self.linear_damping != 0.0
        
        self.angular_damping = element.SelectField("Real:angular damping").Data
        self.change_angular_damping = self.angular_damping != 0.0

class RigidBody:
    def __init__(self, element: TagFieldBlockElement, region, permutation, materials, four_vectors_map, tag, list_shapes_offset, corinth: bool):
        self.valid = False
        self.list_shapes_offset = list_shapes_offset
        self.index = element.ElementIndex
        if tag.corinth and element.SelectField("ShortBlockIndex:serialized shapes").Value > -1:
            return utils.print_warning(f"Serialized Shapes are not supported. Skipping Rigid body {self.index}")
        self.node_index = element.SelectField("node").Value
        self.region = region
        self.permuation = permutation
        shape_element = element.SelectField("Struct:shape reference").Elements[0]
        self.shape_type = ShapeType(shape_element.SelectField("shape type").Value)
        self.shapes = []
        shape_index = shape_element.SelectField("shape").Value
        self.get_shape(shape_index, materials, four_vectors_map, tag, list_shapes_offset, corinth)
        self.valid = True
        self.is_havok_rigid_body = corinth and element.SelectField("flags").TestBit("Havok rigid body")
        self.havok_info = None
        
        if self.is_havok_rigid_body:
            self.havok_info = HavokRigidBody(element)
        
    def get_shape(self, shape_index, materials, four_vectors_map, tag, list_shapes_offset, corinth: bool):
        match self.shape_type:
            case ShapeType.sphere:
                self.shapes.append(Sphere(tag.block_spheres.Elements[shape_index], materials))
            case ShapeType.pill:
                self.shapes.append(Pill(tag.block_pills.Elements[shape_index], materials))
            case ShapeType.box:
                self.shapes.append(Box(tag.block_boxes.Elements[shape_index], materials, corinth))
            case ShapeType.polyhedron:
                self.shapes.append(Polyhedron(tag.block_polyhedra.Elements[shape_index], materials, tag.block_polyhedron_four_vectors, four_vectors_map))
                self.four_vectors_offset = self.shapes[-1].offset
            case ShapeType.mopp | ShapeType._list:
                if self.shape_type == ShapeType.mopp:
                    mopp = tag.block_mopps.Elements[shape_index]
                    if corinth:
                        self.shape_type = ShapeType(mopp.SelectField("Struct:childShapePointer[0]/ShortEnum:shape type").Value)
                        return self.get_shape(mopp.SelectField("Struct:childShapePointer[0]/ShortBlockIndexCustomSearch:shape").Value, materials, four_vectors_map, tag, list_shapes_offset, corinth)
                    else:
                        list_element = tag.block_lists.Elements[mopp.SelectField("list").Value]
                else:
                    list_element = tag.block_lists.Elements[shape_index]
                    
                list_shapes_count = list_element.SelectField("child shapes size").Data
                self.list_shapes_offset += list_shapes_count
                for i in range(list_shapes_offset, list_shapes_offset + list_shapes_count):
                    l_element = tag.block_list_shapes.Elements[i]
                    list_shape_ref = l_element.SelectField("Struct:shape reference").Elements[0]
                    list_shape_index = list_shape_ref.SelectField("shape").Value
                    match ShapeType(list_shape_ref.SelectField("shape type").Value):
                        case ShapeType.sphere:
                            self.shapes.append(Sphere(tag.block_spheres.Elements[list_shape_index], materials))
                        case ShapeType.pill:
                            self.shapes.append(Pill(tag.block_pills.Elements[list_shape_index], materials))
                        case ShapeType.box:
                            self.shapes.append(Box(tag.block_boxes.Elements[list_shape_index], materials, corinth))
                        case ShapeType.polyhedron:
                            self.shapes.append(Polyhedron(tag.block_polyhedra.Elements[list_shape_index], materials, tag.block_polyhedron_four_vectors, four_vectors_map))
                            self.four_vectors_offset = self.shapes[-1].offset
                        case _:
                            utils.print_warning(f"Unsupported physics shape type: {self.shape_type.name}")
            case _:
                utils.print_warning(f"Unsupported physics shape type: {self.shape_type.name}")
                
    def to_objects(self) -> bpy.types.Object:
        for shape in self.shapes:
            shape.to_object()
            
            if self.is_havok_rigid_body:
                self.setup_havok_props(shape)
            
            render_mat = bpy.data.materials.get("Physics")
            if not render_mat:
                render_mat = bpy.data.materials.new("Physics")
                render_mat.use_fake_user = True
                render_mat.diffuse_color = special_materials.Physics.color
                bsdf = render_mat.node_tree.nodes[0]
                bsdf.inputs[0].default_value = special_materials.Physics.color
                bsdf.inputs[4].default_value = special_materials.Physics.color[3]
                render_mat.surface_render_method = 'BLENDED'
                
            shape.ob.data.materials.append(render_mat)
            shape.ob.data.nwo.mesh_type = "_connected_geometry_mesh_type_physics"
            shape.ob.nwo.global_material = shape.material.name
            
    def setup_havok_props(self, shape: Shape):
        nwo = shape.ob.nwo
        havok = self.havok_info
        nwo.rigid_body_type = 'HAVOK'
        nwo.havok_friction = shape.friction
        nwo.havok_restitution = shape.restitution
        nwo.havok_change_mass = havok.change_mass
        nwo.havok_mass = havok.mass
        nwo.havok_change_center_of_mass = havok.change_center_of_mass
        nwo.havok_center_of_mass = havok.center_of_mass
        nwo.havok_change_inertia_tensor = havok.change_inertia_tensor
        nwo.havok_inertia_tensor = havok.inertia_tensor
        nwo.havok_scale_inertia_tensor = havok.scale_inertia_tensor
        nwo.havok_inertia_tensor_scale = havok.inertia_tensor_scale
        nwo.havok_change_linear_damping = havok.change_linear_damping
        nwo.havok_linear_damping = havok.linear_damping
        nwo.havok_change_angular_damping = havok.change_angular_damping
        nwo.havok_angular_damping = havok.angular_damping
            
class CollisionMaterial:
    def __init__(self, element: TagFieldBlockElement):
        self.index = element.ElementIndex
        self.name = element.Fields[0].Data

class BSPCollisionMaterial:
    def __init__(self, element: TagFieldBlockElement):
        self.index = element.ElementIndex
        self.render_method = ""
        self.tag_shader = None
        self.name = ""
        render = element.SelectField("Reference:render method").Path
        if render:
            self.render_method = render.RelativePathWithExtension
            self.tag_shader = render
            self.name = render.ShortName
        
        self.global_material = ""
        if utils.is_corinth():
            override = element.SelectField("override material name").Data
            if override:
                self.global_material = override
                
        if not self.global_material and render and Path(render.Filename).exists():
            if utils.is_corinth():
                with MaterialTag(path=self.render_method) as shader:
                    self.global_material = shader.tag.SelectField("physics material name").Data
            else:
                with ShaderTag(path=self.render_method) as shader:
                    material_name_field = shader.tag.SelectField("material name")
                    if material_name_field is None:
                        material_name_field = shader.tag.SelectField("material name 0")
                    self.global_material = material_name_field.Data
        
        if self.name:
            self.blender_material = get_blender_material(self.name, self.render_method)
        else:
            self.blender_material = None
            
        seam_flag = element.SelectField("WordFlags:flags")
        self.is_seam = seam_flag.TestBit("is seam")
        
class CollisionVertex:
    def __init__(self, element: TagFieldBlockElement):
        self.index = element.ElementIndex
        self.element = element
        self.point = element.Fields[0].Data
        self.first_edge = utils.unsigned_int16(element.Fields[1].Data)
        
    @property
    def position(self) -> Vector:
        return Vector(self.point) * 100
        
class CollisionSurface:
    def __init__(self, element: TagFieldBlockElement, materials: list[CollisionMaterial] | list[BSPCollisionMaterial]):
        self.index = element.ElementIndex
        self.first_edge = utils.unsigned_int16(element.SelectField("first edge").Data)
        material_index = element.SelectField("material").Data
        if material_index < 0 or material_index >= len(materials):
            self.material = None
        else:
            self.material = materials[material_index]
        flags = element.SelectField("flags")
        self.negated = flags.TestBit("plane negated")
        self.invalid = flags.TestBit("invalid")
        self.ladder = flags.TestBit("climbable")
        self.breakable = flags.TestBit("breakable")
        self.slip_surface = flags.TestBit("slip")
        self.invisible = flags.TestBit("invisible")
        self.two_sided = flags.TestBit("two sided") and not (self.breakable or self.invisible)
        
class CollisionEdge:
    def __init__(self, element: TagFieldBlockElement):
        self.element = element
        self.index = element.ElementIndex
        self.start_vertex = utils.unsigned_int16(element.SelectField("start vertex").Data)
        self.end_vertex = utils.unsigned_int16(element.SelectField("end vertex").Data)
        self.forward_edge = utils.unsigned_int16(element.SelectField("forward edge").Data)
        self.reverse_edge = utils.unsigned_int16(element.SelectField("reverse edge").Data)
        self.left_surface = utils.unsigned_int16(element.SelectField("left surface").Data)
        self.right_surface = utils.unsigned_int16(element.SelectField("right surface").Data)
        
class BSP:
    def __init__(self, element: TagFieldBlockElement, name, materials: list[CollisionMaterial]):
        self.name = name
        # self.index = element.ElementIndex
        self.uses_materials = False
        self.surfaces = [CollisionSurface(e, materials) for e in element.SelectField("Block:surfaces").Elements]
        self.vertices = [CollisionVertex(e) for e in element.SelectField("Block:vertices").Elements]
        self.edges = [CollisionEdge(e) for e in element.SelectField("Block:edges").Elements]
        
        self.sphere_collision_only = all(surf.invisible for surf in self.surfaces)
        self.some_sphere_collision = any(surf.invisible for surf in self.surfaces)
        
        self.sky_index = -1
        
    def get_surface_vertex_indices(self, surface: CollisionSurface):
        first_edge = self.edges[surface.first_edge]
        edge = first_edge
        polygon = []

        while True:
            if edge.left_surface == surface.index:
                polygon.append(edge.start_vertex)
                next_edge_index = edge.forward_edge
            else:
                polygon.append(edge.end_vertex)
                next_edge_index = edge.reverse_edge

            if next_edge_index == surface.first_edge:
                break

            edge = self.edges[next_edge_index]

        return polygon

    def yield_indices(self):
        for surface in self.surfaces:
            yield self.get_surface_vertex_indices(surface)
        
    def to_bvh(self):
        verts = [Vector(v.position) for v in self.vertices]
        tris = []

        for poly in self.yield_indices():
            if len(poly) == 3:
                tris.append(tuple(poly))
            elif len(poly) > 3:
                # face_verts is a list of vertex indices
                face_verts = [verts[i] for i in poly]
                # tessellate_polygon returns triangles as tuples of indices (0..len(poly)-1)
                tri_indices = tessellate_polygon([face_verts])
                for tri in tri_indices:
                    tris.append(tuple(poly[i] for i in tri))
            # ignore degenerate faces (<3 verts)

        if tris:
            return bvhtree.BVHTree.FromPolygons(verts, tris)
        
    def to_object(self, mesh_only=False, surface_indices=[], cookie_cutter=False) -> bpy.types.Object:
                
        indices = self.yield_indices()
        # Create the bpy mesh
        mesh = bpy.data.meshes.new(self.name)
        mesh.from_pydata(vertices=[v.position for v in self.vertices], edges=[], faces=list(indices))
        mesh.transform(import_transform.mesh_matrix())
        any_ladder = any_breakable = any_slip = any_invisible = False
        # Check if we need to set any per face properties
        map_material, map_two_sided, map_ladder, map_breakable, map_slip, map_negated, map_invalid, map_invisible = [], [], [], [], [], [], [], []
        for surface in self.surfaces:
            material = surface.material
            two_sided = surface.two_sided
            ladder = surface.ladder
            breakable = surface.breakable
            slip = surface.slip_surface
            negated = surface.negated
            invalid = surface.invalid
            invisible = surface.invisible
            
            if ladder:
                any_ladder = True
            if breakable:
                any_breakable = True
            if slip:
                any_slip = True
            if invisible:
                any_invisible = True
            
            map_material.append(material)
            map_two_sided.append(two_sided)
            map_ladder.append(ladder)
            map_breakable.append(breakable)
            map_slip.append(slip)
            map_negated.append(negated)
            map_invalid.append(invalid)
            map_invisible.append(invisible)
            
        # map_negated_and_not_two_sided = np.logical_and(map_negated, np.logical_not(two_sided))

        materials_set = set(map_material)
        two_sided_set = set(map_two_sided)
        ladder_set = set(map_ladder)
        breakable_set = set(map_breakable)
        slip_set = set(map_slip)
        negated_set = set(map_negated)
        invisible_set = set(map_invisible)

        split_material = len(materials_set) > 1
        split_two_sided = len(two_sided_set) > 1
        split_ladder = len(ladder_set) > 1
        split_breakable = len(breakable_set) > 1
        split_slip = len(slip_set) > 1
        split_negated = len(negated_set) > 1
        split_invisible = len(invisible_set) > 1

        blender_materials_map = {}
        
        if self.uses_materials:
            if split_material:
                for idx, mat in enumerate(sorted(materials_set, key=lambda x: x.name if x is not None else "+")):
                    if mat is None:
                        if isinstance(self, StructureCollision):
                            sky_suffix = self.sky_index if self.sky_index > -1 else ""
                            bmat = get_blender_material(f"+sky{sky_suffix}")
                        else:
                            bmat = get_blender_material("+seamsealer")
                            
                        mesh.materials.append(bmat)
                        blender_materials_map[mat] = idx
                    elif mat.is_seam:
                        bmat = get_blender_material("+seam")
                        mesh.materials.append(bmat)
                        blender_materials_map[mat] = idx
                    else:
                        mesh.materials.append(mat.blender_material)
                        blender_materials_map[mat] = idx
            elif surface.material:
                mesh.materials.append(surface.material.blender_material)
        
        if any_ladder:
            utils.add_face_prop(mesh, "ladder", map_ladder if split_ladder else None)
        if any_breakable:
            utils.add_face_prop(mesh, "face_mode", map_breakable if split_breakable else None).face_mode = 'breakable'
        if any_slip:
            utils.add_face_prop(mesh, "slip_surface", map_slip if split_slip else None)
        if any_invisible:
            utils.add_face_prop(mesh, "face_mode", map_invisible if split_invisible else None).face_mode = 'sphere_collision_only'
        
        if self.uses_materials:
            if split_material:
                material_indices = [blender_materials_map[mat] for mat in map_material]
                mesh.polygons.foreach_set("material_index", material_indices)
        elif not cookie_cutter:
            if split_material:
                indices = np.asarray([s.material.index for s in self.surfaces])
                for mat in materials_set:
                    material_indices = indices == mat.index
                    utils.add_face_prop(mesh, "global_material", material_indices).global_material = mat.name
            elif materials_set:
                utils.add_face_prop(mesh, "global_material").global_material = surface.material.name

        bm = bmesh.new()
        bm.from_mesh(mesh)
        bm.faces.ensure_lookup_table()
        # bmesh.ops.delete(bm, geom=[bm.faces[i] for i in invalid_indices], context='FACES')
        
        to_remove = set(np.nonzero(map_invalid)[0])
        # bad_faces = set(np.nonzero(map_negated_and_not_two_sided)[0])
        
        # if bad_faces:
        #     bad_vert_coords = [set([v.co.to_tuple() for v in f.verts]) for f in bm.faces if f.index in bad_faces]
        #     final_bad_faces = [f.index for f in bm.faces if set(v.co.to_tuple() for v in f.verts) in bad_vert_coords]
        #     to_remove.update(set(final_bad_faces))
            
                    
        if surface_indices:
            to_remove.update({idx for idx in range(len(bm.faces)) if idx not in set(surface_indices)})
        
        if to_remove:
            bmesh.ops.delete(bm, geom=[bm.faces[i] for i in to_remove], context='FACES')
        
        bm.to_mesh(mesh)
        bm.free()
        
        utils.set_two_sided(mesh)
        
        utils.calc_face_prop_counts(mesh)
        
        if mesh_only:
            return mesh
        
        ob = bpy.data.objects.new(self.name, mesh)
        ob.matrix_world = import_transform.rotation_matrix()
        if cookie_cutter:
            mesh.nwo.mesh_type = "_connected_geometry_mesh_type_cookie_cutter"
            apply_props_material(ob, "CookieCutter")
        elif not self.uses_materials:
            mesh.nwo.mesh_type = "_connected_geometry_mesh_type_collision"
            apply_props_material(ob, 'Collision')
        return ob
    
class ModelCollision(BSP):
    def __init__(self, element: TagFieldBlockElement, name, collision_materials: list[CollisionMaterial], nodes: list[str] = None):
        super().__init__(element.SelectField("Struct:bsp").Elements[0], name, collision_materials)
        self.node_index = element.Fields[0].Data
        self.bone = ""
        if nodes:
            self.bone = nodes[self.node_index]
    
class InstanceCollision(BSP):
    def __init__(self, element: TagFieldBlockElement, name, collision_materials: list[CollisionMaterial]):
        super().__init__(element, name, collision_materials)
        self.uses_materials = True
        
class InstancePhysics():
    def __init__(self, element: TagFieldBlockElement, name, physics_materials: list[CollisionMaterial]):
        polyhedra_block = element.SelectField("Block:polyhedra_with_materials")
        four_vectors_block = element.SelectField("Block:polyhedron four vectors")
        four_vectors_map = []
        self.polyhedra: list[Polyhedron] = []
        for poly_element in polyhedra_block.Elements:
            size = poly_element.SelectField("Struct:polyhedron[0]/LongInteger:four vectors size").Data
            if poly_element.ElementIndex == 0:
                four_vectors_map.append(size)
            else:
                four_vectors_map.append(size + four_vectors_map[-1])
                
            self.polyhedra.append(Polyhedron(poly_element, physics_materials, four_vectors_block, four_vectors_map, True))
        
class StructureCollision(BSP):
    def __init__(self, element: TagFieldBlockElement, name, collision_materials: list[CollisionMaterial], sky_index: int):
        super().__init__(element, name, collision_materials)
        self.uses_materials = True
        self.sky_index = sky_index
    
class HavokCollision:
    """A minimal importer for Tool's serialized HaloCompressedMeshShape data."""

    _MAX_POOL_VALUES = 4_000_000
    _COLLISION_TYPE_NAMES = {
        0: "default",
        1: "invisible_wall",
        2: "play_collision",
        3: "bullet_collision",
        4: "none",
    }

    def __init__(self, name: str, vertices: list[tuple[float, float, float]], faces: list[tuple[int, int, int]], material_indices: list[int], collision_materials: list[BSPCollisionMaterial], render_triangle_mappings: list[tuple[int, ...]] | None = None, collision_type: int = 0):
        self.name = name
        self.vertices = vertices
        self.faces = faces
        self.material_indices = material_indices
        self.collision_materials = collision_materials
        self.render_triangle_mappings = render_triangle_mappings or []
        try:
            collision_type = int(collision_type)
        except (TypeError, ValueError):
            collision_type = 0
        self.collision_type = collision_type
        self.collision_type_name = self._COLLISION_TYPE_NAMES.get(collision_type, "default")

    @property
    def has_render_triangle_mappings(self) -> bool:
        return len(self.render_triangle_mappings) == len(self.faces) and any(self.render_triangle_mappings)

    @property
    def unmapped_face_indices(self) -> list[int]:
        return self.get_unmapped_face_indices()

    def get_unmapped_face_indices(self, section_triangle_ranges: list[tuple[int, int, int]] | None = None) -> list[int]:
        if not self.has_render_triangle_mappings:
            return list(range(len(self.faces)))

        unmapped_face_indices = []
        for face_index, render_triangle_indices in enumerate(self.render_triangle_mappings):
            if not any(self._resolve_render_triangle_index(index, section_triangle_ranges) is not None for index in render_triangle_indices):
                unmapped_face_indices.append(face_index)

        return unmapped_face_indices

    def to_surface_triangle_mappings(
        self,
        section_triangle_ranges: list[tuple[int, int, int]] | None = None,
        claimed_render_triangles: dict[tuple[int, int], str] | None = None,
        rejected_face_indices: set[int] | None = None,
    ) -> list[SurfaceMapping]:
        if not self.has_render_triangle_mappings:
            return []

        grouped_mappings = {}
        for face_index, render_triangle_indices in enumerate(self.render_triangle_mappings):
            resolved_triangles = []
            has_collision_type_conflict = False
            for render_triangle_index in render_triangle_indices:
                resolved = self._resolve_render_triangle_index(render_triangle_index, section_triangle_ranges)
                if resolved is None:
                    continue

                if claimed_render_triangles is not None:
                    claimed_collision_type = claimed_render_triangles.get(resolved)
                    if claimed_collision_type is not None:
                        if claimed_collision_type != self.collision_type_name:
                            has_collision_type_conflict = True
                        continue

                resolved_triangles.append(resolved)

            if has_collision_type_conflict and rejected_face_indices is not None:
                rejected_face_indices.add(face_index)
            if not resolved_triangles:
                continue

            material_index = self.material_indices[face_index] if face_index < len(self.material_indices) else -1
            material = self.collision_materials[material_index] if 0 <= material_index < len(self.collision_materials) else None
            group_key = material_index
            surface, triangle_mappings = grouped_mappings.get(group_key, (None, None))
            if surface is None:
                surface = HavokCollisionSurface(material_index, material, self.collision_type_name)
                triangle_mappings = []
                grouped_mappings[group_key] = (surface, triangle_mappings)

            for section_index, local_triangle_index in resolved_triangles:
                triangle_mappings.append(DirectTriangleMapping(local_triangle_index, section_index))
                if claimed_render_triangles is not None:
                    claimed_render_triangles[(section_index, local_triangle_index)] = self.collision_type_name

        return [
            SurfaceMapping.from_render_triangles(surface, triangle_mappings)
            for surface, triangle_mappings in grouped_mappings.values()
            if triangle_mappings
        ]

    @staticmethod
    def _resolve_render_triangle_index(render_triangle_index: int, section_triangle_ranges: list[tuple[int, int, int]] | None):
        if render_triangle_index < 0:
            return None

        if not section_triangle_ranges:
            return 0, render_triangle_index

        if len(section_triangle_ranges) == 1:
            section_index, _, triangle_count = section_triangle_ranges[0]
            if render_triangle_index < triangle_count:
                return section_index, render_triangle_index
            return None

        for section_index, first_triangle_index, triangle_count in section_triangle_ranges:
            if first_triangle_index <= render_triangle_index < first_triangle_index + triangle_count:
                return section_index, render_triangle_index - first_triangle_index

        return None

    @classmethod
    def from_serialized_shape(cls, serialized_data: bytes, name: str, collision_materials: list[BSPCollisionMaterial], bounds_min=None, bounds_max=None, collision_type: int = 0):
        if not serialized_data:
            return None

        data = bytes(serialized_data)
        mesh_data = cls._extract_mesh_data(data, len(collision_materials))
        if mesh_data is None:
            return None

        vertices, faces, material_indices, render_triangle_mappings = mesh_data
        vertices = cls._fit_vertices_to_bounds(vertices, bounds_min, bounds_max)
        if not vertices or not faces:
            return None

        return cls(name, vertices, faces, material_indices, collision_materials, render_triangle_mappings, collision_type)

    @staticmethod
    def _read_packed_int(data: bytes, offset: int) -> tuple[int, int]:
        result = 0
        shift = 0
        while offset < len(data):
            byte = data[offset]
            offset += 1
            result |= (byte & 0x7F) << shift
            if not byte & 0x80:
                value = (result >> 1) ^ -(result & 1)
                return value, offset
            shift += 7
            if shift > 63:
                break

        raise ValueError("Invalid packed Havok integer")

    @classmethod
    def _extract_mesh_data(cls, data: bytes, material_count: int):
        if b"HaloCompressedMeshShape" not in data or b"VertexPool" not in data or b"IndexPool" not in data:
            return None

        scan_start = 0
        for marker in (b"IORenderTriangleIndices", b"RenderMapping", b"IndexPool", b"VertexPool"):
            index = data.find(marker)
            if index != -1:
                scan_start = max(scan_start, index + len(marker) + 1)

        candidates = []
        for offset in range(scan_start, len(data) - 8):
            try:
                vertex_float_count, vertex_data_offset = cls._read_packed_int(data, offset)
            except ValueError:
                continue

            if vertex_float_count < 9 or vertex_float_count % 3:
                continue
            if vertex_float_count > cls._MAX_POOL_VALUES:
                continue

            vertex_data_end = vertex_data_offset + vertex_float_count * 4
            if vertex_data_end >= len(data):
                continue

            try:
                vertex_values = struct.unpack_from(f"<{vertex_float_count}f", data, vertex_data_offset)
            except struct.error:
                continue

            if not cls._valid_vertex_pool(vertex_values):
                continue

            try:
                index_value_count, index_data_offset = cls._read_packed_int(data, vertex_data_end)
            except ValueError:
                continue

            if index_value_count < 4 or index_value_count % 4:
                continue
            if index_value_count > cls._MAX_POOL_VALUES:
                continue

            vertex_count = vertex_float_count // 3
            vertices = [
                (vertex_values[i], vertex_values[i + 1], vertex_values[i + 2])
                for i in range(0, vertex_float_count, 3)
            ]
            for index_pool_header_size in (0, 1):
                index_values = []
                cursor = index_data_offset + index_pool_header_size
                try:
                    for _ in range(index_value_count):
                        value, cursor = cls._read_packed_int(data, cursor)
                        if value < 0:
                            raise ValueError
                        index_values.append(value)
                except ValueError:
                    continue

                faces = []
                material_indices = []
                valid_triangle_indices = []
                material_score = 0
                invalid_triangle_count = 0
                for triangle_index, i in enumerate(range(0, index_value_count, 4)):
                    a, b, c, combined_material = index_values[i:i + 4]
                    if a >= vertex_count or b >= vertex_count or c >= vertex_count or len({a, b, c}) < 3:
                        invalid_triangle_count += 1
                        continue

                    material_index = cls._material_index_from_combined_data(combined_material, material_count)
                    if not material_count or material_index < material_count:
                        material_score += 1

                    faces.append((a, b, c))
                    material_indices.append(material_index)
                    valid_triangle_indices.append(triangle_index)

                triangle_count = index_value_count // 4
                if not faces or invalid_triangle_count > max(0, triangle_count // 10):
                    continue

                render_triangle_mappings = cls._extract_render_mappings(data, cursor, triangle_count)
                if render_triangle_mappings and len(render_triangle_mappings) == triangle_count:
                    render_triangle_mappings = [render_triangle_mappings[i] for i in valid_triangle_indices]
                else:
                    render_triangle_mappings = []
                candidates.append((len(faces), material_score, vertex_count, len(render_triangle_mappings), offset, vertices, faces, material_indices, render_triangle_mappings))

        if not candidates:
            return None

        _, _, _, _, _, vertices, faces, material_indices, render_triangle_mappings = max(candidates, key=lambda c: (c[0], c[1], c[2], c[3], -c[4]))
        return vertices, faces, material_indices, render_triangle_mappings

    @classmethod
    def _extract_render_mappings(cls, data: bytes, offset: int, triangle_count: int) -> list[tuple[int, ...]]:
        if triangle_count <= 0:
            return []

        for start_offset in (offset, offset + 1):
            try:
                mapping_reference_count, cursor = cls._read_packed_int(data, start_offset)
            except ValueError:
                continue

            if mapping_reference_count != triangle_count:
                continue
            if cursor >= len(data):
                continue

            # The next byte is the tagfile array payload marker, followed by one
            # 4-byte mapping reference per collision triangle.
            pointer_table_cursor = cursor + 1
            mapped_indices_cursor = pointer_table_cursor + triangle_count * 4
            if mapped_indices_cursor >= len(data):
                continue

            try:
                mapped_count, cursor = cls._read_packed_int(data, mapped_indices_cursor)
            except ValueError:
                continue

            if mapped_count != triangle_count or cursor >= len(data):
                continue

            # The render triangle indices array has the same one-byte payload marker.
            cursor += 1
            mapped_indices = []
            try:
                for _ in range(triangle_count):
                    render_triangle_index, cursor = cls._read_packed_int(data, cursor)
                    if render_triangle_index < 0:
                        raise ValueError
                    mapped_indices.append(render_triangle_index)
            except ValueError:
                continue

            if len(mapped_indices) == triangle_count:
                return [(index,) for index in mapped_indices]

        return []

    @staticmethod
    def _valid_vertex_pool(values) -> bool:
        if not values:
            return False

        has_non_zero = False
        for value in values:
            if not math.isfinite(value) or abs(value) > 1.0e8:
                return False
            if abs(value) > 1.0e-8:
                has_non_zero = True

        return has_non_zero

    @staticmethod
    def _material_index_from_combined_data(combined_data: int, material_count: int) -> int:
        material_index = combined_data & 0x0FFF
        if material_count:
            if material_index < material_count:
                return material_index
            if combined_data < material_count:
                return combined_data

        return material_index

    @staticmethod
    def _fit_vertices_to_bounds(vertices: list[tuple[float, float, float]], bounds_min, bounds_max) -> list[tuple[float, float, float]]:
        if bounds_min is None or bounds_max is None:
            return [(x * 100, y * 100, z * 100) for x, y, z in vertices]

        try:
            target_min = tuple(float(bounds_min[i]) for i in range(3))
            target_max = tuple(float(bounds_max[i]) for i in range(3))
        except (IndexError, TypeError, ValueError):
            return [(x * 100, y * 100, z * 100) for x, y, z in vertices]

        raw_min = tuple(min(v[axis] for v in vertices) for axis in range(3))
        raw_max = tuple(max(v[axis] for v in vertices) for axis in range(3))
        target_extent = tuple(target_max[axis] - target_min[axis] for axis in range(3))
        raw_extent = tuple(raw_max[axis] - raw_min[axis] for axis in range(3))

        max_target_extent = max(abs(value) for value in target_extent)
        max_bounds_delta = max(
            max(abs(raw_min[axis] - target_min[axis]), abs(raw_max[axis] - target_max[axis]))
            for axis in range(3)
        )

        if max_bounds_delta <= max(0.001, max_target_extent * 0.001):
            return [(x * 100, y * 100, z * 100) for x, y, z in vertices]

        fitted_vertices = []
        for vertex in vertices:
            fitted = []
            for axis in range(3):
                if abs(raw_extent[axis]) > 1.0e-8 and abs(target_extent[axis]) > 1.0e-8:
                    fitted_value = (vertex[axis] - raw_min[axis]) * (target_extent[axis] / raw_extent[axis]) + target_min[axis]
                elif abs(target_extent[axis]) <= 1.0e-8:
                    fitted_value = target_min[axis]
                else:
                    fitted_value = vertex[axis] + target_min[axis] - raw_min[axis]
                fitted.append(fitted_value * 100)

            fitted_vertices.append(tuple(fitted))

        return fitted_vertices

    def to_bvh(self):
        if self.vertices and self.faces:
            return bvhtree.BVHTree.FromPolygons([Vector(v) for v in self.vertices], self.faces)

    def to_object(self, face_indices: list[int] | None = None, name: str | None = None) -> bpy.types.Object:
        if face_indices is None:
            vertices = self.vertices
            faces = self.faces
            material_indices = self.material_indices
            render_triangle_mappings = self.render_triangle_mappings
        else:
            used_vertex_indices = sorted({vertex_index for face_index in face_indices for vertex_index in self.faces[face_index]})
            vertex_remap = {vertex_index: remapped_index for remapped_index, vertex_index in enumerate(used_vertex_indices)}
            vertices = [self.vertices[vertex_index] for vertex_index in used_vertex_indices]
            faces = [
                tuple(vertex_remap[vertex_index] for vertex_index in self.faces[face_index])
                for face_index in face_indices
            ]
            material_indices = [self.material_indices[face_index] for face_index in face_indices]
            render_triangle_mappings = [
                self.render_triangle_mappings[face_index] if face_index < len(self.render_triangle_mappings) else ()
                for face_index in face_indices
            ]

        mesh = bpy.data.meshes.new(name or self.name)
        mesh.from_pydata(vertices=vertices, edges=[], faces=faces)
        mesh.transform(import_transform.mesh_matrix())
        mesh.update()

        material_slots = {}
        for material_index in sorted(set(material_indices)):
            if material_index < 0 or material_index >= len(self.collision_materials):
                continue

            collision_material = self.collision_materials[material_index]
            if collision_material.blender_material is None:
                continue

            material_slots[material_index] = len(mesh.materials)
            mesh.materials.append(collision_material.blender_material)

        if material_slots:
            mesh.polygons.foreach_set("material_index", [material_slots.get(i, 0) for i in material_indices])

        if len(render_triangle_mappings) == len(mesh.polygons):
            render_triangle_indices = np.array([mapping[0] if mapping else -1 for mapping in render_triangle_mappings], dtype=np.int32)
            render_triangle_counts = np.array([len(mapping) for mapping in render_triangle_mappings], dtype=np.int32)
            render_triangle_index_attribute = mesh.attributes.new("foundry_havok_render_triangle_index", 'INT', 'FACE')
            render_triangle_index_attribute.data.foreach_set("value", render_triangle_indices)
            render_triangle_count_attribute = mesh.attributes.new("foundry_havok_render_triangle_count", 'INT', 'FACE')
            render_triangle_count_attribute.data.foreach_set("value", render_triangle_counts)

        utils.add_face_prop(mesh, "collision_type").collision_type = self.collision_type_name

        mesh.nwo.mesh_type = "_connected_geometry_mesh_type_collision"
        ob = bpy.data.objects.new(name or self.name, mesh)
        ob.matrix_world = import_transform.rotation_matrix()
        if not mesh.materials:
            apply_props_material(ob, "Collision")

        return ob

class PathfindingSphere:
    def __init__(self, element: TagFieldBlockElement, nodes: list[str] = None):
        self.index = element.ElementIndex
        self.node_index = element.Fields[0].Value
        self.bone = ""
        if nodes:
            self.bone = nodes[self.node_index]
            
        flags = element.SelectField("flags")
        self.when_open = flags.TestBit("remains when open")
        self.vehicle = flags.TestBit("vehicle only")
        self.sectors = flags.TestBit("with sectors")
        self.center = element.SelectField("center").Data
        self.radius = element.SelectField("radius").Data
        
    def to_object(self):
        name = "pathfinding_sphere"
        if self.when_open:
            name += "::remains_when_open"
        if self.vehicle:
            name += "::vehicle"
        if self.sectors:
            name += "::sectors"
            
        ob = bpy.data.objects.new(name, None)
        ob.empty_display_size = import_transform.distance(self.radius)
        ob.empty_display_type = 'SPHERE'
        ob.nwo.marker_type = "_connected_geometry_marker_type_pathfinding_sphere"
        
        return ob
        
            
class CompressionBounds:
    def __init__(self, element: TagFieldBlockElement):
        first = element.SelectField("position bounds 0").Data
        second = element.SelectField("position bounds 1").Data
        
        self.x0 = first[0] * 100
        self.x1 = first[1] * 100
        self.y0 = first[2] * 100
        self.y1 = second[0] * 100
        self.z0 = second[1] * 100
        self.z1 = second[2] * 100
        
        self.co_matrix = Matrix((
            (self.x1-self.x0, 0, 0, self.x0),
            (0, self.y1-self.y0, 0, self.y0),
            (0, 0, self.z1-self.z0, self.z0),
            (0, 0, 0, 1),
        ))
        
        third = element.SelectField("texcoord bounds 0").Data
        fourth = element.SelectField("texcoord bounds 1").Data
        
        self.u0 = third[0]
        self.u1 = third[1]
        self.v0 = fourth[0]
        self.v1 = fourth[1]
        
class Emissive:
    def __init__(self, element: TagFieldBlockElement):
        self.power = element.Fields[0].Data
        self.color = tuple([utils.srgb_to_linear(n) for n in element.Fields[1].Data])
        self.quality = element.Fields[2].Data
        self.focus = element.Fields[3].Data
        flags = element.Fields[4]
        self.power_per_unit_area = flags.TestBit("power per unit area")
        self.use_shader_gel = flags.TestBit("use shader gel")
        self.attenuation_falloff = element.Fields[5].Data
        self.attenuation_cutoff = element.Fields[6].Data
        self.bounce_ratio = element.Fields[7].Data

class Material:
    def __init__(self, element: TagFieldBlockElement, emissives: list[Emissive] = [], for_bsp=False):
        self.index = element.ElementIndex
        render_method_path = element.SelectField("render method").Path
        self.name = render_method_path.ShortName
        self.new = not bool(bpy.data.materials.get(self.name, 0))
        self.shader_path = render_method_path.RelativePathWithExtension
        self.emissive_index = element.SelectField("imported material index").Data
        self.lm_res = int(element.SelectField("Real:lightmap resolution scale").Data)
        self.lm_transparency = element.SelectField("lightmap additive transparency color").Data
        self.lm_translucency = element.SelectField("lightmap traslucency tint color").Data
        flags = element.SelectField("lightmap flags")
        self.lm_both_sides = flags.TestBit("lighting from both sides")
        self.lm_transparency_override = flags.TestBit("transparency override")
        self.lm_ignore_default_res = flags.TestBit("ignore default resolution scale")
        self.lm_chart_group_index = element.SelectField("ShortInteger:lightmap chart group index").Data
        self.breakable_surface_index = element.SelectField("breakable surface index").Data
        
        self.lm_analytical_absorb = element.SelectField("Real:lightmap analytical light absorb").Data
        self.lm_normal_absorb = element.SelectField("Real:lightmap normal light absorb").Data
        
        self.emissive_invalid = False
        
        self.blender_material = get_blender_material(self.name, self.shader_path)
        
        # Emissive Properties
        self.emissive: Emissive = None
        if for_bsp:
            if self.emissive_index > -1:
                if self.emissive_index < len(emissives):
                    emissive = emissives[self.emissive_index]
                    if emissive.power > 0:
                        self.emissive = emissive
                        # self.blender_material.nwo.emits = True
                elif emissives or self.emissive_index > 0:
                    self.emissive_invalid = True
                    utils.print_warning(f"Invalid emissive on tag material {self.name}, material index={self.index}, emissive index={self.emissive_index}")
    
class IndexLayoutType(Enum):
    DEFAULT = 0
    LINE_LIST = 1
    LINE_STRIP = 2
    TRIANGLE_LIST = 3
    TRIANGLE_FAN = 4
    TRIANGLE_STRIP = 5
    QUAD_LIST = 6
    RECT_LIST = 7
    
class IndexBuffer:
    def __init__(self, index_buffer_type: int, indices: list[int]):
        self.index_layout = IndexLayoutType(index_buffer_type)
        self.indices = indices

    def get_faces(self, mesh: 'Mesh', subparts=None) -> list[Face]:
        idx = 0
        faces = []
        if mesh.subparts:
            if subparts is None:
                for subpart in mesh.subparts:
                    start = subpart.index_start
                    count = subpart.index_count
                    list_indices = list(self._get_indices(start, count))
                    indices = [list_indices[n:n+3] for n in range(0, len(list_indices), 3) if len(list_indices[n:n+3]) == 3]
                    for i in indices:
                        faces.append(Face(indices=i, subpart=subpart, index=idx))
                        idx += 1
            else:
                for subpart in subparts:
                    start = subpart.index_start
                    count = subpart.index_count
                    list_indices = list(self._get_indices(start, count))
                    indices = [list_indices[n:n+3] for n in range(0, len(list_indices), 3) if len(list_indices[n:n+3]) == 3]
                    for i in indices:
                        faces.append(Face(indices=i, subpart=subpart, index=idx))
                        idx += 1
        else:
            start = 0
            count = len(self.indices)
            list_indices = list(self._get_indices(start, count))
            indices = [list_indices[n:n+3] for n in range(0, len(list_indices), 3) if len(list_indices[n:n+3]) == 3]
            for i in indices:
                faces.append(Face(indices=i, subpart=None, index=idx))
                idx += 1
                
        return faces

    def _get_indices(self, start: int, count: int):
        end = len(self.indices) if count < 0 else start + count
        subset = (self.indices[i] for i in range(start, end))
        if self.index_layout == IndexLayoutType.TRIANGLE_LIST:
            return subset
        elif self.index_layout == IndexLayoutType.TRIANGLE_STRIP:
            return self._unpack(subset)
        else:
            raise ValueError(f"Unsupported Index Layout Type {self.index_layout}")

    def _unpack(self, indices) -> list[int]:
        indices = list(indices)
        for pos in range(len(indices) - 2):
            if indices[pos] == indices[pos+1] or indices[pos] == indices[pos+2] or indices[pos+1] == indices[pos+2]:
                continue  # Skip degenerate triangles
            if pos % 2 == 0:
                yield indices[pos]
                yield indices[pos+1]
                yield indices[pos+2]
            else:
                yield indices[pos]
                yield indices[pos+2]
                yield indices[pos+1]

def _serialized_block_data(block):
    count = block.Elements.Count
    if count == 0:
        return memoryview(b""), 0, 0

    block_size = int(block.Size)
    if block_size <= 0 or block_size % count:
        element_size = sum(int(field.Size) for field in block.Elements[0].Fields)
    else:
        element_size = block_size // count

    data = bytes(block.Serialize())
    chunk_start = data.find(b"lbgt")
    if chunk_start == -1:
        raise ValueError("Serialized tag block does not contain an lbgt chunk")

    chunk_count = struct.unpack_from("<I", data, chunk_start + 12)[0]
    if chunk_count != count:
        raise ValueError(f"Serialized tag block count mismatch: {chunk_count} != {count}")

    values_start = chunk_start + 20
    values_end = values_start + element_size * count
    if values_end > len(data):
        raise ValueError("Serialized tag block ended before all element data was read")

    return memoryview(data)[values_start:values_end], element_size, count

def _raw_vertex_offsets(raw_vertices, element_size: int):
    offsets = []
    offset = 0
    for field in raw_vertices.Elements[0].Fields:
        offsets.append(offset)
        offset += int(field.Size)

    if offset > element_size:
        raise ValueError(f"Raw vertex field size {offset} exceeds serialized element size {element_size}")

    return offsets

def _unsigned_int(value: int, field_size: int):
    if value < 0:
        return (1 << (field_size * 8)) + value

    return value

def _read_index_elements(raw_indices):
    if raw_indices.Elements.Count == 0:
        return []

    field_size = int(raw_indices.Elements[0].Fields[0].Size)
    return [_unsigned_int(element.Fields[0].Data, field_size) for element in raw_indices.Elements]

def _read_serialized_indices(raw_indices):
    data, element_size, count = _serialized_block_data(raw_indices)
    if count == 0:
        return []

    field_size = int(raw_indices.Elements[0].Fields[0].Size)
    if field_size not in (1, 2, 4):
        raise ValueError(f"Unsupported raw index size: {field_size}")
    if element_size < field_size:
        raise ValueError(f"Raw index field size {field_size} exceeds serialized element size {element_size}")

    dtype = np.dtype(f"<u{field_size}")
    if element_size == field_size:
        return np.frombuffer(data, dtype=dtype, count=count).tolist()

    index_dtype = np.dtype({
        "names": ["index"],
        "formats": [dtype],
        "offsets": [0],
        "itemsize": element_size,
    })
    return np.frombuffer(data, dtype=index_dtype, count=count)["index"].tolist()

def _read_serialized_raw_vertices(raw_vertices, read_texcoord1: bool):
    data, element_size, count = _serialized_block_data(raw_vertices)
    if count == 0:
        return {
            "positions": [],
            "texcoords": [],
            "normals": [],
            "lightmap_texcoords": [],
            "node_indices": [],
            "node_weights": [],
            "vertex_colors": [],
            "texcoords1": [],
        }

    offsets = _raw_vertex_offsets(raw_vertices, element_size)
    if len(offsets) < 9:
        raise ValueError(f"Raw vertex block has {len(offsets)} fields, expected at least 9")

    names = ["position", "texcoord", "normal", "lightmap_texcoord", "node_indices", "node_weights", "vertex_color"]
    formats = [
        ("<f4", (3,)),
        ("<f4", (2,)),
        ("<f4", (3,)),
        ("<f4", (2,)),
        ("<i1", (4,)),
        ("<f4", (4,)),
        ("<f4", (3,)),
    ]
    field_offsets = [offsets[0], offsets[1], offsets[2], offsets[5], offsets[6], offsets[7], offsets[8]]

    if read_texcoord1 and len(offsets) > 9:
        names.append("texcoord1")
        formats.append(("<f4", (2,)))
        field_offsets.append(offsets[9])

    dtype = np.dtype({
        "names": names,
        "formats": formats,
        "offsets": field_offsets,
        "itemsize": element_size,
    })
    vertices = np.frombuffer(data, dtype=dtype, count=count)

    return {
        "positions": vertices["position"].tolist(),
        "texcoords": vertices["texcoord"].tolist(),
        "normals": vertices["normal"].tolist(),
        "lightmap_texcoords": vertices["lightmap_texcoord"].tolist(),
        "node_indices": vertices["node_indices"].tolist(),
        "node_weights": vertices["node_weights"].tolist(),
        "vertex_colors": vertices["vertex_color"].tolist(),
        "texcoords1": vertices["texcoord1"].tolist() if "texcoord1" in vertices.dtype.names else [],
    }
                
class Tessellation(Enum):
    none = 0
    _4x = 1
    _9x = 2
    _36x = 3
    
class DrawDistance(Enum):
    normal = 0
    detail_mid = 1
    detail_close = 2

class MeshPart:    
    def __init__(self, element: TagFieldBlockElement, materials: list[Material]):
        self.index = element.ElementIndex
        self.material_index = element.SelectField("render method index").Value
        self.index_start = element.SelectField("index start").Data
        self.index_count = element.SelectField("index count").Data
        
        self.draw_distance = DrawDistance.normal
        flags = element.SelectField("part flags")
        if flags.TestBit("draw cull distance close"):
            self.draw_distance = DrawDistance.detail_close
        elif flags.TestBit("draw cull distance medium"):
            self.draw_distance = DrawDistance.detail_mid
            
        self.lm_type_per_vertex = flags.TestBit("per vertex lightmap part")
        
        self.water_surface = False
        if flags.TestBit("is water surface"):
            self.water_surface = True
            
        part_type_index = element.SelectField("part type").Data
        
        if part_type_index > 5:
            part_type_index = 2
            
        self.part_type = PartType(part_type_index)
        self.tessellation = Tessellation(element.SelectField("tessellation").Value)
        if isinstance(materials, dict):
            self.material = materials.get(self.material_index)
        else:
            self.material = next((m for m in materials if m.index == self.material_index), None)
        if self.material is None:
            invalid_mat = bpy.data.materials.get("invalid")
            if invalid_mat is None:
                invalid_mat = bpy.data.materials.new("invalid")
            self.material = invalid_mat
            
class MeshSubpart:
    def __init__(self, element: TagFieldBlockElement, parts: list[MeshPart], water_indices: list[int]):
        self.index = element.ElementIndex
        self.index_start = element.SelectField("index start").Data
        self.index_count = element.SelectField("index count").Data
        self.part_index = element.SelectField("part index").Value
        if isinstance(parts, dict):
            self.part = parts.get(self.part_index)
        else:
            self.part = next((p for p in parts if p.index == self.part_index), None)
        self.is_water_subpart = self.index_start in water_indices
        self.is_water_surface = self.part and self.part.water_surface
        
    def remove(self, ob: bpy.types.Object, tris: Face):
        indices = (t.index for t in tris if t.subpart is self)
        bm = bmesh.new()
        bm.from_mesh(ob.data)
        bm.faces.ensure_lookup_table()
        bmesh.ops.delete(bm, geom=[bm.faces[i] for i in indices], context='FACES')
        bm.to_mesh(ob.data)
        bm.free()
        
    def create(self, ob: bpy.types.Object, tris: Face):
        mesh = ob.data
        material = self.part.material
        blend_material = material.blender_material

        for idx, mat in enumerate(mesh.materials):
            if mat == blend_material:
                blend_material_index = idx
                break
        else:
            blend_material_index = len(mesh.materials)
            mesh.materials.append(blend_material)

        indices = [t.index for t in tris if t.subpart is self]
        all_indices = np.zeros(len(mesh.polygons), dtype=np.int8)
        all_indices[indices] = True
        
        for i in indices:
            mesh.polygons[i].material_index = blend_material_index
            
        corinth = utils.is_corinth(bpy.context)
            
        if self.is_water_surface:
            bm = bmesh.new()
            bm.from_mesh(mesh)
            water_layer = bm.faces.layers.bool.get('foundry_water')
            if water_layer is None:
                water_layer = bm.faces.layers.bool.new('foundry_water')
            
            bm.faces.ensure_lookup_table()
            for i in indices:
                bm.faces[i][water_layer] = True
                
            bm.to_mesh(mesh)
            bm.free()

        if self.part.part_type == PartType.transparent:
            utils.add_face_prop(mesh, "transparent", all_indices)
        elif self.part.part_type == PartType.opaque_non_shadowing:
            utils.add_face_prop(mesh, "no_shadow", all_indices)
        elif self.part.part_type == PartType.opaque_shadow_only:
            utils.add_face_prop(mesh, "face_mode", all_indices).face_mode = 'shadow_only'
        elif self.part.part_type == PartType.lightmap_only:
            utils.add_face_prop(mesh, "face_mode", all_indices).face_mode = 'lightmap_only'
        if self.part.draw_distance.value > 0:
            utils.add_face_prop(mesh, "draw_distance", all_indices).draw_distance = self.part.draw_distance.name
        if self.part.tessellation.value > 0:
            utils.add_face_prop(mesh, "mesh_tessellation_density", all_indices).mesh_tessellation_density = self.part.tessellation.name
        
        if self.part.lm_type_per_vertex:
            utils.add_face_prop(mesh, "lightmap_type", all_indices)
            
        # Material Props
        if not corinth and material.lm_res != LIGHTMAP_RESOLUTION_SCALE and material.lm_res != 0.0:
            res = 3
            if material.lm_res < 1:
                res = "1"
            elif material.lm_res > 7:
                res = "7"
            else:
                res = str(material.lm_res)
            utils.add_face_prop(mesh, "lightmap_resolution_scale", all_indices).lightmap_resolution_scale = res
            
        if material.lm_ignore_default_res != LIGHTMAP_IGNORE_DEFAULT_RESOLUTION_SCALE:
            utils.add_face_prop(mesh, "lightmap_ignore_default_resolution_scale", all_indices).lightmap_ignore_default_resolution_scale = material.lm_ignore_default_res
            
        if material.lm_chart_group_index != LIGHTMAP_CHART_GROUP_INDEX:
            utils.add_face_prop(mesh, "lightmap_chart_group", all_indices).lightmap_chart_group = material.lm_chart_group_index
            
        if material.lm_transparency != LIGHTMAP_ADDITIVE_TRANSPARENCY_COLOR:
            utils.add_face_prop(mesh, "lightmap_additive_transparency", all_indices).lightmap_additive_transparency = utils.argb32_to_rgb(material.lm_transparency)
            
        if material.lm_transparency_override != LIGHTMAP_TRANSPARENCY_OVERRIDE:
            utils.add_face_prop(mesh, "lightmap_transparency_override", all_indices).lightmap_transparency_override = material.lm_transparency_override
            
        if material.lm_analytical_absorb != LIGHTMAP_ANALYTICAL_LIGHT_ABSORB and material.lm_analytical_absorb != 1.0:
            utils.add_face_prop(mesh, "lightmap_analytical_bounce_modifier", all_indices).lightmap_analytical_bounce_modifier = material.lm_analytical_absorb
            
        if material.lm_normal_absorb != LIGHTMAP_NORMAL_LIGHT_ABSORD and material.lm_normal_absorb != 1.0:
            utils.add_face_prop(mesh, "lightmap_general_bounce_modifier", all_indices).lightmap_general_bounce_modifier = material.lm_normal_absorb
            
        if material.lm_translucency != LIGHTMAP_TRANSLUCENCY_TINT_COLOR:
            utils.add_face_prop(mesh, "lightmap_translucency_tint_color", all_indices).lightmap_translucency_tint_color = utils.argb32_to_rgb(material.lm_translucency)
            
        if material.lm_both_sides != LIGHTMAP_LIGHTING_FROM_BOTH_SIDES:
            utils.add_face_prop(mesh, "lightmap_lighting_from_both_sides", all_indices).lightmap_lighting_from_both_sides = material.lm_both_sides
            
        if material.emissive is not None:
            prop = utils.add_face_prop(mesh, "emissive", all_indices)
            atten_factor = 1 if utils.is_corinth(bpy.context) else 0.01
            e = material.emissive
            prop.material_lighting_attenuation_cutoff = e.attenuation_cutoff * atten_factor * (1 / WU_SCALAR)
            prop.material_lighting_attenuation_falloff = e.attenuation_falloff * atten_factor * (1 / WU_SCALAR)
            prop.material_lighting_emissive_focus = radians(180 * (1 - e.focus))
            prop.material_lighting_emissive_color = e.color
            prop.material_lighting_emissive_per_unit = e.power_per_unit_area
            prop.light_intensity = e.power
            prop.material_lighting_emissive_quality = e.quality
            prop.material_lighting_use_shader_gel = e.use_shader_gel
            prop.material_lighting_bounce_ratio = e.bounce_ratio
        elif material.emissive_invalid:
            prop = utils.add_face_prop(mesh, "emissive", all_indices)
            prop.light_intensity = 0
            prop.debug_emissive_index = material.emissive_index
            utils.print_warning(f"Mesh {ob.data.name} has invalid emissive on material {self.part.material.name} (part {self.part_index})")
            

class Mesh:
    '''All new Halo 3 render geometry definitions!'''
    def __init__(self, element: TagFieldBlockElement, bounds: CompressionBounds = None, permutation=None, materials=[], block_node_map=None, does_not_need_parts=False, from_vert_normals=False, tag_path=None):
        self.tag_path = tag_path
        self.index = element.ElementIndex
        self.permutation = permutation
        self.rigid_node_index = element.SelectField("rigid node index").Data
        self.index_buffer_type =  element.SelectField("index buffer type").Value
        self.bounds = bounds
        self.parts: list[MeshPart] = []
        self.subparts: list[MeshSubpart] = []
        self.from_vert_normals = from_vert_normals
        self.index = element.ElementIndex
        self.corinth = utils.is_corinth()
        
        water_indices = {e.Fields[0].Data for e in element.SelectField("Block:water indices start").Elements}
        
        for part_element in element.SelectField("parts").Elements:
            self.parts.append(MeshPart(part_element, materials))
        part_lookup = {part.index: part for part in self.parts}
        for subpart_element in element.SelectField("subparts").Elements:
            sp = MeshSubpart(subpart_element, part_lookup, water_indices)
            if sp.part is not None:
                self.subparts.append(sp)
        self.subparts_by_index = {subpart.index: subpart for subpart in self.subparts}
            
        self.valid = (bool(self.parts) and bool(self.subparts)) or does_not_need_parts
        
        self.does_not_need_parts = does_not_need_parts
            
        self.is_pca = False
        self.uncompressed = False
        if self.corinth:
            mesh_flags = element.SelectField("mesh flags")
            self.is_pca = mesh_flags.TestBit("mesh is PCA")
            self.uncompressed = mesh_flags.TestBit("use uncompressed vertex format")
            
        self.raw_positions = []
        self.raw_texcoords = []
        self.raw_normals = []
        self.raw_node_indices = []
        self.raw_node_weights = []
        self.raw_lightmap_texcoords = []
        self.raw_vertex_colors = []
        self.raw_texcoords1 = []
        self.raw_water_texcoords = []
        self.tris: list[Face] = []
        self.all_triangle_indices: list[list[int]] = []
        self.triangle_indices_by_subpart: dict[int, list[list[int]]] = {}
        self.face_indices_by_subpart: dict[int, list[int]] = {}
        
        self.node_map = []
        if block_node_map is not None and block_node_map.Elements.Count and self.index < block_node_map.Elements.Count:
            map_element = block_node_map.Elements[self.index]
            self.node_map = [utils.unsigned_int8(e.Fields[0].Data) for e in map_element.Fields[0].Elements]
        
        self.vertex_keys = []
        self.mesh_keys = []
        # vertex_keys = element.SelectField("Block:vertex keys")
        # if vertex_keys is not None:
        #     self.vertex_keys = [e.Fields[0].Data for e in vertex_keys.Elements]
        #     self.mesh_keys = [e.Fields[1].Data for e in vertex_keys.Elements]
            
        self.render_model = None
        self.temp_meshes = None
        self.instances = []
        self.real_mesh_index = -1

    def _get_raw_mesh_cache_key(self, raw_mesh_index: int):
        return (self.tag_path or id(self.temp_meshes), raw_mesh_index)

    def _get_blender_material(self, material):
        return material.blender_material if hasattr(material, "blender_material") else material

    def _face_mask(self, face_count: int, face_indices: list[int] | None):
        if face_indices is None or len(face_indices) == face_count:
            return None

        mask = np.zeros(face_count, dtype=np.int8)
        mask[face_indices] = 1
        return mask

    def _set_uv_layer_data(self, uv_layer, uvs, loop_vertex_indices):
        if uv_layer is None or not len(loop_vertex_indices):
            return

        uv_values = np.asarray([(uv[0], uv[1]) for uv in uvs], dtype=np.float32)
        uv_layer.data.foreach_set("uv", uv_values[loop_vertex_indices].ravel())

    def _set_water_attribute(self, mesh: bpy.types.Mesh, face_indices: list[int] | None):
        if face_indices is None:
            values = np.ones(len(mesh.polygons), dtype=np.int8)
        elif face_indices:
            values = np.zeros(len(mesh.polygons), dtype=np.int8)
            values[face_indices] = 1
        else:
            return

        attribute = mesh.attributes.get("foundry_water")
        if attribute is None:
            attribute = mesh.attributes.new("foundry_water", 'BOOLEAN', 'FACE')
        attribute.data.foreach_set("value", values)

    @staticmethod
    def _polygon_normal(coords: list[Vector]) -> Vector | None:
        normal = Vector((0.0, 0.0, 0.0))
        count = len(coords)
        for i, current in enumerate(coords):
            next_coord = coords[(i + 1) % count]
            normal.x += (current.y - next_coord.y) * (current.z + next_coord.z)
            normal.y += (current.z - next_coord.z) * (current.x + next_coord.x)
            normal.z += (current.x - next_coord.x) * (current.y + next_coord.y)

        if normal.length_squared <= 1e-12:
            return None

        normal.normalize()
        return normal

    @staticmethod
    def _polygon_area(coords: list[Vector]) -> float:
        if len(coords) < 3:
            return 0.0

        origin = coords[0]
        area = 0.0
        for i in range(1, len(coords) - 1):
            area += (coords[i] - origin).cross(coords[i + 1] - origin).length * 0.5

        return area

    @staticmethod
    def _bounds_for_coords(coords: list[Vector]) -> tuple[Vector, Vector]:
        return (
            Vector((min(co.x for co in coords), min(co.y for co in coords), min(co.z for co in coords))),
            Vector((max(co.x for co in coords), max(co.y for co in coords), max(co.z for co in coords))),
        )

    @staticmethod
    def _bounds_overlap(a_min: Vector, a_max: Vector, b_min: Vector, b_max: Vector, tolerance: float) -> bool:
        return not (
            a_max.x < b_min.x - tolerance or a_min.x > b_max.x + tolerance or
            a_max.y < b_min.y - tolerance or a_min.y > b_max.y + tolerance or
            a_max.z < b_min.z - tolerance or a_min.z > b_max.z + tolerance
        )

    @staticmethod
    def _project_point_2d(point: Vector, drop_axis: int) -> tuple[float, float]:
        if drop_axis == 0:
            return point.y, point.z
        if drop_axis == 1:
            return point.x, point.z
        return point.x, point.y

    @staticmethod
    def _point_on_segment_2d(point: tuple[float, float], start: tuple[float, float], end: tuple[float, float], tolerance: float) -> bool:
        px, py = point
        ax, ay = start
        bx, by = end
        cross = (px - ax) * (by - ay) - (py - ay) * (bx - ax)
        segment_length = math.hypot(bx - ax, by - ay)
        if abs(cross) > tolerance * max(segment_length, 1.0):
            return False

        return (
            min(ax, bx) - tolerance <= px <= max(ax, bx) + tolerance and
            min(ay, by) - tolerance <= py <= max(ay, by) + tolerance
        )

    @classmethod
    def _point_in_polygon_2d(cls, point: tuple[float, float], polygon: list[tuple[float, float]], tolerance: float) -> bool:
        inside = False
        px, py = point
        previous = polygon[-1]
        for current in polygon:
            if cls._point_on_segment_2d(point, previous, current, tolerance):
                return True

            cx, cy = current
            px_prev, py_prev = previous
            if (cy > py) != (py_prev > py):
                intersection_x = (px_prev - cx) * (py - cy) / (py_prev - cy) + cx
                if px <= intersection_x + tolerance:
                    inside = not inside

            previous = current

        return inside

    def _render_face_match_data(self, mesh: bpy.types.Mesh):
        render_faces = []
        vertices = mesh.vertices
        for poly in mesh.polygons:
            coords = [vertices[i].co.copy() for i in poly.vertices]
            normal = self._polygon_normal(coords)
            if normal is None:
                continue

            bounds_min, bounds_max = self._bounds_for_coords(coords)
            center = sum(coords, Vector((0.0, 0.0, 0.0))) / len(coords)
            render_faces.append((poly.index, coords, center, normal, self._polygon_area(coords), bounds_min, bounds_max))

        return render_faces

    def _find_matching_render_faces(self, collision_coords: list[Vector], render_faces, tolerance=0.005) -> list[int]:
        collision_normal = self._polygon_normal(collision_coords)
        collision_area = self._polygon_area(collision_coords)
        if collision_normal is None or collision_area <= 0.0:
            return []

        collision_bounds_min, collision_bounds_max = self._bounds_for_coords(collision_coords)
        drop_axis = max(range(3), key=lambda axis: abs(collision_normal[axis]))
        collision_poly_2d = [self._project_point_2d(co, drop_axis) for co in collision_coords]
        plane_origin = collision_coords[0]
        matches = []
        matched_area = 0.0

        for face_index, coords, center, normal, area, bounds_min, bounds_max in render_faces:
            if not self._bounds_overlap(collision_bounds_min, collision_bounds_max, bounds_min, bounds_max, tolerance):
                continue
            if abs(normal.dot(collision_normal)) < 0.98:
                continue
            if abs((center - plane_origin).dot(collision_normal)) > tolerance:
                continue
            if not all(self._point_in_polygon_2d(self._project_point_2d(co, drop_axis), collision_poly_2d, tolerance) for co in coords):
                continue

            matches.append(face_index)
            matched_area += area

        perimeter = sum((collision_coords[(i + 1) % len(collision_coords)] - co).length for i, co in enumerate(collision_coords))
        area_tolerance = max(tolerance * max(perimeter, 1.0), collision_area * 0.02)
        if not matches or abs(matched_area - collision_area) > area_tolerance:
            return []

        return matches

    def _resolve_collision_only_surface_mappings(self, mesh: bpy.types.Mesh, surface_triangle_mapping: list[SurfaceMapping], collision_info: BSP | None, section_index: int):
        if collision_info is None or not surface_triangle_mapping:
            return

        collision_only_mappings = [mapping for mapping in surface_triangle_mapping if mapping.collision_only]
        if not collision_only_mappings:
            return

        render_faces = self._render_face_match_data(mesh)
        if not render_faces:
            return

        mesh_matrix = import_transform.mesh_matrix()
        for mapping in collision_only_mappings:
            surface = mapping.surface
            if surface.invisible or surface.breakable or surface.ladder or surface.slip_surface:
                continue

            vertex_indices = collision_info.get_surface_vertex_indices(surface)
            if len(vertex_indices) < 3:
                continue

            collision_coords = [mesh_matrix @ collision_info.vertices[index].position for index in vertex_indices]
            matching_faces = self._find_matching_render_faces(collision_coords, render_faces)
            if matching_faces:
                mapping.triangle_indices = [DirectTriangleMapping(face_index, section_index) for face_index in matching_faces]
                mapping.collision_only = False

    def remove_render_duplicate_faces(self, collision_mesh: bpy.types.Mesh, render_mesh: bpy.types.Mesh):
        if len(collision_mesh.polygons) == 0:
            return

        render_faces = self._render_face_match_data(render_mesh)
        if not render_faces:
            return

        collision_vertices = collision_mesh.vertices
        duplicate_faces = []
        for poly in collision_mesh.polygons:
            coords = [collision_vertices[i].co.copy() for i in poly.vertices]
            if self._find_matching_render_faces(coords, render_faces):
                duplicate_faces.append(poly.index)

        if not duplicate_faces:
            return

        bm = bmesh.new()
        try:
            bm.from_mesh(collision_mesh)
            bm.faces.ensure_lookup_table()
            bmesh.ops.delete(bm, geom=[bm.faces[i] for i in duplicate_faces], context='FACES')
            bm.to_mesh(collision_mesh)
        finally:
            bm.free()

        utils.calc_face_prop_counts(collision_mesh)

    def _apply_subpart_props(self, mesh: bpy.types.Mesh, subpart: MeshSubpart, face_indices: list[int] | None):
        face_count = len(mesh.polygons)
        all_indices = self._face_mask(face_count, face_indices)
        material = subpart.part.material

        if subpart.part.part_type == PartType.transparent:
            utils.add_face_prop(mesh, "transparent", all_indices)
        elif subpart.part.part_type == PartType.opaque_non_shadowing:
            utils.add_face_prop(mesh, "no_shadow", all_indices)
        elif subpart.part.part_type == PartType.opaque_shadow_only:
            utils.add_face_prop(mesh, "face_mode", all_indices).face_mode = 'shadow_only'
        elif subpart.part.part_type == PartType.lightmap_only:
            utils.add_face_prop(mesh, "face_mode", all_indices).face_mode = 'lightmap_only'
        if subpart.part.draw_distance.value > 0:
            utils.add_face_prop(mesh, "draw_distance", all_indices).draw_distance = subpart.part.draw_distance.name
        if subpart.part.tessellation.value > 0:
            utils.add_face_prop(mesh, "mesh_tessellation_density", all_indices).mesh_tessellation_density = subpart.part.tessellation.name

        if subpart.part.lm_type_per_vertex:
            utils.add_face_prop(mesh, "lightmap_type", all_indices)

        if not hasattr(material, "lm_res"):
            return

        if not self.corinth and material.lm_res != LIGHTMAP_RESOLUTION_SCALE and material.lm_res != 0.0:
            res = "1" if material.lm_res < 1 else "7" if material.lm_res > 7 else str(material.lm_res)
            utils.add_face_prop(mesh, "lightmap_resolution_scale", all_indices).lightmap_resolution_scale = res

        if material.lm_ignore_default_res != LIGHTMAP_IGNORE_DEFAULT_RESOLUTION_SCALE:
            utils.add_face_prop(mesh, "lightmap_ignore_default_resolution_scale", all_indices).lightmap_ignore_default_resolution_scale = material.lm_ignore_default_res

        if material.lm_chart_group_index != LIGHTMAP_CHART_GROUP_INDEX:
            utils.add_face_prop(mesh, "lightmap_chart_group", all_indices).lightmap_chart_group = material.lm_chart_group_index

        if material.lm_transparency != LIGHTMAP_ADDITIVE_TRANSPARENCY_COLOR:
            utils.add_face_prop(mesh, "lightmap_additive_transparency", all_indices).lightmap_additive_transparency = utils.argb32_to_rgb(material.lm_transparency)

        if material.lm_transparency_override != LIGHTMAP_TRANSPARENCY_OVERRIDE:
            utils.add_face_prop(mesh, "lightmap_transparency_override", all_indices).lightmap_transparency_override = material.lm_transparency_override

        if material.lm_analytical_absorb != LIGHTMAP_ANALYTICAL_LIGHT_ABSORB and material.lm_analytical_absorb != 1.0:
            utils.add_face_prop(mesh, "lightmap_analytical_bounce_modifier", all_indices).lightmap_analytical_bounce_modifier = material.lm_analytical_absorb

        if material.lm_normal_absorb != LIGHTMAP_NORMAL_LIGHT_ABSORD and material.lm_normal_absorb != 1.0:
            utils.add_face_prop(mesh, "lightmap_general_bounce_modifier", all_indices).lightmap_general_bounce_modifier = material.lm_normal_absorb

        if material.lm_translucency != LIGHTMAP_TRANSLUCENCY_TINT_COLOR:
            utils.add_face_prop(mesh, "lightmap_translucency_tint_color", all_indices).lightmap_translucency_tint_color = utils.argb32_to_rgb(material.lm_translucency)

        if material.lm_both_sides != LIGHTMAP_LIGHTING_FROM_BOTH_SIDES:
            utils.add_face_prop(mesh, "lightmap_lighting_from_both_sides", all_indices).lightmap_lighting_from_both_sides = material.lm_both_sides

        if material.emissive is not None:
            prop = utils.add_face_prop(mesh, "emissive", all_indices)
            atten_factor = 1 if self.corinth else 0.01
            emissive = material.emissive
            prop.material_lighting_attenuation_cutoff = emissive.attenuation_cutoff * atten_factor * (1 / WU_SCALAR)
            prop.material_lighting_attenuation_falloff = emissive.attenuation_falloff * atten_factor * (1 / WU_SCALAR)
            prop.material_lighting_emissive_focus = radians(180 * (1 - emissive.focus))
            prop.material_lighting_emissive_color = emissive.color
            prop.material_lighting_emissive_per_unit = emissive.power_per_unit_area
            prop.light_intensity = emissive.power
            prop.material_lighting_emissive_quality = emissive.quality
            prop.material_lighting_use_shader_gel = emissive.use_shader_gel
            prop.material_lighting_bounce_ratio = emissive.bounce_ratio
        elif material.emissive_invalid:
            prop = utils.add_face_prop(mesh, "emissive", all_indices)
            prop.light_intensity = 0
            prop.debug_emissive_index = material.emissive_index
            utils.print_warning(f"Mesh {mesh.name} has invalid emissive on material {subpart.part.material.name} (part {subpart.part_index})")
                
    def _true_uvs(self, texcoords):
        return [self._interp_uv(tc) for tc in texcoords]
    
    def _interp_uv(self, texcoord):
        u = np.interp(texcoord[0], (0, 1), (self.bounds.u0, self.bounds.u1))
        v = np.interp(texcoord[1], (0, 1), (self.bounds.v0, self.bounds.v1))
        
        return Vector((u, 1-v)) # 1-v to correct UV for Blender
    
    def create(self, render_model, temp_meshes: TagFieldBlock, nodes=[], parent: bpy.types.Object | None = None, instances: list['InstancePlacement'] = [], name="blam", is_io=False, surface_triangle_mapping=[], section_index=0, real_mesh_index=None, collision_info: BSP | None = None):
        if not self.valid:
            return []

        objects = []
        
        self.render_model = render_model
        self.temp_meshes = temp_meshes
        self.instances = instances
        self.real_mesh_index = real_mesh_index

        if instances:
            for instance in instances:
                utils.print_step(instance.name)
                subpart = self.subparts_by_index.get(instance.index)
                if subpart is None:
                    continue
                ob = self._create_mesh(instance.name, parent, nodes, subpart, instance.bone, instance.matrix, is_io, collision_info=collision_info)
                ob.scale = Vector.Fill(3, instance.scale)
                instance.ob = ob
                objects.append(ob)
        else:
            if self.permutation:
                name = f"{self.permutation.region.name}:{self.permutation.name}"
                utils.print_step(name)
                
            ob = self._create_mesh(name, parent, nodes, None, surface_triangle_mapping=surface_triangle_mapping, section_index=section_index, collision_info=collision_info)
            objects.append(ob)
            
            if ob.data.attributes.get('foundry_water'):
                ob_water = ob.copy()
                ob_water.data = ob.data.copy()

                bm = bmesh.new()
                bm.from_mesh(ob.data)
                layer = bm.faces.layers.bool.get('foundry_water')
                bmesh.ops.delete(bm, geom=[f for f in bm.faces if f[layer]], context='FACES')
                bm.faces.layers.bool.remove(layer)
                bm.to_mesh(ob.data)
                bm.free()
                
                bm = bmesh.new()
                bm.from_mesh(ob_water.data)
                layer = bm.faces.layers.bool.get('foundry_water')
                bmesh.ops.delete(bm, geom=[f for f in bm.faces if not f[layer]], context='FACES')
                bm.faces.layers.bool.remove(layer)
                bm.to_mesh(ob_water.data)
                bm.free()
                
                ob_water.data.nwo.mesh_type = '_connected_geometry_mesh_type_water_surface'
                ob_water.nwo.water_volume_depth = 0
                ob_water.nwo.water_type = 'SURFACE'
                
                if ob_water.data.materials:
                    utils.consolidate_materials(ob_water.data)
                    ob_water.name = ob_water.data.materials[0].name
                else:
                    ob_water.name = "water_surface"
                
                objects.append(ob_water)
        
        return objects
    
    def _get_raw_mesh_data(self):
        if self.raw_positions:
            return
        
        raw_mesh_index = self.index if self.real_mesh_index is None else self.real_mesh_index
        cache_key = self._get_raw_mesh_cache_key(raw_mesh_index)
        cache_entry = raw_mesh_data_cache.get(cache_key)
        if cache_entry is None:
            temp_mesh = self.temp_meshes.Elements[raw_mesh_index]

            raw_vertices = temp_mesh.SelectField("raw vertices")
            raw_indices = temp_mesh.SelectField("raw indices")
            if raw_indices.Elements.Count == 0:
                raw_indices = temp_mesh.SelectField("raw indices32")

            try:
                vertex_data = _read_serialized_raw_vertices(raw_vertices, self.corinth)
            except Exception as ex:
                utils.print_warning(f"Failed to read raw vertices with Field.Serialize(); falling back to ManagedBlam mesh helpers: {ex}")
                raw_positions = list(self.render_model.GetPositionsFromMesh(self.temp_meshes, raw_mesh_index))
                raw_texcoords = list(self.render_model.GetTexCoordsFromMesh(self.temp_meshes, raw_mesh_index))
                raw_normals = list(self.render_model.GetNormalsFromMesh(self.temp_meshes, raw_mesh_index))
                vertex_data = {
                    "positions": [tuple(raw_positions[i:i + 3]) for i in range(0, len(raw_positions), 3)],
                    "texcoords": [tuple(raw_texcoords[i:i + 2]) for i in range(0, len(raw_texcoords), 2)],
                    "normals": [tuple(raw_normals[i:i + 3]) for i in range(0, len(raw_normals), 3)],
                    "lightmap_texcoords": [tuple(float(v) for v in e.Fields[5].Data) for e in raw_vertices.Elements],
                    "vertex_colors": [tuple(float(v) for v in e.Fields[8].Data) for e in raw_vertices.Elements],
                    "texcoords1": (
                        [tuple(float(v) for v in e.Fields[9].Data) for e in raw_vertices.Elements]
                        if self.corinth and raw_vertices.Elements.Count and len(raw_vertices.Elements[0].Fields) > 9 else []
                    ),
                    "node_indices": None,
                    "node_weights": None,
                }

            try:
                index_stream = _read_serialized_indices(raw_indices)
            except Exception as ex:
                utils.print_warning(f"Failed to read raw indices with Field.Serialize(); falling back to field reads: {ex}")
                index_stream = _read_index_elements(raw_indices)

            cache_entry = {
                "positions": vertex_data["positions"],
                "texcoords": vertex_data["texcoords"],
                "normals": vertex_data["normals"],
                "lightmap_texcoords": vertex_data["lightmap_texcoords"],
                "vertex_colors": vertex_data["vertex_colors"],
                "texcoords1": vertex_data["texcoords1"],
                "index_stream": index_stream,
                "node_indices": vertex_data["node_indices"],
                "node_weights": vertex_data["node_weights"],
                "water_indices_local": [],
                "water_texcoords_local": [],
            }

            if temp_mesh.SelectField("raw water data").Elements.Count > 0:
                water_data = temp_mesh.SelectField("raw water data").Elements[0]
                cache_entry["water_indices_local"] = [utils.unsigned_int16(e.Fields[0].Data) for e in water_data.Fields[0].Elements]
                cache_entry["water_texcoords_local"] = [tuple(float(v) for v in e.Fields[0].Data) for e in water_data.Fields[1].Elements]

            raw_mesh_data_cache[cache_key] = cache_entry

        self.raw_positions = cache_entry["positions"]
        self.raw_texcoords = cache_entry["texcoords"]
        self.raw_normals = cache_entry["normals"]
        self.raw_lightmap_texcoords = cache_entry["lightmap_texcoords"]
        self.raw_vertex_colors = cache_entry["vertex_colors"]
        self.raw_texcoords1 = cache_entry["texcoords1"]
        self.raw_water_texcoords = []

        if not self.instances and self.rigid_node_index == -1:
            if cache_entry["node_indices"] is None or cache_entry["node_weights"] is None:
                raw_node_indices = list(self.render_model.GetNodeIndiciesFromMesh(self.temp_meshes, raw_mesh_index))
                raw_node_weights = list(self.render_model.GetNodeWeightsFromMesh(self.temp_meshes, raw_mesh_index))
                cache_entry["node_indices"] = [tuple(raw_node_indices[i:i + 4]) for i in range(0, len(raw_node_indices), 4)]
                cache_entry["node_weights"] = [tuple(raw_node_weights[i:i + 4]) for i in range(0, len(raw_node_weights), 4)]

            self.raw_node_indices = cache_entry["node_indices"]
            self.raw_node_weights = cache_entry["node_weights"]

        buffer = IndexBuffer(self.index_buffer_type, cache_entry["index_stream"])
        self.tris = buffer.get_faces(self)
        self.all_triangle_indices = [face.indices for face in self.tris]
        self.triangle_indices_by_subpart = {}
        self.face_indices_by_subpart = {}
        for face in self.tris:
            if face.subpart is None:
                continue
            subpart_index = face.subpart.index
            self.triangle_indices_by_subpart.setdefault(subpart_index, []).append(face.indices)
            self.face_indices_by_subpart.setdefault(subpart_index, []).append(face.index)

        if cache_entry["water_texcoords_local"]:
            water_subparts = [sp for sp in self.subparts if sp.is_water_surface]

            water_global_index_stream = []
            for sp in water_subparts:
                s, c = sp.index_start, sp.index_count
                water_global_index_stream.extend(cache_entry["index_stream"][s:s + c])

            local_to_global = {}
            for gi, li in zip(water_global_index_stream, cache_entry["water_indices_local"]):
                if li not in local_to_global:
                    local_to_global[li] = gi

            vert_count = len(self.raw_positions)
            full = [(0.0, 0.0)] * vert_count
            
            for local_id, uv in enumerate(cache_entry["water_texcoords_local"]):
                gi = local_to_global.get(local_id)
                if gi is not None:
                    full[gi] = (float(uv[0]), float(uv[1]))

            self.raw_water_texcoords = full

    def _create_mesh(self, name, parent, nodes, subpart: MeshSubpart | None, parent_bone=None, local_matrix=None, is_io=False, surface_triangle_mapping=[], section_index=0, collision_info: BSP | None = None):
        has_tag_path = self.tag_path is not None
        matrix = local_matrix or (parent.matrix_world if parent else Matrix.Identity(4))
        final_matrix = import_transform.object_matrix(matrix)
        if has_tag_path:
            transform_signature = import_transform.signature()
            if subpart is None:
                mesh_key = self.index, self.tag_path, transform_signature
            else:
                mesh_key = subpart.index, self.index, self.tag_path, transform_signature
            mesh = mesh_cache.get(mesh_key)
            if mesh is not None and mesh in frozenset(bpy.data.meshes):
                ob = bpy.data.objects.new(name, mesh)
                if parent:
                    ob.parent = parent
                    if parent.type == 'ARMATURE':
                        if self.rigid_node_index > -1:
                            ob.parent_type = "BONE"
                            ob.parent_bone = parent_bone or nodes[self.rigid_node_index].name
                        else:
                            ob.modifiers.new(name="Armature", type="ARMATURE").object = parent
                ob.matrix_world = final_matrix
                return ob
            
        self._get_raw_mesh_data()

        if subpart is None:
            indices = self.all_triangle_indices
        else:
            indices = self.triangle_indices_by_subpart.get(subpart.index, [])

        vertex_indices = sorted({idx for tri in indices for idx in tri})
        idx_start, idx_end = vertex_indices[0], vertex_indices[-1]

        mesh = bpy.data.meshes.new(name)
        ob = bpy.data.objects.new(name, mesh)
        
        if has_tag_path and not self.is_pca:
            mesh_cache[mesh_key] = mesh

        positions = self.raw_positions[idx_start:idx_end + 1]
        texcoords = self.raw_texcoords[idx_start:idx_end + 1]
        normals = self.raw_normals[idx_start:idx_end + 1]
        lighting_texcoords = self.raw_lightmap_texcoords[idx_start:idx_end + 1]
        vertex_colors = self.raw_vertex_colors[idx_start:idx_end + 1]
        texcoords1 = self.raw_texcoords1[idx_start:idx_end + 1] if self.raw_texcoords1 else []
        water_texcoords = self.raw_water_texcoords[idx_start:idx_end + 1] if self.raw_water_texcoords else []

        if idx_start > 0:
            indices = [[i - idx_start for i in tri] for tri in indices]

        mesh.from_pydata(positions, [], indices)

        transform_matrix = import_transform.mesh_matrix() @ (self.bounds.co_matrix if self.bounds else Matrix.Scale(100, 4))
        mesh.transform(transform_matrix)

        has_vertex_colors = any(any(v) for v in vertex_colors)
        has_lighting_texcoords = any(any(v) for v in lighting_texcoords)
        has_texcoords1 = bool(texcoords1) and any(any(v) for v in texcoords1)
        has_water_texcoords = bool(water_texcoords) and any(any(v) for v in water_texcoords)
        uvs = self._true_uvs(texcoords) if self.bounds else [Vector((u, 1-v)) for (u, v) in texcoords]
        if has_texcoords1:
            uvs1 = self._true_uvs(texcoords1) if self.bounds else [Vector((u, 1-v)) for (u, v) in texcoords1]
        uv_layer = mesh.uv_layers.new(name="UVMap0", do_init=False)
        lighting_uv_layer = mesh.uv_layers.new(name="lighting", do_init=False) if has_lighting_texcoords else None
        uvs1_layer = mesh.uv_layers.new(name="UVMap1", do_init=False) if has_texcoords1 else None
        
        if has_water_texcoords:
            if uvs1_layer is None:
                water_uvs_layer = mesh.uv_layers.new(name="UVMap1", do_init=False)
            else:
                water_uvs_layer = mesh.uv_layers.new(name="UVMap2", do_init=False)
                
            water_uvs = self._true_uvs(water_texcoords) if self.bounds else [Vector((u, 1-v)) for (u, v) in water_texcoords]
            
        loop_vertex_indices = np.empty(len(mesh.loops), dtype=np.int32)
        mesh.loops.foreach_get("vertex_index", loop_vertex_indices)
        self._set_uv_layer_data(uv_layer, uvs, loop_vertex_indices)
        if has_texcoords1:
            self._set_uv_layer_data(uvs1_layer, uvs1, loop_vertex_indices)
        if has_water_texcoords:
            self._set_uv_layer_data(water_uvs_layer, water_uvs, loop_vertex_indices)
        if lighting_uv_layer:
            self._set_uv_layer_data(lighting_uv_layer, lighting_texcoords, loop_vertex_indices)

        # normalised_normals = [Vector(n).normalized() for n in normals]
        mesh.normals_split_custom_set_from_vertices(normals)
        if self.is_pca or self.from_vert_normals: # ensures mesh reimports as closely to the original as possible, necessary for re-using PCA animation
            mesh.nwo.from_vert_normals = True

        if has_vertex_colors:
            vcolor_attribute = mesh.color_attributes.new("Color", 'FLOAT_COLOR', 'POINT')
            rgba = np.c_[vertex_colors, np.ones(len(mesh.vertices))]
            vcolor_attribute.data.foreach_set("color", rgba.ravel())
            
        if parent:
            ob.parent = parent
            if parent.type == 'ARMATURE':
                if self.rigid_node_index > -1:
                    ob.parent_type = "BONE"
                    ob.parent_bone = parent_bone or nodes[self.rigid_node_index].name
                else:
                    node_indices = self.raw_node_indices[idx_start:idx_end + 1]
                    node_weights = self.raw_node_weights[idx_start:idx_end + 1]
                    vgroups = ob.vertex_groups
                    group_cache = {}
                    for idx, (ni, nw) in enumerate(zip(node_indices, node_weights)):
                        for i, w in zip(ni, nw):
                            if 0 <= i <= 254 and w > 0:
                                if self.node_map:
                                    i = self.node_map[i]
                                group_name = nodes[i].name
                                group = group_cache.get(group_name)
                                if group is None:
                                    group = vgroups.get(group_name) or vgroups.new(name=group_name)
                                    group_cache[group_name] = group
                                group.add([idx], w, 'REPLACE')
                                    
                    ob.modifiers.new(name="Armature", type="ARMATURE").object = parent

        ob.matrix_world = final_matrix

        if not self.does_not_need_parts:
            if subpart:
                mesh.materials.append(self._get_blender_material(subpart.part.material))
                if subpart.is_water_surface:
                    self._set_water_attribute(mesh, None)
                self._apply_subpart_props(mesh, subpart, None)
            else:
                face_count = len(mesh.polygons)
                material_slot_lookup = {}
                material_indices = np.zeros(face_count, dtype=np.int32)
                water_face_indices = []
                for subpart in self.subparts:
                    face_indices = self.face_indices_by_subpart.get(subpart.index)
                    if not face_indices:
                        continue

                    blend_material = self._get_blender_material(subpart.part.material)
                    blend_material_index = material_slot_lookup.get(blend_material)
                    if blend_material_index is None:
                        blend_material_index = len(mesh.materials)
                        mesh.materials.append(blend_material)
                        material_slot_lookup[blend_material] = blend_material_index

                    material_indices[face_indices] = blend_material_index
                    if subpart.is_water_surface:
                        water_face_indices.extend(face_indices)
                    self._apply_subpart_props(mesh, subpart, face_indices)

                if face_count:
                    mesh.polygons.foreach_set("material_index", material_indices)
                if water_face_indices:
                    self._set_water_attribute(mesh, water_face_indices)
            
        self._resolve_collision_only_surface_mappings(mesh, surface_triangle_mapping, collision_info, section_index)

        # for IG figure out what tris are render only
        if surface_triangle_mapping:
            indices = [t.index for t in self.tris]
            collision_face_indices = set()
            face_count = len(mesh.polygons)
            slip_mask = np.zeros(face_count, dtype=np.int8)
            ladder_mask = np.zeros(face_count, dtype=np.int8)
            breakable_mask = np.zeros(face_count, dtype=np.int8)
            collision_type_masks = {}
            
            for mapping in surface_triangle_mapping:
                surf = mapping.surface
                for t in mapping.triangle_indices:
                    if t.section != section_index:
                        continue

                    idx = t.tri
                    if idx < 0 or idx >= face_count:
                        continue

                    collision_face_indices.add(idx)

                    if surf.slip_surface:
                        slip_mask[idx] = 1
                    if surf.ladder:
                        ladder_mask[idx] = 1
                    if surf.breakable:
                        breakable_mask[idx] = 1

                    collision_type = getattr(surf, "collision_type", "")
                    if collision_type:
                        collision_type_masks.setdefault(collision_type, np.zeros(face_count, dtype=np.int8))[idx] = 1
                        
            render_only_mask = np.zeros(face_count, dtype=np.int8)
            for f in indices:
                if f not in collision_face_indices:
                    render_only_mask[f] = 1
            
            if slip_mask.any():
                utils.add_face_prop(mesh, "slip_surface", None if slip_mask.all() else slip_mask)
            if ladder_mask.any():
                utils.add_face_prop(mesh, "ladder", None if ladder_mask.all() else ladder_mask)
            if breakable_mask.any():
                utils.add_face_prop(mesh, "face_mode", None if breakable_mask.all() else breakable_mask).face_mode = 'breakable'
            for collision_type, collision_type_mask in collision_type_masks.items():
                if collision_type_mask.any():
                    utils.add_face_prop(mesh, "collision_type", None if collision_type_mask.all() else collision_type_mask).collision_type = collision_type
            if render_only_mask.any():
                utils.add_face_prop(mesh, "face_mode", None if render_only_mask.all() else render_only_mask).face_mode = 'render_only'

        # for subpart in water_subparts:
        #     subpart.remove(ob, self.tris)

        if not mesh.nwo.from_vert_normals:
            utils.save_loop_normals_mesh(mesh)
            utils.set_two_sided(mesh, is_io)
            utils.apply_loop_normals(mesh)
            # utils.loop_normal_magic(mesh)
            
        utils.calc_face_prop_counts(mesh)
            
        if self.is_pca:
            attr = mesh.color_attributes.new("tension", 'FLOAT_COLOR', 'POINT')
            black = [0.0, 0.0, 0.0, 1.0] * len(attr.data)
            attr.data.foreach_set("color", black)
            
        if self.uncompressed:
            utils.add_face_prop(mesh, "uncompressed")
            
        # if self.mesh_keys:
        #     bm = bmesh.new()
        #     bm.from_mesh(mesh)
        #     layer = bm.verts.layers.int.new("mesh_key")
        #     for idx, vert in enumerate(bm.verts):
        #         vert[layer] = self.mesh_keys[idx]
        #     bm.to_mesh(mesh)
        #     bm.free()
                
        return ob

        
class InstancePlacement:
    def __init__(self, element: TagFieldBlockElement, nodes: list[Node]):
        self.index = element.ElementIndex
        self.name = utils.any_partition(element.SelectField("name").GetStringData(), "__", False)
        self.node_index = element.SelectField("node_index").Value
        self.bone = ""
        if self.node_index > -1:
            self.bone = next((n.name for n in nodes if n.index == self.node_index), None)
        
        self.scale = element.SelectField("scale").Data
        self.forward = Vector([n for n in element.SelectField("forward").Data])
        self.left = Vector([n for n in element.SelectField("left").Data])
        self.up = Vector([n for n in element.SelectField("up").Data])
        self.position = Vector([n for n in element.SelectField("position").Data]) * 100
        
        # self.matrix = Matrix((
        #     (self.forward[0], self.forward[1], self.forward[2], self.position[0]),
        #     (self.left[0], self.left[1], self.left[2], self.position[1]),
        #     (self.up[0], self.up[1], self.up[2], self.position[2]),
        #     (0, 0, 0, 1),
        # ))
        
        self.matrix = Matrix((
            (self.forward[0], self.left[0], self.up[0], self.position[0]),
            (self.forward[1], self.left[1], self.up[1], self.position[1]),
            (self.forward[2], self.left[2], self.up[2], self.position[2]),
            (0, 0, 0, 1),
        ))
        
        self.ob = None
        
        
    
class MarkerType(Enum):
    _connected_geometry_marker_type_model = 0
    _connected_geometry_marker_type_effects = 1
    _connected_geometry_marker_type_garbage = 2
    _connected_geometry_marker_type_hint = 3
    _connected_geometry_marker_type_pathfinding_sphere = 4
    _connected_geometry_marker_type_physics_constraint = 5
    _connected_geometry_marker_type_target = 6

class Marker:
    def __init__(self, element: TagFieldBlockElement, nodes: list[Node], regions: list[Region]):
        self.region = ""
        self.permutation = ""
        self.bone = ""
        self.translation = []
        self.rotation = []
        self.scale = 0.01
        self.direction = []
        self.linked_to = []
        self.uses_regions = False
        region_index = element.SelectField("region index").Data
        permutation_index = element.SelectField("permutation index").Data
        node_index = element.SelectField("node index").Data
        
        if region_index > -1:
            self.uses_regions = True
            self.region = next(r for r in regions if r.index == region_index)
            if permutation_index > -1:
                self.permutation = next(p for p in self.region.permutations if p.index == permutation_index)
                
        if node_index > -1:
            self.bone = next((n.name for n in nodes if n.index == node_index), None)
        
        self.translation = [n * 100 for n in element.SelectField("translation").Data]
        
        self.rotation = utils.ijkw_to_wxyz([n for n in element.SelectField("rotation").Data])
        self.scale = element.SelectField("scale").Data
        self.direction = ([n for n in element.SelectField("direction").Data])

        self.permutation_type = "exclude"
        self.permutations = []
    
class MarkerGroup:
    def __init__(self, element: TagFieldBlockElement, nodes: list[Node], regions: list[Region]):
        self.name = element.SelectField("name").GetStringData()
        self.index = element.ElementIndex
        
        self.type = MarkerType._connected_geometry_marker_type_model
        if self.name.startswith("fx_"):
            self.type = MarkerType._connected_geometry_marker_type_effects
        elif self.name.startswith("target_"):
            self.type = MarkerType._connected_geometry_marker_type_target
        elif self.name.startswith("garbage_"):
            self.type = MarkerType._connected_geometry_marker_type_garbage
        elif self.name.startswith("hint_"):
            self.type = MarkerType._connected_geometry_marker_type_hint
            
        self.markers = []
        for e in element.SelectField("markers").Elements:
            self.markers.append(Marker(e, nodes, regions))
            
    def to_blender(self, armature: bpy.types.Object, collection: bpy.types.Collection, size_factor: float, allowed_region_permutations: set):
        # Find duplicate markers
        objects = []
        skip_markers = []
        for marker in self.markers:
            if marker in skip_markers: continue
            for marker2 in self.markers:
                if marker2 == marker: continue
                if marker.region and marker.region == marker2.region and marker.translation == marker2.translation and marker.rotation == marker2.rotation:
                    marker.linked_to.append(marker2)
                    skip_markers.append(marker2)
                    
        remaining_markers = [m for m in self.markers if m not in skip_markers]
        
        for marker in remaining_markers:
            # print(f"--- {self.name}")
            if marker.region:
                # Check if there is a marker for every permutation
                if marker.linked_to and len(marker.linked_to) + 1 != len(marker.region.permutations):
                    # If not pick if this is include or exclude type depending on whichever means less permutation entries need to be added
                    # If a tie prefer exclude
                    include_permutations = [marker.permutation.name]
                    include_permutations.extend([m.permutation.name for m in marker.linked_to if m.permutation]) 
                    exclude_permutations = [p.name for p in marker.region.permutations if p.name not in include_permutations]
                    if len(include_permutations) < len(exclude_permutations):
                        marker.permutation_type = "include"
                        marker.permutations = include_permutations
                    else:
                        marker.permutations = exclude_permutations
                elif not marker.linked_to:
                    marker.permutation_type = "include"
                    marker.permutations = [marker.permutation.name]
                else:
                    marker.permutations = [marker.permutation.name]
                    
            if allowed_region_permutations:
                skip = False
                if marker.permutation_type == "include":
                    for perm in marker.permutations:
                        region_perm = tuple((marker.region.name, perm))
                        if region_perm in allowed_region_permutations:
                            break
                    else:
                        skip = True
                else: # exclude
                    for perm in marker.permutations:
                        region_perm = tuple((marker.region.name, perm))
                        if region_perm in allowed_region_permutations:
                            skip = True
                            break
            
                if skip:
                    continue
            
            ob = bpy.data.objects.new(name=self.name, object_data=None)
            collection.objects.link(ob)
            ob.parent = armature
            if marker.bone:
                ob.parent_type = "BONE"
                ob.parent_bone = marker.bone
                local_matrix = import_transform.object_matrix(
                    Matrix.LocRotScale(marker.translation, marker.rotation, Vector.Fill(3, 1)),
                    rotate=False,
                )
                ob.matrix_world = import_transform.keep_marker_axis(
                    armature.pose.bones[marker.bone].matrix @ local_matrix
                )

            nwo = ob.nwo
            nwo.marker_type = self.type.name
            
            nwo.marker_uses_regions = marker.uses_regions
            if marker.uses_regions:
                utils.set_region(ob, marker.region.name, utils.SetType.MODEL)
                nwo.marker_permutation_type = marker.permutation_type
                utils.set_marker_permutations(ob, marker.permutations)

            ob.empty_display_type = "ARROWS"
            ob.empty_display_size *= size_factor * import_transform.scale_factor()
            
            if self.type == MarkerType._connected_geometry_marker_type_target:
                ob.empty_display_size = import_transform.distance(marker.scale)
                ob.empty_display_type = "SPHERE"
            elif self.type == MarkerType._connected_geometry_marker_type_garbage:
                ob.nwo.marker_velocity = marker.direction
            
            objects.append(ob)
            
        return objects
    
def get_blender_material(name, shader_path=""):
    mat = bpy.data.materials.get(name)
    if not mat:
        if name == '+sky' or name == '+seamsealer' or name == "+seam":
            add_special_materials('h4' if utils.is_corinth() else 'reach', 'scenario')
            mat = bpy.data.materials.get(name)
        else:
            mat = bpy.data.materials.new(name)
            mat.nwo.shader_path = shader_path
        
    return mat

def create_fake_mesh(mesh_block: TagFieldBlock, raw_block: TagFieldBlock, render_method_index: int, mesh_index=None):
    if mesh_index is None:
        mesh_element = mesh_block.AddElement()
        raw_element = raw_block.AddElement()
    else:
        mesh_element = mesh_block.Elements[mesh_index]
        raw_element = raw_block.Elements[mesh_index]
        
    parts = mesh_element.SelectField("parts")
    subparts = mesh_element.SelectField("subparts")
    verts = raw_element.SelectField("raw vertices")
    indices = raw_element.SelectField("raw indices")
    
    # Parts
    parts.RemoveAllElements()
    part = parts.AddElement()
