<div align="center"> <img src="img/readme_banner.png"> </div>

**Foundry** is a Blender extension that facilitates a complete asset import & export pipeline for Halo Reach, Halo 4, and Halo 2 Anniversary Multiplayer.

## Requirements
- Blender 5.2 or above
- One or more of the following Halo Editing Kits: [HREK](https://store.steampowered.com/app/1695793/Halo_Reach_Mod_Tools__MCC/),
[H4EK](https://store.steampowered.com/app/1695792/Halo_4_Mod_Tools__MCC/),
[H2AMPEK](https://store.steampowered.com/app/1695790/Halo_2_Anniversary_MP_Mod_Tools__MCC/)

To install the afformentioned editing kits, you must own the respective MCC title on Steam.

## Installation

Foundry only needs to be installed once. Thereafter, you can use Blender to download any future updates automatically. If you would prefer to install a local standalone version of Foundry, skip to the Standalone Installation instructions below this section.

- Launch Blender and open Preferences <div align="left"> <img src="img/install0.png"> </div>
- Navigate to the **Get Extensions** tab and then click **Repositories**
- On the **Repositories** windows click the `+` icon and then **Add Remote Repository** <div align="left"> <img src="img/install1.png"> </div>
- In the **Add New Extension Repository** window copy and paste the following text into the **URL** field: `https://iloveagoodcrisp.github.io/Foundry/api/v1/extensions/index.json`
- I recommend checking the **Check for Updates on Startup** box, but this is optional
-  Now click **Create** to link the remote repository to Blender <div align="left"> <img src="img/install2.png"> </div>
- Enter `Foundry` into the search box and you should see the **Foundry** addon show up with an option to install <div align="left"> <img src="img/install3.png"> </div>
- Once installed, you should have a **Launch Foundry** button show in the top right of the 3D viewport. Click this button to load the addon <div align="left"> <img src="img/install4.png"> </div>
- To use Foundry you'll need at least one project loaded (Editing Kit). When launching Foundry for the first time you'll be prompted to select a project. Use the file dialog that opened to navigate to the folder containing either your HREK, H4EK, or H2AMP editing kit and then hit the Add Project button. Should you wish to add more projects, or reopen the project dialog, new projects can be added from either Foundry preferences or the Foundry Scene Properties panel <div align="left"> <img src="img/install5.png"> </div>

## Standalone Installation

- The standalone zip can be downloaded [here](https://iloveagoodcrisp.github.io/Foundry/api/v1/extensions/io_scene_foundry.zip)

- Locate the file you downloaded named `io_scene_foundry.zip` and then open Blender. Drag and drop the zip file into Blender and press **Ok** on the dialog box that appears

## Credits
- [Crisp](https://github.com/ILoveAGoodCrisp) - Addon Developer
- [Alexis Jonsson | WyvernZu](https://github.com/AlexisJonsson) - UI/UX/Icon Design and debugging
- [General Heed](https://github.com/Generalkidd) - Early Foundry work
- [Krevil](https://github.com/Krevil) - Guidance on editing GR2 files, research into Cubemap checksum calculation, providing offsets for Tool patches
- [Gravemind2401](https://github.com/Gravemind2401) - Advice on tag extraction
- [Matthew](https://github.com/matty45) - GR2 Research and assistance with developing Blender to GR2 exporting
- [Chiefster](https://github.com/chiefster-4014) - Creation of Blender Material Nodes for Halo models and general blender shader advice
- Soul - Creation of Blender Material Nodes for Halo models
- [Abstract Ingenuity](https://github.com/Abstract-Ingenuity) - Insight into Halo animation data and debugging
- [Enash](https://github.com/EnashMods) - Guidance on tag animation resource extraction

## Special Thanks
Testing and reporting bugs:
- [SpacedZed](https://github.com/SpacedZed)
- [Ryan | Stryking](https://github.com/stryking)
- [Pepperman](https://github.com/Pepper-Man)
- [ChunkierBean](https://github.com/TheChunkierBean)
- [lolhalolol1](https://github.com/lolhalolol1)
- [ivanovitch](https://github.com/ivanivanovitch)
- [Greenknight](https://github.com/GreenKnight5417)
- [Gashnor](https://github.com/Gashnor)
- [Priception](https://github.com/Priception)
- UndeadKiva
- DunkODST
- [Echo-482](https://www.youtube.com/@echo-482)
- [SOI_7](https://www.youtube.com/@soi_7915)

## Acknowledgements
This project includes code from [node-arrange](https://github.com/Leonardo-Pike-Excell/node-arrange)  
by Leonardo Pike-Excell, licensed under the [GNU General Public License v3.0](https://www.gnu.org/licenses/gpl-3.0.html).

## Support

 If you like what I make, please consider supporting me on [Ko-fi](https://ko-fi.com/iloveagoodcrisp)
