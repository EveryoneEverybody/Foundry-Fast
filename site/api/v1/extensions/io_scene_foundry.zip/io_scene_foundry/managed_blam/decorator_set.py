

from pathlib import Path
from typing import cast
import bpy

from .bitmap import bitmap_to_image
from .. import utils

from .render_model import RenderModelTag

from ..managed_blam import Tag

class DecoratorType:
    def __init__(self):
        self.render_model_instance_index = -1
        self.decorator_type_index = -1
        self.decorator_type_name = ""

class DecoratorSetTag(Tag):
    tag_ext = 'decorator_set'
    
    def _read_fields(self):
        self.reference_base = self.tag.SelectField("Reference:Base")
        self.reference_lod2 = self.tag.SelectField("Reference:Lod2")
        self.reference_lod3 = self.tag.SelectField("Reference:Lod3")
        self.reference_lod4 = self.tag.SelectField("Reference:Lod4")
        self.reference_texture = self.tag.SelectField("Reference:texture")
        self.decorator_types = self.tag.SelectField("Block:decorator types")
        self.model_instances = self.tag.SelectField("Block:render model instance names")
        
    def get_decorator_types(self) -> list[DecoratorType]:
        decorator_types = []
        instance_count = self.model_instances.Elements.Count
        for element in self.decorator_types.Elements:
            value = element.SelectField("LongBlockIndex:mesh").Value
            if value > -1 and value < instance_count:
                name = self.model_instances.Elements[value].Fields[0].GetStringData()
                if name:
                    dec_type = DecoratorType()
                    dec_type.render_model_instance_index = value
                    dec_type.decorator_type_index = element.ElementIndex
                    dec_type.decorator_type_name = name
                    decorator_types.append(dec_type)
                    
        return decorator_types
    
    def get_first_valid_render_model(self):
        base = self.get_path_str(self.reference_base.Path, True)
        lod2 = self.get_path_str(self.reference_lod2.Path, True)
        lod3 = self.get_path_str(self.reference_lod3.Path, True)
        lod4 = self.get_path_str(self.reference_lod4.Path, True)
        base_exists = base and Path(base).exists()
        lod2_exists = lod2 and Path(lod2).exists()
        lod3_exists = lod3 and Path(lod3).exists()
        lod4_exists = lod4 and Path(lod4).exists()
        
        if base_exists:
            return self.reference_base.Path
        if lod2_exists:
            return self.reference_lod2.Path
        if lod3_exists:
            return self.reference_lod3.Path
        if lod4_exists:
            return self.reference_lod4.Path
        
        return None
        
    def to_blender(self, collection, get_material=False, always_extract_bitmaps=False, single_type=None, lod=0, only_single_type=False):
        base = self.get_path_str(self.reference_base.Path, True)
        lod2 = self.get_path_str(self.reference_lod2.Path, True)
        lod3 = self.get_path_str(self.reference_lod3.Path, True)
        lod4 = self.get_path_str(self.reference_lod4.Path, True)
        texture = self.get_path_str(self.reference_texture.Path, True)
        
        all_obs = []
        single_type_instance_index = None
        
        types = self.get_decorator_types()

        if single_type is not None:
            for t in types:
                if t.decorator_type_name == single_type:
                    single_type_instance_index = t.render_model_instance_index
                    break
                
        if single_type_instance_index is None and only_single_type and types:
            single_type_instance_index = types[0].decorator_type_index
            
        ignore_lods = lod < 1
        continue_getting_lods = True
        
        base_exists = base and Path(base).exists()
        lod2_exists = lod2 and Path(lod2).exists()
        lod3_exists = lod3 and Path(lod3).exists()
        lod4_exists = lod4 and Path(lod4).exists()
        
        if not ignore_lods:
            if lod > 3 and not lod4_exists:
                lod = 3
            if lod > 2 and not lod3_exists:
                lod = 2
            if lod > 1 and not lod2_exists:
                lod = 1
        
        if base_exists and lod < 2:
            base_collection = bpy.data.collections.new(f"{self.tag_path.ShortName}_high")
            collection.children.link(base_collection)
            with RenderModelTag(path=base) as base_render:
                base_obs = base_render.to_blend_objects(collection, True, False, base_collection, no_armature=True, specific_io_index=single_type_instance_index)
                for ob in base_obs:
                    ob.nwo.decorator_lod = 'high'
                    utils.unlink(ob)
                    base_collection.objects.link(ob)
                    
                all_obs.extend(base_obs)
                continue_getting_lods = ignore_lods
        
        if lod2_exists and continue_getting_lods and lod < 3:
            lod2_collection = bpy.data.collections.new(f"{self.tag_path.ShortName}_medium")
            collection.children.link(lod2_collection)
            with RenderModelTag(path=lod2) as lod2_render:
                lod2_obs = lod2_render.to_blend_objects(collection, True, False, lod2_collection, no_armature=True, specific_io_index=single_type_instance_index)
                for ob in lod2_obs:
                    ob.nwo.decorator_lod = 'medium'
                    utils.unlink(ob)
                    lod2_collection.objects.link(ob)
                    
                all_obs.extend(lod2_obs)
                continue_getting_lods = ignore_lods
        
        if lod3_exists and continue_getting_lods and lod < 4:
            lod3_collection = bpy.data.collections.new(f"{self.tag_path.ShortName}_low")
            collection.children.link(lod3_collection)
            with RenderModelTag(path=lod3) as lod3_render:
                lod3_obs = lod3_render.to_blend_objects(collection, True, False, lod3_collection, no_armature=True, specific_io_index=single_type_instance_index)
                for ob in lod3_obs:
                    ob.nwo.decorator_lod = 'low'
                    utils.unlink(ob)
                    lod3_collection.objects.link(ob)
                
                all_obs.extend(lod3_obs)
                continue_getting_lods = ignore_lods
        
        if lod4_exists and continue_getting_lods:
            lod4_collection = bpy.data.collections.new(f"{self.tag_path.ShortName}_very_low")
            collection.children.link(lod4_collection)
            with RenderModelTag(path=lod4) as lod4_render:
                lod4_obs = lod4_render.to_blend_objects(collection, True, False, lod4_collection, no_armature=True, specific_io_index=single_type_instance_index)
                for ob in lod4_obs:
                    ob.nwo.decorator_lod = 'very_low'
                    utils.unlink(ob)
                    lod4_collection.objects.link(ob)
                    
                all_obs.extend(lod4_obs)
        
        if texture and Path(texture).exists():
            
            name = Path(texture).with_suffix("").name
            mat = bpy.data.materials.get(name)
            if mat is None:
                mat = bpy.data.materials.new(name)
                if get_material:
                    tree = cast(bpy.types.NodeTree, mat.node_tree)
                    tree.nodes.clear()
                    node_image = tree.nodes.new(type="ShaderNodeTexImage")
                    
                    info = bitmap_to_image(texture, always_extract_bitmaps)
                    
                    if info.image:
                        node_image.image = info.image
                    node_group = tree.nodes.new(type='ShaderNodeGroup')
                    node_group.node_tree = utils.add_node_from_resources("shared_nodes", "Decorator")
                    tree.links.new(input=node_group.inputs[0], output=node_image.outputs[0])
                    tree.links.new(input=node_group.inputs[1], output=node_image.outputs[1])
                    node_output = tree.nodes.new(type='ShaderNodeOutputMaterial')
                    tree.links.new(input=node_output.inputs[0], output=node_group.outputs[0])
                    render_shader = self.tag.SelectField("CharEnum:render shader").Value
                    if render_shader < 2:
                        mat.surface_render_method = 'BLENDED'
            
            for ob in all_obs:
                ob.data.materials.clear()
                ob.data.materials.append(mat)
                
        return all_obs
    
    def from_blender(self):
        pass