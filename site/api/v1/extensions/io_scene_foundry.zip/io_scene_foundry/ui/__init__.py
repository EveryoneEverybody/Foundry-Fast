import bpy
from . import bar, node_editor, outliner, viewport, panel, timeline, properties
from .panel import animation, asset, help, material, object, scene, sets, setting, tools, cinematic, light

_TOOLBAR_WATCHDOG_INTERVAL = 5.0
_TOOLBAR_FORCE_REPAIR_TICKS = 12
_toolbar_watchdog_enabled = False
_toolbar_watchdog_ticks = 0
_toolbar_draw_identity = None


def _tool_header_draw_identity():
    draw = bpy.types.VIEW3D_HT_tool_header.draw

    return (
        id(draw),
        getattr(draw, "__module__", None),
        getattr(draw, "__qualname__", None),
    )


def _remove_foundry_toolbar():
    bpy.types.VIEW3D_HT_tool_header.remove(bar.draw_foundry_toolbar)

def _tag_view3d_headers_redraw():
    if bpy.app.background:
        return
    
    windows = bpy.context.window_manager.windows

    for window in windows:
        screen = getattr(window, "screen", None)
        if not screen:
            continue
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _ensure_foundry_toolbar():
    global _toolbar_draw_identity
    _remove_foundry_toolbar()
    bpy.types.VIEW3D_HT_tool_header.append(bar.draw_foundry_toolbar)
    _toolbar_draw_identity = _tool_header_draw_identity()
    _tag_view3d_headers_redraw()


def _foundry_toolbar_watchdog():
    global _toolbar_watchdog_ticks

    if not _toolbar_watchdog_enabled or bpy.app.background:
        return None

    _toolbar_watchdog_ticks += 1
    draw_changed = _tool_header_draw_identity() != _toolbar_draw_identity
    force_repair = _toolbar_watchdog_ticks >= _TOOLBAR_FORCE_REPAIR_TICKS

    if draw_changed or force_repair:
        _toolbar_watchdog_ticks = 0
        _ensure_foundry_toolbar()

    return _TOOLBAR_WATCHDOG_INTERVAL


def _start_foundry_toolbar_watchdog():
    global _toolbar_watchdog_enabled, _toolbar_watchdog_ticks
    _toolbar_watchdog_enabled = True
    _toolbar_watchdog_ticks = 0
    _ensure_foundry_toolbar()

    if bpy.app.background:
        return
    
    if not bpy.app.timers.is_registered(_foundry_toolbar_watchdog):
        bpy.app.timers.register(_foundry_toolbar_watchdog, first_interval=0.25)


def _stop_foundry_toolbar_watchdog():
    global _toolbar_watchdog_enabled, _toolbar_watchdog_ticks, _toolbar_draw_identity
    _toolbar_watchdog_enabled = False
    _toolbar_watchdog_ticks = 0
    _toolbar_draw_identity = None

    if bpy.app.timers.is_registered(_foundry_toolbar_watchdog):
        bpy.app.timers.unregister(_foundry_toolbar_watchdog)

    _remove_foundry_toolbar()

classes = [
    bar.NWO_MT_ProjectChooserMenuDisallowNew,
    bar.NWO_MT_ProjectChooserMenu,
    bar.NWO_OT_ProjectChooser,
    bar.NWO_HaloLauncherExplorerSettings,
    bar.NWO_HaloLauncherGameSettings,
    bar.NWO_HaloLauncherGamePruneSettings,
    bar.NWO_HaloLauncherFoundationSettings,
    bar.NWO_HaloExportSettings,
    bar.NWO_HaloExportSettingsScope,
    bar.NWO_HaloExportCoordinateSystem,
    bar.NWO_HaloExportTriangulation,
    bar.NWO_HaloExportSettingsFlags,
    bar.NWO_HaloExportGranny,
    bar.NWO_HaloExport,
    bar.NWO_HaloExportPropertiesGroup,
    bar.NWO_OT_StartFoundry,
    bar.NWO_OT_ReloadIcons,
    node_editor.NWO_OT_HaloMaterialNodes,
    node_editor.NWO_OT_HaloMaterialTilingNode,
    outliner.NWO_OT_PermutationListCollection,
    outliner.NWO_OT_RegionListCollection,
    outliner.NWO_ApplyCollectionType,
    outliner.NWO_ApplyCollectionMenu,
    viewport.NWO_MT_PIE_ApplyTypeMesh,
    viewport.NWO_PIE_ApplyTypeMesh,
    viewport.NWO_OT_ApplyTypeMeshSingle,
    viewport.NWO_OT_ApplyTypeMesh,
    viewport.NWO_MT_PIE_ApplyTypeMarker,
    viewport.NWO_PIE_ApplyTypeMarker,
    viewport.NWO_OT_ApplyTypeMarkerSingle,
    viewport.NWO_OT_ApplyTypeMarker,
    animation.NWO_UL_AnimProps_Node,
    animation.NWO_OT_AddAnimationNode,
    animation.NWO_OT_RemoveAnimationNode,
    animation.NWO_OT_SingleAddAnimationNode,
    animation.NWO_OT_SingleRemoveAnimationNode,
    animation.NWO_OT_ExportFrameEvents,
    animation.NWO_UL_AnimProps_EventsData,
    animation.NWO_OT_AddAnimationEventData,
    animation.NWO_OT_RemoveAnimationEventData,
    animation.NWO_UL_AnimProps_Events,
    animation.NWO_OT_DeleteAnimation,
    animation.NWO_OT_UnlinkAnimation,
    animation.NWO_OT_AnimationLinkToGR2,
    animation.NWO_OT_AnimationMoveToOwnBlend,
    animation.NWO_OT_AnimationsMoveToAssetBlends,
    animation.NWO_OT_OpenExternalAnimationBlend,
    animation.NWO_OT_AnimationsFromBlend,
    animation.NWO_OT_SetTimeline,
    animation.NWO_OT_ClearRenames,
    animation.NWO_OT_ClearEvents,
    animation.NWO_OT_List_Add_Animation_Rename,
    animation.NWO_OT_List_Remove_Animation_Rename,
    animation.NWO_OT_NewAnimation,
    animation.NWO_OT_AnimationRenameMove,
    animation.NWO_UL_AnimationRename,
    animation.NWO_UL_AnimationList,
    animation.NWO_OT_AnimationEventSetFrame,
    animation.NWO_OT_KeyEventInfluenceProperty,
    animation.NWO_OT_PreviewIKEvent,
    animation.NWO_OT_AnimationFramesSyncToKeyFrames,
    animation.NWO_OT_List_Add_Animation_Event,
    animation.NWO_OT_List_Copy_Animation_Event,
    animation.NWO_OT_List_Remove_Animation_Event,
    animation.NWO_OT_AnimationEventMove,
    animation.NWO_OT_SingleList_Add_Animation_Event,
    animation.NWO_OT_SingleList_Remove_Animation_Event,
    animation.NWO_OT_SetActionTracksActive,
    animation.NWO_OT_AddActionTrack,
    animation.NWO_OT_RemoveActionTrack,
    animation.NWO_OT_ActionTrackMove,
    animation.NWO_UL_ActionTrack,
    animation.NWO_OT_AnimationsFromActions,
    animation.NWO_MT_AnimationTools,
    animation.NWO_OT_CopyEvents,
    animation.NWO_OT_PasteEvents,
    animation.NWO_OT_ClearAnimations,
    # asset.NWO_UL_ChildAsset,
    asset.NWO_OT_OpenParentAsset,
    # asset.NWO_OT_OpenChildAsset,
    # asset.NWO_OT_AddChildAsset,
    # asset.NWO_OT_RemoveChildAsset,
    # asset.NWO_OT_MoveChildAsset,
    asset.NWO_UL_IKChain,
    asset.NWO_OT_AddIKChain,
    asset.NWO_OT_RemoveIKChain,
    asset.NWO_OT_MoveIKChain,
    asset.NWO_OT_ClearAsset,
    # asset.NWO_OT_RegisterIcons,
    asset.NWO_OT_CopyScenario,
    asset.NWO_OT_SceneSwitch,
    asset.NWO_OT_CinematicSceneNew,
    asset.NWO_OT_CinematicSceneRemove,
    asset.NWO_OT_CinematicSceneMove,
    asset.NWO_UL_CinematicScenes,
    asset.NWO_OT_SetMainScene,
    material.NWO_OT_MaterialOpenTag,
    material.NWO_OpenImageEditor,
    material.NWO_DuplicateMaterial,
    material.NWO_UL_MaterialPropList,
    material.NWO_MT_MaterialAttributeAddMenu,
    material.NWO_OT_MaterialAttributeAdd,
    material.NWO_OT_MaterialAttributeDelete,
    material.NWO_OT_MaterialAttributeMove,
    # material.NWO_OT_RemoveMaterialProperty,
    # material.NWO_OT_AddLightmapProperty,
    # material.NWO_OT_AddEmissiveProperty,
    object.NWO_MT_FaceAttributeAddMenu,
    # object.NWO_MT_FacePropAddMenu,
    object.NWO_UL_FacePropList,
    object.NWO_OT_FaceAttributeConsolidate,
    object.NWO_OT_FaceAtributeCountRefresh,
    object.NWO_OT_EditMode,
    object.NWO_OT_FaceAttributeDelete,
    object.NWO_OT_FaceAttributeRemove,
    object.NWO_OT_FaceAttributeSetAll,
    object.NWO_OT_FaceAttributeAssign,
    object.NWO_OT_FaceAttributeSelect,
    object.NWO_OT_FaceAttributeMove,
    object.NWO_OT_FacePropCopyToSelected,
    object.NWO_OT_FacePropsCopyToSelected,
    object.NWO_OT_AddEmissiveNode,
    object.NWO_MT_FacePropOperatorsMenu,
    # object.NWO_OT_FaceAttributeAddFaceMode,
    # object.NWO_OT_FaceAttributeAddLightmap,
    object.NWO_OT_ChangeAttribute,
    object.NWO_OT_FaceAttributeAdd,
    object.NWO_OT_FaceAttributeColor,
    object.NWO_OT_FaceAttributeColorAll,
    object.NWO_OT_RegionListFace,
    object.NWO_OT_GlobalMaterialRegionListFace,
    object.NWO_OT_GlobalMaterialMenuFace,
    object.NWO_OT_GlobalMaterialMenuMaterial,
    object.NWO_MT_RegionsMenuSelection,
    object.NWO_MT_SeamBackfaceMenu,
    object.NWO_OT_SeamBackfaceAssignClosest,
    object.NWO_MT_RegionsMenu,
    object.NWO_MT_FaceRegionsMenu,
    object.NWO_MT_MaterialRegionsMenu,
    object.NWO_MT_PermutationsMenuSelection,
    object.NWO_MT_PermutationsMenu,
    object.NWO_MT_MarkerPermutationsMenu,
    object.NWO_MT_MeshTypes,
    object.NWO_MT_MarkerTypes,
    # object.NWO_UL_FaceMapProps,
    object.NWO_OT_FaceDefaultsToggle,
    # object.NWO_MT_MeshPropAddMenu,
    # object.NWO_OT_MeshPropRemove,
    # object.NWO_OT_MeshPropAddLightmap,
    object.NWO_MT_GlobalMaterialMenu,
    object.NWO_OT_GlobalMaterialGlobals,
    object.NWO_OT_RegionList,
    object.NWO_OT_GlobalMaterialRegionList,
    object.NWO_OT_GlobalMaterialList,
    object.NWO_OT_PermutationList,
    object.NWO_OT_BSPListSeam,
    object.NWO_OT_BSPList,
    object.NWO_UL_MarkerPermutations,
    object.NWO_OT_List_Add_MarkerPermutation,
    object.NWO_OT_List_Remove_MarkerPermutation,
    object.NWO_UL_ActorAttachments,
    object.NWO_OT_ActorAttachmentAdd,
    object.NWO_OT_ActorAttachmentRemove,
    object.NWO_OT_ActorAttachmentCopy,
    object.NWO_OT_ActorAttachmentMove,
    object.NWO_OT_GetActorAttachmentMarker,
    object.NWO_OT_GetActorAttachmentTypeMarker,
    # object.NWO_OT_MeshPropAdd,
    object.NWO_OT_SetHintName,
    object.NWO_OT_SelectChildObjects,
    object.NWO_OT_RemapChildDriversToArmature,
    object.NWO_OT_ShowWaterDirection,
    object.NWO_OT_HaloAttach,
    panel.NWO_FoundryPanelProps,
    panel.NWO_FoundryPanelPopover,
    panel.NWO_HotkeyDescription,
    panel.NWO_OpenURL,
    panel.NWO_OT_FoundryTip,
    panel.NWO_OT_ToggleBoneCollectionSelection,
    panel.NWO_OT_PanelUnpin,
    panel.NWO_OT_PanelSet,
    panel.NWO_OT_PanelExpand,
    sets.NWO_OT_SwapMaterial,
    sets.NWO_UL_MaterialOverrides,
    sets.NWO_OT_AddMaterialOverride,
    sets.NWO_OT_RemoveMaterialOverride,
    sets.NWO_OT_MoveMaterialOverride,
    sets.NWO_UL_PermutationClones,
    sets.NWO_OT_AddPermutationClone,
    sets.NWO_OT_RemovePermutationClone,
    sets.NWO_OT_MovePermutationClone,
    sets.NWO_RegionsContextMenu,
    sets.NWO_PermutationsContextMenu,
    sets.NWO_UL_Regions,
    sets.NWO_UL_Permutations,
    # properties.MESH_PT_FoundryMeshData,
    cinematic.NWO_UL_CameraActors,
    cinematic.NWO_OT_CameraActorAdd,
    cinematic.NWO_OT_CameraActorRemove,
    cinematic.NWO_OT_SelectCameraActors,
    cinematic.NWO_OT_CameraActorsClear,
    cinematic.NWO_UL_CameraLights,
    cinematic.NWO_OT_CameraLightAdd,
    cinematic.NWO_OT_CameraLightRemove,
    cinematic.NWO_OT_SelectCameraLights,
    cinematic.NWO_OT_CameraLightsClear,
    cinematic.NWO_UL_CinematicEvents,
    cinematic.NWO_OT_CinematicEventAdd,
    cinematic.NWO_OT_CinematicEventRemove,
    cinematic.NWO_OT_CinematicEventSetFrame,
    cinematic.NWO_OT_UpdateActor,
    cinematic.NWO_OT_OpenCinematicLightingTag,
    cinematic.NWO_OT_TransformCinematicEventFrames,
    cinematic.NWO_OT_GetSoundEffects,
    cinematic.NWO_OT_GetSoundClasses,
    cinematic.NWO_OT_CinematicEventsClear,
    cinematic.NWO_OT_GetCinematicVariant,
    cinematic.NWO_OT_GetCinematicRegion,
    cinematic.NWO_OT_GetCinematicPermutation,
    cinematic.NWO_OT_CinematicAnchorOffsetMain,
    cinematic.NWO_OT_CinematicAnchorOffset,
    cinematic.NWO_OT_BakeVisibilityToKeyframes,
    cinematic.NWO_OT_ClearVisibilityKeyframes,
    cinematic.NWO_GetScenarioCustsceneTitles,
    cinematic.NWO_OT_UserInputBoundsFromCamera,
    cinematic.NWO_OT_GetCinematicFunctions,
    light.NWO_OT_HaloLightToggle,
]

def register():
    for cls in classes: bpy.utils.register_class(cls)
    bpy.types.VIEW3D_MT_object_context_menu.append(viewport.object_context_apply_types)
    bpy.types.VIEW3D_MT_object_context_menu.append(viewport.object_context_sets)
    bpy.types.OUTLINER_MT_collection.append(viewport.collection_context)
    bpy.types.NODE_MT_add.append(node_editor.node_context_menu)
    _start_foundry_toolbar_watchdog()
    # bpy.types.NODE_HT_header.append(bar.draw_foundry_nodes_toolbar)
    bpy.types.VIEW3D_MT_mesh_add.append(viewport.add_halo_scale_model_button)
    bpy.types.VIEW3D_MT_armature_add.append(viewport.add_halo_armature_buttons)
    bpy.types.OUTLINER_HT_header.append(viewport.create_halo_collection)
    bpy.types.VIEW3D_MT_object.append(viewport.add_halo_join)
    bpy.types.TOPBAR_MT_file_import.append(bar.menu_func_import)
    bpy.types.TOPBAR_MT_file_external_data.append(bar.menu_func_external_data)
    bpy.types.DOPESHEET_HT_header.append(timeline.draw_cinematic_info)
    bpy.types.VIEW3D_MT_object_parent.append(object.draw_halo_attach)

    bpy.types.Scene.nwo_export = bpy.props.PointerProperty(
        type=bar.NWO_HaloExportPropertiesGroup, name="Halo Export", description=""
    )
    
def unregister():
    del bpy.types.Scene.nwo_export
    bpy.types.VIEW3D_MT_object_parent.remove(object.draw_halo_attach)
    bpy.types.DOPESHEET_HT_header.remove(timeline.draw_cinematic_info)
    bpy.types.TOPBAR_MT_file_external_data.remove(bar.menu_func_external_data)
    bpy.types.TOPBAR_MT_file_import.remove(bar.menu_func_import)
    _stop_foundry_toolbar_watchdog()
    # bpy.types.NODE_HT_header.remove(bar.draw_foundry_nodes_toolbar)
    bpy.types.VIEW3D_MT_mesh_add.remove(viewport.add_halo_scale_model_button)
    bpy.types.VIEW3D_MT_armature_add.remove(viewport.add_halo_armature_buttons)
    bpy.types.VIEW3D_MT_object.remove(viewport.add_halo_join)
    bpy.types.OUTLINER_HT_header.remove(viewport.create_halo_collection)
    bpy.types.NODE_MT_add.remove(node_editor.node_context_menu)
    bpy.types.OUTLINER_MT_collection.remove(viewport.collection_context)
    bpy.types.VIEW3D_MT_object_context_menu.remove(viewport.object_context_sets)
    bpy.types.VIEW3D_MT_object_context_menu.remove(viewport.object_context_apply_types)
    for cls in reversed(classes): bpy.utils.unregister_class(cls)
