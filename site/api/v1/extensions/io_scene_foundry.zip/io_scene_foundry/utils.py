from collections import Counter, defaultdict
import copy
import ctypes
from enum import Enum, IntEnum, auto
import itertools
import json
from math import radians
import math
from pathlib import Path, PureWindowsPath
import re
import shutil
import subprocess
import struct
import sys
import tempfile
import time
import unicodedata
from uuid import uuid4
import winreg
import zipfile
import bmesh
import bpy
import platform
from mathutils import Color, Euler, Matrix, Vector, Quaternion, geometry as geom, bvhtree
import os
import random
import xml.etree.ElementTree as ET
import numpy as np
from ctypes import c_float, c_int, wintypes
from subprocess import Popen, check_call, PIPE
import threading
import queue

from .tools.node_tree_arrange import arrange
from .constants import COLLISION_MESH_TYPES, OBJECT_TAG_EXTS, PROTECTED_MATERIALS, VALID_MESHES, VALID_OBJECTS, WU_SCALAR, css_colors
from .tools.materials import special_materials, convention_materials
from .icons import get_icon_id, get_icon_id_in_directory
# import requests
from bpy_extras import view3d_utils, anim_utils
from bpy.utils import flip_name


from .constants import object_asset_validation, object_game_validation

spinny = itertools.cycle(["|", "/", "—", "\\"])

HALO_SCALE_NODE = ['Scale Multiplier', 'Scale X', 'Scale Y']
HALO_TILING_NODE = ['Translate X', 'Translate Y', *HALO_SCALE_NODE, 'Vector']
MATERIAL_RESOURCES = os.path.join(os.path.dirname((os.path.realpath(__file__))), 'blends')

special_material_names = [m.name for m in special_materials]
convention_material_names = [m.name for m in convention_materials]

object_exts = '.crate', '.scenery', '.effect_scenery', '.device_control', '.device_machine', '.device_terminal', '.device_dispenser', '.biped', '.creature', '.giant', '.vehicle', '.weapon', '.equipment'

legacy_lightmap_prefixes = 'lm:', 'lp:', 'hl:', 'ds:', 'ds:', 'pf:', 'lt:', 'to:', 'at:', 'ro:'

module = None
zero_vector = Vector.Fill(3, 0)

###########
##GLOBALS##
###########

foundry_output_state = True

hit_target = False

iter_css = iter(set(css_colors.values()))

# Enums #

# animation events #
non_sound_frame_types = [
    "primary keyframe",
    "secondary keyframe",
    "tertiary keyframe",
    "allow interruption",
    "blend range marker",
    "stride expansion",
    "stride contraction",
    "ragdoll keyframe",
    "drop weapon keyframe",
    "match a",
    "match b",
    "match c",
    "match d",
    "right foot lock",
    "right foot unlock",
    "left foot lock",
    "left foot unlock",
]
sound_frame_types = [
    "left foot",
    "right foot",
    "both-feet shuffle",
    "body impact",
]
import_event_types = ["Wrapped Left", "Wrapped Right"]
frame_event_types = {
    "Trigger Events": [
        "primary keyframe",
        "secondary keyframe",
        "tertiary keyframe",
    ],
    "Navigation Events": [
        "match a",
        "match b",
        "match c",
        "match d",
        "stride expansion",
        "stride contraction",
        "right foot lock",
        "right foot unlock",
        "left foot lock",
        "left foot unlock",
    ],
    "Sync Action Events": [
        "ragdoll keyframe",
        "drop weapon keyframe",
        "allow interruption",
        "blend range marker",
    ],
    "Sound Events": [
        "left foot",
        "right foot",
        "body impact",
        "both-feet shuffle",
    ],
    "Import Events": ["Wrapped Left", "Wrapped Right"],
}

# shader exts #
shader_exts = (
    ".shader",
    ".shader_cortana",
    ".shader_custom",
    ".shader_decal",
    ".shader_foliage",
    ".shader_fur",
    ".shader_fur_stencil",
    ".shader_glass",
    ".shader_halogram",
    ".shader_mux",
    ".shader_mux_material",
    ".shader_screen",
    ".shader_skin",
    ".shader_terrain",
    ".shader_water",
    ".material",
)

shader_exts_reach = (
    ".shader",
    ".shader_cortana",
    ".shader_custom",
    ".shader_decal",
    ".shader_foliage",
    ".shader_fur",
    ".shader_fur_stencil",
    ".shader_glass",
    ".shader_halogram",
    ".shader_mux",
    ".shader_mux_material",
    ".shader_screen",
    ".shader_skin",
    ".shader_terrain",
    ".shader_water",
)

blender_object_types_mesh = (
    "MESH",
    "CURVE",
    "SURFACE",
    "META",
    "FONT",
    "CURVES",
    "POINTCLOUD",
    "VOLUME",
    "GPENCIL",
)

BLENDER_IMAGE_FORMATS = (".bmp", ".sgi", ".rgb", ".bw", ".png", ".jpg", ".jpeg", ".jp2", ".j2c", ".tga", ".cin", ".dpx", ".exr", ".hdr", ".tiff", ".tif", ".webp")

#############
##FUNCTIONS##
#############


def is_linked(ob):
    return ob.data.users > 1

def get_project_path(project_name=None):
    if project_name is None:
        project = get_project(get_scene_props().scene_project)
    else:
        project = get_project(project_name)
    if not project:
        return ""
    return project.project_path


def get_tool_path():
    project = get_project(get_scene_props().scene_project)
    if not project:
        return ""
    return str(Path(project.project_path, get_tool_type()))

def get_tags_path():
    project = get_project(get_scene_props().scene_project)
    if not project:
        return ""
    return project.tags_directory

def get_data_path():
    project = get_project(get_scene_props().scene_project)
    if not project:
        return ""
    return project.data_directory

def get_tool_type():
    return bpy.context.preferences.addons[__package__].preferences.tool_type

def get_perm(
    ob,
):  # get the permutation of an object, return default if the perm is empty
    return true_permutation(ob.nwo)


def is_windows():
    return platform.system() == "Windows"

def is_corinth(context=None):
    if context is None:
        context = bpy.context
    project = get_project(get_scene_props().scene_project)
    return bool(project and project.corinth)

def deselect_all_objects():
    bpy.ops.object.select_all(action="DESELECT")


def select_all_objects():
    bpy.ops.object.select_all(action="SELECT")


def set_active_object(ob: bpy.types.Object):
    ob.hide_select = False
    ob.hide_set(False)
    bpy.context.view_layer.objects.active = ob

def get_active_object():
    return bpy.context.view_layer.objects.active

def get_asset_info(filepath=""):
    if not filepath:
        filepath = get_scene_props().sidecar_path
    asset_path = os.path.dirname(filepath).lower()
    asset = os_sep_partition(asset_path, True)

    return asset_path, asset

def get_asset_path():
    """Returns the path to the asset folder."""
    return str(Path(relative_path(get_scene_props().sidecar_path)).parent)

def relative_path(path: str | Path):
    """Gets the tag/data relative path of the given filepath"""
    path = Path(path)
    tags_path = Path(get_tags_path())
    data_path = Path(get_data_path())
    if path.is_relative_to(tags_path):
        return str(path.relative_to(tags_path))
    elif path.is_relative_to(data_path):
        return str(path.relative_to(data_path))
    
    return str(path)


def get_asset_path_full(tags=False):
    """Returns the full system path to the asset folder. For tags, add a True arg to the function call"""
    if not get_scene_props().sidecar_path:
        return None
    asset_path = get_scene_props().sidecar_path.rpartition(os.sep)[0].lower()
    if tags:
        return str(Path(get_tags_path(), asset_path))
    else:
        return str(Path(get_data_path(), asset_path))
    
def get_asset_name():
    if not get_scene_props().sidecar_path:
        return None
    return Path(get_asset_path()).name

# -------------------------------------------------------------------------------------------------------------------


def vector_str(velocity):
    x = round(velocity.x, 11)
    y = round(velocity.y, 11)
    z = round(velocity.z, 11)
    return f"{str(x)} {str(y)} {str(z)}"

def vector(velocity):
    x = velocity.x
    y = velocity.y
    z = velocity.z
    return 1, x, y, z

def color_3p_str(color):
    red = linear_to_srgb(color.r)
    green = linear_to_srgb(color.g)
    blue = linear_to_srgb(color.b)
    return f"{jstr(red)} {jstr(green)} {jstr(blue)}"


def color_3p(color):
    red = linear_to_srgb(color.r)
    green = linear_to_srgb(color.g)
    blue = linear_to_srgb(color.b)
    return red, green, blue

def color_3p_int(color):
    red = color.r * 255
    green = color.g * 255
    blue = color.b * 255
    return red, green, blue

def color_rgba_str(color):
    red = linear_to_srgb(color[0])
    green = linear_to_srgb(color[1])
    blue = linear_to_srgb(color[2])
    alpha = linear_to_srgb(color[3])
    return f"{jstr(red)} {jstr(green)} {jstr(blue)} {jstr(alpha)}"

def color_rgba(color) -> tuple:
    red = linear_to_srgb(color[0])
    green = linear_to_srgb(color[1])
    blue = linear_to_srgb(color[2])
    alpha = linear_to_srgb(color[3])
    return red, green, blue, alpha

def color_argb_str(color):
    red = linear_to_srgb(color[0])
    green = linear_to_srgb(color[1])
    blue = linear_to_srgb(color[2])
    alpha = linear_to_srgb(color[3])
    return f"{jstr(alpha)} {jstr(red)} {jstr(green)} {jstr(blue)}"

def color_argb(color) -> tuple:
    red = linear_to_srgb(color[0])
    green = linear_to_srgb(color[1])
    blue = linear_to_srgb(color[2])
    alpha = linear_to_srgb(color[3])
    return alpha, red, green, blue

def linear_to_srgb(v):
    # if linear <= 0.0031308:
    #     return 12.92 * linear
    # else:
    #     return 1.055 * (linear ** (1/2.4)) - 0.055
    return v ** (1 / 2.2)
    
def srgb_to_linear(v):
    # if srgb <= 0.04045:
    #     return srgb / 12.92
    # else:
    #     return ((srgb + 0.055) / 1.055) ** 2.4
    return v ** 2.2
    
def linear_to_xrgb(v):
    return v ** (1 / 1.95)
    
def xrgb_to_linear(v):
    return v ** 1.95

def bool_str(bool_var):
    """Returns a boolean as a string. 1 if true, 0 if false"""
    if bool_var:
        return "1"
    else:
        return "0"


def radius_str(ob, pill=False, scale=1):
    """Returns the radius of a sphere (or a pill if second arg is True) as a string"""
    if pill:
        diameter = max(ob.dimensions.x, ob.dimensions.y)
    else:
        diameter = max(ob.dimensions)

    radius = diameter / 2.0

    return jstr(radius * scale)

def radius(ob, pill=False, scale=1):
    """Returns the radius of a sphere (or a pill if second arg is True) as a string"""
    if pill:
        diameter = max(ob.dimensions.x, ob.dimensions.y)
    else:
        diameter = max(ob.dimensions)

    radius = diameter / 2.0

    return radius * scale


def jstr(number):
    """Takes a number, rounds it to six decimal places and returns it as a string"""
    
    return format(round(number, 6), 'f')

def true_region(halo):
    locked = halo.region_name_locked
    if locked:
        return locked.lower()
    else:
        return halo.region_name.lower()

def true_permutation(halo):
    locked = halo.permutation_name_locked
    if locked:
        return locked.lower()
    else:
        return halo.permutation_name.lower()

def clean_tag_path(path, file_ext=None):
    """Cleans a path and attempts to make it appropriate for reading by Tool. Can accept a file extension (without a period) to force the existing one if it exists to be replaced"""
    path = path.strip('. "\'')
    if not path:
        return ""
    path = Path(path)
    if file_ext and not file_ext.startswith('.'):
        file_ext = '.' + file_ext
    # If a file ext is provided, replace the existing one / add it
    if file_ext is not None:
        path = path.with_suffix(file_ext)
    # attempt to make path tag relative
    path = relative_path(path)
    return path

def is_shared(ob):
    return true_region(ob.nwo) == "shared"

def shortest_string(*strings):
    """Takes strings and returns the shortest non null string"""
    string_list = [*strings]
    temp_string = ""
    while temp_string == "" and len(string_list) > 0:
        temp_string = min(string_list, key=len)
        string_list.remove(temp_string)

    return temp_string

def print_box(text, line_char="-", char_count=100):
    """Prints the specified text surrounded by lines created with the specified character. Optionally define the number of charactrers to repeat per line"""
    side_char_count = (char_count - len(text) - 2) // 2
    side_char_count = max(side_char_count, 0)
    side_fix = 0
    if side_char_count > 1:
        side_fix = (
            1
            if (char_count - len(text) - 2) // 2 != (char_count - len(text) - 2) / 2
            else 0
        )
    print(line_char * char_count)
    print(
        f"{line_char * side_char_count} {text} {line_char * (side_char_count + side_fix)}"
    )
    print(line_char * char_count)
    
def set_tool_event_level(event_level):
    try:
        with open(Path(get_project_path(), "bonobo_init.txt"), "w") as init:
            if event_level == 'NONE':
                init.write("events_enabled 0\n")
            else:
                level_txt = event_level.lower()
                init.write("events_enabled 1\n")
                init.write(f"events_global_display {level_txt}\n")
                init.write(f"events_global_log {level_txt}\n")
                init.write(f"events_global_debugger {level_txt}\n")
    except:
        print("Unable to replace bonobo_init.txt to set event level. It is currently read only")

def run_tool(tool_args: list, in_background=False, null_output=False, event_level=None, force_tool=False, log_file=None, force_tool_fast=False, tool_patches=None):
    """Runs Tool using the specified function and arguments. Do not include 'tool' in the args passed"""
    project_dir = get_project_path()
    os.chdir(project_dir)
    if force_tool:
        tool_type = "tool"
    elif force_tool_fast:
        tool_type = "tool_fast"
    else:
        tool_type = get_tool_type()

    command = [str(Path(project_dir, tool_type).with_suffix(".exe")), *[str(arg) for arg in tool_args]]
    # print(subprocess.list2cmdline(command))
    
    log_warnings = event_level == 'LOG'
    tmp_log = None
    if log_warnings:
        tmp_log = Path(tempfile.gettempdir(), "halo_errors.txt")
    if event_level is not None and event_level not in {'DEFAULT', 'LOG'}:
        set_tool_event_level(event_level)
    
    if in_background:
        if log_file:
            return _popen_tool(command, project_dir, stdout=log_file, stderr=log_file, tool_patches=tool_patches)
        elif null_output:
            return _popen_tool(command, project_dir, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, tool_patches=tool_patches)
        elif log_warnings:
            file = open(tmp_log, "w")
            try:
                return _popen_tool(command, project_dir, stderr=file, tool_patches=tool_patches)
            finally:
                file.close()
        else:
            return _popen_tool(command, project_dir, tool_patches=tool_patches)
    else:
        if null_output:
            return _check_call_tool(command, project_dir, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, tool_patches=tool_patches)
        elif log_warnings:
            with open(tmp_log, "w") as file:
                result = _check_call_tool(command, project_dir, stderr=file, tool_patches=tool_patches)
                
            if tmp_log.exists() and os.path.getsize(tmp_log) > 0:
                os.startfile(tmp_log)
            return result
        else:
            return _check_call_tool(command, project_dir, tool_patches=tool_patches)


def _check_call_tool(command, cwd, stdout=None, stderr=None, tool_patches=None):
    process = _popen_tool(command, cwd, stdout=stdout, stderr=stderr, tool_patches=tool_patches)
    returncode = process.wait()
    if returncode:
        raise subprocess.CalledProcessError(returncode, command)
    return 0
        
def _stderr_reader(pipe, q):
    for line in iter(pipe.readline, b''):
        q.put(line)
    q.put(None)

class _ToolMemoryPatchError(RuntimeError):
    pass


_CREATE_SUSPENDED = 0x00000004
_DUPLICATE_SAME_ACCESS = 0x00000002
_HANDLE_FLAG_INHERIT = 0x00000001
_INFINITE = 0xFFFFFFFF
_INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
_PAGE_EXECUTE_READWRITE = 0x40
_STARTF_USESTDHANDLES = 0x00000100
_STD_INPUT_HANDLE = -10
_STD_OUTPUT_HANDLE = -11
_STD_ERROR_HANDLE = -12
_STILL_ACTIVE = 259
_WAIT_FAILED = 0xFFFFFFFF
_WAIT_TIMEOUT = 0x00000102

_windows_kernel32 = None
_windows_ntdll = None


class _SECURITY_ATTRIBUTES(ctypes.Structure):
    _fields_ = [
        ("nLength", wintypes.DWORD),
        ("lpSecurityDescriptor", ctypes.c_void_p),
        ("bInheritHandle", wintypes.BOOL),
    ]


class _STARTUPINFO(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD),
        ("lpReserved", wintypes.LPWSTR),
        ("lpDesktop", wintypes.LPWSTR),
        ("lpTitle", wintypes.LPWSTR),
        ("dwX", wintypes.DWORD),
        ("dwY", wintypes.DWORD),
        ("dwXSize", wintypes.DWORD),
        ("dwYSize", wintypes.DWORD),
        ("dwXCountChars", wintypes.DWORD),
        ("dwYCountChars", wintypes.DWORD),
        ("dwFillAttribute", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("wShowWindow", wintypes.WORD),
        ("cbReserved2", wintypes.WORD),
        ("lpReserved2", ctypes.c_void_p),
        ("hStdInput", wintypes.HANDLE),
        ("hStdOutput", wintypes.HANDLE),
        ("hStdError", wintypes.HANDLE),
    ]


class _PROCESS_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("hProcess", wintypes.HANDLE),
        ("hThread", wintypes.HANDLE),
        ("dwProcessId", wintypes.DWORD),
        ("dwThreadId", wintypes.DWORD),
    ]


class _PROCESS_BASIC_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("Reserved1", ctypes.c_void_p),
        ("PebBaseAddress", ctypes.c_void_p),
        ("Reserved2_0", ctypes.c_void_p),
        ("Reserved2_1", ctypes.c_void_p),
        ("UniqueProcessId", ctypes.c_void_p),
        ("Reserved3", ctypes.c_void_p),
    ]


class _PatchedToolProcess:
    def __init__(self, process_handle, pid, stdout_file=None, stderr_file=None):
        self._process_handle = process_handle
        self.pid = pid
        self.stdout = stdout_file
        self.stderr = stderr_file
        self.returncode = None

    def poll(self):
        if self.returncode is not None:
            return self.returncode

        kernel32, _ntdll = _windows_patch_api()
        code = wintypes.DWORD()
        _check_windows_call(kernel32.GetExitCodeProcess(self._process_handle, ctypes.byref(code)))
        if code.value == _STILL_ACTIVE:
            return None

        self.returncode = code.value
        return self.returncode

    def wait(self, timeout=None):
        kernel32, _ntdll = _windows_patch_api()
        milliseconds = _INFINITE if timeout is None else max(0, int(timeout * 1000))
        result = kernel32.WaitForSingleObject(self._process_handle, milliseconds)
        if result == _WAIT_TIMEOUT:
            raise subprocess.TimeoutExpired(self.pid, timeout)
        if result == _WAIT_FAILED:
            raise ctypes.WinError(ctypes.get_last_error())
        return self.poll()

    def kill(self):
        kernel32, _ntdll = _windows_patch_api()
        kernel32.TerminateProcess(self._process_handle, 1)
        self.returncode = 1

    def __del__(self):
        try:
            if self.stdout is not None:
                self.stdout.close()
            if self.stderr is not None:
                self.stderr.close()
        except Exception:
            pass
        try:
            if self._process_handle:
                kernel32, _ntdll = _windows_patch_api()
                kernel32.CloseHandle(self._process_handle)
                self._process_handle = None
        except Exception:
            pass


def _windows_patch_api():
    global _windows_kernel32, _windows_ntdll
    if _windows_kernel32 is None:
        _windows_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        _windows_ntdll = ctypes.WinDLL("ntdll", use_last_error=True)
        kernel32 = _windows_kernel32
        ntdll = _windows_ntdll

        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel32.CreatePipe.argtypes = [ctypes.POINTER(wintypes.HANDLE), ctypes.POINTER(wintypes.HANDLE), ctypes.POINTER(_SECURITY_ATTRIBUTES), wintypes.DWORD]
        kernel32.CreatePipe.restype = wintypes.BOOL
        kernel32.CreateProcessW.argtypes = [wintypes.LPCWSTR, wintypes.LPWSTR, ctypes.c_void_p, ctypes.c_void_p, wintypes.BOOL, wintypes.DWORD, ctypes.c_void_p, wintypes.LPCWSTR, ctypes.POINTER(_STARTUPINFO), ctypes.POINTER(_PROCESS_INFORMATION)]
        kernel32.CreateProcessW.restype = wintypes.BOOL
        kernel32.DuplicateHandle.argtypes = [wintypes.HANDLE, wintypes.HANDLE, wintypes.HANDLE, ctypes.POINTER(wintypes.HANDLE), wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel32.DuplicateHandle.restype = wintypes.BOOL
        kernel32.FlushInstructionCache.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_size_t]
        kernel32.GetCurrentProcess.restype = wintypes.HANDLE
        kernel32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel32.GetExitCodeProcess.restype = wintypes.BOOL
        kernel32.GetStdHandle.argtypes = [wintypes.DWORD]
        kernel32.GetStdHandle.restype = wintypes.HANDLE
        kernel32.ReadProcessMemory.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
        kernel32.ReadProcessMemory.restype = wintypes.BOOL
        kernel32.ResumeThread.argtypes = [wintypes.HANDLE]
        kernel32.ResumeThread.restype = wintypes.DWORD
        kernel32.SetHandleInformation.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.DWORD]
        kernel32.SetHandleInformation.restype = wintypes.BOOL
        kernel32.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
        kernel32.TerminateProcess.restype = wintypes.BOOL
        kernel32.VirtualProtectEx.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
        kernel32.VirtualProtectEx.restype = wintypes.BOOL
        kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel32.WaitForSingleObject.restype = wintypes.DWORD
        kernel32.WriteProcessMemory.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)]
        kernel32.WriteProcessMemory.restype = wintypes.BOOL
        ntdll.NtQueryInformationProcess.argtypes = [wintypes.HANDLE, wintypes.ULONG, ctypes.c_void_p, wintypes.ULONG, ctypes.POINTER(wintypes.ULONG)]
        ntdll.NtQueryInformationProcess.restype = wintypes.LONG

    return _windows_kernel32, _windows_ntdll


def _check_windows_call(result):
    if not result:
        raise ctypes.WinError(ctypes.get_last_error())


def _popen_tool(command, cwd, stdout=None, stderr=None, tool_patches=None):
    if tool_patches and os.name == "nt":
        return _create_patched_tool_process(command, cwd, stdout, stderr, tool_patches)

    return Popen(command, stdout=stdout, stderr=stderr, cwd=cwd)


def _create_patched_tool_process(command, cwd, stdout, stderr, tool_patches):
    kernel32, _ntdll = _windows_patch_api()
    startup = _STARTUPINFO()
    startup.cb = ctypes.sizeof(startup)
    process_info = _PROCESS_INFORMATION()
    stdout_file = None
    stderr_file = None
    handles_to_close = []
    files_to_close = []
    inherit_handles = False

    try:
        if stdout is not None or stderr is not None:
            inherit_handles = True
            startup.dwFlags |= _STARTF_USESTDHANDLES
            startup.hStdInput = _stdio_child_handle(None, _STD_INPUT_HANDLE, "rb", handles_to_close, files_to_close)[0]
            startup.hStdOutput, stdout_file = _stdio_child_handle(stdout, _STD_OUTPUT_HANDLE, "wb", handles_to_close, files_to_close)
            startup.hStdError, stderr_file = _stdio_child_handle(stderr, _STD_ERROR_HANDLE, "wb", handles_to_close, files_to_close)

        command_line = subprocess.list2cmdline([str(arg) for arg in command])
        command_line_buffer = ctypes.create_unicode_buffer(command_line)
        _check_windows_call(kernel32.CreateProcessW(
            str(command[0]),
            command_line_buffer,
            None,
            None,
            inherit_handles,
            _CREATE_SUSPENDED,
            None,
            str(cwd),
            ctypes.byref(startup),
            ctypes.byref(process_info),
        ))
    except Exception:
        for handle in handles_to_close:
            if handle:
                kernel32.CloseHandle(handle)
        for file in files_to_close:
            file.close()
        if stdout_file is not None:
            stdout_file.close()
        if stderr_file is not None:
            stderr_file.close()
        raise

    for handle in handles_to_close:
        if handle:
            kernel32.CloseHandle(handle)
    for file in files_to_close:
        file.close()

    try:
        _apply_tool_memory_patches(process_info.hProcess, Path(command[0]), tool_patches)
        if kernel32.ResumeThread(process_info.hThread) == 0xFFFFFFFF:
            raise ctypes.WinError(ctypes.get_last_error())
    except Exception as e:
        kernel32.TerminateProcess(process_info.hProcess, 1)
        kernel32.CloseHandle(process_info.hThread)
        kernel32.CloseHandle(process_info.hProcess)
        if stdout_file is not None:
            stdout_file.close()
        if stderr_file is not None:
            stderr_file.close()
        if isinstance(e, _ToolMemoryPatchError):
            raise
        raise _ToolMemoryPatchError(f"Failed to apply in-memory Reach Tool patch: {e}") from e

    kernel32.CloseHandle(process_info.hThread)
    return _PatchedToolProcess(process_info.hProcess, process_info.dwProcessId, stdout_file, stderr_file)


def _stdio_child_handle(stream, std_handle_id, devnull_mode, handles_to_close, files_to_close):
    import msvcrt

    kernel32, _ntdll = _windows_patch_api()
    if stream is subprocess.PIPE:
        read_pipe = wintypes.HANDLE()
        write_pipe = wintypes.HANDLE()
        security = _SECURITY_ATTRIBUTES()
        security.nLength = ctypes.sizeof(security)
        security.bInheritHandle = True
        _check_windows_call(kernel32.CreatePipe(ctypes.byref(read_pipe), ctypes.byref(write_pipe), ctypes.byref(security), 0))
        _check_windows_call(kernel32.SetHandleInformation(read_pipe, _HANDLE_FLAG_INHERIT, 0))
        fd = msvcrt.open_osfhandle(read_pipe.value, os.O_RDONLY | getattr(os, "O_BINARY", 0))
        handles_to_close.append(write_pipe)
        return write_pipe, os.fdopen(fd, "rb", buffering=0)

    if stream is subprocess.DEVNULL:
        file = open(os.devnull, devnull_mode)
        files_to_close.append(file)
        handle = _duplicate_inheritable_handle(msvcrt.get_osfhandle(file.fileno()))
        handles_to_close.append(handle)
        return handle, None

    if stream is not None:
        handle = _duplicate_inheritable_handle(msvcrt.get_osfhandle(stream.fileno()))
        handles_to_close.append(handle)
        return handle, None

    std_handle = kernel32.GetStdHandle(std_handle_id)
    if std_handle and std_handle != _INVALID_HANDLE_VALUE:
        handle = _duplicate_inheritable_handle(std_handle)
        handles_to_close.append(handle)
        return handle, None

    file = open(os.devnull, devnull_mode)
    files_to_close.append(file)
    handle = _duplicate_inheritable_handle(msvcrt.get_osfhandle(file.fileno()))
    handles_to_close.append(handle)
    return handle, None


def _duplicate_inheritable_handle(handle):
    kernel32, _ntdll = _windows_patch_api()
    if not handle or handle == _INVALID_HANDLE_VALUE:
        return wintypes.HANDLE()

    current_process = kernel32.GetCurrentProcess()
    duplicate = wintypes.HANDLE()
    _check_windows_call(kernel32.DuplicateHandle(
        current_process,
        handle,
        current_process,
        ctypes.byref(duplicate),
        0,
        True,
        _DUPLICATE_SAME_ACCESS,
    ))
    return duplicate


def _apply_tool_memory_patches(process_handle, tool_path: Path, tool_patches):
    image_base = _get_remote_image_base(process_handle)
    sections = _read_pe_sections(tool_path)
    for offset, patch, original in tool_patches:
        _write_tool_memory_patch(process_handle, image_base, sections, offset, patch, original)


def _get_remote_image_base(process_handle):
    kernel32, ntdll = _windows_patch_api()
    process_info = _PROCESS_BASIC_INFORMATION()
    returned_length = wintypes.ULONG()
    status = ntdll.NtQueryInformationProcess(
        process_handle,
        0,
        ctypes.byref(process_info),
        ctypes.sizeof(process_info),
        ctypes.byref(returned_length),
    )
    if status != 0:
        raise _ToolMemoryPatchError(f"Failed to query Tool process information: 0x{status & 0xffffffff:X}")

    image_base = ctypes.c_void_p()
    bytes_read = ctypes.c_size_t()
    image_base_offset = 0x10 if ctypes.sizeof(ctypes.c_void_p) == 8 else 0x08
    _check_windows_call(kernel32.ReadProcessMemory(
        process_handle,
        ctypes.c_void_p((process_info.PebBaseAddress or 0) + image_base_offset),
        ctypes.byref(image_base),
        ctypes.sizeof(image_base),
        ctypes.byref(bytes_read),
    ))
    return image_base.value


def _read_pe_sections(tool_path: Path):
    data = tool_path.read_bytes()
    pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
    if data[pe_offset:pe_offset + 4] != b"PE\0\0":
        raise _ToolMemoryPatchError(f"Tool executable is not a valid PE file: {tool_path}")

    section_count = struct.unpack_from("<H", data, pe_offset + 6)[0]
    optional_header_size = struct.unpack_from("<H", data, pe_offset + 20)[0]
    section_table_offset = pe_offset + 24 + optional_header_size
    sections = []
    for section_index in range(section_count):
        section_offset = section_table_offset + section_index * 40
        virtual_size, virtual_address, raw_size, raw_pointer = struct.unpack_from("<IIII", data, section_offset + 8)
        sections.append((raw_pointer, raw_size, virtual_address, virtual_size))

    return sections


def _file_offset_to_rva(sections, offset):
    for raw_pointer, raw_size, virtual_address, _virtual_size in sections:
        if raw_pointer <= offset < raw_pointer + raw_size:
            return virtual_address + (offset - raw_pointer)

    raise _ToolMemoryPatchError(f"Tool patch offset 0x{offset:X} is not in a PE section")


def _write_tool_memory_patch(process_handle, image_base, sections, offset, patch, original):
    kernel32, _ntdll = _windows_patch_api()
    assert len(patch) == len(original)
    address = image_base + _file_offset_to_rva(sections, offset)
    current_buffer = (ctypes.c_ubyte * len(original))()
    bytes_read = ctypes.c_size_t()
    _check_windows_call(kernel32.ReadProcessMemory(
        process_handle,
        ctypes.c_void_p(address),
        current_buffer,
        len(original),
        ctypes.byref(bytes_read),
    ))
    current = bytes(current_buffer)
    if current == patch:
        return
    if current != original:
        raise _ToolMemoryPatchError(
            f"Tool memory patch at 0x{offset:X} expected {original.hex(' ')} but found {current.hex(' ')}"
        )

    old_protect = wintypes.DWORD()
    _check_windows_call(kernel32.VirtualProtectEx(
        process_handle,
        ctypes.c_void_p(address),
        len(patch),
        _PAGE_EXECUTE_READWRITE,
        ctypes.byref(old_protect),
    ))
    try:
        patch_buffer = (ctypes.c_ubyte * len(patch)).from_buffer_copy(patch)
        bytes_written = ctypes.c_size_t()
        _check_windows_call(kernel32.WriteProcessMemory(
            process_handle,
            ctypes.c_void_p(address),
            patch_buffer,
            len(patch),
            ctypes.byref(bytes_written),
        ))
        kernel32.FlushInstructionCache(process_handle, ctypes.c_void_p(address), len(patch))
    finally:
        restored_protect = wintypes.DWORD()
        kernel32.VirtualProtectEx(
            process_handle,
            ctypes.c_void_p(address),
            len(patch),
            old_protect.value,
            ctypes.byref(restored_protect),
        )

def run_tool_sidecar(tool_args: list, event_level='WARNING', tool_patches=None):
    """Runs Tool using the specified function and arguments. Do not include 'tool' in the args passed"""
    failed = False
    scene_nwo = get_scene_props()
    frame_events_blender_authored = scene_nwo.frame_events_from_blender
    project_dir = get_project_path()
    tags_dir = get_tags_path()
    os.chdir(project_dir)
    tool_path = Path(project_dir, get_tool_type()).with_suffix(".exe")
    command = [str(tool_path), *[str(arg) for arg in tool_args]]
    # print(subprocess.list2cmdline(command))
    error = ""
    cull_warnings = event_level == 'DEFAULT'
    log_warnings = event_level == 'LOG'
    tmp_log = None
    try:
        if cull_warnings:
            p = _popen_tool(command, project_dir, stderr=subprocess.PIPE, tool_patches=tool_patches)
        elif log_warnings:
            tmp_log = Path(tempfile.gettempdir(), "halo_errors.txt")
            with open(tmp_log, "w") as file:
                p = _popen_tool(command, project_dir, stderr=file, tool_patches=tool_patches)
        else:
            p = _popen_tool(command, project_dir, tool_patches=tool_patches)
    except _ToolMemoryPatchError as e:
        return True, str(e)
    except OSError as e:
        if getattr(e, "winerror", None) == 4551:
            return True, (
                "Windows Application Control blocked Reach Tool before Foundry could launch it. "
                "Restore the original Tool executable and try again."
            )
        raise
    # error_log = os.path.join(asset_path, "error.log")
    if not (cull_warnings or log_warnings):
        set_tool_event_level(event_level)
        
    composite_timeout_active = False
    last_activity_time = time.time()
    timeout_seconds = 10

    q = queue.Queue()
    if cull_warnings:
        t = threading.Thread(target=_stderr_reader, args=(p.stderr, q), daemon=True)
        t.start()
            
    # Read and print stderr contents while writing to the file
    if cull_warnings:
        while True:
            now = time.time()

            if composite_timeout_active and (now - last_activity_time) > timeout_seconds:
                p.kill()
                raise RuntimeError("Failed to parse composite animation")

            try:
                item = q.get(timeout=0.1)
            except queue.Empty:
                item = None

            if item is None:
                if p.poll() is not None and q.empty():
                    break
                continue

            line = item.decode().rstrip("\n")

            if failed and not error:
                error = get_error_explanation(line)

            elif not failed and is_error_line(line):
                print_error(line)
                failed = True

            else:
                if "(skipping tangent-space calculations)" in line or "if it is a decorator" in line:
                    # this really shouldn't be a warning, so don't print/write it
                    continue
                elif "but has flags that only make sense on render geometry" in line:
                    # Pointless error and just ends up being spam
                    continue
                elif "Uncompressed vertices are not supported for meshes with type" in line:
                    # This is just incorrect and outputs when a mesh is a valid type for uncompressed
                    # Export logic prevents uncompressed from being applied to invalid types
                    continue
                elif "which only makes sense on two-sided (or one sided transparent) geometry" in line:
                    # Annonying and outputs on things like collision geometry when it does not matter
                    continue
                elif "Do you really want this?" in line:
                    # No but don't whine about shaders on imported geometry
                    continue
                elif "Failed to find any animated nodes" in line: # 07/01/2025 removed and "idle" from this
                    # Skip because we often want the idle to not have animation e.g. for vehicles
                    continue
                elif "graph was imported with old codec which is no longer supported!" in line:
                    # Skip since the animation import codec is fine
                    continue
                elif "animation graph update failed!" in line:
                    # Always outputs on new animation graph creation
                    continue
                elif "Mesh marked to include per-vertex alpha has entirely opaque values!" in line:
                    # Always outputs on new animation graph creation
                    continue
                elif "sidecar does not specify a model path" in line:
                    # Invalid error for cinematic sidecars
                    continue
                elif "unrecognized output tag type cinematic_scene for object cinematic_scene" in line:
                    # Bungie what you doing
                    continue
                elif "Suspension marker(s)" in line:
                    # Useless warning. Tool is unable to automatically calculate suspension ground depth
                    continue
                elif frame_events_blender_authored and "removing orphaned frame event" in line:
                    # Frame events are Blender controlled, ignore
                    continue
                elif "tags: tag_save: couldn't overwrite" in line:
                    fix_tag_copy_fail(project_dir, tags_dir, line)
                elif "animation:import: processing composite" in line:
                    print(line)
                    composite_timeout_active = True
                    last_activity_time = now
                else:
                    composite_timeout_active = False
                    # need to handle animation stuff. Most animation output is written to stderr...
                    if line.startswith("animation:import:"):
                        warning_line = line.rpartition("animation:import: ")[2]
                        if warning_line.startswith("Failed to extract"):
                            print_warning(line)
                        elif warning_line.startswith("Failed"):
                            print_error(line)
                        else:
                            print(line)
                    else:
                        print_warning(line)
                        
        if composite_timeout_active:
            while True:
                if (time.time() - last_activity_time) > timeout_seconds:
                    raise RuntimeError("Failed to parse composite animation")
                if p.poll() is not None:
                    break
                time.sleep(0.1)

    p.wait()
    
    if tmp_log is not None and tmp_log.exists() and os.path.getsize(tmp_log) > 0:
        os.startfile(tmp_log)

    return failed, error


def is_error_line(line):
    return line.startswith("IMPORT FAILED") or "### ASSERTION FAILED" in line or "FATAL ERROR!" in line

def get_error_explanation(line):
    if "plane3d_passes_through_point" in line:
        pattern = r'\(structure_bsp[^)]*\bpoop\s+(\S+)'
        match = re.search(pattern, line)
        mesh_name = match.group(1) if match else None
        if mesh_name is None:
            return "Tool failed to process an object. Usually this happens with large geometry whose origin is far from the geometry itself. Try setting origin to object or otherwise adjusting the origin and geometry"
        else:
            return f"Tool failed to process the instanced geometry object [{mesh_name.strip(' )')}]. Usually this happens with large geometry whose origin is far from the geometry itself. Try setting origin to object or otherwise adjusting the origin and geometry"
    elif "no corresponding model region (will not be collideable)" in line:
        return "You need to add a render mesh that has the region referenced above or change the named region on collision meshes to one in use by any render mesh"
    elif "no corresponding model region (will not be physical)" in line:
        return "You need to add a render mesh that has the region referenced above or change the named region on physics meshes to one in use by any render mesh"
    
    
    return ""

def fix_tag_copy_fail(project_dir, tags_dir, line):
    match = re.search(r"couldn't overwrite '([^']+)' with '([^']+)'", line)
    if not match:
        return None, None

    dest, tmp = match.groups()
    
    tmp_file = Path(project_dir, tmp)
    tag_file = Path(tags_dir, dest)
    if not tmp_file.exists():
        return print_warning(line)

    try:
        copy_file(tmp_file, tag_file)
        print(f"Fixed tag copy fail: {tmp_file} copied to {tag_file}")
    except:
        print("failure...")
        print_warning(line)

def set_project_in_registry():
    """Sets the current project in the users registry"""
    key_path = r"SOFTWARE\Halo\Projects"
    name = get_scene_props().scene_project
    if not name:
        return
    # Get project name
    project = get_project(name)
    project_name = project.project_name
    try:
        # Open the registry key
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_WRITE) as key:
            winreg.SetValueEx(key, "Current", 0, winreg.REG_SZ, project_name)
    except:
        pass

def run_ek_cmd(args: list, in_background=False):
    """Executes a cmd line argument at the root editing kit directory"""
    # Set the current project in the users registry, this avoids the switch project prompt
    set_project_in_registry()
    os.chdir(get_project_path())
    command = f"""{' '.join(f'"{arg}"' for arg in args)}"""
    # print(command)
    if in_background:
        return Popen(command)
    else:
        try:
            return check_call(command)
        except Exception as e:
            return e

def dot_partition(target_string, get_suffix=False):
    """Returns a string after partitioning it using period. If the returned string will be empty, the function will instead return the argument passed"""
    if get_suffix:
        return shortest_string(target_string.rpartition(".")[2], target_string)
    else:
        return shortest_string(target_string.rpartition(".")[0], target_string)
    
def any_partition(target_string, part, get_suffix=False):
    """Returns a string after partitioning it using the given string. If the returned string will be empty, the function will instead return the argument passed"""
    if get_suffix:
        return shortest_string(target_string.rpartition(part)[2], target_string)
    else:
        return shortest_string(target_string.rpartition(part)[0], target_string)
    
def space_partition(target_string, get_suffix=False):
    """Returns a string after partitioning it using space. If the returned string will be empty, the function will instead return the argument passed"""
    if get_suffix:
        return shortest_string(target_string.rpartition(" ")[2], target_string)
    else:
        return shortest_string(target_string.rpartition(" ")[0], target_string)
    
def os_sep_partition(target_string, get_suffix=False):
    """Returns a string after partitioning it using the OS separator. If the returned string will be empty, the function will instead return the argument passed"""
    if get_suffix:
        return shortest_string(target_string.rpartition(os.sep)[2], target_string)
    else:
        return shortest_string(target_string.rpartition(os.sep)[0], target_string)


def check_path(filePath):
    return filePath.lower().startswith(os.path.join(get_project_path().lower(), "data"))


def valid_nwo_asset(context=None):
    """Returns true if this blender scene is a valid NWO asset"""
    if not context:
        context = bpy.context
    return get_scene_props().is_valid_asset

def nwo_asset_type():
    """Returns the NWO asset type"""
    return get_scene_props().asset_type


######################################
# MANAGER STUFF
######################################


def get_collection_parent_chains(current_coll, all_collections):
    parents = [coll for coll in all_collections if current_coll in tuple(coll.children)]
    if not parents:
        return [[current_coll]]

    chains = []
    for parent in parents:
        for chain in get_collection_parent_chains(parent, all_collections):
            chains.append([current_coll, *chain])

    return chains


def get_coll_prefix(coll, prefixes):
    for prefix in prefixes:
        if coll.startswith(prefix):
            return prefix

    return False


def get_prop_from_collection_chain(collection_list, valid_type):
    for c in collection_list:
        c_type = c.nwo.type
        if c_type != valid_type: continue
        match c_type:
            case 'region':
                return c.nwo.region or ''
            case 'permutation':
                return c.nwo.permutation or ''
            case 'exclude':
                return True

    return ''


def get_prop_from_collection(ob, valid_type):
    if bpy.context.scene.collection.children:
        all_collections = tuple(bpy.context.scene.collection.children_recursive)
        context_collection = getattr(bpy.context, "collection", None)
        context_matches = []
        matches = []
        for c in all_collections:
            if ob in tuple(c.objects):
                for collection_list in get_collection_parent_chains(c, all_collections):
                    value = get_prop_from_collection_chain(collection_list, valid_type)
                    if valid_type == 'exclude' and value:
                        return True
                    matches.append(value)
                    if context_collection in collection_list:
                        context_matches.append(value)

        if context_matches:
            return context_matches[-1]
        if matches:
            return matches[-1]
            
    return ''

def print_warning(string="Warning"):
    print("\033[93m" + string + "\033[0m")


def print_error(string="Error"):
    print("\033[91m" + string + "\033[0m")

def get_valid_shader_name(string):
    shader_name = get_valid_material_name(string)
    return cull_invalid_chars(shader_name)


def get_valid_material_name(material_name):
    """Removes characters from a blender material name that would have been used in legacy material properties"""
    material_parts = material_name.split(" ")
    # clean material name
    if len(material_parts) > 1:
        material_name = material_parts[1]
    else:
        material_name = material_parts[0]
    # ignore if duplicate name
    dot_partition(material_name)
    # ignore material suffixes
    material_name = material_name.rstrip("%#?!@*$^-&=.;)><|~({]}['")
    # dot partition again in case a pesky dot remains
    return dot_partition(material_name).lower()


def cull_invalid_chars(string):
    """Calls invalid characters from a string to make a valid path. Spaces are replaced with underscores"""
    path = string.replace(" ", "_")
    path = path.replace("<", "")
    path = path.replace(">", "")
    path = path.replace(":", "")
    path = path.replace('"', "")
    path = path.replace("/", "")
    path = path.replace("\\", "")
    path = path.replace("|", "")
    path = path.replace("?", "")
    path = path.replace("*", "")

    return path


def protected_material_name(material_name):
    """Returns True if the passed material name is equal to a protected material"""
    return material_name.startswith(PROTECTED_MATERIALS)

############ FOUNDRY UI UTILS
def mesh_object(ob):
    return ob.type in blender_object_types_mesh


def formalise_string(string):
    formal_string = string.replace("_", " ")
    return formal_string.title()


def bpy_enum(name, index):
    return (name, formalise_string(name), "", "", index)


def bpy_enum_list(name, index):
    return (name, name, "", "", index)


def bpy_enum_seam(name, index):
    return (name, name, "", get_icon_id("seam"), index)

def export_objects(context):
    return {ob for ob in context.view_layer.objects if not ob.nwo.ignore_for_export}

def export_objects_no_arm():
    context = bpy.context
    export_obs = []
    for ob in context.view_layer.objects:
        if (
            ob.nwo.export_this
            and ob.type != "ARMATURE"
            and not any(
                coll.nwo.type == 'exclude' for coll in ob.users_collection
            )
        ):
            export_obs.append(ob)

    return export_obs

def export_objects_mesh_only():
    context = bpy.context
    export_obs = []
    for ob in context.view_layer.objects:
        if (
            ob.nwo.export_this
            and is_mesh(ob)
            and not any(
                coll.nwo.type == 'exclude' for coll in ob.users_collection
            )
        ):
            export_obs.append(ob)

    return export_obs


def sort_alphanum(var_list):
    return sorted(
        var_list,
        key=lambda item: (
            int(item.partition(" ")[0]) if item[0].isdigit() else float("inf"),
            item,
        ),
    )


def closest_bsp_object(context, ob, valid_targets=None):
    """
    Returns the BSP hit by a ray cast from the seam backface.
    """
    if ob is None or ob.type not in VALID_MESHES or ob.data is None:
        return None

    depsgraph = context.evaluated_depsgraph_get()
    ray_offset = 0.001
    closest_bsp = None
    closest_distance = float("inf")

    def object_bvh(target_object):
        eval_ob = target_object.evaluated_get(depsgraph)
        mesh = None
        try:
            mesh = eval_ob.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
            if mesh is None or not mesh.polygons:
                return None

            mesh.calc_loop_triangles()
            if not mesh.loop_triangles:
                return None

            matrix_world = target_object.matrix_world or Matrix.Identity(4)
            verts = [matrix_world @ vertex.co for vertex in mesh.vertices]
            flip_winding = matrix_world.is_negative
            if getattr(target_object, "invert_topology", False):
                flip_winding = not flip_winding

            tris = []
            for tri in mesh.loop_triangles:
                indices = tuple(tri.vertices)
                if flip_winding:
                    indices = indices[0], indices[2], indices[1]
                tris.append(indices)

            if not tris:
                return None

            return bvhtree.BVHTree.FromPolygons(verts, tris)
        finally:
            if mesh is not None:
                eval_ob.to_mesh_clear()

    def backface_rays(source_object):
        eval_ob = source_object.evaluated_get(depsgraph)
        mesh = None
        rays = []
        try:
            mesh = eval_ob.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
            if mesh is None or not mesh.polygons:
                return rays

            matrix_world = source_object.matrix_world or Matrix.Identity(4)
            normal_matrix = matrix_world.to_3x3().inverted_safe().transposed()
            flip_normal = matrix_world.is_negative
            if getattr(source_object, "invert_topology", False):
                flip_normal = not flip_normal

            for polygon in mesh.polygons:
                normal = normal_matrix @ polygon.normal
                if flip_normal:
                    normal.negate()

                if not normal.length_squared:
                    continue

                normal.normalize()
                direction = -normal
                origin = matrix_world @ polygon.center - direction * ray_offset
                rays.append((origin, direction))

            return rays
        finally:
            if mesh is not None:
                eval_ob.to_mesh_clear()

    rays = backface_rays(ob)
    if not rays:
        return None

    if not valid_targets:
        valid_targets = {ob for ob in export_objects(context) if ob.type in VALID_MESHES}

    for target_ob in valid_targets:
        if (
            ob != target_ob
            and target_ob.type in VALID_MESHES
            and target_ob.data is not None
            and target_ob.data.nwo.mesh_type == "_connected_geometry_mesh_type_structure"
            and true_region(target_ob.nwo) != true_region(ob.nwo)
        ):
            bvh = object_bvh(target_ob)
            if bvh is None:
                continue

            for origin, direction in rays:
                loc, _normal, _index, distance = bvh.ray_cast(origin, direction)
                if loc is None:
                    continue

                if distance < closest_distance:
                    closest_distance = distance
                    closest_bsp = target_ob
    
    return closest_bsp


def object_median_point(ob):
    """Returns the median point of a blender object"""
    me = ob.data
    verts = [v.co for v in me.vertices]
    return ob.matrix_world @ sum(verts, Vector()) / len(verts)


def attribute_face_count(mesh: bpy.types.Mesh, attribute: bpy.types.Attribute) -> int:
    """Returns the number of faces in a bmesh that have an face int custom_layer with a value greater than 0"""
    array = np.zeros(len(mesh.polygons), dtype=np.int8)
    attribute.data.foreach_get("value", array)
    return len(np.nonzero(array)[0])

def layer_faces(bm, face_attribute):
    """Returns the faces in a bmesh that have an face int custom_layer with a value greater than 0"""
    if face_attribute:
        return [face for face in bm.faces if face[face_attribute]]
    
def layer_face_count(bm, face_attribute):
    """Returns the faces in a bmesh that have an face int custom_layer with a value greater than 0"""
    if face_attribute:
        return len([face for face in bm.faces if face[face_attribute]])
    
def layer_face_indices(bm, face_attribute):
    """Returns the face indices in a bmesh that have an face int custom_layer with a value greater than 0"""
    if face_attribute:
        return {face.index for face in bm.faces if face[face_attribute]}

def random_color():
    global iter_css
    rgb = next(iter_css, None)
    if rgb is None:
        iter_css = iter(set(css_colors.values()))
        return random_color()
    
    return rgb


def nwo_enum(enum_name, display_name, description, icon="", index=-1, custom_icon=True) -> tuple:
    """Returns a single enum entry for use with bpy EnumPropertys"""
    full_enum = icon != "" or index != -1
    if full_enum:
        if custom_icon:
            return (
                enum_name,
                display_name,
                description,
                get_icon_id(icon),
                index,
            )

        return (enum_name, display_name, description, icon, index)

    return (enum_name, display_name, description)


def area_redraw(context):
    windows = context.window_manager.windows
    for window in windows:
        areas = window.screen.areas
        for area in areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def delete_object_list(context, object_list):
    """Deletes the given object list from the blend scene"""
    override = context.copy()
    override["selected_objects"] = object_list
    with context.temp_override(**override):
        bpy.ops.object.delete()


def disable_prints():
    """Disables console prints"""
    sys.stdout = open(os.devnull, "w")


def enable_prints():
    """Enables console prints"""
    sys.stdout = sys.__stdout__
    
class MutePrints():
    def __enter__(self):
        disable_prints()
        return self
        
    def __exit__(self, exc_type, exc_value, traceback):
        enable_prints()
        
class ExportManager():
    def __enter__(self):
        get_scene_props().export_in_progress = True
        return self
        
    def __exit__(self, exc_type, exc_value, traceback):
        get_scene_props().export_in_progress = False

def update_progress(job_title, progress):
    if progress <= 1:
        length = 20
        block = int(round(length * progress))
        msg = "\r{0}: {1} {2}%".format(
            job_title,
            "■" * block + "□" * (length - block),
            round(progress * 100, 2),
        )
        if progress >= 1:
            msg += "     \r\n"
        sys.stdout.write(msg)
        sys.stdout.flush()

def update_job(job_title, progress):
    msg = "\r{0}".format(job_title)
    if progress < 1:
        msg += "..."
    else:
        msg += "     \r\n"

    sys.stdout.write(msg)
    sys.stdout.flush()


def update_job_count(message, spinner, completed, total):
    msg = "\r{0}".format(message)
    msg += f" ({completed} / {total}) "
    if completed < total:
        msg += f"{spinner}"
    else:
        msg += "     \r\n"

    sys.stdout.write(msg)
    sys.stdout.flush()
    
def job_for_spinner(message):
    message += "     \r\n"
    sys.stdout.write(message)
    sys.stdout.flush()

def poll_ui(selected_types) -> bool:
    scene_nwo = get_scene_props()
    asset_type = scene_nwo.asset_type

    return asset_type == 'resource' or asset_type in selected_types


def is_halo_object(ob) -> bool:
    return (
        ob
        and ob.type not in ("LATTICE", "LIGHT_PROBE", "SPEAKER", "CAMERA")
        and not (ob.type == "EMPTY" and ob.empty_display_type == "IMAGE")
        and poll_ui(
            (
                "model",
                "scenario",
                "sky",
                "decorator_set",
                "particle_model",
                "prefab",
                "animation",
            )
        )
    )


def has_mesh_props(ob) -> bool:
    valid_mesh_types = (
        "_connected_geometry_mesh_type_collision",
        "_connected_geometry_mesh_type_physics",
        "_connected_geometry_mesh_type_default",
        "_connected_geometry_mesh_type_structure",
        "_connected_geometry_mesh_type_object_instance",
        "_connected_geometry_mesh_type_water_surface",
    )
    nwo = ob.nwo
    return (
        ob
        and nwo.export_this
        and is_mesh(ob)
        and nwo.mesh_type in valid_mesh_types
    )


valid_mesh_types = (
    "_connected_geometry_mesh_type_default",
    "_connected_geometry_mesh_type_structure",
    '_connected_geometry_mesh_type_collision',
    '_connected_geometry_mesh_type_object_instance',
)

def has_face_props(ob) -> bool:
    return ob.type in VALID_MESHES and ob.nwo.mesh_type in valid_mesh_types

def has_shader_path(mat):
    """Returns whether the given material supports shader paths"""
    name = mat.name
    return not (mat.grease_pencil or name.startswith('+sky') or name in special_material_names or name in convention_material_names)

def get_halo_material_count() -> tuple:
    count = 0
    total = 0
    for mat in bpy.data.materials:
        nwo = mat.nwo
        if not has_shader_path(mat): continue
        nwo = mat.nwo
        if nwo.shader_path:
            count += 1

        total += 1

    return count, total

def validate_ek() -> str | None:
    """Returns an relevant error message if the current game does not reference a valid editing kit. Else returns None"""
    ek = Path(get_project_path())
    scene_project = get_scene_props().scene_project
    if not ek.exists():
        return f"{scene_project} Editing Kit path invalid"
    elif not Path(ek, get_tool_type()).with_suffix('.exe').exists():
        return f"Tool not found, please check that you have tool.exe within your {scene_project} directory"
    elif not Path(ek, "data").exists():
        return f"Editing Kit data folder not found. Please ensure your {scene_project} directory has a 'data' folder"
    elif not Path(ek, "bin", "ManagedBlam.dll").exists():
        return f"ManagedBlam not found in your {scene_project} bin folder, please ensure this exists"
    # elif not managed_blam.mb_operational:
    #     return 'Failed to load Managedblam.dll. Please check that your Halo Editing Kit is installed correctly'
    else:
        prefs = get_prefs()
        projects = prefs.projects
        for p in projects:
            if p.name == scene_project:
                if os.path.exists(p.project_path):
                    return
                return f'{p.name} project path does not exist'
        return 'Please select a project in Foundry Scene Properties'
    
# def foundry_update_check(current_version):
#     update_url = 'https://api.github.com/repos/iloveagoodcrisp/foundry-halo-blender-creation-kit/releases'
#     if not bpy.app.background:
#         try:
#             response = requests.get(update_url, timeout=1)
#             releases = response.json()
#             latest_release = releases[0]
#             latest_version = latest_release['tag_name']
#             if current_version < latest_version:
#                 return f"New Foundry version available: {latest_version}", True
#         except:
#             pass

#     return "Foundry is up to date", False

def unlink(ob):
    if ob.library is None:
        for c in list(ob.users_collection):
            c.objects.unlink(ob)

def set_object_mode(context):
    mode = context.mode

    if mode == "OBJECT":
        return

    if mode.startswith("EDIT") and not mode.endswith("GPENCIL"):
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
    else:
        match mode:
            case "POSE":
                bpy.ops.object.posemode_toggle()
            case "SCULPT":
                bpy.ops.sculpt.sculptmode_toggle()
            case "PAINT_WEIGHT":
                bpy.ops.paint.weight_paint_toggle()
            case "PAINT_VERTEX":
                bpy.ops.paint.vertex_paint_toggle()
            case "PAINT_TEXTURE":
                bpy.ops.paint.texture_paint_toggle()
            case "PARTICLE":
                bpy.ops.particle.particle_edit_toggle()
            case "PAINT_GPENCIL":
                bpy.ops.gpencil.paintmode_toggle()
            case "EDIT_GPENCIL":
                bpy.ops.gpencil.editmode_toggle()
            case "SCULPT_GPENCIL":
                bpy.ops.gpencil.sculptmode_toggle()
            case "WEIGHT_GPENCIL":
                bpy.ops.gpencil.weightmode_toggle()
            case "VERTEX_GPENCIL":
                bpy.ops.gpencil.vertexmode_toggle()
            case "SCULPT_CURVES":
                bpy.ops.curves.sculptmode_toggle()
                
def restore_mode(mode):
    if mode == "OBJECT":
        return

    if mode.startswith("EDIT") and not mode.endswith("GPENCIL"):
        bpy.ops.object.mode_set(mode='EDIT', toggle=False)
    else:
        match mode:
            case "POSE":
                bpy.ops.object.posemode_toggle()
            case "SCULPT":
                bpy.ops.sculpt.sculptmode_toggle()
            case "PAINT_WEIGHT":
                bpy.ops.paint.weight_paint_toggle()
            case "PAINT_VERTEX":
                bpy.ops.paint.vertex_paint_toggle()
            case "PAINT_TEXTURE":
                bpy.ops.paint.texture_paint_toggle()
            case "PARTICLE":
                bpy.ops.particle.particle_edit_toggle()
            case "PAINT_GPENCIL":
                bpy.ops.gpencil.paintmode_toggle()
            case "EDIT_GPENCIL":
                bpy.ops.gpencil.editmode_toggle()
            case "SCULPT_GPENCIL":
                bpy.ops.gpencil.sculptmode_toggle()
            case "WEIGHT_GPENCIL":
                bpy.ops.gpencil.weightmode_toggle()
            case "VERTEX_GPENCIL":
                bpy.ops.gpencil.vertexmode_toggle()
            case "SCULPT_CURVES":
                bpy.ops.curves.sculptmode_toggle()
    

def get_prefs():
    return bpy.context.preferences.addons[__package__].preferences

def is_halo_mapping_node(node: bpy.types.Node) -> bool:
    """Checks if the given node is one of Foundry's texture tiling node variants."""
    input_names = {i.name for i in node.inputs}
    return input_names == set(HALO_SCALE_NODE) or input_names == set(HALO_TILING_NODE)

def recursive_image_search(tree_owner):
    nodes = tree_owner.node_tree.nodes
    for n in nodes:
        if getattr(n, "image", 0):
            return True
        elif n.type == 'GROUP':
            image_found = recursive_image_search(n)
            if image_found:
                return True
            

def remove_chars(string, chars):
    while any(c in string for c in chars):
        for c in chars:
            string = string.replace(c, "")

    return string

def write_projects_list(project_list):
    appdata = os.getenv('APPDATA')
    foundry_folder = Path(appdata, "Foundry")

    if not foundry_folder.exists():
        foundry_folder.mkdir(exist_ok=True)
    
    if not foundry_folder.exists():
        return print('Failed to write projects list. Foundry will not work correctly')

    projects = Path(foundry_folder, "projects.json")
    with open(projects, 'w') as file:
        json.dump(project_list, file, indent=4)

def read_projects_list() -> list:
    projects_list = []
    appdata = os.getenv('APPDATA')
    foundry_folder = os.path.join(appdata, "Foundry")

    if not os.path.exists(foundry_folder):
        return print("No Foundry Folder")

    projects = os.path.join(foundry_folder, "projects.json")
    if not os.path.exists(projects):
        return print("No Foundry json")
    
    try:
        with open(projects, 'r') as file:
            projects_list = json.load(file)
    except:
        try:
            os.remove(projects)
        except:
            return print("Foundry JSON corrupt. Failed to delete")
        return print("Foundry JSON corrupt. Deleted")

    return projects_list

class ProjectXML():
    def __init__(self):
        self.name = ""
        self.display_name = ""
        self.remote_database_name = ""
        self.project_xml = ""
        self.image_path = ""
        self.default_material = ""
        self.default_water = ""
        self.blender_path = ""
        self.last_scenario = ""

    def parse(self, project_root):
        has_changes = False
        self.project_xml = Path(project_root, "project.xml")
        try:
            if not self.project_xml.exists():
                return print(f"{project_root} is not a path to a valid Halo project. Expected project root directory to contain project.xml")
            tree = ET.parse(self.project_xml)
        except OSError as ex:
            return print_warning(f"Failed to access project XML: {self.project_xml} ({ex})")
        except ET.ParseError as ex:
            return print_warning(f"Failed to parse XML: {self.project_xml} ({ex})")
        root = tree.getroot()
        if self.name and self.name != root.get('name', 0):
            root.set("name", self.name)
            has_changes = True
        else:
            self.name = root.get('name', 0)
            if not self.name:
                return print(f"Failed to parse XML: {self.project_xml}. Could not return Name")
        if self.display_name and self.display_name != root.get('displayName', 0):
            root.set("displayName", self.display_name)
            has_changes = True
        else:
            self.display_name = root.get('displayName', 0)
            if not self.display_name:
                return print(f"Failed to parse XML: {self.project_xml}. Could not return displayName")
        self.remote_database_name = root.find('./tagDatastore').get('remoteDatabaseName', 0)
        if not self.remote_database_name:
            return print(f"Failed to parse XML: {self.project_xml}. Could not return remoteDatabaseName")
        # It's fine if these fail, they are only used to render icons
        self.remote_server_name = root.find('./tagDatastore').get('remoteServerName', 0)
        image = root.find('./imagePath', 0)
        if image is not None:
            self.image_path = image.text
            
        material = root.find('./defaultMaterial', 0)
        if material is not None:
            if self.default_material and self.default_material != material.text:
                material.text = self.default_material
                has_changes = True
            else:
                self.default_material = material.text
        else:
            material = ET.SubElement(root, 'defaultMaterial')
            if self.default_material:
                material.text = self.default_material
            else:
                match self.remote_server_name:
                    case 'bngtoolsql':
                        material.text = r"shaders\invalid.shader"
                    case 'metawins':
                        material.text = r"shaders\invalid.material"
                    case 'episql.343i.selfhost.corp.microsoft.com':
                        material.text = r"shaders\invalid.material"
                self.default_material = material.text
            has_changes = True
        
        water = root.find('./defaultWater', 0)
        if water is not None:
            if self.default_water and self.default_water != water.text:
                water.text = self.default_water
                has_changes = True
            else:
                self.default_water = water.text
        else:
            if self.default_water:
                water.text = self.default_water
            else:
                water = ET.SubElement(root, 'defaultWater')
                match self.remote_server_name:
                    case 'bngtoolsql':
                        water.text = r"levels\solo\m50\shaders\water\m50_atrium_fountain_water.shader_water"
                    case 'metawins':
                        water.text = r"levels\multi\z11_valhalla\materials\valhalla_water_river.material"
                    case 'episql.343i.selfhost.corp.microsoft.com':
                        water.text = r"levels\sway\ca_sanctuary\materials\rocks\ca_sanctuary_rockflat_water.material"
                self.default_water = water.text
            has_changes = True
            
        blender_path = root.find('./blenderPath', 0)
        if blender_path is not None:
            if blender_path.text != bpy.app.binary_path:
                blender_path.text = bpy.app.binary_path
                self.blender_path = blender_path.text
                has_changes = True
            else:
                self.blender_path = blender_path.text
        else:
            blender_path = ET.SubElement(root, 'blenderPath')
            blender_path.text = bpy.app.binary_path
            self.blender_path = blender_path.text
            has_changes = True
            
        last_scenario = root.find('./lastScenario', 0)
        if last_scenario is not None:
            if self.last_scenario and last_scenario.text != self.last_scenario:
                last_scenario.text = self.last_scenario
                has_changes = True
            else:
                self.last_scenario = last_scenario.text
        elif self.last_scenario:
            last_scenario = ET.SubElement(root, 'lastScenario')
            last_scenario.text = self.last_scenario
            has_changes = True
        
        if has_changes:
            try:
                tree.write(self.project_xml, encoding='utf-8', xml_declaration=True)
            except OSError as ex:
                return print_warning(f"Failed to update project XML: {self.project_xml} ({ex})")

def setup_projects_list(skip_registry_check=False, report=None):
    projects_list = read_projects_list()
    new_projects_list = []
    prefs = get_prefs()
    prefs.projects.clear()
    display_names = []
    if projects_list is not None:
        for i in projects_list:
            xml = ProjectXML()
            xml.parse(i)
            if xml.name and xml.display_name and xml.remote_database_name and xml.project_xml:
                if xml.display_name in display_names:
                    warning = f"{xml.display_name} already exists. Ensure new project has a unique project display name. This can be changed by editing the displayName field in {os.path.join(i, 'project.xml')}"
                    print_warning(warning)
                    if report is not None:
                        report({'WARNING'}, warning)
                    continue

                display_names.append(xml.display_name)
                new_projects_list.append(i)
                p = prefs.projects.add()
                p.project_path = i
                p.tags_directory = str(Path(i, "tags"))
                p.data_directory = str(Path(i, "data"))
                p.project_xml = str(xml.project_xml)
                p.project_name = xml.name
                p.name = xml.display_name
                p.remote_server_name = xml.remote_server_name
                p.image_path = xml.image_path
                p.corinth = xml.remote_database_name == "tags"
                p.default_material = xml.default_material
                p.default_water = xml.default_water
                p.last_scenario = xml.last_scenario
    
    if new_projects_list:
        # Write new file to ensure sync
        write_projects_list(new_projects_list)
        return prefs.projects
    elif not skip_registry_check:
        # Attempt to get the current project if no projects found
        key_path = r"bonobo\shell\open\command"
        try:
            # Open the registry key
            with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, key_path) as key:
                # Read the default value (an empty string) of the key
                value, _ = winreg.QueryValueEx(key, None)
                
            bonobo_path = value.rpartition('.exe"')[0].strip('"\' ')
            project_root = os.path.dirname(bonobo_path)
            if os.path.exists(os.path.join(project_root, "project.xml")):
                write_projects_list([project_root])
                setup_projects_list(True, report)
                    
        except:
            pass

    return []

def update_tables_from_objects(context):
    scene_nwo = get_scene_props()
    regions_table = scene_nwo.regions_table
    region_names = {e.name for e in regions_table}
    permutations_table = scene_nwo.permutations_table
    permutation_names = {e.name for e in permutations_table}
    asset_set_type = set_type_from_asset(scene_nwo)

    def ensure_region(region):
        if not region or region in region_names:
            return
        new_region = regions_table.add()
        new_region.old = region
        new_region.name = region
        new_region.set_type = asset_set_type
        region_names.add(region)

    def ensure_permutation(permutation):
        if not permutation or permutation in permutation_names:
            return
        new_permutation = permutations_table.add()
        new_permutation.old = permutation
        new_permutation.name = permutation
        new_permutation.set_type = asset_set_type
        permutation_names.add(permutation)

    def ensure_collection_sets(collection):
        if collection.library:
            return
        match collection.nwo.type:
            case 'region':
                ensure_region(collection.nwo.region)
            case 'permutation':
                ensure_permutation(collection.nwo.permutation)
        for child in collection.children:
            ensure_collection_sets(child)

    for collection in context.scene.collection.children:
        ensure_collection_sets(collection)

    default_region = regions_table[0].name if regions_table else ""
    default_permutation = permutations_table[0].name if permutations_table else ""
    scene_obs = context.scene.objects
    for ob in scene_obs:
        ob_region = true_region(ob.nwo)
        if not ob_region:
            ob.nwo.region_name = default_region
        else:
            ensure_region(ob_region)
            ob.nwo.region_name = ob_region

        ob_permutation = true_permutation(ob.nwo)
        if not ob_permutation:
            ob.nwo.permutation_name = default_permutation
        else:
            ensure_permutation(ob_permutation)
            ob.nwo.permutation_name = ob_permutation

# def update_objects_from_tables(context, table_str, ob_prop_str):
#     entry_names = [e.name for e in getattr(get_scene_props(), table_str)]
#     default_entry = entry_names[0]
#     scene_obs = context.scene.objects
#     for ob in scene_obs:
#         if getattr(ob.nwo, ob_prop_str) not in entry_names:
#             setattr(ob.nwo, ob_prop_str, default_entry)

def addon_root():
    return os.path.dirname(os.path.realpath(__file__))

def extract_from_resources(relative_file_path):
    p = PureWindowsPath(relative_file_path)
    resources_zip = os.path.join(addon_root(), 'resources.zip')
    os.chdir(addon_root())
    with zipfile.ZipFile(resources_zip, "r") as zip:
        file = zip.extract(p.as_posix())
    return file

def import_gltf(path):
    unit_settings = bpy.context.scene.unit_settings
    old_unit_scale = unit_settings.scale_length
    unit_settings.scale_length = 1
    print(path)
    bpy.ops.import_scene.gltf(filepath=path, import_shading='FLAT')
    unit_settings.scale_length = old_unit_scale

def get_mesh_display(mesh_type):
    match mesh_type:
        case '_connected_geometry_mesh_type_structure':
            return 'Structure', get_icon_id('structure')
        case '_connected_geometry_mesh_type_collision':
            return 'Collision', get_icon_id('collider')
        case '_connected_geometry_mesh_type_physics':
            return 'Physics', get_icon_id('physics')
        case '_connected_geometry_mesh_type_object_instance':
            return 'Instanced Object', get_icon_id('instance')
        case '_connected_geometry_mesh_type_seam':
            return 'Seam', get_icon_id('seam')
        case '_connected_geometry_mesh_type_portal':
            return 'Portal', get_icon_id('portal')
        case '_connected_geometry_mesh_type_water_surface':
            return 'Water', get_icon_id('water')
        case '_connected_geometry_mesh_type_boundary_surface':
            return 'Boundary Surface', get_icon_id('soft_ceiling')
        case '_connected_geometry_mesh_type_poop_rain_blocker':
            return 'Rain Blocker', get_icon_id('rain_blocker')
        case '_connected_geometry_mesh_type_obb_volume':
            return 'Bounding Box', get_icon_id('volume')
        case '_connected_geometry_mesh_type_poop_vertical_rain_sheet':
            return 'Rain Sheet', get_icon_id('rain_sheet')
        case '_connected_geometry_mesh_type_cookie_cutter':
            return 'Pathfinding Cutout Volume', get_icon_id('cookie_cutter')
        case '_connected_geometry_mesh_type_planar_fog_volume':
            return 'Fog Sheet', get_icon_id('fog')
        case '_connected_geometry_mesh_type_lightmap_region':
            return 'Lightmap Region', get_icon_id('lightmap')
        case _:
            if poll_ui(('scenario', 'prefab')):
                return 'Instanced Geometry', get_icon_id('instance')
            elif poll_ui(('DECORATOR')):
                return 'Decorator', get_icon_id('decorator')
            else:
                return 'Render', get_icon_id('render')

def library_instanced_collection(ob):
    return ob.instance_type == 'COLLECTION' and ob.instance_collection and ob.instance_collection.library

def get_marker_display(mesh_type, ob):
    match mesh_type:
        case '_connected_geometry_marker_type_effects':
            return 'Effects', get_icon_id('effects')
        case '_connected_geometry_marker_type_garbage':
            return 'Garbage', get_icon_id('garbage')
        case '_connected_geometry_marker_type_hint':
            return 'Hint', get_icon_id('hint')
        case '_connected_geometry_marker_type_pathfinding_sphere':
            return 'Pathfinding Sphere', get_icon_id('pathfinding_sphere')
        case '_connected_geometry_marker_type_physics_constraint':
            return 'Physics Constraint', get_icon_id('physics_constraint')
        case '_connected_geometry_marker_type_target':
            return 'Target', get_icon_id('target')
        case '_connected_geometry_marker_type_game_instance':
            match dot_partition(ob.nwo.marker_game_instance_tag_name).lower():
                case "crate":
                    name = "Crate Tag"
                    icon = "crate"
                case "scenery":
                    name = "Scenery Tag"
                    icon = "scenery"
                case "effect_scenery":
                    name = "Effect Scenery Tag"
                    icon = "effect_scenery"
                case "device_control":
                    name = "Device Control Tag"
                    icon = "device_control"
                case "device_machine":
                    name = "Device Machine Tag"
                    icon = "device_machine"
                case "device_terminal":
                    name = "Device Terminal Tag"
                    icon = "device_terminal"
                case "device_dispenser":
                    name = "Device Dispenser Tag"
                    icon = "device_dispenser"
                case "biped":
                    name = "Biped Tag"
                    icon = "biped"
                case "creature":
                    name = "Creature Tag"
                    icon = "creature"
                case "giant":
                    name = "Giant Tag"
                    icon = "giant"
                case "vehicle":
                    name = "Vehicle Tag"
                    icon = "vehicle"
                case "weapon":
                    name = "Weapon Tag"
                    icon = "weapon"
                case "equipment":
                    name = "Equipment Tag"
                    icon = "equipment"
                case "prefab":
                    name = "Prefab Tag"
                    icon = "prefab"
                case "light":
                    name = "Light Tag"
                    icon = "light_cone"
                case "cheap_light":
                    name = "Cheap Light Tag"
                    icon = "light_cone"
                case "leaf":
                    name = "Leaf Tag"
                    icon = "decorator"
                case "decorator_set":
                    name = "Decorator Set Tag"
                    icon = "decorator"
                case _:
                    name = "Game Object"
                    icon = "game_object"
            return name, get_icon_id(icon)
        case '_connected_geometry_marker_type_airprobe':
            return 'Airprobe', get_icon_id('airprobe')
        case '_connected_geometry_marker_type_envfx':
            return 'Environment Effect', get_icon_id('environment_effect')
        case '_connected_geometry_marker_type_lightCone':
            return 'Light Cone', get_icon_id('light_cone')
        case _:
            if poll_ui(('scenario', 'prefab')):
                return 'Structure Marker', get_icon_id('marker')
            else:
                return 'Model Marker', get_icon_id('marker')
            
def is_mesh(ob):
    return ob.type in VALID_MESHES

def is_marker(ob):
    return ob.type == 'EMPTY' and ob.empty_display_type != "IMAGE"

def is_frame(ob):
    if ob.type == 'ARMATURE' or (ob.type == 'EMPTY' and ob.nwo.is_frame):
        return True
    
    return False

def is_light(ob):
    return ob.type == 'LIGHT'

def is_camera(ob):
    return ob.type == 'CAMERA'

def get_object_type(ob, get_ui_name=False):
    if is_mesh(ob):
        return 'Mesh' if get_ui_name else '_connected_geometry_object_type_mesh'
    elif is_light(ob):
        return 'Light' if get_ui_name else '_connected_geometry_object_type_light'
    elif is_camera(ob):
        return 'Camera' if get_ui_name else '_connected_geometry_object_type_animation_camera'
    elif is_frame(ob):
        return 'Frame' if get_ui_name else '_connected_geometry_object_type_frame'
    elif is_marker(ob):
        return 'Marker' if get_ui_name else '_connected_geometry_object_type_marker'
    else:
        return 'None' if get_ui_name else '_connected_geometry_object_type_none'
    
def type_valid(m_type, asset_type=None, game_version=None):
    if asset_type is None:
        asset_type = get_scene_props().asset_type
    if game_version is None:
        game_version = 'corinth' if is_corinth() else 'reach'
    if asset_type in {'cinematic', 'animation'}:
        return True
    return asset_type in object_asset_validation.get(m_type, []) and game_version in object_game_validation.get(m_type, [])

def get_shader_name(mat):
    if not protected_material_name(mat.name):
        shader_name = get_valid_shader_name(mat.name)
        if shader_name != "":
            return shader_name

    return None

def get_arm_count(context: bpy.types.Context):
    arms = [ob for ob in context.view_layer.objects if ob.type == 'ARMATURE']
    return len(arms)

def blender_toolset_installed():
    script_dirs = bpy.utils.script_paths()
    for dir in script_dirs:
        if os.path.exists(os.path.join(dir, 'addons', 'io_scene_halo')):
            return True
        elif os.path.exists(os.path.join(dir, 'addons_core', 'io_scene_halo')):
            return True
    return False
    
def amf_addon_installed():
    script_dirs = bpy.utils.script_paths()
    for dir in script_dirs:
        if os.path.exists(os.path.join(dir, 'addons', 'Blender AMF2.py')):
            return 'Blender AMF2'
        elif os.path.exists(os.path.join(dir, 'addons', 'Blender_AMF2.py')):
            return 'Blender_AMF2'
        elif os.path.exists(os.path.join(dir, 'addons_core', 'Blender AMF2.py')):
            return 'Blender AMF2'
        elif os.path.exists(os.path.join(dir, 'addons_core', 'Blender_AMF2.py')):
            return 'Blender_AMF2'
        
    return False
    
def has_collision_type(ob: bpy.types.Object) -> bool:
    nwo = ob.nwo
    mesh_type = nwo.mesh_type
    if not poll_ui(('scenario', 'prefab')) and mesh_type != '_connected_geometry_mesh_type_collision':
        return False
    if mesh_type in COLLISION_MESH_TYPES:
        return True
    if is_instance_or_structure_proxy(ob):
        return True
    return False

def get_sky_perm(mat: bpy.types.Material) -> int:
    name = mat.name
    index_part = name.rpartition('+sky')[2]
    if not index_part:
        return -1
    index_ignore_period = dot_partition(index_part)
    index = ''.join(c for c in index_ignore_period if c.isdigit())
    if not index:
        return -1
    return int(index)
        
def is_instance_or_structure_proxy(ob) -> bool:
    mesh_type = ob.nwo.mesh_type
    if not poll_ui(('scenario', 'prefab')):
        return False
    if mesh_type == '_connected_geometry_mesh_type_default':
        return True
    if is_corinth() and mesh_type == '_connected_geometry_mesh_type_structure' and ob.nwo.proxy_instance:
        return True
    return False
    
def set_origin_to_floor(ob):
    bounding_box_corners = [Vector(corner) for corner in ob.bound_box]
    min_z = min([corner.z for corner in bounding_box_corners])
    translation = Vector((0, 0, -min_z))
    for vert in ob.data.vertices:
        vert.co += translation
        
    ob.matrix_world = ob.matrix_world @ Matrix.Translation(-translation)
    
def set_origin_to_centre(ob):
    centroid = Vector((0, 0, 0))
    for vert in ob.data.vertices:
        centroid += vert.co
    centroid /= len(ob.data.vertices)
    
    translation = -centroid
    
    for vert in ob.data.vertices:
        vert.co += translation
        
    ob.matrix_world = ob.matrix_world @ Matrix.Translation(-translation)
    
def set_origin_to_point(ob: bpy.types.Object, point: Vector):
    translation_matrix = Matrix.Translation(point - ob.location)
    ob.data.transform(translation_matrix)
    ob.matrix_world = ob.matrix_world @ translation_matrix.inverted_safe()

def current_project_valid():
    project = get_project(get_scene_props().scene_project)
    
    return bool(project)

def get_project(project_name=None):
    if project_name is None:
        project_name = get_scene_props().scene_project
    
    projects = get_prefs().projects
    if projects:
        for p in projects:
            if p.name == project_name:
                return p
        
        return projects[0]
    
def get_project_from_path(path: str):
    projects = get_prefs().projects
    if projects:
        for p in projects:
            if p.project_path == path:
                return p
    
def material_read_only(path):
    """Returns true if a material is read only aka in the project's protected list"""
    # Return false immediately if user has disabled material protection
    if not get_prefs().protect_materials: return False
    # Ensure path is correctly sliced
    path = path.strip(" .\"'")
    if not path: return False
    path = str(Path(relative_path(path)).with_suffix(""))
    project = get_project(get_scene_props().scene_project)
    protected_list = os.path.join(addon_root(), 'protected_tags', project.project_name, 'materials.txt')
    if not os.path.exists(protected_list): return False
    protected_materials = None
    with open(protected_list, 'r') as f:
        protected_materials = [line.rstrip('\n') for line in f]
    if protected_materials is None: return False
    for tag in protected_materials:
        if path == tag:
            return True
    return False

def stomp_scale_multi_user(objects):
    """Checks that at least one user of a mesh has a uniform scale of 1,1,1. If not, applies scale to all linked objects, using the object with the smallest scale as a basis"""
    good_scale = Vector.Fill(3, 1)
    meshes = {ob.data for ob in objects}
    mesh_ob_dict = {mesh: [ob for ob in bpy.data.objects if ob.data == mesh] for mesh in meshes}
    for me in mesh_ob_dict.keys():
        scales = []
        for ob in mesh_ob_dict[me]:
            abs_scale = Vector((abs(ob.scale.x), abs(ob.scale.y), abs(ob.scale.z)))
            if abs_scale == good_scale:
                # print(f"{me.name} has at least one object with good scale [{ob.name}]")
                scales.clear()
                break
            scales.append(abs(ob.scale.x))
        if not scales: continue
        basis_scale = np.median(scales)
        obs_matching_basis = [ob for ob in mesh_ob_dict[me] if abs(ob.scale.x) == basis_scale]
        if obs_matching_basis:
            basis_ob = obs_matching_basis[0]
        else:
            basis_ob = mesh_ob_dict[me][0]
        with bpy.context.temp_override(active_object=basis_ob, selected_editable_objects=[ob for ob in mesh_ob_dict[me]]):
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True, isolate_users=True)
        
def get_scale_ratio(scale):
    return round(scale.x / scale.y, 6), round(scale.y / scale.z, 6), round(scale.z / scale.x, 6)

def enforce_uniformity(objects):
    """Check for non-uniform scale objects and split them into new meshes if needed with applied scale"""
    meshes = {ob.data for ob in objects}
    mesh_ob_dict = {mesh: [ob for ob in objects if ob.data == mesh] for mesh in meshes}
    deselect_all_objects()
    for me in mesh_ob_dict.keys():
        scale_ob_dict = {}
        for ob in mesh_ob_dict[me]:
            scale = ob.scale
            if scale.x == scale.y and scale.x == scale.z:
                continue
            scale_ratio = get_scale_ratio(scale)
            if scale_ob_dict.get(scale_ratio, 0):
                scale_ob_dict[scale_ratio].append(ob)
            else:
                scale_ob_dict[scale_ratio] = [ob]
    
    for k in scale_ob_dict:
        [ob.select_set(True) for ob in scale_ob_dict[k]]
        set_active_object(scale_ob_dict[k][0])
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True, isolate_users=True)
        deselect_all_objects()
        
def get_light_intensity_factor(light_type=""):
    if is_corinth():
        match light_type:
            case 'SPOT':
                return 1
            case _:
                return 3
    else:
        match light_type:
            case 'SPOT':
                return 1
            case _:
                return 3
        
def calc_light_intensity(light_data, scale):
    
    if light_data.type == 'SUN':
        return light_data.energy

    if is_corinth():
        return light_data.energy * (scale ** 2) / 10
    else:
        return light_data.energy * (scale ** 2) / 100

def calc_light_energy(light_data, intensity, scale):
    if light_data.type == 'SUN':
        return intensity

    if is_corinth():
        return intensity / (scale ** 2) * 10
    else:
        return intensity / (scale ** 2) * 100

def calc_emissive_intensity(emissive_power, factor=1):
    scale = 1.0 / get_export_scale(bpy.context)  # meters per engine unit
    return emissive_power * (scale ** 2)  * get_light_intensity_factor()

def calc_emissive_energy(intensity):
    scale = 1.0 / get_export_scale(bpy.context)
    return intensity / (scale ** 2) / get_light_intensity_factor()

def calc_max_intensity(cutoff: float, cutoff_intensity: float = 0.1):
    return 4 * math.pi * cutoff_intensity * (cutoff ** 2)

def calc_attenuation(power: float, intensity_threshold=0.5, cutoff_intensity=0.05) -> tuple[float, float]:
    power = abs(power)
    falloff = math.sqrt(power / (4 * math.pi * intensity_threshold))
    cutoff = math.sqrt(power / (4 * math.pi * cutoff_intensity))
    return 0.0, cutoff

def get_blender_shader(node_tree: bpy.types.NodeTree) -> bpy.types.Node | None:
    """Gets the BSDF shader node from a node tree"""
    output = None
    shaders = []
    for node in node_tree.nodes:
        if node.type == "OUTPUT_MATERIAL":
            output = node
        elif node.type.startswith("BSDF"):
            shaders.append(node)
    # Get the shader plugged into the output
    if output is None:
        return
    for s in shaders:
        outputs = s.outputs
        if not outputs:
            return
        links = outputs[0].links
        if not links:
            return
        if links[0].to_node == output:
            return s

    return

def find_mapping_node(node: bpy.types.Node, start_node: bpy.types.Node) -> bpy.types.Node | None:
    links = node.inputs['Vector'].links
    if not links:
        return None, None
    next_node = links[0].from_node
    if next_node.type == 'MAPPING':
        return next_node, False
    elif is_halo_mapping_node(next_node):
        return next_node, True
    else:
        global hit_target
        tile_node, _ = find_node_in_chain('GROUP', start_node, first_target=node.name, group_is_tiling_node=True)
        hit_target = False
        if tile_node:
            return tile_node, True
        else:
            tile_node, _ = find_node_in_chain('MAPPING', start_node, first_target=node.name)
            hit_target = False
            if tile_node:
                return tile_node, False
    
    return None, None

def insert_uv_map_node(image_node: bpy.types.Node, uvmap_name: str) -> bpy.types.Node | None:
    """Adds a UV Map node at the start of the vector chain feeding an image node."""
    vector_input = image_node.inputs.get('Vector')
    if vector_input is None:
        return

    node_tree = image_node.id_data
    if node_tree is None:
        return

    def input_by_name(node: bpy.types.Node, *names: str) -> bpy.types.NodeSocket | None:
        for name in names:
            if not name:
                continue
            for socket in node.inputs:
                if socket.name.lower() == name.lower():
                    return socket
        return None

    def linked_vector_input(node: bpy.types.Node, from_socket: bpy.types.NodeSocket) -> bpy.types.NodeSocket | None:
        if node.type == 'REROUTE':
            return node.inputs[0] if node.inputs else None

        return input_by_name(node, from_socket.name, 'Vector', 'UV')

    target_input = vector_input
    visited_nodes = []
    while target_input.links:
        link = target_input.links[0]
        source_node = link.from_node
        if source_node in visited_nodes:
            break

        visited_nodes.append(source_node)
        next_input = linked_vector_input(source_node, link.from_socket)
        if next_input is None:
            break

        target_input = next_input

    existing_links = list(target_input.links)
    if existing_links and existing_links[0].from_node.type == 'UVMAP':
        uv_node = existing_links[0].from_node
        uv_node.uv_map = uvmap_name
        return uv_node

    uv_node = node_tree.nodes.new(type='ShaderNodeUVMap')
    uv_node.uv_map = uvmap_name

    if existing_links:
        uv_node.location = existing_links[0].from_node.location
    else:
        uv_node.location.x = target_input.node.location.x - 300
        uv_node.location.y = target_input.node.location.y

    for link in existing_links:
        node_tree.links.remove(link)

    node_tree.links.new(input=target_input, output=uv_node.outputs['UV'])
    return uv_node

def find_linked_node(start_node: bpy.types.Node, input_name: str, node_type: str) -> bpy.types.Node:
    """Using the given node as a base, finds the first node from the given input that matches the given node type"""
    for i in start_node.inputs:
        if input_name == i.name.lower():
            if i.links:
                input = i
                break
            else:
                return
    else:
        return
    
    link = input.links[0]
    node, _ = find_node_in_chain(node_type, link.from_node, link.from_socket.name.lower())
    if node:
        return node
    
def find_node_in_chain(node_type: str, node: bpy.types.Node, group_output_input='', group_node=None, last_input_name='', first_target=None, group_is_tiling_node=False) -> tuple[bpy.types.Node, bpy.types.Node]:
    global hit_target
    if node.type == node_type and (not group_is_tiling_node or is_halo_mapping_node(node)) and (first_target is None or hit_target):
        return node, group_node
    
    if node.name == first_target:
        hit_target = True
    
    if node.type == 'GROUP':
        group_node = node
        group_nodes = node.node_tree.nodes
        for n in group_nodes:
            if n.type == 'GROUP_OUTPUT':
                for input in n.inputs:
                    if input.name.lower() == group_output_input:
                        links = input.links
                        for l in links:
                            new_node = l.from_node
                            valid_node, group_node = find_node_in_chain(node_type, new_node, group_output_input, group_node, input.name, first_target, group_is_tiling_node)
                            if valid_node:
                                return valid_node, group_node

                break
            
    elif node.type == 'GROUP_INPUT':
        for input in node.inputs:
            if input.name.lower() == last_input_name:
                group_test_input = input
                for link in group_test_input.links:
                    next_node = link.from_node
                    valid_node, group_node = find_node_in_chain(node_type, next_node, link.from_socket.name, None, group_test_input.name, first_target, group_is_tiling_node)
                    if valid_node:
                        return valid_node, group_node
            
    for input in node.inputs:
        for link in input.links:
            next_node = link.from_node
            if next_node.type == 'GROUP':
                valid_node, group_node = find_node_in_chain(node_type, next_node, link.from_socket.name, node, input.name, first_target, group_is_tiling_node)
            else:
                valid_node, group_node = find_node_in_chain(node_type, next_node, group_output_input, group_node, input.name, first_target, group_is_tiling_node)
            if valid_node:
                return valid_node, group_node
    
    return None, None
            
def get_material_albedo(source: bpy.types.Material | bpy.types.Node, input=None) -> tuple[float, float, float, float]:
    """Returns the albedo tint of a material as a tuple in the form RGBA directly from the material or from the given node"""
    col = [1, 1, 1]
    if type(source) == bpy.types.Material:
        col = source.diffuse_color
    else:
        if input:
            color_node = find_linked_node(source, input.name.lower(), 'RGB')
        else:
            color_node = find_linked_node(source, 'color', 'RGB')
        if color_node:
            col = color_node.color
        if input:
            col = input.default_value
        else:
            for i in source.inputs:
                if 'color' in i.name.lower():
                    col = i.default_value
                    break
                
    return col[:3] # Only 3 since we don't care about the alpha
            
def get_rig(context=None, return_mutliple=False) -> bpy.types.Object | None | list[bpy.types.Object]:
    """Gets the main armature from the scene (or tries to)"""
    if context is None:
        context = bpy.context
    scene_nwo = get_scene_props()
    ob = context.object
    if scene_nwo.main_armature:
        if context.scene.objects.get(scene_nwo.main_armature.name):
            return scene_nwo.main_armature
        else:
            print_warning(f"Scene rig [{scene_nwo.main_armature.name}] is not in current scene. Please check asset editor panel")
    obs = export_objects(context)
    rigs = [ob for ob in obs if ob.type == 'ARMATURE']
    if not rigs:
        return
    elif len(rigs) > 1 and return_mutliple:
        return rigs
    if ob in rigs:
        scene_nwo.main_armature = ob
        return ob
    else:
        scene_nwo.main_armature = rigs[0]
        return rigs[0]
    
def get_rig_prioritize_active(context=None):
    if context is None:
        context = bpy.context
        
    if context.object and context.object.type == "ARMATURE":
        return context.object
    elif context.object and context.object.parent and context.object.parent.type == "ARMATURE":
        return context.object.parent
    else:
        return get_rig(context)

    
def find_file_in_directory(root_dir, filename) -> str:
    """Finds the first file in the current and sub-directories matching the given filename. If none found, returns an empty string"""
    for root, _, files in os.walk(root_dir):
        for file in files:
            if file == filename:
                return os.path.join(root, file)
            
    return ''

material_shader_fallbacks = {
    "srf_char_skin_tension_detail_normal": "srf_char_blinn_detailnormal"
}

def add_node_from_resources(blend_name, name, link=True, check_multiple=False) -> bpy.types.NodeGroup | None:
    node_group = bpy.data.node_groups.get(name)
    if node_group is not None:
        return node_group
    
    lib_blend = Path(MATERIAL_RESOURCES, f'{blend_name}.blend')
    
    if not lib_blend.exists():
        return
    
    found = False
    with bpy.data.libraries.load(str(lib_blend), link=link) as (data_from, data_to):
        from_node_groups = frozenset(data_from.node_groups)
        if name in from_node_groups:
            data_to.node_groups = [name]
            found = True
        elif check_multiple:
            fallback = material_shader_fallbacks.get(name)
            if fallback is not None:
                if fallback in from_node_groups:
                    data_to.node_groups = [fallback]
                    found = True
            else:
                while len(name) >= 7:
                    name = name[:-1]
                    if name in from_node_groups:
                        data_to.node_groups = [name]
                        found = True
                        break
                
    if found:
        return bpy.data.node_groups[name]

def rgb_to_float_list(red, green, blue):
    return [red / 255, green / 255, blue / 255]

def copy_file(from_path, to_path):
    return shutil.copyfile(from_path, to_path)

def base_material_name(name: str, strip_legacy_halo_names=False) -> str:
    """Returns a material name with legacy halo naming conventions stripped and ignoring .00X blender duplicate names"""
    """Tries to find a shader match. Includes logic for filtering out legacy material name prefixes/suffixes"""
    material_name = dot_partition(name)
    if not strip_legacy_halo_names:
        return material_name
    # match lightmap prefixe/suffixes
    parts = material_name.split()
    if len(parts) > 1:
        if parts[0].startswith(legacy_lightmap_prefixes):
            material_name = ' '.join(parts[1:])
        elif parts[-1].startswith(legacy_lightmap_prefixes):
            material_name = ' '.join(parts[:-1])
            
    # ignore material suffixes
    return material_name.rstrip("%#?!@*$^-&=.;)><|~({]}[' ") # excluding 0 here as it can interfere with normal naming convention

def reset_to_basis(keep_animation=False, record_current_action=False):
    ob_actions = {}
    animated_objects = [ob for ob in bpy.data.objects if ob.animation_data]
    for ob in animated_objects:
        ob_actions[ob] = ob.animation_data.action
        if not keep_animation:
            ob.animation_data.action = None
        ob.matrix_basis = Matrix()
        if ob.type == 'ARMATURE':
            for bone in ob.pose.bones:
                bone.matrix_basis = Matrix()
                
    if record_current_action:
        return ob_actions

def clear_animation(animation):
    for group in animation.action_tracks:
        if group.action is not None and group.object is not None:
            if group.is_shape_key_action:
                if group.object.type == 'MESH' and group.object.data.shape_keys and group.object.data.shape_keys.animation_data:
                    group.object.data.shape_keys.animation_data.action = None
                    for kb in group.object.data.shape_keys.key_blocks:
                        kb.value = 0
                        
            else:
                if group.object.animation_data:
                    if group.object.type == 'ARMATURE':
                        for bone in group.object.pose.bones:
                            bone.matrix_basis = Matrix.Identity(4)
                        reset_control_rig_props(group.object)
                    
                    group.object.animation_data.action = None
                    # group.object.matrix_local = Matrix.Identity(4)
                    group.object.animation_data.use_nla = False
                    group.object.animation_data.action = None

def reset_control_rig_props(armature: bpy.types.Object):
    settings_bone = armature.pose.bones.get("CTRL_settings")
    if settings_bone is None:
        return

    for key in settings_bone.keys():
        settings_bone[key] = 0.0

def asset_path_from_blend_location() -> str | None:
    blend_path = bpy.data.filepath.lower()
    data_path = get_data_path()
    if blend_path.startswith(data_path):
        return os.path.dirname(blend_path).replace(data_path, '')
    return None

def get_export_scale(context) -> float:
    export_scale = 1
    scene_nwo = get_scene_props()
    if scene_nwo.scale == 'blender':
        export_scale = (1 / 0.03048)
        
    return export_scale

def get_import_scale(context) -> float:
    export_scale = 1
    scene_nwo = get_scene_props()
    if scene_nwo.scale == 'max':
        export_scale = (1 / 0.03048)
        
    return export_scale

def get_unit_conversion_factor(context) -> float:
    '''Returns the factor needed to convert a unit back to blender scale'''
    export_scale = 1
    scene_nwo = get_scene_props()
    if scene_nwo.scale == 'max':
        export_scale = 0.03048
        
    return export_scale

def wu(meters) -> int:
    '''Converts a meter to a world unit'''
    return meters * 3.048

def exit_local_view(context):
    local_views = set()
    for area in context.screen.areas:
        if area.type == "VIEW_3D":
            space = area.spaces[0]
            if space.local_view:
                local_views.add(space)
                for region in area.regions:
                    if region.type == "WINDOW":
                        override = context.copy()
                        override["area"] = area
                        override["region"] = region
                        with context.temp_override(**override):
                            bpy.ops.view3d.localview()
    
    return local_views

def set_local_view(context, local_views):
    for area in context.screen.areas:
        if area.type == "VIEW_3D":
            space = area.spaces[0]
            if space in local_views:
                for region in area.regions:
                    if region.type == "WINDOW":
                        override = context.copy()
                        override["area"] = area
                        override["region"] = region
                        with context.temp_override(**override):
                            bpy.ops.view3d.localview()
                            
def rotate_follow_path_axis(con_axis: str, old_forward: str, new_forward: str):
    if old_forward == new_forward:
        return
    axis = con_axis[-1]
    if axis == 'Z':
        return con_axis
    
    forward_back = con_axis[:-1]
    
    if forward_back == 'FORWARD_':
        forward_back_inverse = 'TRACK_NEGATIVE_'
    else:
        forward_back_inverse = 'FORWARD_'
        
    if axis in old_forward.upper() and axis in new_forward.upper():
        if con_axis.startswith('TRACK_NEGATIVE'):
            return con_axis.replace('TRACK_NEGATIVE', 'FORWARD')
        else:
            return con_axis.replace('FORWARD', 'TRACK_NEGATIVE')
    else:
        if '-' in old_forward and '-' in new_forward:
            if axis == 'X':
                return forward_back + 'Y'
            else:
                return forward_back + 'X'
        else:
            if axis == 'X':
                return forward_back_inverse + 'Y'
            else:
                return forward_back_inverse + 'X'
            
def fix_mirror_angles(mod, old_forward, new_forward):
    if old_forward == new_forward:
        return
    old_axis = old_forward[0]
    new_axis = new_forward[0]
    old_axis_negative = len(old_forward) > 1
    new_axis_negative = len(new_forward) > 1
    
    axis_x, axis_y, _ = mod.use_axis
    bisect_x, bisect_y, _ = mod.use_bisect_axis
    flip_x, flip_y, _ = mod.use_bisect_flip_axis
    
    if old_axis != new_axis:
        if bisect_y and flip_x:
            mod.use_bisect_axis[1] = False
            mod.use_bisect_flip_axis[0] = False
        else:
            if axis_x != axis_y:
                mod.use_axis[0] = (not axis_x)
                mod.use_axis[1] = (not axis_y)
            if bisect_x != bisect_y:
                mod.use_bisect_axis[0] = (not bisect_x)
                mod.use_bisect_axis[1] = (not bisect_y)
            mod.use_bisect_flip_axis[0] = (not flip_x)
            mod.use_bisect_flip_axis[1] = (not flip_y)
                    
    if old_axis_negative != new_axis_negative:
        mod.use_bisect_flip_axis[0] = (not mod.use_bisect_flip_axis[0])
        mod.use_bisect_flip_axis[1] = (not mod.use_bisect_flip_axis[1])
        
                            
class BoneChild():
    def __init__(self, ob: bpy.types.Object, parent: bpy.types.Object, parent_bone: str):
        self.ob = ob
        self.parent = parent
        self.parent_bone = parent_bone
        
class ArmatureWithParent():
    def __init__(self, ob: bpy.types.Object, parent: bpy.types.Object, parent_type: str, parent_bone: str):
        self.ob = ob
        self.parent = parent
        self.parent_type = parent_type
        self.parent_bone = parent_bone
        
class TransformManager():
    def __enter__(self):
        get_scene_props().transforming = True
        return self
        
    def __exit__(self, exc_type, exc_value, traceback):
        get_scene_props().transforming = False
        
def rotation_and_pivot(rotation):
    axis_z = Vector((0, 0, 1))
    pivot = Vector((0.0, 0.0, 0.0))
    rotation_matrix = Matrix.Rotation(rotation, 4, axis_z)
    pivot_matrix = (Matrix.Translation(pivot) @ rotation_matrix @ Matrix.Translation(-pivot))
    
    return rotation_matrix, pivot_matrix

def halo_transforms(ob: bpy.types.Object, scale=None, rotation=None, marker=False) -> Matrix:
    '''
    Returns an object's matrix_world transformed for Halo. Used when writing object transforms directly to tags
    '''
    if scale is None:
        if get_scene_props().scale == 'max':
            scale = 0.03048 * WU_SCALAR
        else:
            scale = WU_SCALAR
    
    if rotation is None:
        rotation = blender_halo_rotation_diff(get_scene_props().forward_direction)
        
    rotation_matrix, pivot_matrix = rotation_and_pivot(rotation)
    
    scale_matrix = Matrix.Scale(scale, 4)
    
    object_matrix = ob.matrix_world
    final_matrix = rotation_matrix @ scale_matrix @ object_matrix
    
    # If it's a marker and we have been asked to maintain marker axis
    if marker and get_scene_props().maintain_marker_axis:
        marker_rotation_matrix = Matrix.Rotation(-rotation, 4, 'Z')
        final_matrix = final_matrix @ marker_rotation_matrix
    
    return final_matrix

def halo_transforms_matrix(matrix: Matrix, scale=None, rotation=None, marker=False) -> Matrix:
    '''
    Returns an object's matrix_world transformed for Halo. Used when writing object transforms directly to tags
    '''
    if scale is None:
        if get_scene_props().scale == 'max':
            scale = 0.03048 * WU_SCALAR
        else:
            scale = WU_SCALAR
    
    if rotation is None:
        rotation = blender_halo_rotation_diff(get_scene_props().forward_direction)
        
    rotation_matrix, pivot_matrix = rotation_and_pivot(rotation)
    
    scale_matrix = Matrix.Scale(scale, 4)
    
    final_matrix = rotation_matrix @ scale_matrix @ matrix
    
    # If it's a marker and we have been asked to maintain marker axis
    if marker and get_scene_props().maintain_marker_axis:
        marker_rotation_matrix = Matrix.Rotation(-rotation, 4, 'Z')
        final_matrix = final_matrix @ marker_rotation_matrix
    
    return final_matrix

def halo_transform_matrix(matrix: Matrix) -> Matrix:
    """Converts a matrix from blender space to halo space"""
    scale = WU_SCALAR
    if get_scene_props().scale == 'max':
        scale = 0.03048 * WU_SCALAR
    
    rotation = blender_halo_rotation_diff(get_scene_props().forward_direction)
    
    rotation_matrix, _ = rotation_and_pivot(rotation)
    scale_matrix = Matrix.Scale(scale, 4)

    transform_matrix = rotation_matrix @ scale_matrix
    
    return transform_matrix @ matrix

def blender_transform_matrix(matrix: Matrix) -> Matrix:
    """Converts a matrix from halo space to blender space."""
    scale = WU_SCALAR
    if get_scene_props().scale == 'max':
        scale = 0.03048 * WU_SCALAR

    rotation = blender_halo_rotation_diff(get_scene_props().forward_direction)
    rotation_matrix, _ = rotation_and_pivot(rotation)

    inv_scale_matrix = Matrix.Scale(1.0 / scale, 4)
    inv_rotation_matrix = rotation_matrix.transposed()

    return inv_scale_matrix @ inv_rotation_matrix @ matrix


def maya_transform_matrix(matrix: Matrix) -> Matrix:
    matrix = halo_transform_matrix(matrix)
    
    linear3x3 = Matrix((
        (0.0, 0.1, 0.0),
        (0.0, 0.0, 0.1),
        (0.1, 0.0, 0.0)
    ))

    inverse_linear3x3 = Matrix((
        (0.0, -0.0, 10.0),
        (10.0, 0.0, -0.0),
        (0.0, 10.0, 0.0)
    ))

    linear_matrix = linear3x3.to_4x4()
    inverse_linear_matrix = inverse_linear3x3.to_4x4()

    transformed_matrix = inverse_linear_matrix @ linear_matrix @ matrix
    return transformed_matrix

def halo_loc_rot_sca(matrix: Matrix, scale=None, rotation=None, marker=False) -> Matrix:
    matrix = halo_transforms_matrix(matrix, scale, rotation, marker)
    matrix_3x3 = matrix.to_3x3().normalized()
    forward = matrix_3x3.col[0]
    left = matrix_3x3.col[1]
    up = matrix_3x3.col[2]
    
    return matrix.translation, ypr_from_flu(forward, left, up), 1

import math

def ypr_from_flu(forward, left, up):
    R = [
        [left[0], up[0], forward[0]],
        [left[1], up[1], forward[1]],
        [left[2], up[2], forward[2]],
    ]
    
    yaw = math.atan2(R[1][2], R[0][2])
    
    pitch = math.asin(-R[2][2])
    
    roll = math.atan2(R[2][1], R[2][0])
    
    yaw_deg = math.degrees(yaw) + 90
    pitch_deg = math.degrees(pitch)
    roll_deg = math.degrees(roll)
    
    return yaw_deg, pitch_deg, roll_deg

def parentage_depth(ob: bpy.types.Object) -> int:
    '''Returns the depth of an object in a parentage chain. If the object has no parent, returns 0'''
    depth = 0
    while ob.parent is not None:
        depth += 1
        ob = ob.parent
        
    return depth

class TransformObject:
    def __init__(self, ob: bpy.types.Object, matrix: Matrix = None, scale: float = None, marker_z_matrix: Matrix = None):
        self.ob = ob
        self.original_matrix = self.ob.matrix_world.copy()
        self.marker_z_matrix = marker_z_matrix
        if matrix is None:
            self.matrix = ob.matrix_world.copy()
        else:
            self.matrix = matrix @ ob.matrix_world
        if scale is not None:
            self.matrix.translation = zero_vector.lerp(self.matrix.translation, scale)
        
    def apply(self):
        self.ob.matrix_world = self.matrix
        if self.marker_z_matrix is not None:
            self.ob.matrix_basis = self.ob.matrix_basis @ self.marker_z_matrix

def transform_scene(context: bpy.types.Context, scale_factor, rotation, old_forward, new_forward, keep_marker_axis=None, objects=None, actions=None, apply_rotation=False, exclude_scale_models=False, skip_data=False, scale_light_energy=False, scale_vector=None):
    """Transform blender objects by the given scale factor and rotation. Optionally this can be scoped to a set of objects and animations rather than all"""
    print("\nTransforming Scene\n")
    context.view_layer.update()
    all_objects = False
    armatures_to_reparent = {}
    energy_factor = (scale_factor ** 2)
    with TransformManager():
        # armatures = [ob for ob in bpy.data.objects if ob.type == 'ARMATURE']
        if objects is None:
            objects = bpy.data.objects
            all_objects = True
            
        if exclude_scale_models:
            objects = [ob for ob in objects if not ob.nwo.scale_model]
            
        if not skip_data:
            curves = {ob.data for ob in objects if ob.type in {'CURVE', 'FONT'}}
            metaballs = {ob.data for ob in objects if ob.type =='METABALL'}
            meshes = {ob.data for ob in objects if ob.type =='MESH'}
            cameras = {ob.data for ob in objects if ob.type =='CAMERA'}
            lights = {ob.data for ob in objects if ob.type =='LIGHT'}
            
        if actions is None:
            actions = bpy.data.actions
            
        if keep_marker_axis is None:
            keep_marker_axis = get_scene_props().maintain_marker_axis

        armatures = {}
        scene_coll = context.scene.collection.objects
        rotation_euler = Euler((0, 0, rotation))
        rotation_matrix = Matrix.Rotation(rotation, 4, Vector((0, 0, 1)))
        if scale_vector is None:
            scale_matrix = Matrix.Scale(scale_factor, 4)
        else:
            scale_matrix = Matrix.Diagonal(scale_vector).to_4x4()
        transform_matrix = rotation_matrix @ scale_matrix
        transform_objects = []
        marker_z = Matrix.Rotation(-rotation, 4, 'Z')
        child_of_constraints = []
        
        parents = {o.parent for o in objects if o.parent is not None}
        
        armatures = {ob: ob.data.pose_position for ob in objects if ob.type == 'ARMATURE'}
        for ob in armatures.keys():
            ob.data.pose_position = 'REST'
            if ob.parent is not None:
                m = ob.matrix_world.copy()
                armatures_to_reparent[ob] = ob.parent
                ob.parent = None
                ob.matrix_world = m
                
        if armatures:
            context.view_layer.update()
        
        for ob in objects:
            match ob.type:
                case 'ARMATURE':
                    transform_objects.append(TransformObject(ob, scale=scale_factor)) # scale loc but otherwise retain matrix
                case 'LATTICE' | 'LIGHT':
                    transform_objects.append(TransformObject(ob, transform_matrix)) # update loc, rot, sca
                    if ob.type == 'LIGHT':
                        ob.nwo.light_fade_start_distance *= scale_factor
                        ob.nwo.light_fade_end_distance *= scale_factor
                        ob.nwo.light_volume_distance *= scale_factor
                case 'EMPTY':
                    ob.empty_display_size *= scale_factor
                    if keep_marker_axis and not is_frame(ob) and ob not in parents:
                        transform_objects.append(TransformObject(ob, rotation_matrix, scale_factor, marker_z_matrix=marker_z))
                    else:
                        transform_objects.append(TransformObject(ob, rotation_matrix, scale_factor))
                case _:
                    ob.nwo.water_volume_flow_direction += rotation
                    transform_objects.append(TransformObject(ob, rotation_matrix, scale_factor)) # update and scale loc, update rot

            if not skip_data:
                for mod in ob.modifiers:
                    match mod.type:
                        case 'BEVEL':
                            mod.width *= scale_factor
                        case 'DISPLACE':
                            mod.strength *= scale_factor
                        case 'CAST':
                            mod.radius *= scale_factor
                        case 'SHRINKWRAP':
                            mod.offset *= scale_factor
                            mod.project_limit *= scale_factor
                        case 'WAVE':
                            mod.offset *= scale_factor
                            mod.height *= scale_factor
                            mod.width *= scale_factor
                            mod.falloff_radius *= scale_factor
                            mod.narrowness *= scale_factor
                            mod.start_position_x *= scale_factor
                            mod.start_position_y *= scale_factor
                        case 'OCEAN':
                            mod.depth *= scale_factor
                            mod.wave_scale_min *= scale_factor
                            mod.wind_velocity *= scale_factor
                        case 'ARRAY':
                            mod.constant_offset_displace *= scale_factor
                            mod.merge_threshold *= scale_factor
                        case 'MIRROR':
                            mod.merge_threshold *= scale_factor
                            mod.bisect_threshold *= scale_factor
                            if not keep_marker_axis and mod.mirror_object and is_marker(mod.mirror_object):
                                fix_mirror_angles(mod, old_forward, new_forward)
                        case 'REMESH':
                            mod.voxel_size *= scale_factor
                            mod.adaptivity *= scale_factor
                        case 'SCREW':
                            mod.screw_offset *= scale_factor
                        case 'SOLIDIFY':
                            mod.thickness *= scale_factor
                        case 'WELD':
                            mod.merge_threshold *= scale_factor
                        case 'WIREFRAME':
                            mod.thickness *= scale_factor
                        case 'CAST':
                            mod.radius *= scale_factor
                        case 'HOOK':
                            mod.falloff_radius *= scale_factor
                        case 'WARP':
                            mod.falloff_radius *= scale_factor
                        case 'DATA_TRANSFER':
                            mod.islands_precision *= scale_factor
                            mod.max_distance *= scale_factor
                            mod.ray_radius *= scale_factor
                            
                for con in ob.constraints:
                    match con.type:
                        case 'LIMIT_DISTANCE':
                            con.distance *= scale_factor
                        case 'LIMIT_LOCATION':
                            con.min_x *= scale_factor
                            con.min_y *= scale_factor
                            con.min_z *= scale_factor
                            con.max_x *= scale_factor
                            con.max_y *= scale_factor
                            con.max_z *= scale_factor
                        case 'STRETCH_TO':
                            con.rest_length *= scale_factor
                        case 'SHRINKWRAP':
                            con.distance *= scale_factor
                        case 'FOLLOW_PATH':
                            if rotation:
                                con.forward_axis = rotate_follow_path_axis(con.forward_axis, old_forward, new_forward)
                        case 'CHILD_OF':
                            child_of_constraints.append(con)
        
        transform_objects.sort(key=lambda t_o: parentage_depth(t_o.ob))
        
        if not skip_data:
            for curve in curves:
                if hasattr(curve, 'size'):
                    curve.size *= scale_factor
                if hasattr(curve, 'use_radius'):
                    curve.use_radius = False
                    
                curve.transform(scale_matrix)
                # curve.nwo.material_lighting_attenuation_falloff *= scale_factor
                # curve.nwo.material_lighting_attenuation_cutoff *= scale_factor
                
            for metaball in metaballs:
                metaball.transform(scale_matrix)
                # metaball.nwo.material_lighting_attenuation_falloff *= scale_factor
                # metaball.nwo.material_lighting_attenuation_cutoff *= scale_factor
                
            # for lattice in lattices:
            #     lattice.transform(scale_matrix)
            
            for mesh in meshes:
                mesh.transform(scale_matrix)
                
            for camera in cameras:
                camera.display_size *= scale_factor
                
            for light in lights:
                light.nwo.light_far_attenuation_start *= scale_factor
                light.nwo.light_far_attenuation_end *= scale_factor
                # light.nwo.light_near_attenuation_start *= scale_factor
                # light.nwo.light_near_attenuation_end *= scale_factor
                light.shadow_soft_size *= scale_factor
                if scale_light_energy and light.type != 'SUN':
                    light.energy *= energy_factor

            if armatures:
                deselect_all_objects()
                arm_datas = set()
                arm_linkyness = {}
                for arm in armatures:
                    if arm.library or arm.data.library:
                        print_warning(f'Cannot scale {arm.name}')
                        continue

                    should_be_hidden = False
                    should_be_unlinked = False
                    data = arm.data

                    if arm.hide_get():
                        arm.hide_set(False)
                        should_be_hidden = True

                    if not arm.visible_get():
                        original_collections = arm.users_collection
                        unlink(arm)
                        scene_coll.link(arm)
                        should_be_unlinked = True
                    
                    set_active_object(arm)
                    arm.select_set(True)
                    arm_linkyness[arm] = should_be_hidden, should_be_unlinked
                    
                bpy.ops.object.mode_set(mode='EDIT', toggle=False)
                for arm in armatures:
                    data = arm.data
                    if data not in arm_datas:
                        arm_datas.add(data)

                        uses_edit_mirror = bool(data.use_mirror_x)
                        data.use_mirror_x = False

                        edit_bones = data.edit_bones
                        connected = [b for b in edit_bones if b.use_connect]
                        for b in connected:
                            b.use_connect = False

                        arm_inv = scale_matrix @ arm.matrix_world.inverted_safe()

                        for b in edit_bones:
                            world = arm.matrix_world @ b.matrix
                            b.matrix = arm_inv @ (rotation_matrix @ world)

                        for b in connected:
                            b.use_connect = True

                        data.use_mirror_x = uses_edit_mirror

                bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
                for arm in armatures:
                    uses_pose_mirror = bool(arm.pose.use_mirror_x)
                    arm.pose.use_mirror_x = False

                    for pb in arm.pose.bones:
                        pb.custom_shape_translation *= scale_factor
                        pb.custom_shape_scale_xyz *= scale_factor

                        for con in pb.constraints:
                            match con.type:
                                case 'LIMIT_DISTANCE':
                                    con.distance *= scale_factor
                                case 'LIMIT_LOCATION':
                                    con.min_x *= scale_factor
                                    con.min_y *= scale_factor
                                    con.min_z *= scale_factor
                                    con.max_x *= scale_factor
                                    con.max_y *= scale_factor
                                    con.max_z *= scale_factor
                                case 'STRETCH_TO':
                                    con.rest_length *= scale_factor
                                case 'SHRINKWRAP':
                                    con.distance *= scale_factor
                                case 'FOLLOW_PATH':
                                    if rotation:
                                        con.forward_axis = rotate_follow_path_axis(
                                            con.forward_axis, old_forward, new_forward
                                        )
                                case 'CHILD_OF':
                                    child_of_constraints.append(con)

                    arm.pose.use_mirror_x = uses_pose_mirror
                    # bpy.ops.object.posemode_toggle()

                    for bone in data.bones:
                        bone.bbone_x *= scale_factor
                        bone.bbone_z *= scale_factor

                for arm, (should_be_hidden, should_be_unlinked) in arm_linkyness.items():
                    if should_be_hidden:
                        arm.hide_set(True)

                    if should_be_unlinked:
                        unlink(arm)
                        for coll in original_collections:
                            coll.objects.link(arm)

        for action in actions:
            for slot in action.slots:
                fc_quaternions: list[bpy.types.FCurve] = []
                fc_locations: list[bpy.types.FCurve] = []
                fcurves = get_fcurves(action, slot)
                for fcurve in fcurves:
                    if fcurve.data_path == 'location':
                        fc_locations.append(fcurve)
                    if fcurve.data_path.endswith('location'):
                        for mod in fcurve.modifiers:
                            if mod.type == 'NOISE':
                                mod.strength *= scale_factor
                        for keyframe_point in fcurve.keyframe_points:
                            keyframe_point.co_ui[1] *= scale_factor
                            
                    elif fcurve.data_path.startswith('rotation_euler') and fcurve.array_index == 2:
                        for kfp in fcurve.keyframe_points:
                            kfp.co_ui[1] += rotation
                    elif fcurve.data_path.startswith('rotation_quaternion'):
                        fc_quaternions.append(fcurve)
                        
                if fc_locations:
                    assert(len(fc_locations) == 3)
                    keyframes_x = []
                    keyframes_y = []
                    keyframes_z = []
                    for fc in fc_locations:
                        if fc.array_index == 0:
                            keyframes_x.append(fc.keyframe_points)
                        elif fc.array_index == 1:
                            keyframes_y.append(fc.keyframe_points)
                        elif fc.array_index == 2:
                            keyframes_z.append(fc.keyframe_points)
                            
                    for i in range(len(keyframes_x)):
                        for kfpx, kfpy, kfpz in zip(keyframes_x[i], keyframes_y[i], keyframes_z[i]):
                            v = Vector((kfpx.co[1], kfpy.co[1], kfpz.co[1]))
                            mat = Matrix.Translation(v)
                            loc = rotation_matrix @ mat
                            vloc = loc.to_translation()
                            kfpx.co_ui[1], kfpy.co_ui[1], kfpz.co_ui[1] = vloc[0], vloc[1], vloc[2]
                    
                if fc_quaternions:
                    assert(len(fc_quaternions) == 4)
                    keyframes_w = []
                    keyframes_x = []
                    keyframes_y = []
                    keyframes_z = []
                    for fc in fc_quaternions:
                        if fc.array_index == 0:
                            keyframes_w.append(fc.keyframe_points)
                        elif fc.array_index == 1:
                            keyframes_x.append(fc.keyframe_points)
                        elif fc.array_index == 2:
                            keyframes_y.append(fc.keyframe_points)
                        elif fc.array_index == 3:
                            keyframes_z.append(fc.keyframe_points)
                            
                    for i in range(len(keyframes_w)):
                        for kfpw, kfpx, kfpy, kfpz in zip(keyframes_w[i], keyframes_x[i], keyframes_y[i], keyframes_z[i]):
                            q = Quaternion((kfpw.co[1], kfpx.co[1], kfpy.co[1], kfpz.co[1]))
                            q.rotate(rotation_matrix)
                            kfpw.co_ui[1], kfpx.co_ui[1], kfpy.co_ui[1], kfpz.co_ui[1] = q[0], q[1], q[2], q[3]

                for fc in fcurves:
                    fc.keyframe_points.handles_recalc()
                
        for transform_ob in transform_objects:
            transform_ob.apply()
            
        for con in child_of_constraints:
            con.set_inverse_pending = True
            
        if apply_rotation:
            with context.temp_override(selected_editable_objects=objects, object=objects[0]):
                bpy.ops.object.transform_apply(location=False, rotation=True, scale=False, isolate_users=True)
                
        for arm, pose_pos in armatures.items():
            arm.data.pose_position = pose_pos
        
        if armatures_to_reparent:
            context.view_layer.update()
        
        for arm, parent in armatures_to_reparent.items():
            m = arm.matrix_world.copy()
            arm.parent = parent
            arm.matrix_world = m
            
def get_area_info(context):
    area = [
        area
        for area in context.screen.areas
        if area.type == "VIEW_3D"
    ][0]
    return area, area.regions[-1], area.spaces.active

def blender_halo_rotation_diff(direction):
    """Returns the rotation (radians) needed to go from the current blender forward to Halo X forward"""
    match direction:
        case "y":
            return radians(-90)
        case "y-":
            return radians(90)
        case "x-":
            return radians(180)
            
    return 0

def blender_rotation_diff(from_direction, to_direction):
    """Returns the rotation (radians) needed to go from the current blender forward to the selected forward"""
    rot = blender_halo_rotation_diff(to_direction)
    match from_direction:
        case "y":
            return rot - radians(-90)
        case "y-":
            return rot - radians(90)
        case "x-":
            return rot - radians(180)
        case "x":
            return rot - 0
            
    return 0

def rotation_diff_from_forward(from_direction, to_direction):
    from_radians = 0
    match from_direction:
        case "y-":
            from_radians = 0
        case "y":
            from_radians = radians(180)
        case "x-":
            from_radians = radians(90)
        case "x":
            from_radians = radians(-90)
        
    to_radians = 0
    match to_direction:
        case "y-":
            to_radians = 0
        case "y":
            to_radians = radians(180)
        case "x-":
            to_radians = radians(90)
        case "x":
            to_radians = radians(-90)
        
    return from_radians - to_radians

def mute_armature_mods():
    muted_arms = []
    for ob in bpy.data.objects:
        for mod in ob.modifiers:
            if mod.type == 'ARMATURE' and mod.use_vertex_groups:
                muted_arms.append(mod)
                mod.use_vertex_groups = False
                
    return muted_arms
                
def unmute_armature_mods(muted_arms):
    for mod in muted_arms:
        mod.use_vertex_groups = True
        
class ArmatureDeformMute:
    def __init__(self):
        self.muted_armature_mods = []
    
    def __enter__(self):
        for ob in bpy.data.objects:
            for mod in ob.modifiers:
                if mod.type == 'ARMATURE' and mod.use_vertex_groups:
                    self.muted_armature_mods.append(mod)
                    mod.use_vertex_groups = False
        
    def __exit__(self, exc_type, exc_value, traceback):
        for mod in self.muted_armature_mods:
            mod.use_vertex_groups = True
    
def rig_root_deform_bone(rig: bpy.types.Object, return_name=False) -> None | bpy.types.Bone| str| list:
    """Returns the root deform bone of this rig. If multiple bones are found, returns none"""
    root_bones = [b for b in rig.data.bones if b.use_deform and not b.parent]
    if len(root_bones) == 1:
        root = root_bones[0]
        if return_name:
            return root.name
        else:
            return root
    elif root_bones:
        return root_bones
    
def in_exclude_collection(ob):
    user_collections = ob.users_collection
    if any([coll.nwo.type == 'exclude' for coll in user_collections]):
        return True

def excluded(ob):
    return not ob.nwo.export_this or in_exclude_collection(ob)

def get_camera_track_camera(context: bpy.types.Context) -> bpy.types.Object | None:
    if get_scene_props().camera_track_camera:
        return get_scene_props().camera_track_camera
    
    cameras = [ob for ob in context.view_layer.objects if ob.type == 'CAMERA']
    animated_cameras = [ob for ob in cameras if ob.animation_data]
    if animated_cameras:
        return animated_cameras[0]
    if cameras:
        return cameras[0]
    
def get_collection_children(collection: bpy.types.Collection):
    child_collections = collection.children
    collections = set()
    for collection in child_collections:
        collections.add(collection)
        if collection.children:
            collections.update(get_collection_children(collection))
            
    return collections
    
def get_exclude_collections():
    '''Gets all collections which are themselves exclude collections or a child of one'''
    direct_exclude_collections = [c for c in bpy.context.scene.collection.children if c.nwo.type == 'exclude']
    all_exclude_collections = set(direct_exclude_collections)
    for collection in direct_exclude_collections:
        if collection.children:
            all_exclude_collections.update(get_collection_children(collection))
    
    return all_exclude_collections
    
def valid_filename(name: str) -> str:
    bad_chars = r'\/:*?"<>'
    for char in bad_chars:
        name = name.replace(char, '_')
        
    return name

def valid_image_name(name: str) -> str:
    for f in BLENDER_IMAGE_FORMATS:
        name = name.replace(f, '')
    
    name = name.replace('.', '_')
    
    return valid_filename(name)

def paths_in_dir(directory: str, valid_extensions: tuple[str] | str = '') -> list[str]:
    assert os.path.exists(directory), f"Directory not a valid filepath: [{directory}]"

    if isinstance(valid_extensions, str):
        valid_extensions = (valid_extensions,)

    results = []
    stack = [directory]

    while stack:
        current = stack.pop()
        with os.scandir(current) as it:
            for entry in it:
                if entry.is_dir(follow_symlinks=False):
                    stack.append(entry.path)
                elif not valid_extensions or entry.name.endswith(valid_extensions):
                    results.append(entry.path)

    return results

class DebugMenuCommand:
    def __init__(self, asset_dir, filename):
        self.path = str(Path(asset_dir, filename)).replace('\\', '\\\\')
        self.tag_type = dot_partition(filename, True).lower()
        self.name = dot_partition(filename).lower()
        
    def __repr__(self):
        return f'<item type = command name = "Foundry: Drop {self.name} [{self.tag_type}]" variable = "drop \\"{self.path}\\"">\n'
    
class DebugMenuType(Enum):
    DEFAULT = 0
    CUBEMAP = 1
    IMPOSTER = 2
    CAMERA = 3

CAMERA_SYNC_DEBUG_NAME = "foundry_camera_sync"
    
def update_debug_menu(asset_dir="", asset_name="", update_type=DebugMenuType.DEFAULT, bsp_names=[]):
    menu_commands: list[DebugMenuCommand] = []
    match update_type:
        case DebugMenuType.DEFAULT:
            asset_dir = relative_path(asset_dir)
            full_path = Path(get_tags_path(), asset_dir)
            if not full_path.exists():
                return
            for file in full_path.iterdir():
                if file.name.startswith(asset_name) and file.suffix in object_exts:
                    menu_commands.append(DebugMenuCommand(asset_dir, file.name))
        case DebugMenuType.CUBEMAP:
            menu_commands.append('<item type = command name = "Foundry: Generate Dynamic Cubemaps" variable = "\\(cubemap_dynamic_generate\\)">\n')
        case DebugMenuType.IMPOSTER:
            for idx, name in enumerate(bsp_names):
                menu_commands.append(f'<item type = command name = "Foundry: Generate Instance Imposters for BSP {name}" variable = "\\(structure_instance_snapshot {idx}\\)">\n')
        case DebugMenuType.CAMERA:
            menu_commands.append(f'<item type = command name = "Foundry: Load Game Camera from Blender" variable = "\\(debug_camera_load_simple_name \\"{CAMERA_SYNC_DEBUG_NAME}\\"\\)">\n')
            menu_commands.append(f'<item type = command name = "Foundry: Save Game Camera for Blender" variable = "\\(debug_camera_save_simple_name \\"{CAMERA_SYNC_DEBUG_NAME}\\"\\)">\n')
            
    menu_path = os.path.join(get_project_path(), 'bin', 'debug_menu_user_init.txt')
    Path(menu_path).parent.mkdir(parents=True, exist_ok=True)
    valid_lines = None
    # Read first so we can keep the users existing commands
    if os.path.exists(menu_path):
        with open(menu_path, 'r') as menu:
            existing_menu = menu.readlines()
            # Strip out Foundry entries. These get rebuilt in the next step.
            valid_lines = [line for line in existing_menu if '"Foundry: ' not in line]
            
    with open(menu_path, 'w') as menu:
        if valid_lines is not None:
            menu.writelines(valid_lines)
            
        menu.writelines([str(cmd) for cmd in menu_commands])
        
def is_halo_rig(ob):
    '''Returns True if the given object is a halo rig'''
    if ob.type != 'ARMATURE':
        return False
    
def get_object_controls(context: bpy.types.Context) -> list[bpy.types.Object]:
    object_controls = get_scene_props().object_controls
    if not object_controls:
        return []
    
    return [control.ob for control in object_controls if control.ob and control.ob.animation_data]

def add_auto_smooth(context: bpy.types.Context, ob: bpy.types.Object, angle=radians(30), apply_mod=False):
    """Applies auto smooth to an object using geometry nodes"""
    mods = ob.modifiers
    auto_smooth = mods.new("foundry_auto_smooth", type="NODES")
    
    node_tree = bpy.data.node_groups.get("foundry_auto_smooth")
    if not node_tree:
        node_tree = bpy.data.node_groups.new("foundry_auto_smooth", "GeometryNodeTree")
        # node_tree.is_modifier = True
        
    # Create input/output sockets
    interface = node_tree.interface
    
    interface.new_socket("Geometry", description="", in_out="INPUT", socket_type="NodeSocketGeometry", parent=None)
    interface.new_socket("Geometry", description="", in_out="OUTPUT", socket_type="NodeSocketGeometry", parent=None)
    
    # Create the nodes! (left to right)
    nodes = node_tree.nodes
    
    edge_angle = nodes.new("GeometryNodeInputMeshEdgeAngle")
    edge_angle.location = Vector((-450, -260))
    face_smooth = nodes.new("GeometryNodeInputShadeSmooth")
    face_smooth.location = Vector((-450, -430))
    
    edge_smooth = nodes.new("GeometryNodeInputEdgeSmooth")
    edge_smooth.location = Vector((-240, -150))
    compare_math = nodes.new("FunctionNodeCompare")
    compare_math.operation = "LESS_EQUAL"
    compare_math.inputs[1].default_value = angle
    compare_math.location = Vector((-245, -225))
    bool_math_a = nodes.new("FunctionNodeBooleanMath")
    bool_math_a.operation = "OR"
    bool_math_a.inputs[1].default_value = True
    bool_math_a.location = Vector((-240, -400))
    
    mesh_input = nodes.new("NodeGroupInput")
    mesh_input.location = Vector((-60, -25))
    node_tree.interface
    bool_math_b = nodes.new("FunctionNodeBooleanMath")
    bool_math_b.operation = "OR"
    bool_math_b.location = Vector((-50, -130))
    bool_math_c = nodes.new("FunctionNodeBooleanMath")
    bool_math_c.operation = "AND"
    bool_math_c.location = Vector((-50, -280))
    
    shade_smooth_a = nodes.new('GeometryNodeSetShadeSmooth')
    shade_smooth_a.domain = 'EDGE'
    shade_smooth_a.location = Vector((145, -50))
    
    shade_smooth_b = nodes.new('GeometryNodeSetShadeSmooth')
    shade_smooth_b.domain = 'FACE'
    shade_smooth_b.inputs[2].default_value = True
    shade_smooth_b.location = Vector((340, -50))
    
    mesh_output = nodes.new("NodeGroupOutput")
    mesh_output.location = Vector((530, -50))
    
    # Link the nodes! (right to left)
    links = node_tree.links
    
    links.new(mesh_output.inputs[0], shade_smooth_b.outputs[0])
    
    links.new(shade_smooth_b.inputs[0], shade_smooth_a.outputs[0])
    
    links.new(shade_smooth_a.inputs[0], mesh_input.outputs[0])
    links.new(shade_smooth_a.inputs[1], bool_math_b.outputs[0])
    links.new(shade_smooth_a.inputs[2], bool_math_c.outputs[0])
    
    links.new(bool_math_b.inputs[0], edge_smooth.outputs[0])
    links.new(bool_math_c.inputs[0], compare_math.outputs[0])
    links.new(bool_math_c.inputs[1], bool_math_a.outputs[0])
    
    links.new(compare_math.inputs[0], edge_angle.outputs[0])
    links.new(bool_math_a.inputs[0], face_smooth.outputs[0])
    
    auto_smooth.node_group = node_tree
    
    if apply_mod:
        with context.temp_override(object=ob):
            bpy.ops.object.modifier_apply(modifier="foundry_auto_smooth", single_user=True)
            
def restart_blender():
    if bpy.data.filepath:
        subprocess.Popen([bpy.app.binary_path, bpy.data.filepath])
    else:
        subprocess.Popen([bpy.app.binary_path])
    bpy.ops.wm.quit_blender()
    
def save_blender():
    bpy.ops.wm.save_mainfile(compress=bpy.context.preferences.filepaths.use_file_compression)
    
def human_time(time: float | int, decimal_seconds=False) -> str:
    '''Returns a string of hours, minutes and seconds using the given time input (in seconds)'''
    hours, minutes_remainder = divmod(time, 3600)
    minutes, seconds_remainder = divmod(minutes_remainder, 60)
    seconds, decimals = divmod(seconds_remainder, 1)
    
    hours = int(hours)
    minutes = int(minutes)
    seconds = int(seconds)
    decimals =  int(decimals * 1000)
    
    final_str = ""
    if hours:
        final_str += f"{hours} hours"
        
    if minutes:
        if hours:
            if seconds:
                final_str += ", "
            else:
                final_str += " and "
        final_str += f"{minutes} minute{'s' if int(minutes) != 1 else ''}"
        
    if seconds:
        if hours or minutes:
            final_str += " and "
        if decimals and decimal_seconds:
            final_str += f"{seconds}.{decimals} seconds"
        else:
            final_str += f"{seconds} second{'s' if int(seconds) != 1 else ''}"
            
    elif decimals:
        if hours or minutes:
            final_str += " and "
        final_str += f"{decimals} millisecond{'s' if int(decimals) != 1 else ''}"
        
    return final_str

def area_light_to_emissive(light_ob: bpy.types.Object, corinth: bool):
    """Converts the given area light to a lightmap only emissive plane"""
    light = light_ob.data
    light_nwo = light_ob.data.nwo
    new_name = light_ob.name + "[emissive]"
    points: list[Vector] = []
    if light.shape in ("SQUARE", "RECTANGLE"):
        plane_data = bpy.data.meshes.new(new_name)
        if light.shape == "SQUARE":
            radius = light.size / 2
            points.append(Vector((-radius, -radius, 0)))
            points.append(Vector((-radius, radius, 0)))
            points.append(Vector((radius, radius, 0)))
            points.append(Vector((radius, -radius, 0)))
        else:
            radius_x = light.size / 2
            radius_y = light.size_y / 2
            points.append(Vector((-radius_x, -radius_y, 0)))
            points.append(Vector((-radius_x, radius_y, 0)))
            points.append(Vector((radius_x, radius_y, 0)))
            points.append(Vector((radius_x, -radius_y, 0)))
    else:
        plane_data = bpy.data.curves.new(new_name, type="CURVE")
        plane_data.dimensions = "2D"
        plane_data.fill_mode = "BOTH"
        if light.shape == "DISK":
            radius = light.size / 2
            points.append(Vector((-radius, 0, 0)))
            points.append(Vector((0, radius, 0)))
            points.append(Vector((radius, 0, 0)))
            points.append(Vector((0, -radius, 0)))
        else:
            radius_x = light.size / 2
            radius_y = light.size_y / 2
            points.append(Vector((-radius_x, 0, 0)))
            points.append(Vector((0, radius_y, 0)))
            points.append(Vector((radius_x, 0, 0)))
            points.append(Vector((0, -radius_y, 0)))
            
        
    if isinstance(plane_data, bpy.types.Mesh):
        plane_data.from_pydata(vertices=points, edges=[], faces=[range(len(points))])
    else:
        plane_data: bpy.types.Curve
        spline = plane_data.splines.new("BEZIER")
        spline.bezier_points.add(3)
        for idx, point in enumerate(points):
            spline.bezier_points[idx].co = point
            
        for bezier_point in spline.bezier_points:
            bezier_point.handle_left_type = 'AUTO'
            bezier_point.handle_right_type = 'AUTO'
            
        spline.use_cyclic_u = True
        
        temp_ob = bpy.data.objects.new(new_name + "_temp", plane_data)
        plane_data = temp_ob.to_mesh().copy()
        bm = bmesh.new()
        bm.from_mesh(plane_data)
        bmesh.ops.reverse_faces(bm, faces=bm.faces)
        bm.to_mesh(plane_data)
        bm.free()
    
    plane_ob = bpy.data.objects.new(new_name, plane_data)
    plane_ob.matrix_world = light_ob.matrix_world
    plane_nwo = plane_data.nwo
    if corinth:
        plane_nwo.mesh_type = "_connected_geometry_mesh_type_default"
        plane_ob.nwo.poop_lightmap_resolution_scale = 0.001
        invis_mat = bpy.data.materials.get("Invisible")
        if invis_mat is None:
            invis_mat = bpy.data.materials.new("Invisible")
            invis_mat.diffuse_color = [0.4, 1.0, 0.4, 0.6]
            bsdf = invis_mat.node_tree.nodes[0]
            bsdf.inputs[0].default_value = invis_mat.diffuse_color
            bsdf.inputs[4].default_value = invis_mat.diffuse_color[3]
            invis_mat.blend_method = 'BLEND'
            invis_mat.nwo.shader_path = r'levels\shared\shaders\simple\invis.material'
        plane_data.materials.append(invis_mat)
    else:
        plane_nwo.mesh_type = "_connected_geometry_mesh_type_structure" # saves on the instance budget
    plane_ob.nwo.region_name = true_region(light_ob.nwo)
    plane_ob.nwo.permutation_name = true_permutation(light_ob.nwo)
    add_face_prop(plane_data, 'face_mode').face_mode = 'lightmap_only'
    prop = add_face_prop(plane_data, 'emissive')
    prop.material_lighting_attenuation_cutoff = light_nwo.light_far_attenuation_end
    prop.material_lighting_attenuation_falloff = light_nwo.light_far_attenuation_start
    prop.material_lighting_emissive_focus = light.spread
    prop.material_lighting_emissive_per_unit = light.normalize
    if light.use_custom_distance:
        intensity = light_nwo.light_intensity
    else:
        intensity = calc_light_intensity(light, get_import_scale(bpy.context))
        
    prop.material_lighting_emissive_color, prop.material_lighting_emissive_power = get_light_final_color_and_intensity(light, intensity, ignore_colorspace_conversion=True)
        
    prop.material_lighting_emissive_quality = light_nwo.light_quality
    prop.material_lighting_use_shader_gel = light_nwo.light_use_shader_gel
    prop.material_lighting_bounce_ratio = plane_ob.nwo.light_bounce_ratio
    
    return plane_ob

def get_asset_animation_graph(full=False):
    if valid_nwo_asset(bpy.context):
        asset_dir, asset_name = get_asset_info()
        tag_path = Path(asset_dir, asset_name).with_suffix(".model_animation_graph")
        full_path = Path(get_tags_path(), tag_path)
        if full_path.exists():
            if full:
                return str(full_path)
            else:
                return str(tag_path)
            
def get_asset_render_model(full=False):
    if valid_nwo_asset(bpy.context):
        asset_dir, asset_name = get_asset_info()
        tag_path = Path(asset_dir, asset_name).with_suffix(".render_model")
        full_path = Path(get_tags_path(), tag_path)
        if full_path.exists():
            if full:
                return str(full_path)
            else:
                return str(tag_path)
            
def get_asset_collision_model(full=False):
    if valid_nwo_asset(bpy.context):
        asset_dir, asset_name = get_asset_info()
        tag_path = Path(asset_dir, asset_name).with_suffix(".collision_model")
        full_path = Path(get_tags_path(), tag_path)
        if full_path.exists():
            if full:
                return str(full_path)
            else:
                return str(tag_path)
            
def get_asset_physics_model(full=False):
    if valid_nwo_asset(bpy.context):
        asset_dir, asset_name = get_asset_info()
        tag_path = Path(asset_dir, asset_name).with_suffix(".physics_model")
        full_path = Path(get_tags_path(), tag_path)
        if full_path.exists():
            if full:
                return str(full_path)
            else:
                return str(tag_path)
            
def get_asset_tag(extension: str, full=False, return_path_anyway=False):
    if not extension.startswith('.'):
        extension = '.' + extension
    if valid_nwo_asset(bpy.context):
        asset_dir, asset_name = get_asset_info()
        tag_path = Path(asset_dir, asset_name).with_suffix(extension)
        full_path = Path(get_tags_path(), tag_path)
        if full_path.exists() or return_path_anyway:
            if full:
                return str(full_path)
            else:
                return str(tag_path)
            
def get_asset_tags(extension= "", full=False):
    if extension and not extension.startswith('.'):
        extension = '.' + extension
    if valid_nwo_asset(bpy.context):
        tags_path = Path(get_tags_path())
        matching_tags = set()
        asset_dir, asset_name = get_asset_info()
        full_dir_path = Path(get_tags_path(), asset_dir)
        if not full_dir_path.exists(): return []
        for file in full_dir_path.iterdir():
            if file.suffix == extension:
                if full:
                    matching_tags.add(file)
                else:
                    matching_tags.add(file.relative_to(tags_path))
    
        return sorted(matching_tags)
    
    return []
            
def save_loop_normals(bm: bmesh.types.BMesh, mesh: bpy.types.Mesh):
    attribute_names = [f"ln{i}" for i in range(max(len(face.verts) for face in bm.faces))]
    layers = {}

    for name in attribute_names:
        if not bm.faces.layers.float_vector.get(name):
            layers[name] = bm.faces.layers.float_vector.new(name)
        else:
            layers[name] = bm.faces.layers.float_vector.get(name)

    bm.faces.ensure_lookup_table()

    for idx, face in enumerate(bm.faces):
        for i in range(len(face.verts)):
            layer = layers[f"ln{i}"]
            face[layer] = mesh.loops[mesh.polygons[idx].loop_indices[i]].normal
            
def save_loop_normals_mesh(mesh: bpy.types.Mesh):
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        if bm.faces:
            save_loop_normals(bm, mesh)
            bm.to_mesh(mesh)
    finally:
        bm.free()
            
def remove_face_attributes(bm: bmesh.types.BMesh, layer_prefix="ln"):
    layers_to_remove = [layer for layer in bm.faces.layers.float_vector.keys() if layer.startswith(layer_prefix)]
    
    for attribute_name in layers_to_remove:
        layer = bm.faces.layers.float_vector[attribute_name]
        bm.faces.layers.float_vector.remove(layer)
            
def apply_loop_normals(mesh: bpy.types.Mesh):        
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        if bm.faces:
            loop_normals = list(yield_loop_normals(bm))
            remove_face_attributes(bm)
            bm.to_mesh(mesh)
            if len(mesh.loops) > len(loop_normals):
                diff = len(mesh.loops) - len(loop_normals)
                loop_normals.extend([[0.0,0.0,0.0]]*diff)
            mesh.normals_split_custom_set(loop_normals)
    finally:
        bm.free()

def loop_normal_magic(mesh: bpy.types.Mesh, distance=0.01):
    '''Saves current normals, merges vertices, and then restores the normals as loop normals'''
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        save_loop_normals(bm, mesh)
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=distance)
        if bm.faces:
            loop_normals = list(yield_loop_normals(bm))
            remove_face_attributes(bm)
            bm.to_mesh(mesh)
            if len(mesh.loops) > len(loop_normals):
                diff = len(mesh.loops) - len(loop_normals)
                loop_normals.extend([[0.0,0.0,0.0]]*diff)
            mesh.normals_split_custom_set(loop_normals)
        else:
            bm.to_mesh(mesh)
    finally:
        bm.free()
    
def yield_loop_normals(bm):
    max_verts = max(len(face.verts) for face in bm.faces)
    layers = {i: bm.faces.layers.float_vector.get(f"ln{i}") for i in range(max_verts)}
    for face in bm.faces:
        for i in range(len(face.verts)):
            layer = layers.get(i)
            if layer:
                yield face[layer].copy()
    
def clean_materials(ob: bpy.types.Object) -> list[bpy.types.MaterialSlot]:
    materials = ob.data.materials
    slots = ob.material_slots
    slots_to_remove = set()
    duplicate_slots = {}
    material_indices = dict.fromkeys(slots)
    for idx, slot in enumerate(slots):
        if not slot.material:
            slots_to_remove.add(idx)
            continue
        slot_name = slot.material.name
        if slot_name not in material_indices.keys():
            material_indices[slot_name] = idx
        else:
            slots_to_remove.add(idx)
            duplicate_slots[idx] = material_indices[slot_name]
    
    if ob.type == 'MESH':
        bm = bmesh.new()
        bm.from_mesh(ob.data)
        bm.faces.ensure_lookup_table()
        used_material_indices = set()
        for face in bm.faces:
            used_material_indices.add(face.material_index)
            if duplicate_slots and face.material_index in duplicate_slots.keys():
                face.material_index = duplicate_slots[face.material_index]
                
        bm.to_mesh(ob.data)
        bm.free()
        
        for i in range(len(slots)):
            if i not in used_material_indices:
                slots_to_remove.add(i)
    
    slots_to_remove = sorted(slots_to_remove, reverse=True)
        
    for idx in slots_to_remove:
        materials.pop(index=idx)
        
    if not ob.data.materials:
        ob.data.materials.clear()
        
    return ob.material_slots

def add_to_collection(objects: list[bpy.types.Object], always_new=False, parent_collection=None, name="collection"):
    if not objects:
        return
    
    for ob in objects: unlink(ob)
    collection = bpy.data.collections.get(name)
    if always_new or not collection:
        collection = bpy.data.collections.new(name)
    
    if parent_collection is None:
        parent_collection = bpy.context.scene.collection
    
    parent_collection.children.link(collection)
    
    [collection.objects.link(ob) for ob in objects]

def get_major_vertex_group(ob: bpy.types.Object):
    if not ob.data.vertices or not ob.vertex_groups:
        return
    if len(ob.vertex_groups) == 1:
        return ob.vertex_groups[0].name
    vert_group_indices = []
    for vert in ob.data.vertices:
        for g in vert.groups:
            vert_group_indices.append(g.group)
    
    if len(vert_group_indices) < 2:
        return ob.vertex_groups[0].name
    
    most_common_index = Counter(vert_group_indices).most_common(1)[0][0]
    
    if len(ob.vertex_groups) > most_common_index: 
        return ob.vertex_groups[most_common_index].name
    
class SetType(IntEnum):
    DEFAULT = 0
    MODEL = 1
    SCENARIO = 2
    
def set_region(ob, region, set_type=SetType.DEFAULT):
    regions_table = get_scene_props().regions_table
    entry = regions_table.get(region, 0)
    if not entry:
        regions_table.add()
        entry = regions_table[-1]
        entry.old = region
        entry.name = region
        entry.set_type = set_type.name
        
    ob.nwo.region_name = region
    
def add_region(region, set_type=SetType.DEFAULT) -> str:
    regions_table = get_scene_props().regions_table
    entry = regions_table.get(region, 0)
    if not entry:
        regions_table.add()
        entry = regions_table[-1]
        entry.old = region
        entry.name = region
        entry.set_type = set_type.name
        
    return entry.name

def set_permutation(ob, permutation, set_type=SetType.DEFAULT):
    permutations_table = get_scene_props().permutations_table
    entry = permutations_table.get(permutation, 0)
    if not entry:
        permutations_table.add()
        entry = permutations_table[-1]
        entry.old = permutation
        entry.name = permutation
        entry.set_type = set_type.name
        
    ob.nwo.permutation_name = permutation
    
def add_permutation(permutation, set_type=SetType.DEFAULT) -> str:
    permutations_table = get_scene_props().permutations_table
    entry = permutations_table.get(permutation, 0)
    if not entry:
        permutations_table.add()
        entry = permutations_table[-1]
        entry.old = permutation
        entry.name = permutation
        entry.set_type = set_type.name
        
    return entry.name
        
def set_marker_permutations(ob, permutations: list[str]):
    for p in permutations:
        name = add_permutation(p)
        ob.nwo.marker_permutations.add().name = name
        
def set_type_from_asset(scene_nwo):
    match scene_nwo.asset_type:
        case 'model' | 'sky':
            return 'MODEL'
        case 'scenario' | 'prefab' | 'multi_prefab':
            return 'SCENARIO'
        
    return 'DEFAULT'
    
def new_face_prop(data, attribute_name, display_name, override_prop, other_props={}) -> str:
    face_props = data.nwo.face_props
    layer = face_props.add()
    layer.attribute_name = attribute_name
    # layer.name = display_name
    layer.color = random_color()
    setattr(layer, override_prop, True)
    for prop, value in other_props.items():
        setattr(layer, prop, value)
        
    return attribute_name

def new_face_attribute(bm, data, attribute_name, display_name, override_prop, other_props={}):
    layer = bm.faces.layers.int.get(attribute_name)
    if layer:
        return layer
    else:
        return bm.faces.layers.int.new(new_face_prop(data, attribute_name, display_name, override_prop, other_props))
    
def face_attribute_count(mesh: bpy.types.Mesh, prop) -> 0:
    attribute = mesh.attributes.get(prop.attribute_name)
    if attribute is None:
        return 0
    
    array = np.zeros(len(mesh.polygons), dtype=np.int8)
    attribute.data.foreach_get("value", array)
    
    return len(np.nonzero(array)[0])

def face_attribute_count_edit_mode(mesh: bpy.types.Mesh, prop) -> 0:
    bm = bmesh.from_edit_mesh(mesh)
    attribute = bm.faces.layers.bool.get(prop.attribute_name)
    if attribute is None:
        return 0
    
    face_count = 0
    for face in bm.faces:
        if face[attribute]:
            face_count += 1
            
    return face_count

def calc_face_prop_counts(mesh: bpy.types.Mesh):
    for prop in mesh.nwo.face_props:
        prop.face_count = face_attribute_count(mesh, prop)
    
def add_face_attribute(mesh: bpy.types.Mesh) -> bpy.types.Attribute:
    attribute = mesh.attributes.new(f"foundry_attribute__{str(uuid4())[:8]}", 'BOOLEAN', 'FACE')
    array = np.ones(len(mesh.polygons), dtype=np.int8)
    attribute.data.foreach_set("value", array)
    
    return attribute

def add_face_attribute_empty(mesh: bpy.types.Mesh) -> bpy.types.Attribute:
    attribute = mesh.attributes.new(f"foundry_attribute__{str(uuid4())[:8]}", 'BOOLEAN', 'FACE')
    return attribute

def test_face_prop_any(mesh: bpy.types.Mesh, prop_name: str):
    '''Tests if a mesh has a face prop with the given name assigned to ANY face'''
    for prop in mesh.nwo.face_props:
        if prop.name == prop_name:
            if isinstance(mesh, bpy.types.Mesh):
                return bool(face_attribute_count(mesh, prop))
            else:
                return True
    
    return False

def test_face_prop_all(mesh: bpy.types.Mesh, prop_name: str):
    '''Tests if a mesh has a face prop with the given name assigned to ALL faces.'''
    face_count = len(mesh.polygons)
    for prop in mesh.nwo.face_props:
        if prop.name == prop_name:
            if isinstance(mesh, bpy.types.Mesh):
                return face_attribute_count(mesh, prop) == face_count
            else:
                return True
            
    return False

def copy_face_prop(mesh: bpy.types.Mesh, prop, copy_mesh: bpy.types.Mesh):
    copy_prop = copy_mesh.nwo.face_props.add()
    for k, v in prop.items():
        copy_prop[k] = v
        
    if not isinstance(mesh, bpy.types.Mesh) or not isinstance(copy_mesh, bpy.types.Mesh):
        copy_prop.attribute_name = ""
        return
    
    attribute = mesh.attributes.get(prop.attribute_name)
    
    if attribute is None:
        return
    
    face_count = len(mesh.polygons)
    if face_count == face_attribute_count(mesh, prop):
        copy_attribute = add_face_attribute(copy_mesh)
        copy_prop.face_count = len(copy_mesh.polygons)
    else:
        copy_attribute = add_face_attribute_empty(copy_mesh)
        indices = np.zeros(face_count, dtype=np.int8)
        attribute.data.foreach_get("value", indices)
        copy_indices = np.zeros(len(copy_mesh.polygons), dtype=np.int8)
        min_size = min(indices.size, copy_indices.size)
        copy_indices[:min_size] = indices[:min_size]
        copy_attribute.data.foreach_set("value", copy_indices)
        
    copy_prop.attribute_name = copy_attribute.name

def add_face_prop(mesh: bpy.types.Mesh, prop_type: str, values_map=None):
    prop = mesh.nwo.face_props.add()
    prop.type = prop_type
    prop.color = random_color()
    attribute = None
    if isinstance(mesh, bpy.types.Mesh):
        has_any_values = values_map.any() if isinstance(values_map, np.ndarray) else bool(values_map)
        
        if has_any_values:
            attribute = add_face_attribute_empty(mesh)
            attribute.data.foreach_set("value", values_map)
            prop.face_count = len(np.nonzero(values_map)[0])
        else:
            attribute = add_face_attribute(mesh)
            prop.face_count = len(mesh.polygons)
            
        prop.attribute_name = attribute.name
        
    return prop

def add_face_attribute_edit_mode(mesh: bpy.types.Mesh, assign_all=False) -> bmesh.types.BMLayerItem:
    bm = bmesh.from_edit_mesh(mesh)
    
    attribute = bm.faces.layers.bool.new(f"foundry_attribute__{str(uuid4())[:8]}")
    
    if assign_all:
        for face in bm.faces:
            face[attribute] = True
            
    bmesh.update_edit_mesh(mesh)
    
    return attribute

def assign_face_attribute(mesh: bpy.types.Mesh) -> tuple[bmesh.types.BMLayerItem, int]:
    attribute = mesh.attributes.get(mesh.nwo.face_props[mesh.nwo.face_props_active_index].attribute_name)
    face_count = len(mesh.polygons)
    if attribute is None:
        attribute = add_face_attribute(mesh)
    else:
        array = np.ones(face_count, dtype=np.int8)
        attribute.data.foreach_set("value", array)
        
    return attribute, face_count

def assign_face_attribute_edit_mode(mesh: bpy.types.Mesh) -> tuple[bmesh.types.BMLayerItem, int]:
    bm = bmesh.from_edit_mesh(mesh)
    attribute = bm.faces.layers.bool.get(mesh.nwo.face_props[mesh.nwo.face_props_active_index].attribute_name)
    if attribute is None:
        attribute = add_face_attribute_edit_mode(mesh)
    
    face_count = 0
    for face in bm.faces:
        if face.select:
            face[attribute] = True
            face_count += 1
        
        elif face[attribute]:
            face_count += 1
            
    bmesh.update_edit_mesh(mesh)
    
    return attribute, face_count

def remove_face_attribute_edit_mode(mesh: bpy.types.Mesh) -> int:
    bm = bmesh.from_edit_mesh(mesh)
    attribute = bm.faces.layers.bool.get(mesh.nwo.face_props[mesh.nwo.face_props_active_index].attribute_name)
    if attribute is None:
        attribute = add_face_attribute_edit_mode(mesh, True)
    
    face_count = 0
    for face in bm.faces:
        if face.select:
            face[attribute] = False
        elif face[attribute]:
            face_count += 1
            
    bmesh.update_edit_mesh(mesh)
    bm.free()
    
    return attribute, face_count

def select_face_attribute_edit_mode(mesh: bpy.types.Mesh, select=True):
    bm = bmesh.from_edit_mesh(mesh)
    attribute = bm.faces.layers.bool.get(mesh.nwo.face_props[mesh.nwo.face_props_active_index].attribute_name)
    if attribute is None:
        return
    
    for face in bm.faces:
        if face[attribute]:
            face.select = select
            
    bmesh.update_edit_mesh(mesh)
    
class EditArmature:
    ob: bpy.types.Object
    head_vectors: dict
    tail_vectors: dict
    lengths: dict
    matrices: dict[Matrix]
    bones: list[str]
    
    def __init__(self, arm):
        self.ob = arm
        scene_coll = bpy.context.scene
        should_be_hidden = False
        should_be_unlinked = False
        if arm.hide_get():
            arm.hide_set(False)
            should_be_hidden = True
            
        if not arm.visible_get():
            original_collections = arm.users_collection
            unlink(arm)
            scene_coll.link(arm)
            should_be_unlinked = True       
            
        set_active_object(arm)
        bpy.ops.object.mode_set(mode='EDIT', toggle=False)
        edit_bones = arm.data.edit_bones
        self.head_vectors = {b.name: b.head for b in edit_bones}
        self.tail_vectors = {b.name: b.tail for b in edit_bones}
        self.lengths = {b.name: b.length for b in edit_bones}
        self.matrices = {b.name: b.matrix for b in edit_bones}
        self.bones = [b.name for b in edit_bones]
        bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
        
        if should_be_hidden:
            arm.hide_set(True)
            
        if should_be_unlinked:
            unlink(arm)
            if original_collections:
                for coll in original_collections:
                    coll.objects.link(arm)
                    
def disable_excluded_collections(context) -> set[bpy.types.Collection]:
    child_coll = context.view_layer.layer_collection.children
    hidden_colls = set()
    for layer in child_coll:
        hidden_colls = hide_excluded_recursively(layer, hidden_colls)
        
    return hidden_colls

def hide_excluded_recursively(layer: bpy.types.Collection, hidden_colls: set[bpy.types.Collection]):
    if layer.collection.nwo.type == 'exclude' and layer.is_visible:
        layer.exclude = True
        hidden_colls.add(layer)
    for child_layer in layer.children:
        hidden_colls = hide_excluded_recursively(child_layer, hidden_colls)
        
    return hidden_colls
        
def unhide_collections(context):
    layer_collection = context.view_layer.layer_collection
    recursive_unhide_collections(layer_collection)

def recursive_unhide_collections(collections):
    coll_children = collections.children
    for collection in coll_children:
        collection.hide_viewport = False
        if collection.children:
            recursive_unhide_collections(collection)
                
def update_view_layer(context):
    context.view_layer.update()
    
def remove_relative_parenting(armature):
    '''
    Sets bone relative parenting to false for each bone on the given armature\n
    Resolves correct object parent inverses to account for the change
    '''
    relative_bones = set()
    for b in armature.data.bones:
        if b.use_relative_parent:
            relative_bones.add(b)

    relative_bone_names = [b.name for b in relative_bones]
    for ob in bpy.data.objects:
        if ob.parent == armature and ob.parent_type == 'BONE' and ob.parent_bone in relative_bone_names:
            bone = armature.data.bones[ob.parent_bone]
            ob.matrix_parent_inverse = (armature.matrix_world @ Matrix.Translation(bone.tail_local - bone.head_local) @ bone.matrix_local).inverted_safe()

    for b in relative_bones: b.use_relative_parent = False
    
def apply_armature_scale(context, arm: bpy.types.Object):
    '''Applies an armature's scale while scaling animations. Assumes scaling is positive and uniform'''
    old_scale = arm.scale.copy()
    scale_factor = arm.scale.x
    scale_matrix = Matrix.Scale(scale_factor, 4)
    scene_coll = context.scene.collection.objects
    arm_children = {ob: ob.matrix_world.copy() for ob in bpy.data.objects if ob.parent == arm}
    
    arm.scale = Vector.Fill(3, 1)
    
    for ob, world in arm_children.items():
        ob.matrix_world = world

    # scale the armature bones
    should_be_hidden = False
    should_be_unlinked = False
    data: bpy.types.Armature = arm.data
    if arm.hide_get():
        arm.hide_set(False)
        should_be_hidden = True
        
    if not arm.visible_get():
        original_collections = arm.users_collection
        unlink(arm)
        scene_coll.link(arm)
        should_be_unlinked = True
        
    set_active_object(arm)
    bpy.ops.object.mode_set(mode='EDIT', toggle=False)
    
    uses_edit_mirror = bool(arm.data.use_mirror_x)
    if uses_edit_mirror: arm.data.use_mirror_x = False
    edit_bones = data.edit_bones
    connected_bones = [b for b in edit_bones if b.use_connect]
    for edit_bone in connected_bones: edit_bone.use_connect = False
    for edit_bone in edit_bones: edit_bone.transform(scale_matrix)
    for edit_bone in connected_bones: edit_bone.use_connect = True
    if uses_edit_mirror: arm.data.use_mirror_x = True
        
    bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
    
    if should_be_hidden:
        arm.hide_set(True)
        
    if should_be_unlinked:
        unlink(arm)
        if original_collections:
            for coll in original_collections:
                coll.objects.link(arm)
    
    # Scale the animations
    for action in bpy.data.actions:
        for slot in action.slots:
            fcurves = get_fcurves(action, slot)
            for fcurve in fcurves:
                if fcurve.data_path.endswith('location'):
                    for keyframe_point in fcurve.keyframe_points: keyframe_point.co_ui[1] *= scale_factor

            for fc in fcurves:
                if fcurve.data_path.endswith('location'):
                    fc.keyframe_points.handles_recalc()
                
def project_game_icon(context, project=None):
    if project is None:
        project = get_project(get_scene_props().scene_project)
    if not project:
        return get_icon_id('tag_test')
    match project.remote_server_name:
        case 'bngtoolsql':
            return get_icon_id('halo_reach')
        case 'metawins':
            return get_icon_id('halo_4')
        case 'episql.343i.selfhost.corp.microsoft.com':
            return get_icon_id('halo_2amp')
        
def project_game_for_mcc(context, project=None):
    if project is None:
        project = get_project(get_scene_props().scene_project)
    match project.remote_server_name:
        case 'bngtoolsql':
            return 'HaloReach'
        case 'metawins':
            return 'Halo4'
        case 'episql.343i.selfhost.corp.microsoft.com':
            return 'Halo2A'
        
def project_icon(context, project=None):
    if project is None:
        project = get_project(get_scene_props().scene_project)
    if not project:
        return get_icon_id('tag_test')
    
    thumbnail = Path(project.project_path, project.image_path)
    if thumbnail.exists():
        return get_icon_id_in_directory(str(thumbnail))
    else:
        return project_game_icon(context, project)
    
class Spinner:
    busy = False
    delay = 0.1

    def __init__(self, delay=None):
        if delay and float(delay): self.delay = delay

    def spinner_task(self):
        while self.busy:
            sys.stdout.write(next(spinny))
            sys.stdout.flush()
            time.sleep(self.delay)
            sys.stdout.write('\b')
            sys.stdout.flush()

    def __enter__(self):
        self.busy = True
        threading.Thread(target=self.spinner_task).start()

    def __exit__(self, exception, value, tb):
        self.busy = False
        time.sleep(self.delay)
        if exception is not None:
            return False
        
class TagImportMover():
    def __init__(self, tags_dir, file):
        self.needs_to_move = False
        self.source_file = Path(file)
        name = self.source_file.with_suffix("").name
        self.temp_file = Path(tags_dir, "_temp", name + self.source_file.suffix)
        if not self.source_file.is_relative_to(Path(tags_dir)):
            print_warning(f"Tag [{self.source_file.name}] is from a different project and may fail to load")
            self.potential_source_tag_dir = Path(any_partition(str(self.source_file), f'{os.sep}tags{os.sep}'), "tags")
            self.needs_to_move = True
            self.tag_path = str(Path("_temp", name + self.source_file.suffix))
            if not self.temp_file.parent.exists():
                self.temp_file.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(self.source_file, self.temp_file)
        else:
            self.tag_path = str(self.source_file.relative_to(tags_dir))
    
    def __enter__(self):
        return self
        
    def __exit__(self, exc_type, exc_value, traceback):
        if self.needs_to_move and self.temp_file.exists():
            pass
            # self.temp_file.unlink()
                
def get_foundry_blam_exe():
    bin_dir = Path(get_project_path(), "bin")
    if is_corinth():
        target_exe = Path(bin_dir, "FoundryBlamCorinth.exe")
    else:
        target_exe = Path(bin_dir, "FoundryBlam.exe")
    target_json_dll = Path(bin_dir, "Newtonsoft.Json.dll")
    if False and target_exe.exists() and target_json_dll.exists():
        return str(target_exe)
    else:
        source_dir = Path(addon_root(), "managed_blam", "FoundryBlam")
        if is_corinth():
            source_exe = Path(source_dir, "FoundryBlamCorinth.exe")
        else:
            source_exe = Path(source_dir, "FoundryBlam.exe")
            
        source_json_dll = Path(source_dir, "Newtonsoft.Json.dll")
        try:
            shutil.copyfile(source_exe, target_exe)
            shutil.copyfile(source_json_dll, target_json_dll)
        except:
            pass

    if not target_json_dll.exists():
        raise RuntimeError("Failed to copy Newtonsoft.Json.dll for FoundryBlam")

    if target_exe.exists():
        return str(target_exe)
    
    raise RuntimeError("Failed to copy FoundryBlam.exe")

def mouse_in_object_editor_region(context, x, y):
    for area in context.screen.areas:
        if area.type not in ('VIEW_3D', "PROPERTIES", "OUTLINER"):
            continue
        for region in area.regions:
            if region.type == 'WINDOW':
                if (x >= region.x and
                    y >= region.y and
                    x < region.width + region.x and
                    y < region.height + region.y):
                    return True

    return False

def get_exe(name: str):
    project_dir = Path(get_project_path())
    for file in project_dir.iterdir():
        if file.suffix.lower() != ".exe": continue
        if name in file.name:
            return file
        
def to_convex_hull(ob: bpy.types.Object):
    """Converts the given object to a convex hull"""
    if ob.type not in ("CURVE", "SURFACE", "META", "FONT", "MESH"): return
    mesh = ob.to_mesh()
    new_data = ob.data.copy()
    bm = bmesh.new()
    bm.from_mesh(mesh)
    for edge in bm.edges: bm.edges.remove(edge)
    bm.edges.ensure_lookup_table()
    result = bmesh.ops.convex_hull(bm, input=bm.verts, use_existing_faces=True)
    bmesh.ops.delete(bm, geom=result["geom_interior"], context='VERTS')
    bm.to_mesh(new_data)
    bm.free()
    ob.data = new_data
    

def to_bounding_box(ob: bpy.types.Object):
    """Converts the given object to its bounding box"""
    if ob.type not in ("CURVE", "SURFACE", "META", "FONT", "MESH"): return
    new_data = ob.data.copy()
    bm = bmesh.new()
    bbox = ob.bound_box
    for co in bbox:
        bmesh.ops.create_vert(bm, co=co)

    bm.verts.ensure_lookup_table()
    back_face = [bm.verts[0], bm.verts[1], bm.verts[2], bm.verts[3]]
    front_face = [bm.verts[4], bm.verts[5], bm.verts[6], bm.verts[7]]
    left_face = [bm.verts[0], bm.verts[1], bm.verts[4], bm.verts[5]]
    right_face = [bm.verts[2], bm.verts[3], bm.verts[6], bm.verts[7]]
    bottom_face = [bm.verts[0], bm.verts[3], bm.verts[4], bm.verts[7]]
    top_face = [bm.verts[1], bm.verts[2], bm.verts[5], bm.verts[6]]
    bmesh.ops.contextual_create(bm, geom=back_face, mat_nr=0, use_smooth=False)
    bmesh.ops.contextual_create(bm, geom=front_face, mat_nr=0, use_smooth=False)
    bmesh.ops.contextual_create(bm, geom=left_face, mat_nr=0, use_smooth=False)
    bmesh.ops.contextual_create(bm, geom=right_face, mat_nr=0, use_smooth=False)
    bmesh.ops.contextual_create(bm, geom=bottom_face, mat_nr=0, use_smooth=False)
    bmesh.ops.contextual_create(bm, geom=top_face, mat_nr=0, use_smooth=False)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(new_data)
    bm.free()
    ob.data = new_data
    
def id_from_string(name) -> str:
    rand = random.Random(name)
    return rand.randint(-2147483647, 2147483647)

def ijkw_to_wxyz(rot: list[float, float, float, float] | Vector | Quaternion) -> Quaternion:
    i, j, k, w = rot
    return Quaternion((w, i, j, k))

def unsigned_int16(n: int) -> int:
    if n < 0:
        return 65536 + n
    return n

def unsigned_int8(n: int) -> int:
    if n < 0:
        return 256 + n
    return n

def signed_int8(value):
    if not 0 <= value <= 255:
        raise ValueError("Value must be between 0 and 255")
    return value - 256 if value > 127 else value

class BoundsDisplay(Enum):
    BOX = auto()
    PILL = auto()
    SPHERE = auto()

def set_bounds_display(ob: bpy.types.Object, display: BoundsDisplay):
    match display:
        case BoundsDisplay.BOX:
            ob.show_bounds = True
            ob.display_bounds_type = 'BOX'
        case BoundsDisplay.PILL:
            ob.show_bounds = True
            ob.display_bounds_type = 'CAPSULE'
        case BoundsDisplay.SPHERE:
            ob.show_bounds = True
            ob.display_bounds_type = 'SPHERE'
            
class MessageBoxType(Enum):
    OK = 0
    OKCXL = 1
    YESNOCXL = 3
    YESNO = 4

class MessageBox:
    mtype: MessageBoxType
    title: str
    message: str
    confirmed: bool
    def __init__(self, mtype: MessageBoxType, title: str, message: str):
        self.mtype = mtype
        self.title = title
        self.message = message
        self.confirmed = False
    
    def show(self):
        result = ctypes.windll.user32.MessageBoxW(0, self.message, self.title, self.mtype.value)
        if (self.mtype == MessageBoxType.YESNO or self.mtype == MessageBoxType.YESNOCXL) and result == 6:
            self.confirmed = True
            
def set_foundry_panel_active():
    '''Sets Foundry as the active panel'''
    area = next((area for area in bpy.context.screen.areas if area.type == 'VIEW_3D'), None)
    if area is not None:
        tool_region = next((region for region in area.regions if region.type == 'UI'), None)
        if tool_region is not None:
            tool_region.active_panel_category = "Foundry"
            
def cut_out_mesh(ob: bpy.types.Object, cutter: bpy.types.Object):
    '''Cuts out mesh from the first object using the second'''
    bm = bmesh.new()
    bm.from_mesh(ob.data)
    cutter_coords = {v.co for v in cutter.data.vertices}
    for v in bm.verts:
        v.select = False
        if v.co in cutter_coords:
            v.select = True
            
    bmesh.ops.delete(bm, geom=[f for f in bm.faces if f.select], context='FACES')
    bm.to_mesh(ob.data)
    bm.free()
    
def get_halo_props_for_granny(props) -> dict:
    # halo_props = {k: v.encode() for k, v in props.items() if type(k) == str}
    halo_props = {}
    prop_array_type = getattr(bpy.types, "bpy_prop_array", None)
    sequence_types = (tuple, list, Color, Vector, np.ndarray)
    if prop_array_type is not None:
        sequence_types = (*sequence_types, prop_array_type)
    for key, v in props.items():
        k = key.encode()
        if isinstance(v, str):
            halo_props[k] = v.encode()
        elif isinstance(v, bool):
            halo_props[k] = c_int(int(v))
        elif isinstance(v, int):
            halo_props[k] = c_int(v)
        elif isinstance(v, float):
            halo_props[k] = c_float(v)
        elif isinstance(v, np.integer):
            halo_props[k] = c_int(int(v))
        elif isinstance(v, np.floating):
            halo_props[k] = c_float(float(v))
        elif isinstance(v, bytes):
            halo_props[k] = v
        elif isinstance(v, sequence_types):
            values = list(np.asarray(v).ravel()) if isinstance(v, np.ndarray) else list(v)
            if not values:
                continue
            if all(isinstance(item, (bool, int, float, np.integer, np.floating)) for item in values):
                halo_props[k] = (c_float * len(values))(*(float(item) for item in values))
            else:
                raise NotImplementedError(f"Unsupported Granny property sequence {key}: {type(v)}")
        else:
            raise NotImplementedError(f"Unsupported Granny property {key}: {type(v)}")
            
    return halo_props

def get_bone_matrix_local(bone: bpy.types.PoseBone) -> Matrix:
    if not bone.parent:
        return bone.matrix.copy()
    return bone.parent.matrix.inverted_safe() @ bone.matrix

def get_version() -> tuple[int, int, int]:
    return module.bl_info["version"]

def get_version_string() -> str:
    version = get_version()
    return ".".join([str(n) for n in version])

def has_gr2_viewer() -> bool:
    viewer_path = get_prefs().granny_viewer_path
    if len(viewer_path.strip()) < 3:
        return False
    return Path(viewer_path.strip("""'\" """)).with_suffix(".exe").exists()

def remove_node_prefix(string):
    node_prefix_tuple = ('b ', 'b_', 'bone ', 'bone_', 'frame ', 'frame_', 'bip01 ', 'bip01_')
    name = string

    for node_prefix in node_prefix_tuple:
        if name.lower().startswith(node_prefix):
            name = re.split(node_prefix, name, maxsplit=1, flags=re.IGNORECASE)[1]
            break

    return name

def get_pose_bone(arm: bpy.types.Object, node_name: str) -> bpy.types.PoseBone | None:
    for bone in arm.pose.bones:
        if bone.name.lower() == node_name.lower():
            return bone

    for bone in arm.pose.bones:
        if remove_node_prefix(bone.name).lower() == node_name.lower():
            return bone
        
def mesh_and_material(m_type, context):
    mesh_type = ""
    material = ""
    match m_type:
        case "collision":
            mesh_type = "_connected_geometry_mesh_type_collision"
            if get_scene_props().asset_type == 'model':
                material = "Collision"
        case "physics":
            mesh_type = "_connected_geometry_mesh_type_physics"
            material = "Physics"
        case "render":
            mesh_type = "_connected_geometry_mesh_type_default"
        case "io":
            mesh_type = "_connected_geometry_mesh_type_object_instance"
        case "instance":
            mesh_type = "_connected_geometry_mesh_type_default"
        case "structure":
            mesh_type = "_connected_geometry_mesh_type_structure"
        case "seam":
            mesh_type = "_connected_geometry_mesh_type_seam"
            material = "Seam"
        case "portal":
            mesh_type = "_connected_geometry_mesh_type_portal"
            material = "Portal"
        case "water_surface":
            mesh_type = "_connected_geometry_mesh_type_water_surface"
        case "rain_sheet":
            mesh_type = "_connected_geometry_mesh_type_poop_vertical_rain_sheet"
        case "fog":
            mesh_type = "_connected_geometry_mesh_type_planar_fog_volume"
            material = "Fog"
        case "lightmap_region":
            mesh_type = "_connected_geometry_mesh_type_lightmap_region"
            material = "LightmapRegion"
        case "boundary_surface":
            mesh_type = "_connected_geometry_mesh_type_boundary_surface"
            material = "SoftCeiling"
        case "soft_ceiling":
            mesh_type = "_connected_geometry_mesh_type_boundary_surface"
            material = "SoftCeiling"
        case "soft_kill":
            mesh_type = "_connected_geometry_mesh_type_boundary_surface"
            material = "SoftKill"
        case "slip_surface":
            mesh_type = "_connected_geometry_mesh_type_boundary_surface"
            material = "SlipSurface"
        case "obb_volume":
            mesh_type = "_connected_geometry_mesh_type_obb_volume"
            material = "StreamingVolume"
        case "streaming_volume":
            mesh_type = "_connected_geometry_mesh_type_obb_volume"
            material = "StreamingVolume"
        case "lightmap_exclusion":
            mesh_type = "_connected_geometry_mesh_type_obb_volume"
            material = "LightmapExcludeVolume"
        case "cookie_cutter":
            mesh_type = "_connected_geometry_mesh_type_cookie_cutter"
            material = "CookieCutter"
        case "rain_blocker":
            mesh_type = "_connected_geometry_mesh_type_poop_rain_blocker"
        case "decorator":
            mesh_type = "_connected_geometry_mesh_type_decorator"
            
    return mesh_type, material

def clamp(number: float | int, minimum: float | int, maximum: float | int) -> float | int:
    return max(min(maximum, number), minimum)

def tri_mod_to_bmesh_tri(txt: str) -> str:
    match txt:
        case 'CLIP':
            return 'EAR_CLIP'
        case 'SHORTEST_DIAGONAL':
            return 'SHORT_EDGE'
        case 'LONGEST_DIAGONAL':
            return 'LONG_EDGE'
        
    return txt

def quaternion_to_ypr(q):
    w, x, y, z = q.w, q.x, q.y, q.z
    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    pitch = math.atan2(t0, t1)

    t2 = +2.0 * (w * y - z * x)
    t2 = +1.0 if t2 > +1.0 else t2
    t2 = -1.0 if t2 < -1.0 else t2
    roll = math.asin(t2)

    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(t3, t4)

    return round(yaw, 3), round(pitch, 3), round(roll, 3)

def unique_id() -> int:
    return random.randint(-2147483648, 2147483648)

def actor_validation(ob) -> str | None:
    if ob.type != 'ARMATURE':
        return f"{ob.name} is not an armature"
    if not ob.nwo.cinematic_object:
        return f"{ob.name} does not have a cinematic object specified. You can set this by selecting the object and updating its Foundry object properties"
    tag_path = Path(ob.nwo.cinematic_object)
    full_tag_path = Path(get_tags_path(), tag_path)
    if not full_tag_path.exists():
        return f"{ob.name}'s cinematic object does not exist: {full_tag_path}"
    elif tag_path.suffix.lower() not in OBJECT_TAG_EXTS:
        return f"{ob.name}'s cinematic object does is not a valid object tag type. Must be one of: {OBJECT_TAG_EXTS}"

def current_shot_index(context: bpy.types.Context):
    scene = context.scene
    markers = [m for m in scene.timeline_markers if m.camera is not None and m.frame >= scene.frame_start and m.frame <= scene.frame_end]
    markers.sort(key=lambda m: m.frame)
    # Remove markers that cover the same frame
    to_remove_indexes = []
    for idx, m in enumerate(markers):
        if idx + 1 == len(markers): # last index
            break
        if m.frame == markers[idx + 1].frame:
            to_remove_indexes.append(idx)
            
    for idx in reversed(to_remove_indexes):
        markers.pop(idx)
    
    frame_current = scene.frame_current
    if frame_current < all([m.frame for m in markers]):
        return 0
    for idx, marker in enumerate(markers):
        if marker.frame <= frame_current and (len(markers) - 1 == idx or markers[idx + 1].frame > frame_current):
            return idx + 1
        
    return 0

def get_timeline_markers(scene: bpy.types.Scene) -> list[bpy.types.TimelineMarker]:
    markers = [m for m in scene.timeline_markers if m.camera is not None and m.camera.type == 'CAMERA' and m.frame >= scene.frame_start and m.frame <= scene.frame_end]
    markers.sort(key=lambda m: m.frame)
    return markers

def halo_scale(number: float) -> float:
    if get_scene_props().scale == 'max':
        scale = 0.03048 * WU_SCALAR
    else:
        scale = WU_SCALAR
        
    return number * scale

def blender_scale(number: float) -> float:
    if get_scene_props().scale == 'max':
        return number * (1 / 0.03048)
    else:
        return number


# def valid_child_asset() -> bool:
#     '''Returns if this scene is a valid child asset'''
#     nwo = get_scene_props()
#     parent_asset = nwo.parent_asset
#     if not parent_asset.strip():
#         return False
#     parent_name = Path(parent_asset).name
#     parent_sidecar = Path(get_tags_path(), parent_asset, f"{parent_name}.sidecar.xml")
#     return parent_sidecar.exists()

# def get_ultimate_asset_path(full=False) -> Path:
#     '''Gets the ultimate (parent if there is one) asset path for this asset. First argument is whether to return a full path or a relative path'''
#     nwo = get_scene_props()
#     if nwo.is_child_asset:
#         assert(valid_child_asset())
#         path = nwo.parent_asset
#     else:
#         path = get_asset_path()
        
#     if full:
#         return Path(get_tags_path(), path)
#     else:
#         return Path(path)

def ray_cast_mouse(context, coords_2d):
    try:
        scene = context.scene
        region = context.region
        rv3d = context.region_data
        viewlayer = context.view_layer.depsgraph
        view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coords_2d)
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coords_2d)

        hit, location, normal, index, object, matrix = scene.ray_cast(viewlayer, ray_origin, view_vector)
        return hit, location, normal, index, object, matrix
    except:
        return False, None, None, None, None, None

def game_str(text: str) -> str:
    '''Converts a string to lower, removes leading & trailing spaces & underscores, and replaces remaining spaces with underscores'''
    return text.strip(" _").lower().replace(" ", "_")

# def has_anim_slots() -> bool:
#     return bpy.data.version >= (4, 4, 0)

def copy_to_clipboard(text):
    bpy.context.window_manager.clipboard = text
    
def get_from_clipboard() -> str:
    return bpy.context.window_manager.clipboard

def redraw_area(context, area_type):
    for area in context.screen.areas:
        if area.type == area_type:
            for region in area.regions:
                region.tag_redraw()
                
def tag_to_xml(filepath: Path | str) -> None | Path:
    """Exports the given tag to an xml using the local Tool.exe. This will recursively search parent folders to find Tool. Returns the xml Path if successful"""
    if not isinstance(filepath, Path):
        filepath = Path(filepath)
        
    if not (filepath.exists() and filepath.is_absolute() and filepath.is_file()):
        print_warning(f"{filepath} does not exist or is not absolute or is not a file")
        return
    
    dir = filepath.parent
    
    while dir != dir.parent:
        tool_path = Path(dir, "tool.exe")
        if tool_path.exists():
            break
        dir = dir.parent
    else:
        print_warning(f"Failed to find Tool by searching backwards from {filepath}")
        return
    
    # H3/H2 needs the full path to the tag, CE needs the EK relative path
    if Path(dir, "halo_tag_test.exe").exists():
        final_filepath = str(filepath.relative_to(dir))
    else:
        final_filepath = str(filepath)
        
    output_path = f"{filepath}.xml"
    os.chdir(tool_path.parent)
    command = f'tool export-tag-to-xml "{final_filepath}" "{output_path}"'
    subprocess.run(command)
    
    path_xml = Path(output_path)
    
    if path_xml.exists():
        return path_xml
    
def within_tolerance(value_a: float, value_b: float, tolerance=0.1):
    if value_a < value_b:
        return value_a + tolerance > value_b
    else:
        return value_b + tolerance > value_a
    
def get_end_node(start_node: bpy.types.Node) -> bpy.types.Node:
    """Go back nodes until there are no more links"""
    while start_node.inputs and start_node.inputs[0].is_linked and start_node.inputs[0].links:
        next_node = start_node.inputs[0].links[0].from_node
        if next_node is None:
            return start_node
        start_node = next_node
        
    return start_node

def ultimate_armature_parent(ob: bpy.types.Object):
    """Traverses an objects parentage until it finds an armature, if no armature is found then returns None"""
    if ob is None:
        return
    while ob.type != 'ARMATURE':
        parent = ob.parent
        if parent is None:
            return
        ob = parent
        
    return ob

def time_step() -> float:
    return bpy.context.scene.render.fps_base / int(bpy.context.scene.render.fps)

def real_frame_rate() -> int:
    return bpy.context.scene.render.fps / bpy.context.scene.render.fps_base

def tokenise(name: str) -> tuple:
    '''Tokenises an animation name'''
    token_name = name.replace(":", " ").lower()
    tokens = token_name.split()
    return tuple(tokens)

def flatten_dict(d, parent_keys=()):
    flat = {}
    for k, v in d.items():
        new_keys = parent_keys + (k,)
        if isinstance(v, dict):
            flat.update(flatten_dict(v, new_keys))
        else:
            flat[new_keys] = v
    return flat

def delete_face_attribute(mesh: bpy.types.Mesh, face_prop_index: int, remove_face_prop=True):
    attribute = mesh.attributes.get(mesh.nwo.face_props[face_prop_index].attribute_name)
    if attribute is not None:
        mesh.attributes.remove(attribute)
    
    if remove_face_prop:
        mesh.nwo.face_props.remove(face_prop_index)
        mesh.nwo.face_props_active_index = min(mesh.nwo.face_props_active_index, len(mesh.nwo.face_props) - 1)

def delete_face_attribute_edit_mode(mesh: bpy.types.Mesh, face_prop_index: int, remove_face_prop=True):
    bm = bmesh.from_edit_mesh(mesh)
    attribute = bm.faces.layers.bool.get(mesh.nwo.face_props[face_prop_index].attribute_name)
    if attribute is not None:
        bm.faces.layers.bool.remove(attribute)
    
    if remove_face_prop:
        mesh.nwo.face_props.remove(face_prop_index)
        mesh.nwo.face_props_active_index = min(mesh.nwo.face_props_active_index, len(mesh.nwo.face_props) - 1)
    
    bmesh.update_edit_mesh(mesh)
    bm.free()
    
def delete_face_prop(mesh: bpy.types.Mesh, idx: int, bm: bmesh.types.BMesh = None):
    has_no_bm = bm is None
    preserve_normals = has_no_bm and mesh.has_custom_normals
    if has_no_bm:
        bm = bmesh.new()
        bm.from_mesh(mesh)
        if preserve_normals and bm.faces:
            save_loop_normals(bm, mesh)
    layer = bm.faces.layers.int.get(mesh.nwo.face_props[idx].attribute_name)
    if layer is not None:
        bm.faces.layers.int.remove(layer)
        
    mesh.nwo.face_props.remove(idx)
    
    mesh.nwo.face_props_active_index = min(mesh.nwo.face_props_active_index, len(mesh.nwo.face_props) - 1)
    
    if has_no_bm:
        bm.to_mesh(mesh)
        bm.free()
        if preserve_normals:
            apply_loop_normals(mesh)

def consolidate_materials(mesh: bpy.types.Mesh):
    
    if not isinstance(mesh, bpy.types.Mesh):
        return

    face_count = len(mesh.polygons)
    slot_count = len(mesh.materials)
    if slot_count == 0:
        return

    if face_count:
        idx_buf = np.empty(face_count, dtype=np.int32)
        mesh.polygons.foreach_get("material_index", idx_buf)
    else:
        idx_buf = np.empty(0, dtype=np.int32)

    mat_primary_slot = {}
    dup_to_primary   = {}

    for s, mat in enumerate(mesh.materials):
        if mat is None:
            continue
        if mat not in mat_primary_slot:
            mat_primary_slot[mat] = s
        else:
            dup_to_primary[s] = mat_primary_slot[mat]

    if dup_to_primary and face_count:
        for dup, prim in dup_to_primary.items():
            idx_buf[idx_buf == dup] = prim

    used_slots = set(idx_buf) if face_count else set()
    used_slots.discard(-1)
    if not used_slots:
        mesh.materials.clear()
        if face_count:
            idx_buf.fill(-1)
            mesh.polygons.foreach_set("material_index", idx_buf.tolist())
            mesh.update()
        return

    kept_slots = sorted(used_slots)

    old_to_new = np.full(slot_count, -1, dtype=np.int32)
    for new, old in enumerate(kept_slots):
        old_to_new[old] = new

    if face_count:
        idx_buf = old_to_new[idx_buf]

    new_mats = [mesh.materials[i] for i in kept_slots]

    mesh.materials.clear()
    for mat in new_mats:
        mesh.materials.append(mat)

    if face_count:
        mesh.polygons.foreach_set("material_index", idx_buf.tolist())
        
def emissive_signature(prop):
    """Tuple that uniquely identifies an Emissive prop by its lighting fields."""
    return (
        prop.material_lighting_attenuation_cutoff,
        prop.material_lighting_attenuation_falloff,
        prop.material_lighting_emissive_focus,
        tuple(round(c, 6) for c in prop.material_lighting_emissive_color),
        prop.material_lighting_emissive_per_unit,
        prop.material_lighting_emissive_power,
        # prop.light_intensity,
        prop.material_lighting_emissive_quality,
        prop.debug_emissive_index,
    )
    
def consolidate_face_attributes(mesh: bpy.types.Mesh):
    '''Consolidates face layers into the most minimal list'''
    if not isinstance(mesh, bpy.types.Mesh):
        return
    
    face_count = len(mesh.polygons)
    if face_count == 0:
        return

    face_props_by_name = defaultdict(list)
    type_order = defaultdict(list)
    attr_prop_map = {}
    to_remove = set()

    sphere_coll_attr = lightmap_only_attr = shadow_only_attr = None
    two_side_attr = render_only_attr = None

    for i, prop in enumerate(mesh.nwo.face_props):

        attr = mesh.attributes.get(prop.attribute_name)
        if not attr:
            continue

        name = attr.name
        face_props_by_name[prop.name].append((i, attr, prop))
        type_order[prop.type].append(name)
        attr_prop_map[name] = prop

        if prop.name == "Sphere Collision Only":
            sphere_coll_attr = name
        elif prop.name == "Lightmap Only":
            lightmap_only_attr = name
        elif prop.name == "Shadow Only":
            shadow_only_attr = name
        elif prop.name == "Two-Sided":
            two_side_attr  = name
        elif prop.name == "Render Only":
            render_only_attr = name

    attr_merge = defaultdict(list)

    for pname, lst in face_props_by_name.items():
        if len(lst) == 1:
            continue
        if pname.startswith("Emissive"):
            sig_primary = {}
            for idx, attr, prop in lst:
                sig = emissive_signature(prop)
                if sig not in sig_primary:
                    sig_primary[sig] = attr.name
                else:
                    attr_merge[sig_primary[sig]].append(attr.name)
                    to_remove.add(idx)
        else:
            prim = lst[0][1].name
            for idx, attr, _ in lst[1:]:
                attr_merge[prim].append(attr.name)
                to_remove.add(idx)

    needed = set(attr_prop_map.keys())
    for dupes in attr_merge.values(): needed.update(dupes)
    needed.update(n for n in (
        sphere_coll_attr, lightmap_only_attr,
        shadow_only_attr, two_side_attr,
        render_only_attr) if n)

    masks, buf = {}, np.empty(face_count, dtype=np.int8)
    for name in needed:
        attr = mesh.attributes.get(name)
        if attr:
            attr.data.foreach_get("value", buf)
            masks[name] = buf.astype(bool)
        else:
            masks[name] = np.zeros(face_count, dtype=bool)

    for prim, dupes in attr_merge.items():
        m = masks[prim]
        for d in dupes:
            m |= masks[d]
        masks[prim] = m
        
    plus_faces = np.array([
        mesh.materials[p.material_index].name.lstrip().startswith("+")
        if 0 <= p.material_index < len(mesh.materials)
           and mesh.materials[p.material_index] is not None
        else False
        for p in mesh.polygons
    ], dtype=bool)
    if plus_faces.any():
        for m in masks.values():
            m[plus_faces] = False


    if two_side_attr and sphere_coll_attr:
        masks[two_side_attr] &= ~masks[sphere_coll_attr]

    if render_only_attr:
        wipe = np.zeros(face_count, dtype=bool)
        if lightmap_only_attr: wipe |= masks[lightmap_only_attr]
        if shadow_only_attr:   wipe |= masks[shadow_only_attr]
        masks[render_only_attr] &= ~wipe

    for attr_list in type_order.values():
        if len(attr_list) < 2:
            continue
        taken = np.zeros(face_count, dtype=bool)
        for attr_name in attr_list:
            m = masks[attr_name]
            overlap = taken & m
            if overlap.any():
                m[overlap] = False
            taken |= m

    for name, mask in masks.items():
        attr = mesh.attributes.get(name)
        if not attr:
            continue
        attr.data.foreach_set("value", mask.astype(np.int8))

        count = int(mask.sum())
        prop = attr_prop_map.get(name)
        if prop:
            prop.face_count = count
            
    for j, prop in enumerate(mesh.nwo.face_props):
        if prop.face_count == 0:
            to_remove.add(j)
    
    if to_remove:
        preserve_normals = mesh.has_custom_normals
        bm = bmesh.new()
        bm.from_mesh(mesh)
        if preserve_normals and bm.faces:
            save_loop_normals(bm, mesh)
        for j in sorted(to_remove, reverse=True):
            delete_face_prop(mesh, j, bm)
            
        bm.to_mesh(mesh)
        bm.free()
        if preserve_normals:
            apply_loop_normals(mesh)
        
def connect_verts_on_edge(mesh: bpy.types.Mesh, do_degen_dissolve=True):
    """Split edges so that stray verts become connected"""

    bm = bmesh.new()
    preserve_normals = mesh.has_custom_normals
    try:
        bm.from_mesh(mesh)
        if preserve_normals and bm.faces:
            save_loop_normals(bm, mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()

        tol=0.005

        tol2 = tol * tol

        for e in bm.edges:
            if not e.is_valid:
                continue
            a, b = e.verts
            seg = b.co - a.co
            if seg.length_squared == 0.0:
                continue

            bb_min = Vector((min(a.co.x, b.co.x) - tol,
                             min(a.co.y, b.co.y) - tol,
                             min(a.co.z, b.co.z) - tol))
            bb_max = Vector((max(a.co.x, b.co.x) + tol,
                             max(a.co.y, b.co.y) + tol,
                             max(a.co.z, b.co.z) + tol))

            stray = []
            for v in bm.verts:
                if v in e.verts:
                    continue

                c = v.co
                if (c.x < bb_min.x or c.x > bb_max.x or
                    c.y < bb_min.y or c.y > bb_max.y or
                    c.z < bb_min.z or c.z > bb_max.z):
                    continue

                closest, t = geom.intersect_point_line(c, a.co, b.co)
                if (c - closest).length_squared > tol2:
                    continue
                if tol < t < 1 - tol:
                    stray.append((t, v))

            if not stray:
                continue

            stray.sort(key=lambda tv: tv[0])
            cur_e   = e
            cur_src = a

            for _t, v in stray:
                closest, t = geom.intersect_point_line(v.co,
                                                       cur_src.co,
                                                       cur_e.other_vert(cur_src).co)

                _, helper = bmesh.utils.edge_split(cur_e, cur_src, t)
                bmesh.ops.pointmerge(bm, verts=[v, helper], merge_co=v.co)
                cur_src = v
                cur_e   = next(ed for ed in v.link_edges if ed.other_vert(v) == b)

        # if do_degen_dissolve:
        #     bmesh.ops.dissolve_degenerate(bm, dist=0.000725/0.03048, edges=bm.edges)

        bm.to_mesh(mesh)
    finally:
        bm.free()

    if preserve_normals:
        apply_loop_normals(mesh)

def set_two_sided(mesh, is_io=False):
    face_dict = {}
    verts = mesh.vertices
    for face in mesh.polygons:
        vert_set = frozenset(verts[v].co.to_tuple() for v in face.vertices)
        face_dict.setdefault(vert_set, []).append(face)
        
    vert_to_faces = defaultdict(list)
    for f in mesh.polygons:
        for v in f.vertices:
            vert_to_faces[v].append(f.index)

    to_remove = set()
    two_sided = np.zeros(len(mesh.polygons), dtype=np.int8)
    for faces in face_dict.values():
        for i, f1 in enumerate(faces):
            for f2 in faces[i+1:]:
                if f1.material_index == f2.material_index and {verts[v].co.to_tuple() for v in f1.vertices} == {verts[v].co.to_tuple() for v in reversed(f2.vertices)}:
                    to_remove.add(f2.index)
                    two_sided[f1.index] = True
                    break

    if to_remove:
        if len(mesh.polygons) == len(to_remove):
            add_face_prop(mesh, "face_sides")
        elif is_io:
            return
        else:
            add_face_prop(mesh, "face_sides", two_sided)
        
        preserve_normals = mesh.has_custom_normals
        bm = bmesh.new()
        try:
            bm.from_mesh(mesh)
            if preserve_normals and bm.faces:
                save_loop_normals(bm, mesh)
            bm.faces.ensure_lookup_table()
            bmesh.ops.delete(bm, geom=[bm.faces[i] for i in to_remove], context='FACES')
            bm.to_mesh(mesh)
        finally:
            bm.free()

        if preserve_normals:
            apply_loop_normals(mesh)

def join_objects(objects: list[bpy.types.Object]) -> bpy.types.Object:
    """Joins an iterable of objects together, ensuring no material or face property conflicts. All objects are joined into the first object in the list"""
    active = objects[0]
    objects = objects[1:]
    # consolidate_face_attributes(active.data)
    mat_to_idx = {m: i for i, m in enumerate(active.data.materials)}
    # Consolidate any dupe face layers and remove unused materials, and map all materials to material indices
    for ob in objects:
        # consolidate_face_attributes(ob.data)
        
        for layer in ob.data.nwo.face_props:
            new_layer = active.data.nwo.face_props.add()
            for k,v in layer.items():
                new_layer[k] = v
                
        for mat in ob.data.materials:
            if mat not in mat_to_idx:
                mat_to_idx[mat] = len(active.data.materials)
                active.data.materials.append(mat)

    for ob in objects:
        idx_map = np.asarray([mat_to_idx[m] for m in ob.data.materials])
        material_indices = np.empty(len(ob.data.polygons), dtype=np.int32)
        ob.data.polygons.foreach_get("material_index", material_indices)
        remap = idx_map[material_indices]

        ob.data.materials.clear()
        for mat in active.data.materials:
            ob.data.materials.append(mat)
            
        ob.data.polygons.foreach_set("material_index", remap)

    # Join everything together
    bm = bmesh.new()
    bm.from_mesh(active.data)
    save_loop_normals(bm, active.data)
    for ob in objects:
        ob_bm = bmesh.new()
        ob_bm.from_mesh(ob.data)
        save_loop_normals(ob_bm, ob.data)
        ob_bm.to_mesh(ob.data)
        ob_bm.free()
        bm.from_mesh(ob.data)
        
        bpy.data.objects.remove(ob)
    
    bm.to_mesh(active.data)
    bm.free()
    apply_loop_normals(active.data)
    set_two_sided(active.data)
    loop_normal_magic(active.data)
    consolidate_face_attributes(active.data)
    
    uv = active.data.uv_layers[0]
    active.data.uv_layers.active = uv
    uv.active_render = True
    
    return active

def intersect_ray_plane(origin, direction, plane_co, plane_no):
    denom = direction.dot(plane_no)
    if abs(denom) < 1e-6:
        return None
    t = (plane_co - origin).dot(plane_no) / denom
    if t < 0.0:
        return None
    return origin + direction * t
            
def matrix_from_mouse(mouse_x, mouse_y):
    region = bpy.context.region
    space = bpy.context.space_data
    if not hasattr(space, "region_3d"):
        return Matrix.Identity(4)
    rv3d = space.region_3d
    coord = (mouse_x, mouse_y)
    origin_loc = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    origin_vec = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    hit, loc, normal, *_ = bpy.context.scene.ray_cast(bpy.context.view_layer.depsgraph, origin_loc, origin_vec)
    
    if hit:
        matrix = normal.to_track_quat('Z', 'Y').to_matrix().to_4x4()
        matrix.translation = loc
    else:
        # test against the grid floor
        plane_co = Vector((0, 0, 0))
        plane_normal = Vector((0, 0, 1))       # +Z
        loc = intersect_ray_plane(origin_loc, origin_vec, plane_co, plane_normal)
        matrix = Matrix.Identity(4)
        if loc is not None:
            matrix.translation = loc
    
    return matrix

def argb32_to_rgb(value: int):
    r = (value >> 16) & 0xFF
    g = (value >> 8) & 0xFF
    b = value & 0xFF
    
    return r / 255, g / 255, b / 255

def human_number(num: int | float):
    '''Converts an int or float to a string and adds commas'''
    return f"{num:,}"

def material_add_shield(material: bpy.types.Material):
    node_tree = material.node_tree
    
    if any(n.type == 'GROUP' and n.node_tree and n.node_tree.name == "Shield" for n in node_tree.nodes):
        return

    output_node = next((n for n in node_tree.nodes if n.type == 'OUTPUT_MATERIAL'), None)
    if output_node is None:
        output_node = node_tree.nodes.new('ShaderNodeOutputMaterial')

    surf_in = output_node.inputs[0]
    old_link = surf_in.links[0] if surf_in and surf_in.is_linked else None
    from_socket = old_link.from_socket if old_link else None

    shield_node = node_tree.nodes.new('ShaderNodeGroup')
    shield_node.node_tree = add_node_from_resources("shared_nodes", 'Shield')

    def first_socket(sockets, kind):
        for s in sockets:
            if s.type == kind:
                return s
        return sockets[0] if sockets else None

    new_in = first_socket(shield_node.inputs,  from_socket.type if from_socket else 'SHADER')
    new_out = (shield_node.outputs.get('Shader') or first_socket(shield_node.outputs, surf_in.type))

    if old_link:
        node_tree.links.remove(old_link)
    # if from_socket and new_in:
    #     node_tree.links.new(from_socket, new_in)

    if surf_in and new_out:
        node_tree.links.new(new_out, surf_in)
        
    arrange(node_tree)

def material_add_emissive(material: bpy.types.Material):
    node_tree = material.node_tree
    
    if any(n.type == 'GROUP' and n.node_tree and n.node_tree.name == "Halo Emissive" for n in node_tree.nodes):
        return

    output_node = next((n for n in node_tree.nodes if n.type == 'OUTPUT_MATERIAL'), None)
    if output_node is None:
        output_node = node_tree.nodes.new('ShaderNodeOutputMaterial')
        # output_node.location = (400, 0)

    surf_in = output_node.inputs[0]
    old_link = surf_in.links[0] if surf_in and surf_in.is_linked else None
    from_socket = old_link.from_socket if old_link else None

    emissive_node = node_tree.nodes.new('ShaderNodeGroup')
    emissive_node.node_tree = add_node_from_resources("shared_nodes", 'Halo Emissive')

    def first_socket(sockets, kind):
        for s in sockets:
            if s.type == kind:
                return s
        return sockets[0] if sockets else None

    new_in = first_socket(emissive_node.inputs,  from_socket.type if from_socket else 'SHADER')
    new_out = (emissive_node.outputs.get('Shader') or first_socket(emissive_node.outputs, surf_in.type))

    if old_link:
        node_tree.links.remove(old_link)
    if from_socket and new_in:
        node_tree.links.new(from_socket, new_in)

    if surf_in and new_out:
        node_tree.links.new(new_out, surf_in)
        
    arrange(node_tree)


def mesh_add_emissive_attributes(mesh: bpy.types.Mesh):
    nwo = mesh.nwo
    
    if not isinstance(mesh, bpy.types.Mesh):
        return
    
    face_count = len(mesh.polygons)
    
    if not face_count:
        return
    
    used_materials = {m for m in mesh.materials if m is not None}
    
    if not used_materials:
        return
    
    color_off  = np.array((1.0, 1.0, 1.0), dtype=np.single)
    color_data = np.tile(color_off, (face_count, 1))
    power_off  = np.array((0.0, 0.0, 0.0), dtype=np.single)
    power_data = np.tile(power_off, (face_count, 1))
    
    if mesh.materials:
        material_indices = np.empty(face_count, dtype=np.int32)
        mesh.polygons.foreach_get("material_index", material_indices)
        
        for idx, mat in enumerate(mesh.materials):
            if mat is None:
                continue
            for m_prop in mat.nwo.material_props:
                if m_prop.type != 'emissive':
                    continue
                mask_buffer = material_indices == idx
                mask = mask_buffer.astype(bool)

                if not mask.any():
                    continue

                color_on = np.array(m_prop.material_lighting_emissive_color[:], dtype=np.single)
                power_on = np.array((prop.material_lighting_emissive_power, prop.material_lighting_attenuation_falloff, prop.material_lighting_attenuation_cutoff), dtype=np.single)

                color_data[mask] = color_on
                power_data[mask] = power_on

    for prop in nwo.face_props:
        if prop.type != 'emissive':
            continue
        attribute = mesh.attributes.get(prop.attribute_name)
        if attribute is None:
            continue

        mask_buffer = np.empty(face_count, dtype=np.int32)
        attribute.data.foreach_get("value", mask_buffer)
        mask = mask_buffer.astype(bool)

        if not mask.any():
            continue
        
        color_on = np.array(prop.material_lighting_emissive_color[:], dtype=np.single)
        power_on = np.array((prop.material_lighting_emissive_power, prop.material_lighting_attenuation_falloff, prop.material_lighting_attenuation_cutoff), dtype=np.single)
        
        color_data[mask] = color_on
        power_data[mask] = power_on
        
    on_mask = power_data[:, 0] > 0.0

    if on_mask.any():
        color_attribute = mesh.attributes.get("foundry_color")
        if color_attribute is None:
            color_attribute = mesh.attributes.new("foundry_color", 'FLOAT_VECTOR', 'FACE')

        power_attribute = mesh.attributes.get("foundry_power")
        if power_attribute is None:
            power_attribute = mesh.attributes.new("foundry_power", 'FLOAT_VECTOR', 'FACE')
        
        bm = bmesh.new()
        bm.from_mesh(mesh)
        layer = bm.faces.layers.float_vector.get("foundry_color")
        layer_power = bm.faces.layers.float_vector.get("foundry_power")
        for idx, face in enumerate(bm.faces):
            face[layer] = color_data[idx]
            face[layer_power] = power_data[idx]
        bm.to_mesh(mesh)
        bm.free()
        
        # Can't get this working with foreach_set... Had to use bmesh :(
        # color_attribute.data.foreach_set("vector", color_data.ravel())
        # power_attribute.data.foreach_set("value", power_data)
        
        return on_mask

def setup_emissive_attributes(mesh: bpy.types.Mesh):
    on_mask = mesh_add_emissive_attributes(mesh)
    if on_mask is None:
        return
    
    material_indices = np.empty(len(mesh.polygons), dtype=np.int32)
    mesh.polygons.foreach_get("material_index", material_indices)
    used_material_indices = np.unique(material_indices[on_mask])
    for idx in used_material_indices:
        material_add_emissive(mesh.materials[idx])
        
def can_export_check_parent(ob: bpy.types.Object):
    if ob.parent:
        return can_export_check_parent(ob.parent)
    
    return ob.nwo.export_this

def pointer_ob_valid(ob: bpy.types.Object) -> bool:
    if ob is None or not ob.name:
        return False
    
    return any(scene_ob is ob for scene_ob in bpy.context.scene.objects)

def to_aabb(ob: bpy.types.Object):
    matrix = halo_transforms(ob)
    world_corners = [matrix @ Vector(corner) for corner in ob.bound_box]
    
    min_co = Vector((
        min(c.x for c in world_corners),
        min(c.y for c in world_corners),
        min(c.z for c in world_corners),
    ))

    max_co = Vector((
        max(c.x for c in world_corners),
        max(c.y for c in world_corners),
        max(c.z for c in world_corners),
    ))
    
    return min_co, max_co

def resolve_relative_blend(fp: str):
    if fp.startswith("//"):
        if bpy.data.filepath:
            return str(Path(Path(bpy.data.filepath).parent, fp[2:]))
        else:
            return ""
    
    return fp

class ExportCollection:
    def __init__(self, collection: bpy.types.Collection):
        self.region = None
        self.permutation = None
        self.non_export = False
        
        match collection.nwo.type:
            case 'region':
                self.region = collection.nwo.region or None
            case 'permutation':
                self.permutation = collection.nwo.permutation or None
            case 'exclude':
                self.non_export = True

        for ob in collection.objects:
            ob.nwo.export_collection = collection.name

    def inherit(self, parent_export_collection):
        if parent_export_collection.region is not None and self.region is None:
            self.region = parent_export_collection.region
        if parent_export_collection.permutation is not None and self.permutation is None:
            self.permutation = parent_export_collection.permutation
        if parent_export_collection.non_export:
            self.non_export = True

    def merge(self, other):
        self.region = self.region if self.region == other.region else None
        self.permutation = self.permutation if self.permutation == other.permutation else None
        self.non_export = self.non_export or other.non_export

def create_parent_mapping(context):
    for ob in bpy.data.objects:
        ob.nwo.export_collection = ""

    collection_map: dict[str: ExportCollection] = {}
    for collection in context.scene.collection.children:
        recursive_parent_mapper(collection, collection_map, None)
            
    return collection_map

def recursive_parent_mapper(collection: bpy.types.Collection, collection_map: dict[str: ExportCollection], parent_export_collection: ExportCollection | None):
    export_collection = ExportCollection(collection)
    if parent_export_collection is not None:
        export_collection.inherit(parent_export_collection)

    if collection.name in collection_map:
        collection_map[collection.name].merge(export_collection)
    else:
        collection_map[collection.name] = export_collection
            
    for child in collection.children:
        recursive_parent_mapper(child, collection_map, export_collection)
        
def reduce_suffix(name: str) -> str:
    """Reduce Blender's .00X suffix by 1, or strip it if .001"""
    m = re.match(r"^(.*)\.(\d{3})$", name)
    if not m:
        return name
    base, num_str = m.groups()
    num = int(num_str)
    if num <= 1:
        return base  # .001 → base
    return f"{base}.{num-1:03d}"

def is_child_of(potential_child, parent):
    actual_parent = potential_child.parent
    if actual_parent is not None:
        if actual_parent == parent:
            return True
        return is_child_of(actual_parent, parent)
    
    return False

def is_child_of_any(potential_child, parents):
    actual_parent = potential_child.parent
    if actual_parent is not None:
        if actual_parent in parents:
            return True
        return is_child_of_any(actual_parent, parents)
    
    return False

def recursive_parentage(ob, collection_map):
    if ob.parent:
        return recursive_parentage(ob.parent, collection_map)
        
    return ignore_for_export_fast_no_frame(ob, collection_map, ob)

def ignore_for_export_fast_no_frame(ob, collection_map, instancer):
    nwo = ob.nwo
    if not nwo.export_this:
        return True
    
    if ob.type not in VALID_OBJECTS:
        return True

    if ob.parent and recursive_parentage(ob, collection_map):
        return True
    
    if instancer.nwo.export_collection:
        return collection_map[instancer.nwo.export_collection].non_export
    
    return False

def ignore_for_export_fast(ob, collection_map, instancer_parent):
    nwo = ob.nwo
    if not nwo.export_this:
        return True
    
    if ob.type not in VALID_OBJECTS:
        return True
    
    if nwo.is_frame and ob.type == 'EMPTY':
        return True

    if ob.parent and recursive_parentage(ob, collection_map):
        return True
    
    if instancer_parent is None:
        instancer_parent = ob
    
    if instancer_parent.nwo.export_collection:
        return collection_map[instancer_parent.nwo.export_collection].non_export
    
    return False

damage_states = "h_ping", "s_ping", "h_kill", "s_kill"
directions = "front", "left", "right", "back"
regions = "gut", "chest", "head", "l_arm", "l_hand", "l_leg", "l_foot", "r_arm", "r_hand", "r_leg", "r_foot"

class AnimationStateType(Enum):
    ACTION = 0
    DAMAGE = 1
    TRANSITION = 2

class AnimationName:
    def __init__(self, name: str):
        self.data_name = name.replace(":", " ")
        self.tag_name = name.replace(" ", ":")
        self.valid = False
        self.mode = "any"
        self.weapon_class = "any"
        self.weapon_type = "any"
        self.set = "any"
        self.state = "any"
        self.direction = ""
        self.region = ""
        self.destination_mode = ""
        self.destination_state = ""
        self.variant = ""
        self.type = AnimationStateType.ACTION
        self.custom = False
        
        tokens = list(tokenise(name))
        if not tokens:
            return
        
        if tokens[-1].startswith("var"):
            self.variant = tokens.pop()

        if len(tokens) == 1:
            self.custom = True
            return
        
        if len(tokens) > 2 and tokens[-1] in regions:
            if tokens[-2] in directions and tokens[-3] in damage_states:
                self.type = AnimationStateType.DAMAGE
                self.region = tokens.pop()
                self.direction = tokens.pop()
                
        elif len(tokens) > 2 and "2" in tokens:
            index_2 = tokens.index("2")
            if index_2 > 0 and index_2 < (len(tokens) - 1):
                self.type = AnimationStateType.TRANSITION
                self.destination_state = tokens.pop()
                if tokens[-1] == "2":
                    tokens.pop()
                else:
                    self.destination_mode = tokens[index_2 + 1]
                    while tokens[-1] != "2":
                        tokens.pop()
                    tokens.pop()
                    
        self.state = tokens.pop()

        if tokens:
            self.mode = tokens.pop(0)
            
        if tokens:
            self.weapon_class = tokens.pop(0)
            
        if tokens:
            self.weapon_type = tokens.pop(0)
            
        if tokens:
            self.set = tokens.pop(0)
            
        if tokens:
            print_warning(("Bad animation name?", name, tokens))
            
        self.valid = True
        
    def copy(self):
        return copy.copy(self)
    
    def __eq__(self, value):
        if not isinstance(value, AnimationName):
            return False
        
        return all(
            self.mode == value.mode,
            self.weapon_class == value.weapon_class,
            self.weapon_type == value.weapon_type,
            self.set == value.set,
            self.state == value.state,
            self.direction == value.direction,
            self.region == value.region,
            self.destination_mode == value.destination_mode,
            self.destination_state == value.destination_state,
        )
        
    def __str__(self):
        return self.data_name
        
    def __repr__(self):
        match self.type:
            case AnimationStateType.ACTION:
                return f"ACTION, MODE:{self.mode}, CLASS:{self.weapon_class}, TYPE:{self.weapon_type}, SET:{self.set}, STATE:{self.state}"
            case AnimationStateType.DAMAGE:
                return f"DAMAGE, MODE:{self.mode}, CLASS:{self.weapon_class}, TYPE:{self.weapon_type}, SET:{self.set}, STATE:{self.state}, DIRECTION:{self.direction}, REGION:{self.region}"
            case AnimationStateType.TRANSITION:
                return f"TRANSITION, MODE:{self.mode}, CLASS:{self.weapon_class}, TYPE:{self.weapon_type}, SET:{self.set}, STATE:{self.state}, DEST_MODE:{self.destination_mode}, DEST_STATE:{self.destination_state}"
            case _:
                return self.data_name
            
def test_point_bvh(bvhs, point):
    origin = Vector(point)
    origin.z += 0.1 # nudge point up a little in case object is directly on bsp floor
    direction = Vector((0, 0, -1)) # raycast down

    for bvh in bvhs:
        hit = bvh.ray_cast(origin, direction)
        if hit[0] is None:
            continue
        
        loc, normal, index, dist = hit
        if direction.dot(normal) < 0:
            return True
    
    return False

class DepsgraphRead:
    def __init__(self):
        self.hidden_objects = {}
        self.local_view = None
        self.marker_instancers = []
    
    def __enter__(self):
        self.marker_instancers = [ob for ob in bpy.data.objects if ob.type == 'EMPTY' and ob.instance_type == 'COLLECTION' and ob.nwo.marker_instance]
        for ob in self.marker_instancers:
            ob.instance_type = 'NONE'
        
        self.local_views = exit_local_view(bpy.context)
        bpy.context.view_layer.update()
        
        for ob in bpy.context.view_layer.objects:
            hidden, viewport_hidden = ob.hide_get(), ob.hide_viewport
            if hidden or viewport_hidden:
                self.hidden_objects[ob] = hidden, viewport_hidden
                if hidden:
                    ob.hide_set(False)
                if viewport_hidden:
                    ob.hide_viewport = False
                
        
    def __exit__(self, exc_type, exc_value, traceback):
        for ob, (hidden, viewport_hidden) in self.hidden_objects.items():
            if hidden:
                ob.hide_set(True)
            if viewport_hidden:
                ob.hide_viewport = True
            
        set_local_view(bpy.context, self.local_views)
        
        for ob in self.marker_instancers:
            ob.instance_type = 'COLLECTION'
        
def hide_from_rays(ob: bpy.types.Object):
    ob.visible_diffuse = False
    ob.visible_glossy = False
    ob.visible_transmission = False
    ob.visible_volume_scatter = False
    ob.visible_shadow = False
    
def make_halo_emissive(data: bpy.types.Mesh, primary_scale="", secondary_scale="", color_node_tree=None, strength_node_tree=None, gobo_image=None, intensity_from_power=False):
    pass

def make_blender_light(data: bpy.types.Light):
    if data.type == 'SUN':
        return

    data.use_custom_distance = False
    data.energy = calc_light_energy(data, data.nwo.light_intensity, get_import_scale(bpy.context))
    tree = data.node_tree
    tree.nodes.clear()
    
    emission = tree.nodes.new('ShaderNodeEmission')
    output = tree.nodes.new('ShaderNodeOutputLight')
    
    emission.location = (0, 0)
    output.location = (200, 0)

    tree.links.new(emission.outputs[0], output.inputs[0])
    
    
def make_halo_light(data: bpy.types.Light, primary_scale="", secondary_scale="", color_node_tree=None, strength_node_tree=None, gobo_image=None, intensity_from_power=False) -> bpy.types.Node:
    
    if data.type == 'SUN':
        return
    
    # data.use_nodes = True
    data.use_custom_distance = True
    tree = data.node_tree
    tree.nodes.clear()
    light_node = tree.nodes.new('ShaderNodeGroup')
    light_node.node_tree = add_node_from_resources("shared_nodes", 'Halo Light')
    
    output_node = tree.nodes.new('ShaderNodeOutputLight')
    
    tree.links.new(input=output_node.inputs[0], output=light_node.outputs[0])
    
    if color_node_tree is not None:
        color_node = tree.nodes.new('ShaderNodeGroup')
        color_node.node_tree = color_node_tree
        tree.links.new(input=light_node.inputs[0], output=color_node.outputs[0])
        
    if strength_node_tree is not None:
        strength_node = tree.nodes.new('ShaderNodeGroup')
        strength_node.node_tree = strength_node_tree
        tree.links.new(input=light_node.inputs[1], output=strength_node.outputs[0])
    
    if primary_scale:
        node_primary_scale = tree.nodes.new(type="ShaderNodeAttribute")
        node_primary_scale.attribute_name = primary_scale
        node_primary_scale.attribute_type = 'INSTANCER'
        tree.links.new(input=light_node.inputs[2], output=node_primary_scale.outputs[2])
        
    if secondary_scale:
        node_secondary_scale = tree.nodes.new(type="ShaderNodeAttribute")
        node_secondary_scale.attribute_name = secondary_scale
        node_secondary_scale.attribute_type = 'INSTANCER'
        tree.links.new(input=light_node.inputs[3], output=node_secondary_scale.outputs[2])
        
    if gobo_image is not None:
        node_image = tree.nodes.new(type='ShaderNodeTexImage')
        node_image.image = gobo_image
        tree.links.new(input=light_node.inputs[4], output=node_image.outputs[0])
        
    arrange(tree)
    
    scale = get_import_scale(bpy.context)
    
    if intensity_from_power:
        data.nwo.light_intensity = calc_light_intensity(data, scale)
    
    # data.energy = 10 * (scale ** 2)
    if is_corinth():
        data.energy = 10 * (scale ** 2)
    else:
        data.energy = 100 * (scale ** 2)
    
    data.use_custom_distance = True
    data.cutoff_distance = data.nwo.light_far_attenuation_end

    return light_node
    
class ExportObject:
    def __init__(self):
        self.name = ""
        self.type = ""
        self.nwo = None
        self.data: bpy.types.Mesh = None
        self.ob: bpy.types.Object = None
        self.parent: bpy.types.Object = None
        self.parent_type = ""
        self.parent_bone = ""
        self.matrix_world: Matrix = None
        self.material_slots = None
        self.vertex_groups = None
        self.eval_ob = None
        self.empty_display_type = ""
        self.pose = None
        self.empty_display_size = 1
        self.invert_topology = False
        self.for_pca = False
        self.pca_animations = []
        self.modifiers = tuple()
        self.transform: Matrix = None
        self.collection_region = ""
        
    def copy(self):
        return copy.copy(self)
    
def is_instancer(ob):
    return ob and ob.type == 'EMPTY' and ob.instance_type == 'COLLECTION' and ob.nwo.marker_instance

def get_slot_from_id(action: bpy.types.Action, ob_slot: bpy.types.Object = None):
    if ob_slot is None:
        return
    
    if isinstance(ob_slot, bpy.types.Object):
        if ob_slot.animation_data is None:
            return
        else:
            slot_name = ob_slot.animation_data.last_slot_identifier
    else:
        slot_name = ob_slot

    return action.slots.get(slot_name)

def get_fcurves(action: bpy.types.Action, ob_slot: bpy.types.Object = None):
    if ob_slot is None:
        return
    
    if isinstance(ob_slot, bpy.types.Object) or isinstance(ob_slot, str):
        slot = get_slot_from_id(action, ob_slot)
    else:
        slot = ob_slot
        
    if slot is None:
        return
    
    channelbag = anim_utils.action_ensure_channelbag_for_slot(action, slot)
    if channelbag is None:
        return
    else:
        return channelbag.fcurves
    
def clear_directory(dir: Path | str):
    if not isinstance(dir, Path):
        dir = Path(dir)
        
    if not dir.exists():
        return print_warning(f"Tried to delete a directory which does not exist: {dir}")
    
    try:
        shutil.rmtree(dir)
        return
    except Exception as e:
        print_warning(f"Failed to remove directory: {dir}\nReason: {e}\nClearing files instead")
        
    for path in dir.rglob("*"):
        try:
            if path.is_file() or path.is_symlink():
                path.unlink()
        except Exception as e:
            print_warning(f"Failed to delete file: {path} ({e})")
            
    for path in sorted(dir.rglob("*"), reverse=True):
        try:
            if path.is_dir():
                path.rmdir()
        except Exception:
            pass
        
    try:
        dir.rmdir()
    except Exception as e:
        print_warning(f"Failed to remove directory root: {dir} ({e})")

def copy_material_nodes(existing_mat: bpy.types.Material, mat: bpy.types.Material):
    existing_tree = existing_mat.node_tree
    new_tree = mat.node_tree

    new_tree.nodes.clear()

    node_map = {}

    for node in existing_tree.nodes:
        new = new_tree.nodes.new(node.bl_idname)

        # Copy simple properties
        new.location = node.location
        new.label = node.label
        new.width = node.width
        new.height = node.height
        new.mute = node.mute

        # Copy properties (best effort)
        for prop in node.bl_rna.properties:
            if not prop.is_readonly and prop.identifier not in (
                "name",
                "location",
                "width",
                "height",
                "parent",
            ):
                try:
                    setattr(new, prop.identifier, getattr(node, prop.identifier))
                except Exception:
                    pass

        node_map[node] = new
        
    def socket_index(node, socket, is_output=False):
        sockets = node.outputs if is_output else node.inputs
        for i, s in enumerate(sockets):
            if s.identifier == socket.identifier and s.name == socket.name:
                return i
        for i, s in enumerate(sockets):
            if s.name == socket.name:
                return i
        return None

    for link in existing_tree.links:
        from_node = node_map.get(link.from_node)
        to_node = node_map.get(link.to_node)

        if not from_node or not to_node:
            continue

        out_i = socket_index(link.from_node, link.from_socket, is_output=True)
        in_i = socket_index(link.to_node, link.to_socket, is_output=False)

        if out_i is None or in_i is None:
            continue

        try:
            new_tree.links.new(from_node.outputs[out_i], to_node.inputs[in_i])
        except Exception:
            pass
        
def mesh_to_cube(mesh: bpy.types.Mesh):
    verts = [
        (-0.5, -0.5, -0.5),
        (-0.5, -0.5,  0.5),
        (-0.5,  0.5, -0.5),
        (-0.5,  0.5,  0.5),
        ( 0.5, -0.5, -0.5),
        ( 0.5, -0.5,  0.5),
        ( 0.5,  0.5, -0.5),
        ( 0.5,  0.5,  0.5),
    ]

    indices = [
        (0, 1, 3, 2),
        (4, 6, 7, 5),
        (0, 4, 5, 1),
        (2, 3, 7, 6),
        (1, 5, 7, 3),
        (0, 2, 6, 4),
    ]
    
    mesh.from_pydata(vertices=verts, edges=[], faces=indices)
    
def project_file_exists(path, data=False):
    root = get_data_path() if data else get_tags_path()
    rel = relative_path(path)
    return Path(root, rel).exists()

def clear_constraints(id):
    for con in reversed(id.constraints):
        id.constraints.remove(con)
        
def get_scene_props():
    for s in bpy.data.scenes:
        if s.nwo.is_main_scene:
            return s.nwo

    return bpy.context.scene.nwo

def get_export_props():
    for s in bpy.data.scenes:
        if s.nwo.is_main_scene:
            return s.nwo_export

    return bpy.context.scene.nwo_export

def get_launcher_props():
    for s in bpy.data.scenes:
        if s.nwo.is_main_scene:
            return s.nwo_halo_launcher

    return bpy.context.scene.nwo_halo_launcher

class Section(Enum):
    FILE = "FILE"
    OBJECT = "OBJECT"
    STEP = "STEP"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"

_last_section = None

def print_section(title: str):
    print()
    print("=" * len(title))
    print(title)
    print("=" * len(title))

def print_tag(title: str):
    print()
    print(f"• {title}")
    
def print_done(msg: str):
    print(f"-> {msg}")

def print_step(msg: str):
    print(f"  - {msg}")
    
def print_bullet(msg: str):
    print(f"• {msg}")

def print_info(msg: str):
    print(f"    {msg}")

def display_warning(title: str, message: str):
    try:
        MB_ICONWARNING = 0x30
        MB_OK = 0x0
        ctypes.windll.user32.user32.MessageBoxW(
            None,
            message,
            title,
            MB_OK | MB_ICONWARNING,
        )
    except Exception:
        pass
    
def action_shot_index(name):
    no_dupe = dot_partition(name)
    num = any_partition(no_dupe, "_", True)
    if num.isdigit():
        return int(num)
    
def is_halo_light(ob):
    return ob.type == 'LIGHT' and ob.data.type != 'AREA'

def scale_to_one(x, max_value):
    x, max_value = float(x), float(max_value)
    if max_value == 0.0:
        return 0.0
    
    return x / max_value

def get_frame_start_end_from_keyframes(action, ob_slot):
    
    slot = get_slot_from_id(action, ob_slot)
    
    if action is None or slot is None:
        return 0, 0
    
    frames = set()
    for fcurve in get_fcurves(action, slot):
        for kfp in fcurve.keyframe_points:
            frames.add(kfp.co[0])
        
    if len(frames) > 1:
        return int(min(*frames)), int(max(*frames))
    else:
        return int(bpy.context.scene.frame_start), int(bpy.context.scene.frame_end)

def lerp(x1: float, x2: float, y1: float, y2: float, x: float):
    return ((y2 - y1) * x + x2 * y1 - x1 * y2) / (x2 - x1)

def get_light_final_color_and_intensity(light: bpy.types.Light | float, intensity=1.0, return_argb=False, return_255=False, ignore_colorspace_conversion=False) -> Color:
    
    if isinstance(light, bpy.types.Light):
        base = Color(light.color)

        if light.use_temperature:
            temp_color = light.temperature_color
            base.r *= temp_color.r
            base.g *= temp_color.g
            base.b *= temp_color.b
    else:
        base = Color(light)
    
    max_color = max(base.r, base.g, base.b, 1.0)
    if base.r > 0:
        base.r /= max_color
    if base.g > 0:
        base.g /= max_color
    if base.b > 0:
        base.b /= max_color
        
    intensity *= max_color
    
    # if intensity > 100: # make color whiter in extreme intensity
    #     base.s = lerp(100, 1000, 1, 0, intensity)
        
    red = base.r if ignore_colorspace_conversion else linear_to_srgb(base.r)
    green = base.g if ignore_colorspace_conversion else linear_to_srgb(base.g)
    blue = base.b if ignore_colorspace_conversion else linear_to_srgb(base.b)
    alpha = 1.0
    
    if return_255:
        red *= 255.0
        green *= 255.0
        blue *= 255.0
        alpha = 255.0
        
    if return_argb:
        return [alpha, red, green, blue], intensity
    else:
        return [red, green, blue], intensity
    
def copy_bl_props(source_id, dest_id):
    for k, v in source_id.items():
        if type(v).__name__ != 'IDPropertyGroup':
            dest_id[k] = v
            
def source_blend_from_sidecar(sidecar_path):
    
    sidecar_path = str(sidecar_path)
    
    if not os.path.exists(sidecar_path):
        return
    
    try:
        tree = ET.parse(sidecar_path)
        root = tree.getroot()

        header = root.find("Header")
        if header is None:
            return None

        source_blend_element = header.find("SourceBlend")
        if source_blend_element is None:
            return None

        source_blend = (source_blend_element.text or "").strip()
        if not source_blend:
            return None

        if os.path.isabs(source_blend):
            return source_blend if os.path.exists(source_blend) else None

        combined = os.path.join(get_data_path(), source_blend)
        return combined if os.path.exists(combined) else None

    except Exception as ex:
        print(f"Failed reading sidecar: {sidecar_path}")
        return None
    
def round_int(x: float):
    return int(round(x, 0))
    
def game_frame(frame: int):
    return round_int(frame * (30 / real_frame_rate()))

def blender_frame(frame: int):
    return round_int(frame / (30 / real_frame_rate()))

_WINDOWS_RESERVED = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}

def clean_text(value: str, replacement: str = "_", replace_spaces=False, empty_string_allowed=False) -> str:
    value = unicodedata.normalize("NFKD", value)
    value = value.encode("ascii", "ignore").decode("ascii")
    value = re.sub(r"[.\s]+", replacement, value)
    value = re.sub(r'[<>:"/\\|?*\x00-\x1F]', "", value)
    value = re.sub(r"[^A-Za-z0-9_\-]", "", value)

    # Prevent empty string
    if not value:
        value = "" if empty_string_allowed else "default"

    # Avoid reserved names (case-insensitive)
    if value.upper() in _WINDOWS_RESERVED:
        value = f"{value}_"
        
    if replace_spaces:
        return value.replace(" ", replacement)
    else:
        return value


def find_layer_collection(layer_coll, collection):
    if layer_coll.collection == collection:
        return layer_coll
    for child in layer_coll.children:
        result = find_layer_collection(child, collection)
        if result:
            return result
    return None

def bpy_enum_from_list(l: list, start_with_none=False):
    items = [("none", "None", "")] if start_with_none else []
    for i in l:
        items.append((i, i, ""))
        
    if not items:
        return [("none", "None", "")]
    
    return items

def uses_array_mod(ob: bpy.types.Object):
    try:
        return any(
            mod.type == 'NODES' and mod.name.lower().startswith("array") and not mod.properties.inputs.Socket_38
            for mod in ob.modifiers
        )
    except:
        print_warning(f"Failed to check for array modifier on {ob.name}")
        return False

def open_in_explorer(fp: str | Path) -> bool:
    """Returns True if the file folder was opened"""
    def open_dir(full_fp):
        if full_fp.is_dir():
            os.startfile(full_fp)
            return True
        elif full_fp.is_file():
            os.startfile(full_fp.parent)
            return True
        
        return False
            
    if len(str(fp)) < 3:
        return False
    
    fp = Path(fp)
    
    if fp.exists():
        return open_dir(fp)
    
    tags_fp = Path(get_tags_path(), fp)
    if tags_fp.exists():
        return open_dir(tags_fp)
    
    data_fp = Path(get_data_path(), fp)
    if data_fp.exists():
        return open_dir(data_fp)
    
    return False
