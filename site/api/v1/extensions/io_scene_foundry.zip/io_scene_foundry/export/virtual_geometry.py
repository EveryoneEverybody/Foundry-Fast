'''Classes to store intermediate geometry data to be passed to granny files'''

from collections import defaultdict
import csv
from ctypes import Array, Structure, c_char_p, c_float, c_int, POINTER, c_ubyte, c_void_p, cast, create_string_buffer, memmove, pointer, sizeof
import logging
from math import asin, atan2, degrees, inf, nextafter, pi, radians
from pathlib import Path
import bmesh
import bpy
from mathutils import Color, Euler, Matrix, Quaternion, Vector
import numpy as np

from ..props.scene import NWO_ScenePropertiesGroup

from ..managed_blam.material import MaterialTag

from ..managed_blam.shader import ShaderTag
from ..managed_blam.shader_decal import ShaderDecalTag

from ..granny.formats import GrannyAnimation, GrannyBone, GrannyCurveDataDaKeyframes32f, GrannyDataTypeDefinition, GrannyMaterial, GrannyMaterialMap, GrannyMemberType, GrannyMorphTarget, GrannyTrackGroup, GrannyTransform, GrannyTransformTrack, GrannyTriAnnotationSet, GrannyTriMaterialGroup, GrannyTriTopology, GrannyVectorTrack, GrannyVertexData
from ..granny import Granny

from .export_info import AdditionalCompression, ExportInfo, FaceDrawDistance, FaceMode, FaceType, LightmapType, MeshTessellationDensity, MeshType, ObjectType, PoopCollisionType

from ..props.mesh import NWO_MeshPropertiesGroup

from .. import utils

from ..tools.asset_types import AssetType

from .cinematic import Actor, Frame

from ..constants import IDENTITY_MATRIX, IK_INFLUENCE_ROUNDING_TOLERANCE, VALID_MESHES, WU_SCALAR
NORMAL_FIX_MATRIX = Matrix(((1, 0, 0), (0, -1, 0), (0, 0, -1)))
logging.basicConfig(level=logging.DEBUG)

HAVOK_MAYA_COORDINATE_MATRIX_INV = Matrix(((0.0, 1.0, 0.0), (0.0, 0.0, 1.0), (1.0, 0.0, 0.0)))
LEGACY_CONSTRAINT_MARKER_TYPES = {
    "_connected_geometry_marker_type_physics_hinge_constraint",
    "_connected_geometry_marker_type_physics_socket_constraint",
}

face_prop_defaults = {
    "bungie_face_region": 0,
    "bungie_face_global_material": 0,
    "bungie_face_type": 0,
    "bungie_face_mode": 0,
    "bungie_face_sides": 0,
    "bungie_mesh_poop_collision_type": 0,
    "bungie_mesh_type": 3,
    "bungie_face_draw_distance": 0,
    "bungie_ladder": 0,
    "bungie_slip_surface": 0,
    "bungie_decal_offset": 0,
    "bungie_no_shadow": 0,
    "bungie_invisible_to_pvs": 0,
    "bungie_no_lightmap": 0,
    "bungie_precise_position": 0,
    "bungie_mesh_use_uncompressed_verts": 0,
    "bungie_mesh_tessellation_density": 0,
    "bungie_lightmap_ignore_default_resolution_scale": 0,
    "bungie_lightmap_additive_transparency": (0, 0, 0),
    "bungie_lightmap_resolution_scale": 3,
    "bungie_lightmap_type": 0,
    "bungie_lightmap_translucency_tint_color": (0, 0, 0),
    "bungie_lightmap_lighting_from_both_sides": 0,
    "bungie_lightmap_transparency_override": 0,
    "bungie_lightmap_analytical_bounce_modifier": 1.0,
    "bungie_lightmap_general_bounce_modifier": 1.0,
    "bungie_lightmap_chart_group": 0,
    "bungie_lighting_emissive_power": 0.0,
    "bungie_lighting_emissive_color": (0, 0, 0, 0),
    "bungie_lighting_emissive_per_unit": 0,
    "bungie_lighting_emissive_quality": 1.0,
    "bungie_lighting_use_shader_gel": 0,
    "bungie_lighting_bounce_ratio": 1.0,
    "bungie_lighting_attenuation_enabled": 0,
    "bungie_lighting_attenuation_cutoff": 0.0,
    "bungie_lighting_attenuation_falloff": 0.0,
    "bungie_lighting_emissive_focus": 0.0,
    "bungie_lighting_emissive_focus": 0.0,
}

# TODO
# default invalid shader / default water shader
# Look into lighting_info failing to open

DESIGN_MESH_TYPES = {
    MeshType.planar_fog_volume.value,
    MeshType.boundary_surface.value,
    MeshType.water_physics_volume.value,
    MeshType.poop_rain_blocker.value,
    MeshType.poop_vertical_rain_sheet.value
}

FACE_PROP_TYPES = {
    MeshType.default.value,
    MeshType.poop.value,
    MeshType.collision.value,
    MeshType.poop_collision.value,
    MeshType.object_instance.value,
    MeshType.water_surface.value,
}

COLLISION_FACE_MODES = (
    FaceMode.normal.value,
    FaceMode.collision_only.value,
    FaceMode.sphere_collision_only.value,
    FaceMode.breakable.value,
)

WATER_PHYSICS_SIMPLIFY_MERGE_DISTANCE = 0.1
WATER_PHYSICS_SIMPLIFY_PLANAR_ANGLE = radians(5)
WATER_PHYSICS_SIMPLIFY_BOUNDARY_DISTANCE = 0.1
WATER_PHYSICS_SIMPLIFY_BOUNDARY_ANGLE = radians(15)
WATER_PHYSICS_SIMPLIFY_BOUNDARY_PASSES = 8

def add_triangle_mod(scene, ob: bpy.types.Object) -> bpy.types.Modifier:
    mods = ob.modifiers
    for m in mods:
        if m.type == 'TRIANGULATE': return
        
    tri_mod = mods.new('Triangulate', 'TRIANGULATE')
    tri_mod.quad_method = scene.quad_method
    tri_mod.ngon_method = scene.ngon_method
    tri_mod.keep_custom_normals = True
    
def add_decimate_mod(ob: bpy.types.Object) -> bpy.types.Modifier:
    mods = ob.modifiers
    decimate_mod = mods.new('Decimate', 'DECIMATE')
    decimate_mod.decimate_type = 'DISSOLVE'

def mesh_triangle_count(mesh: bpy.types.Mesh) -> int:
    return sum(max(poly.loop_total - 2, 0) for poly in mesh.polygons)

def water_physics_boundary_dissolve_candidates(bm):
    candidates = []
    candidate_neighbors = {}

    for vert in bm.verts:
        if not vert.is_valid:
            continue

        boundary_edges = [edge for edge in vert.link_edges if edge.is_valid and edge.is_boundary]
        if len(boundary_edges) != 2:
            continue

        vert_a = boundary_edges[0].other_vert(vert)
        vert_b = boundary_edges[1].other_vert(vert)
        if not vert_a.is_valid or not vert_b.is_valid:
            continue

        line = vert_b.co - vert_a.co
        line_length_squared = line.length_squared
        if line_length_squared == 0:
            continue

        factor = (vert.co - vert_a.co).dot(line) / line_length_squared
        if factor <= 0.0 or factor >= 1.0:
            continue

        closest = vert_a.co + line * factor
        if (vert.co - closest).length > WATER_PHYSICS_SIMPLIFY_BOUNDARY_DISTANCE:
            continue

        edge_a = vert_a.co - vert.co
        edge_b = vert_b.co - vert.co
        if edge_a.length_squared == 0 or edge_b.length_squared == 0:
            continue

        deflection = pi - edge_a.angle(edge_b, pi)
        if deflection > WATER_PHYSICS_SIMPLIFY_BOUNDARY_ANGLE:
            continue

        candidates.append(vert)
        candidate_neighbors[vert] = (vert_a, vert_b)

    # Dissolving adjacent boundary verts in the same pass can over-collapse smooth loops.
    dissolved = []
    blocked = set()
    for vert in candidates:
        if vert in blocked:
            continue

        vert_a, vert_b = candidate_neighbors[vert]
        dissolved.append(vert)
        blocked.update((vert, vert_a, vert_b))

    return dissolved

def simplify_water_physics_mesh(mesh: bpy.types.Mesh, scene: 'VirtualScene') -> None:
    before_triangles = mesh_triangle_count(mesh)
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        if not bm.faces:
            return

        bmesh.ops.remove_doubles(
            bm,
            verts=bm.verts,
            dist=WATER_PHYSICS_SIMPLIFY_MERGE_DISTANCE,
        )
        bmesh.ops.dissolve_degenerate(
            bm,
            edges=bm.edges,
            dist=WATER_PHYSICS_SIMPLIFY_MERGE_DISTANCE,
        )
        bmesh.ops.dissolve_limit(
            bm,
            angle_limit=WATER_PHYSICS_SIMPLIFY_PLANAR_ANGLE,
            use_dissolve_boundaries=False,
            verts=bm.verts,
            edges=bm.edges,
            delimit=set(),
        )

        for _ in range(WATER_PHYSICS_SIMPLIFY_BOUNDARY_PASSES):
            boundary_verts = water_physics_boundary_dissolve_candidates(bm)
            if not boundary_verts:
                break

            verts_before = len(bm.verts)
            bmesh.ops.dissolve_verts(
                bm,
                verts=boundary_verts,
                use_face_split=False,
                use_boundary_tear=False,
            )
            bmesh.ops.dissolve_degenerate(
                bm,
                edges=bm.edges,
                dist=WATER_PHYSICS_SIMPLIFY_MERGE_DISTANCE,
            )
            if len(bm.verts) == verts_before:
                break

        bmesh.ops.triangulate(
            bm,
            faces=bm.faces,
            quad_method=utils.tri_mod_to_bmesh_tri(scene.quad_method),
            ngon_method=utils.tri_mod_to_bmesh_tri(scene.ngon_method),
        )
        bm.to_mesh(mesh)
        mesh.update()
    finally:
        bm.free()

    print(f"--- Water physics simplification [{mesh.name}]: {before_triangles} -> {mesh_triangle_count(mesh)} triangles")
    
def read_frame_id_list() -> list:
    filepath = Path(utils.addon_root(), "export", "frameidlist.csv")
    frame_ids = []
    with filepath.open(mode="r") as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=",")
        frame_ids = [row for row in csv_reader]

    return frame_ids

class VirtualShotAnimation:
    def __init__(self, animation_name, granny_track_group, granny_animation, index: int, is_pca):
        self.name = animation_name
        self.granny_track_group = granny_track_group
        # self.granny_event_track_groups = None
        self.granny_animation = granny_animation
        self.is_pca = is_pca
        self.gr2_path = None
        self.shot_index = index
        
        self.vector_tracks = [] # TODO Support exporting wrinkle map events for cinematics
        
        # Always empty for cinematic animation
        self.animation_nodes = []
        
class VirtualShotActor:
    def __init__(self, actor: Actor, scene: 'VirtualScene'):
        self.name = actor.name
        self.name_encoded = actor.name.encode()
        self.ob = actor.ob
        self.actor = actor
        self.bones = None
        self.in_scope = scene.cinematic_scope != 'CAMERA' and (not scene.selected_cinematic_objects_only or actor.ob in scene.selected_actors)
        model = scene.models.get(actor.ob)
        if model is not None:
            skeleton = model.skeleton
            if skeleton is not None:
                self.bones = skeleton.animated_bones
                
        self.positions = defaultdict(list)
        self.orientations = defaultdict(list)
        self.scales = defaultdict(list)

class VirtualShot:
    def __init__(self,  frame_start: int, frame_end: int, actors: list[Actor], camera: bpy.types.Object, index, scene: 'VirtualScene', shape_key_objects=[], in_scope=True):
        self.shot_actors = [VirtualShotActor(actor, scene) for actor in actors]
        self.camera = camera
        self.frame_start = frame_start
        self.frame_end = frame_end
        self.frame_count = frame_end - frame_start + 1
        self.frames: list[Frame] = []
        self.index = index
        self.actor_animation = {}
        self.shot_index = index
        self.sounds = []
        self.effects = []
        self.scripts = []
        self.in_scope = in_scope
    
    def perform(self, scene: 'VirtualScene', film_aperture: float):
        if scene.cinematic_scope != 'OBJECT' and self.in_scope:
            fps = utils.real_frame_rate()
            start, end = self.frame_start, self.frame_end

            start_time = start / fps
            end_time = end / fps
            duration = end_time - start_time

            for i in range(self.frame_count):
                t = i / (self.frame_count - 1) if self.frame_count > 1 else 0.0
                time = start_time + t * duration

                frame_float = time * fps
                frame = int(frame_float)
                subframe = frame_float - frame

                if frame > end:
                    frame = end
                    subframe = 0.0

                scene.context.scene.frame_set(frame, subframe=subframe)
                self.frames.append(Frame(self.camera, scene.corinth, film_aperture, scene.halo_transform_scale, scene.halo_rotation))
                for shot_actor in self.shot_actors:
                    if not shot_actor.in_scope:
                        continue

                    bone_inverse_matrices = {}

                    for bone in shot_actor.bones:
                        if bone.parent:
                            matrix_world = scene.rotation_matrix @ bone.ob.matrix_world @ bone.pbone.matrix
                            bone_inverse_matrices[bone.pbone] = matrix_world.inverted_safe()
                            matrix = bone_inverse_matrices[bone.parent] @ matrix_world
                        else:
                            matrix = scene.rotation_matrix @ bone.ob.matrix_world @ bone.pbone.matrix
                            bone_inverse_matrices[bone.pbone] = matrix.inverted_safe()

                        loc, rot, sca = matrix.decompose()

                        position = (c_float * 3)(loc.x, loc.y, loc.z)
                        orientation = (c_float * 4)(rot.x, rot.y, rot.z, rot.w)
                        scale_shear = (c_float * 9)(sca.x, 0.0, 0.0, 0.0, sca.y, 0.0, 0.0, 0.0, sca.z)

                        shot_actor.positions[bone].extend(position)
                        shot_actor.orientations[bone].extend(orientation)
                        shot_actor.scales[bone].extend(scale_shear)

        frame_total = self.frame_count - 1
                
        for shot_actor in self.shot_actors:
            if shot_actor.in_scope:
                tracks = []
                for bone in shot_actor.bones:
                    tracks.append((c_float * (self.frame_count * 3))(*shot_actor.positions[bone]))
                    tracks.append((c_float * (self.frame_count * 4))(*shot_actor.orientations[bone]))
                    tracks.append((c_float * (self.frame_count * 9))(*shot_actor.scales[bone]))
                    
                granny_tracks = []
                for bone_idx, i in enumerate(range(0, len(tracks), 3)):
                    granny_track = GrannyTransformTrack()
                    granny_track.name = shot_actor.bones[bone_idx].pbone.name.encode()
                    
                    builder = scene.granny.begin_curve(scene.granny.keyframe_type, 0, 3, self.frame_count)
                    scene.granny.push_control_array(builder, tracks[i])
                    position_curve = scene.granny.end_curve(builder)
                    
                    builder = scene.granny.begin_curve(scene.granny.keyframe_type, 0, 4, self.frame_count)
                    scene.granny.push_control_array(builder, tracks[i + 1])
                    orientation_curve = scene.granny.end_curve(builder)
                    
                    builder = scene.granny.begin_curve(scene.granny.keyframe_type, 0, 9, self.frame_count)
                    scene.granny.push_control_array(builder, tracks[i + 2])
                    scale_curve = scene.granny.end_curve(builder)
                    
                    granny_track.position_curve = position_curve.contents
                    granny_track.orientation_curve = orientation_curve.contents
                    granny_track.scale_shear_curve = scale_curve.contents

                    del position_curve
                    del orientation_curve
                    del scale_curve

                    granny_tracks.append(granny_track)
                    
                granny_track = GrannyTransformTrack()
                granny_track.name = b"world"
                arm_tracks = []
                loc, rot, sca = IDENTITY_MATRIX.decompose()
                positions = []
                orientations = []
                scales = []
                for frame in range(self.frame_count):
                    position = (c_float * 3)(0, 0, 0)
                    orientation = (c_float * 4)(0, 0, 0, 1)
                    scale_shear = (c_float * 9)(1, 0.0, 0.0, 0.0, 1, 0.0, 0.0, 0.0, 1)
                    positions.extend(position)
                    orientations.extend(orientation)
                    scales.extend(scale_shear)

                arm_tracks.append((c_float * (self.frame_count * 3))(*positions))
                arm_tracks.append((c_float * (self.frame_count * 4))(*orientations))
                arm_tracks.append((c_float * (self.frame_count * 9))(*scales))

                builder = scene.granny.begin_curve(scene.granny.keyframe_type, 0, 3, self.frame_count)
                scene.granny.push_control_array(builder, arm_tracks[0])
                position_curve = scene.granny.end_curve(builder)
                
                builder = scene.granny.begin_curve(scene.granny.keyframe_type, 0, 4, self.frame_count)
                scene.granny.push_control_array(builder, arm_tracks[1])
                orientation_curve = scene.granny.end_curve(builder)
                
                builder = scene.granny.begin_curve(scene.granny.keyframe_type, 0, 9, self.frame_count)
                scene.granny.push_control_array(builder, arm_tracks[2])
                scale_curve = scene.granny.end_curve(builder)

                granny_track.position_curve = position_curve.contents
                granny_track.orientation_curve = orientation_curve.contents
                granny_track.scale_shear_curve = scale_curve.contents

                granny_tracks.append(granny_track)

                granny_tracks.sort(key=lambda track: track.name)
                granny_transform_tracks = (GrannyTransformTrack * len(granny_tracks))(*granny_tracks)
                    
                granny_track_group = GrannyTrackGroup()
                granny_track_group.name = b"world"
                granny_track_group.transform_track_count = len(granny_tracks)
                granny_track_group.transform_tracks = granny_transform_tracks
                granny_track_group.flags = 2
                ptr_granny_track_group = pointer(granny_track_group)
                
                granny_animation = GrannyAnimation()
                animation_name = f"{shot_actor.name}_{self.index + 1}"
                granny_animation.name = animation_name.encode()
                granny_animation.duration = scene.time_step * frame_total + 0.00001
                granny_animation.time_step = scene.time_step
                granny_animation.oversampling = 1
                granny_animation.track_group_count = 1
                granny_animation.track_groups = pointer(ptr_granny_track_group)
                animation = VirtualShotAnimation(animation_name, ptr_granny_track_group, pointer(granny_animation), self.index, False)
                self.actor_animation[shot_actor] = animation
            else:
                animation_name = f"{shot_actor.name}_{self.index + 1}"
                animation = VirtualShotAnimation(animation_name, None, None, self.index, False)
                self.actor_animation[shot_actor] = animation
                
vector_event_types = {
    '_connected_geometry_animation_event_type_ik_active',
    '_connected_geometry_animation_event_type_ik_passive',
    '_connected_geometry_animation_event_type_wrinkle_map',
    '_connected_geometry_animation_event_type_object_function'
}

class VectorEvent:
    def __init__(
        self,
        name: str,
        event,
        effect_name: str,
        on_event_model=False,
        source_object: bpy.types.Object | None = None,
        source_bone_name: str = "",
        source_property: str = "",
    ):
        self.name = name
        self.event = event
        self.effect_name = effect_name
        self.effect_data: list[float] = []
        self.on_event_model = on_event_model
        self.source_object = source_object
        self.source_bone_name = source_bone_name
        self.source_property = source_property

    def _round_influence(self, value: float) -> float:
        value = max(0.0, min(1.0, float(value)))
        if value <= IK_INFLUENCE_ROUNDING_TOLERANCE:
            return 0.0
        if 1.0 - value <= IK_INFLUENCE_ROUNDING_TOLERANCE:
            return 1.0
        return round(value, 6)

    def value(self) -> float:
        if self.source_property and self.source_object is not None and self.source_object.type == 'ARMATURE':
            pose_bone = self.source_object.pose.bones.get(self.source_bone_name)
            if pose_bone is not None and self.source_property in pose_bone:
                value = pose_bone[self.source_property]
                if self.effect_name == "bungie_animation_control_ik_effect":
                    return self._round_influence(value)
                return float(value)

        if self.effect_name == "bungie_animation_control_ik_effect":
            return self._round_influence(self.event.event_value)

        return float(self.event.event_value)
                    
class VectorTrack:
    def __init__(self, granny_vector_track, bone_name, granny_track_group):
        self.granny_vector_track = granny_vector_track
        self.bone_name = bone_name
        self.granny_track_group = granny_track_group
            
class VirtualAnimation:
    def __init__(self, animation, scene: 'VirtualScene', sample: bool, animation_controls=[], shape_key_objects=[], vector_events=[]):
        is_scene_anim = isinstance(animation, NWO_ScenePropertiesGroup)
        if is_scene_anim:
            self.name = Path(bpy.data.filepath).with_suffix("").name
            self.anim = animation
            self.compression = 'Default'
            self.animation_type = None
            self.movement = None
            self.space = None
            self.overlay = scene.scene_nwo.animation_overlay
            self.frame_count: int = utils.game_frame(animation.id_data.frame_end - animation.id_data.frame_start + 1)
            self.frame_range: tuple[int, int] = (animation.id_data.frame_start, animation.id_data.frame_end)
        else:
            self.name = animation.name
            
            if scene.default_animation_compression != "Automatic" and animation.compression == "Default":
                self.compression = scene.default_animation_compression
            else:
                self.compression = animation.compression
                
            self.animation_type = animation.animation_type
            self.movement = animation.animation_movement_data
            self.space = animation.animation_space
            self.overlay = animation.animation_type == 'overlay'
            
            self.frame_count: int = utils.game_frame(animation.frame_end - animation.frame_start + 1)
            self.frame_range: tuple[int, int] = (animation.frame_start, animation.frame_end)
        
        self.pose_overlay = False # Now calculating this rather than this being user defined
        self.anim = animation
        self.morph_target_data = []
        self.is_pca = False
        
        self.vector_tracks = []
        self.composite_blend_axis_values = {}
            
        self.granny_animation = None
        self.granny_track_group = None
        self.granny_vector_tracks = None
        # self.granny_event_track_groups = []
        
        self.granny_morph_targets_counts = {}
        self.granny_morph_targets = {}
        
        self.nodes = []
        self.suspension = False
        self.suspension_marker = None
        self.suspension_contact_marker = None
        self.suspension_extension_depth = 0.0
        self.suspension_compression_depth = 0.0
        self.suspension_destroyed_contact_marker = None
        self.suspension_destroyed_extension_depth = 0.0
        self.suspension_destroyed_compression_depth = 0.0
        self.suspension_destroyed_region_name = ""
        
        self.animation_nodes = animation.animation_nodes
        
        uses_suspension = not scene.disable_automatic_suspension_computation and utils.tokenise(self.name)[0] == "suspension"
        if uses_suspension:
            if not animation.suspension_marker:
                scene.warnings.append(f"Suspension Point not set for {animation.name}. Cannot automatically calculate suspension extension and compression points")
            if not animation.suspension_contact_marker:
                scene.warnings.append(f"Suspension Contact Point not set for {animation.name}. Cannot automatically calculate suspension extension and compression points")
                
            if animation.suspension_marker is not None and animation.suspension_contact_marker is not None:
                self.suspension = True
                self.suspension_marker = animation.suspension_marker
                self.suspension_contact_marker = animation.suspension_contact_marker
                if animation.suspension_destroyed_region_name.strip():
                    self.suspension_destroyed_region_name = animation.suspension_destroyed_region_name
                    if animation.suspension_destroyed_contact_marker is None:
                        self.suspension_destroyed_contact_marker = animation.suspension_contact_marker
                    else:
                        self.suspension_destroyed_contact_marker = animation.suspension_destroyed_contact_marker

        if sample:
            self.create_track_group(scene.skeleton_model.skeleton.animated_bones + animation_controls, scene, shape_key_objects, vector_events)
            self.to_granny_animation(scene)
            
        if not is_scene_anim:
            animation.pose_overlay = self.pose_overlay
            
    def create_vector_track_groups(self, scene: 'VirtualScene', vector_events: list[VectorEvent]):
        for event in vector_events:
            granny_vector_track = GrannyVectorTrack()
            granny_vector_track.name = event.effect_name.encode()
            granny_vector_track.track_key = 0
            granny_vector_track.dimension = 1

            curve_data = GrannyCurveDataDaKeyframes32f()
            curve_data.dimension = 1
            curve_data.control_count = len(event.effect_data)
            curve_data.controls = (c_float * len(event.effect_data))(*event.effect_data)
            granny_vector_track.value_curve.curve_data.type = scene.granny.keyframe_type
            granny_vector_track.value_curve.curve_data.object = cast(pointer(curve_data), c_void_p)
            
            if event.on_event_model:
                granny_track_group = event.name.encode()
            else:
                granny_track_group = None
            
            self.vector_tracks.append(VectorTrack(granny_vector_track, event.name.encode(), granny_track_group))
        
    def create_track_group(self, bones: list['AnimatedBone'], scene: 'VirtualScene', shape_key_objects, vector_events: list[VectorEvent]):
        positions = defaultdict(list)
        orientations = defaultdict(list)
        scales = defaultdict(list)
        tracks = []
        pose_overlay_frame_data = defaultdict(list)
        morph_target_datas = defaultdict(list)
        shape_key_data = {}
        root_track_bone = self._composite_root_bone(bones, scene)
        root_translations = []
        root_rotations = []

        for ob in shape_key_objects:
            node = scene.nodes.get(ob)
            if node is not None:
                shape_key_data[ob] = node
                self.nodes.append(node)

        if shape_key_data:
            self.is_pca = True
            
        wrap_events = {}
        
        for event in self.anim.animation_events:
            if event.event_type == '_connected_geometry_animation_event_type_import':
                wrap_events[utils.blender_frame(event.frame_frame)] = event.import_name

        first_frame = True
        suspension_extension_frame = False
        suspension_reference_height = 0.0
        suspension_extension_height = 0.0
        suspension_compression_height = 0.0
        suspension_destroyed_extension_height = 0.0
        suspension_destroyed_compression_height = 0.0

        fps = utils.real_frame_rate()
        start, end = self.frame_range

        start_time = start / fps
        end_time = end / fps
        duration = end_time - start_time

        real_frame_count = 0

        for i in range(self.frame_count):
            t = i / (self.frame_count - 1) if self.frame_count > 1 else 0.0
            time = start_time + t * duration

            frame_float = time * fps
            frame = int(frame_float)
            subframe = frame_float - frame

            if frame > end:
                frame = end
                subframe = 0.0

            scene.context.scene.frame_set(frame, subframe=subframe)

            real_frame_count += 1

            if self.suspension:
                if first_frame:
                    suspension_reference_height = self.suspension_marker.matrix_world.translation.z
                    suspension_extension_frame = True
                elif suspension_extension_frame:
                    suspension_extension_height = self.suspension_contact_marker.matrix_world.translation.z
                    if self.suspension_destroyed_region_name:
                        suspension_destroyed_extension_height = self.suspension_destroyed_contact_marker.matrix_world.translation.z
                    suspension_extension_frame = False
                elif i == self.frame_count - 1:
                    suspension_compression_height = self.suspension_contact_marker.matrix_world.translation.z

                    self.suspension_extension_depth = (suspension_reference_height - suspension_extension_height) * scene.unit_factor * WU_SCALAR
                    self.suspension_compression_depth = (suspension_reference_height - suspension_compression_height) * scene.unit_factor * WU_SCALAR

                    if self.suspension_destroyed_region_name:
                        suspension_destroyed_compression_height = self.suspension_destroyed_contact_marker.matrix_world.translation.z

                        self.suspension_destroyed_extension_depth = (suspension_reference_height - suspension_destroyed_extension_height) * scene.unit_factor * WU_SCALAR
                        self.suspension_destroyed_compression_depth = (suspension_reference_height - suspension_destroyed_compression_height) * scene.unit_factor * WU_SCALAR

            bone_inverse_matrices = {}
            for bone in bones:
                if bone.is_object:
                    matrix_world = scene.rotation_matrix @ bone.pbone.matrix_world
                    matrix = matrix_world
                elif bone.parent:
                    matrix_world = scene.rotation_matrix @ bone.ob.matrix_world @ bone.pbone.matrix
                    bone_inverse_matrices[bone.pbone] = matrix_world.inverted_safe()
                    matrix = bone_inverse_matrices[bone.parent] @ matrix_world
                else:
                    matrix = scene.rotation_matrix @ bone.ob.matrix_world @ bone.pbone.matrix
                    matrix_world = matrix
                    bone_inverse_matrices[bone.pbone] = matrix.inverted_safe()
                    
                loc, rot, sca = matrix.decompose()

                if bone is root_track_bone:
                    root_translations.append(loc.copy())
                    root_rotations.append(rot.copy())

                if self.overlay and bone.is_aim_bone and not first_frame:
                    frame_data = tuple((rot.x, rot.y, rot.z, wrap_events.get(frame)))
                    pose_overlay_frame_data[bone.name].append(frame_data)

                position = (c_float * 3)(loc.x, loc.y, loc.z)
                orientation = (c_float * 4)(rot.x, rot.y, rot.z, rot.w)
                scale_shear = (c_float * 9)(sca.x, 0.0, 0.0, 0.0, sca.y, 0.0, 0.0, 0.0, sca.z)

                positions[bone].extend(position)
                orientations[bone].extend(orientation)
                scales[bone].extend(scale_shear)
                
            first_frame = False

            for event in vector_events:
                event.effect_data.append(event.value())

            if shape_key_data:
                for ob, node in shape_key_data.items():
                    morph_target_datas[node].append(VirtualMorphTargetData(ob, scene, node))

        self.composite_blend_axis_values = self.calculate_composite_blend_axis_values(root_translations, root_rotations, scene)
        if self.composite_blend_axis_values:
            scene.add_composite_blend_axis_values(self.name, self.composite_blend_axis_values)

        self.create_vector_track_groups(scene, vector_events)
        
        if self.overlay and pose_overlay_frame_data:
            frame_data = zip(*pose_overlay_frame_data.values())
            data_map = defaultdict(list)
            for idx, data in enumerate(frame_data):
                data_map[data].append(idx)
            
            duplicate_data = {key: indexes for key, indexes in data_map.items() if len(indexes) > 1}
            if len(duplicate_data) != len(data_map):
                # This must be a pose overlay if aim bones don't have same rotation on every frame
                # Even if duplicate frame data is found, keep this as pose overlay so the user is also warned of the issue by Tool
                # NOTE wrap events allow duplicate frames along as the duplicate frames have different wrap events
                self.pose_overlay = True
                if duplicate_data:
                    scene.warnings.append(f"Pose overlay animation [{self.name}] has duplicate frames and may fail pose computation. Details below:")
                    for rotation, indexes in duplicate_data.items():
                        frames = [self.anim.frame_start + i + 1 for i in indexes]
                        rotation_with_names = {tuple(pose_overlay_frame_data)[idx]: tuple(degrees(r) for r in rot[:3]) for (idx, rot) in enumerate(rotation)}
                        scene.warnings.append(f"--- XYZ rotation {rotation_with_names} occurs at frames {frames}")

        for bone in bones:
            tracks.append((c_float * (self.frame_count * 3))(*positions[bone]))
            tracks.append((c_float * (self.frame_count * 4))(*orientations[bone]))
            tracks.append((c_float * (self.frame_count * 9))(*scales[bone]))
            
        granny_tracks = []
        for bone_idx, i in enumerate(range(0, len(tracks), 3)):
            granny_track = GrannyTransformTrack()
            granny_track.name = bones[bone_idx].pbone.name.encode()
            
            builder = scene.granny.begin_curve(scene.granny.keyframe_type, 0, 3, self.frame_count)
            scene.granny.push_control_array(builder, tracks[i])
            position_curve = scene.granny.end_curve(builder)
            
            builder = scene.granny.begin_curve(scene.granny.keyframe_type, 0, 4, self.frame_count)
            scene.granny.push_control_array(builder, tracks[i + 1])
            orientation_curve = scene.granny.end_curve(builder)
            
            builder = scene.granny.begin_curve(scene.granny.keyframe_type, 0, 9, self.frame_count)
            scene.granny.push_control_array(builder, tracks[i + 2])
            scale_curve = scene.granny.end_curve(builder)
            
            granny_track.position_curve = position_curve.contents
            granny_track.orientation_curve = orientation_curve.contents
            granny_track.scale_shear_curve = scale_curve.contents

            del position_curve
            del orientation_curve
            del scale_curve

            granny_tracks.append(granny_track)

        granny_track = GrannyTransformTrack()
        granny_track.name = b"world"
        arm_tracks = []
        loc, rot, sca = IDENTITY_MATRIX.decompose()
        positions = []
        orientations = []
        scales = []
        for frame in range(self.frame_count):
            position = (c_float * 3)(0, 0, 0)
            orientation = (c_float * 4)(0, 0, 0, 1)
            scale_shear = (c_float * 9)(1, 0.0, 0.0, 0.0, 1, 0.0, 0.0, 0.0, 1)
            positions.extend(position)
            orientations.extend(orientation)
            scales.extend(scale_shear)

        arm_tracks.append((c_float * (self.frame_count * 3))(*positions))
        arm_tracks.append((c_float * (self.frame_count * 4))(*orientations))
        arm_tracks.append((c_float * (self.frame_count * 9))(*scales))

        builder = scene.granny.begin_curve(scene.granny.keyframe_type, 0, 3, self.frame_count)
        scene.granny.push_control_array(builder, arm_tracks[0])
        position_curve = scene.granny.end_curve(builder)
        
        builder = scene.granny.begin_curve(scene.granny.keyframe_type, 0, 4, self.frame_count)
        scene.granny.push_control_array(builder, arm_tracks[1])
        orientation_curve = scene.granny.end_curve(builder)
        
        builder = scene.granny.begin_curve(scene.granny.keyframe_type, 0, 9, self.frame_count)
        scene.granny.push_control_array(builder, arm_tracks[2])
        scale_curve = scene.granny.end_curve(builder)

        granny_track.position_curve = position_curve.contents
        granny_track.orientation_curve = orientation_curve.contents
        granny_track.scale_shear_curve = scale_curve.contents

        # del position_curve
        # del orientation_curve
        # del scale_curve

        granny_tracks.append(granny_track)

        granny_tracks.sort(key=lambda track: track.name)
        granny_transform_tracks = (GrannyTransformTrack * len(granny_tracks))(*granny_tracks)
            
        granny_track_group = GrannyTrackGroup()
        granny_track_group.name = b"world"
        granny_track_group.transform_track_count = len(granny_tracks)
        granny_track_group.transform_tracks = granny_transform_tracks
        
        granny_track_group.flags = 2
        self.granny_track_group = pointer(granny_track_group)
        # self.granny_track_group = scene.granny.end_track_group(group_builder)
        
        for node, data in morph_target_datas.items():
            morphs = [morph.granny_morph_target for morph in data]
            scene.morph_vertex_data[self].extend([m.vertex_data for m in morphs])
            self.granny_morph_targets_counts[node] = len(morphs)
            self.granny_morph_targets[node] = (GrannyMorphTarget * len(morphs))(*morphs)

    def calculate_composite_blend_axis_values(self, translations: list[Vector], rotations: list[Quaternion], scene: 'VirtualScene') -> dict[str, float]:
        translation = Vector((0.0, 0.0, 0.0))
        if translations:
            translation = translations[-1] - translations[0]

        movement = self.movement or "none"
        has_xy_translation = movement in {"xy", "xyyaw", "xyzyaw", "full", "world"} or self.animation_type == "world"
        has_z_translation = movement in {"xyzyaw", "full", "world"} or self.animation_type == "world"
        has_yaw_rotation = movement in {"xyyaw", "xyzyaw", "full", "world"} or self.animation_type == "world"

        if not has_xy_translation:
            translation.x = 0.0
            translation.y = 0.0
        if not has_z_translation:
            translation.z = 0.0

        horizontal = translation.to_2d().length
        movement_angle = 0.0 if horizontal < 1e-3 else degrees(atan2(translation.y, translation.x))

        total_angular_offset = 0.0
        if has_yaw_rotation and len(rotations) > 1:
            previous_yaw = self._yaw_degrees(rotations[0])
            for rotation in rotations[1:]:
                yaw = self._yaw_degrees(rotation)
                total_angular_offset += self._signed_angle_difference(previous_yaw, yaw)
                previous_yaw = yaw

        sampled_duration = scene.time_step * (self.frame_count - 1)
        linear_speed = 0.0 if sampled_duration <= 0.0 else horizontal / sampled_duration
        average_angular_rate = 0.0 if sampled_duration <= 0.0 else total_angular_offset / sampled_duration

        return {
            "none": 0.0,
            "linear_movement_angle": self._zero_small(movement_angle),
            "linear_movement_speed": self._zero_small(linear_speed * WU_SCALAR),
            "total_angular_offset": self._zero_small(total_angular_offset),
            "average_angular_rate": self._zero_small(average_angular_rate),
            "translation_offset_x": self._zero_small(translation.x * WU_SCALAR),
            "translation_offset_y": self._zero_small(translation.y * WU_SCALAR),
            "translation_offset_z": self._zero_small(translation.z * WU_SCALAR),
            "translation_offset_horizontal": self._zero_small(horizontal),
            "negative_translation_offset_x": self._zero_small(-translation.x * WU_SCALAR),
            "negative_translation_offset_y": self._zero_small(-translation.y * WU_SCALAR),
            "negative_translation_offset_z": self._zero_small(-translation.z * WU_SCALAR),
        }

    @staticmethod
    def _composite_root_bone(bones: list['AnimatedBone'], scene: 'VirtualScene'):
        if scene.root_bone is not None:
            for bone in bones:
                if not bone.is_object and bone.pbone == scene.root_bone:
                    return bone

        for bone in bones:
            if not bone.is_object and bone.parent is None:
                return bone

        for bone in bones:
            if not bone.is_object:
                return bone

        return None

    @staticmethod
    def _yaw_degrees(rotation: Quaternion) -> float:
        return degrees(rotation.to_euler().z)

    @staticmethod
    def _signed_angle_difference(a: float, b: float) -> float:
        delta = (b - a + 180.0) % 360.0 - 180.0
        return 180.0 if delta == -180.0 else delta

    @staticmethod
    def _zero_small(value: float) -> float:
        return 0.0 if abs(value) < 1e-3 else value

    def to_granny_animation(self, scene: 'VirtualScene'):
        frame_total = self.frame_count - 1
        granny_animation = GrannyAnimation()
        granny_animation.name = self.name.encode()
        granny_animation.duration = scene.time_step * frame_total + 0.00001
        granny_animation.time_step = scene.time_step
        granny_animation.oversampling = 1
        
        # granny_animation.track_group_count = len(all_track_groups)
        # granny_animation.track_groups = (POINTER(GrannyTrackGroup) * len(all_track_groups))(*all_track_groups)
        
        self.granny_animation = pointer(granny_animation)

class MaterialExtendedData(Structure):
    _pack_ = 1
    _fields_ = [('shader_path', c_char_p), ('shader_type', c_char_p)]

class VirtualMaterial:  
    def __init__(self, name, scene: 'VirtualScene', shader_path: str | Path | None = None):
        self.name: str = name
        self.granny_material = None
        self.shader_path = "override"
        self.shader_type = "override"
        self.granny_texture = None
        self.scene = scene
        if shader_path is not None:
            if not str(shader_path).strip() or str(shader_path) == '.':
                return self.set_default_shader(scene)
        
            path = Path(shader_path)
            full_path = Path(scene.tags_dir, shader_path)
            if not (full_path.exists() and full_path.is_file()):
                return self.set_default_shader(scene)
        
            self.shader_path = str(path.with_suffix(""))
            
            if scene.corinth:
                self.shader_type = "material"
            else:
                self.shader_type = path.suffix[1:]
                if not self.shader_type.startswith("shader"):
                    self.shader_type = "shader"
            
        
        self.to_granny_data(scene)
        if scene.uses_textures:
            self.make_granny_texture(scene)
        
    def set_default_shader(self, scene: 'VirtualScene'):
        self.shader_path = scene.default_shader_path
        self.shader_type = scene.default_shader_type
        self.to_granny_data(scene)
    
    def to_granny_data(self, scene):
        self.granny_material = GrannyMaterial()
        self.granny_material.name = self.name.encode()
        data = MaterialExtendedData(shader_path=self.shader_path.encode(), shader_type=self.shader_type.encode())
        self.granny_material.extended_data.object = cast(pointer(data), c_void_p)
        self.granny_material.extended_data.type = scene.material_extended_data_type
        self.granny_material = pointer(self.granny_material)
        
    def make_granny_texture(self, scene: 'VirtualScene'):
        if self.shader_type == "override" or not self.shader_path:
            return

        shader_path = Path(self.shader_path).with_suffix("." + self.shader_type)
        full_path = Path(scene.tags_dir, shader_path)
        bitmap_data = None
        if not full_path.exists():
            return
        if scene.corinth:
            with MaterialTag(path=shader_path) as shader:
                bitmap_data = shader.get_diffuse_bitmap_data_for_granny()
        else:
            match self.shader_type:
                case 'shader':
                    with ShaderTag(path=shader_path) as shader:
                        bitmap_data = shader.get_diffuse_bitmap_data_for_granny()
                case 'shader_decal':
                    with ShaderDecalTag(path=shader_path) as shader:
                        bitmap_data = shader.get_diffuse_bitmap_data_for_granny()
            
        if not bitmap_data:
            return
        
        # Create a granny texture builder instance
        width, height, stride, rgba = bitmap_data
        builder = scene.granny.begin_texture_builder(width, height)
        scene.granny.encode_image(builder, width, height, stride, 1, rgba)
        texture = scene.granny.end_texture(builder)
        texture.contents.file_name = str(full_path).encode()
        texture.contents.texture_type = 2
        self.granny_texture = texture
        self.granny_material.contents.texture = texture
        # Set up texture map
        map = GrannyMaterialMap()
        map.usage = b"diffuse"
        map.material = self.granny_material
        self.granny_material.contents.maps = pointer(map)
        self.granny_material.contents.map_count = 1

class VirtualMorphTargetData:
    def __init__(self, ob, scene, node: 'VirtualNode'):
        self.ob = ob
        self.positions: np.ndarray = None
        self.normals: np.ndarray = None
        # self.vertex_colors: list[np.ndarray] = [] # Up to two sets of vert colors
        self.tension: np.ndarray = None
        self.num_vertices = 0
        self.invalid = False
        self._setup(ob, scene, node)
        self._granny_vertex_data(scene)
        self._write_vertex_position(scene, node)
        self.granny_morph_target = GrannyMorphTarget(None, self.granny_vertex_data, 0)
        
    def _write_vertex_position(self, scene, node):
        self.granny_vertex_data = GrannyVertexData()
        # self.granny_vertex_data.vertex_component_names = self.vertex_component_names
        # self.granny_vertex_data.vertex_component_name_count = self.vertex_component_name_count
        self.granny_vertex_data.vertex_type = self.vertex_type
        vertex_array = (c_ubyte * self.len_vertex_array)()
        if node.matrix_world == IDENTITY_MATRIX:
            vertex_array = self.vertex_array
        else:
            vertex_array = (c_ubyte * self.len_vertex_array)()
            memmove(vertex_array, self.vertex_array, self.len_vertex_array)
            affine3, linear3x3, inverse_linear3x3 = calc_transforms(node.matrix_world)
            scene.granny.transform_vertices(self.num_vertices,
                                            self.granny_vertex_data.vertex_type,
                                            vertex_array,
                                            affine3,
                                            linear3x3,
                                            inverse_linear3x3,
                                            True,
                                            False,
                                            )
        
        self.granny_vertex_data.vertices = cast(vertex_array, POINTER(c_ubyte))
        self.granny_vertex_data.vertex_count = self.num_vertices
        self.granny_vertex_data = pointer(self.granny_vertex_data)   
    
    def _setup(self, ob: bpy.types.Object, scene: 'VirtualScene' , node: 'VirtualNode'):
        eval_ob = ob.ob.evaluated_get(scene.depsgraph)

        # Get a fully evaluated mesh (preserve data layers so corner_normals / colors exist)
        mesh = eval_ob.to_mesh(preserve_all_data_layers=True, depsgraph=scene.depsgraph)
        
        self.name = mesh.name
        if not mesh.polygons:
            scene.warnings.append(f"Mesh data [{self.name}] of object [{ob.name}] has no faces. Skipping writing morph target data")
            self.invalid = True
            return

        # Keep morph sampling topology aligned with VirtualMesh export topology.
        loop_totals = np.empty(len(mesh.polygons), dtype=np.int32)
        mesh.polygons.foreach_get("loop_total", loop_totals)
        unique_loop_totals = np.unique(loop_totals)
        if len(unique_loop_totals) > 1 or unique_loop_totals[0] != 3:
            bm = bmesh.new()
            bm.from_mesh(mesh)
            bmesh.ops.triangulate(
                bm,
                faces=bm.faces,
                quad_method=utils.tri_mod_to_bmesh_tri(scene.quad_method),
                ngon_method=utils.tri_mod_to_bmesh_tri(scene.ngon_method),
            )
            bm.to_mesh(mesh)
            bm.free()
            
        num_loops = len(mesh.loops)
        num_vertices = len(mesh.vertices)
        
        # print(mesh.vertices[0].co)
        
        vertex_positions = np.empty((num_vertices, 3), dtype=np.single)
        loop_vertex_indices = np.empty(num_loops, dtype=np.int32)
        
        mesh.vertices.foreach_get("co", vertex_positions.ravel())
        mesh.loops.foreach_get("vertex_index", loop_vertex_indices)
        
        self.positions = vertex_positions[loop_vertex_indices]
        self.normals = np.empty((num_loops, 3), dtype=np.single)
        mesh.corner_normals.foreach_get("vector", self.normals.ravel())
        
        for idx, layer in enumerate(mesh.color_attributes):
            # if len(self.vertex_colors) >= 2:
            #     break

            is_tension = layer.name.lower() == "tension"
            if not is_tension:
                continue
            
            colors = np.empty((num_vertices, 4) if layer.domain == 'POINT' else (num_loops, 4), dtype=np.single)
            layer.data.foreach_get("color", colors.ravel())
            is_tension = layer.name.lower() == "tension"
            
            colors = colors[:, :3]
            if layer.domain == 'POINT':
                colors = colors[loop_vertex_indices]

            self.tension = colors

                
        if self.tension is None:
            self.tension = np.zeros((num_loops, 3), dtype=np.single)
        
        if node.for_pca and node.mesh.pca_new_indices is not None:
            new_indices = node.mesh.pca_new_indices
        else:
            new_indices = node.mesh.new_indices

        if new_indices is not None:
            new_indices = np.asarray(new_indices, dtype=np.int32)
            if new_indices.size:
                max_index = int(new_indices.max())
                if max_index >= len(self.positions):
                    max_valid_index = max(len(self.positions) - 1, 0)
                    scene.warnings.append(
                        f"PCA morph target [{ob.name}] loop index mismatch for node [{node.name}] "
                        f"(max index {max_index}, loops {len(self.positions)}). Clamping to valid loop range."
                    )
                    new_indices = np.clip(new_indices, 0, max_valid_index)

            self.positions = self.positions[new_indices, :]
            
            if self.normals is not None:
                self.normals = self.normals[new_indices, :]
                    
            if self.tension is not None:
                self.tension = self.tension[new_indices, :]
            
        # eval_ob.to_mesh_clear()
        
        self.num_vertices = len(self.positions)

    def _granny_vertex_data(self, scene: 'VirtualScene'):
        data = [self.positions]
        types = [GrannyDataTypeDefinition(GrannyMemberType.granny_real32_member.value, b"Position", None, 3)]
        type_names = [b"Position"]
        dtypes = [('Position', np.single, (3,))]
        
        if self.normals is not None:
            data.append(self.normals)
            types.append(GrannyDataTypeDefinition(GrannyMemberType.granny_real32_member.value, b"Normal", None, 3))
            type_names.append(b"Normal")
            dtypes.append(('Normal', np.single, (3,)))
            
        if self.tension is not None:
            data.append(self.tension)
            types.append(GrannyDataTypeDefinition(GrannyMemberType.granny_real32_member.value, b"DiffuseColor0", None, 3))
            type_names.append(b"tension")
            dtypes.append(("tension", np.single, (3,)))

        types.append((GrannyMemberType.granny_end_member.value, None, None, 0))
        
        num_types = len(type_names)
        names_array = (c_char_p * num_types)(*type_names)
        # self.vertex_component_names = cast(names_array, POINTER(c_char_p))
        # self.vertex_component_name_count = num_types
        
        type_info_array = (GrannyDataTypeDefinition * (num_types + 1))(*types)
        self.vertex_type = cast(type_info_array, POINTER(GrannyDataTypeDefinition))
        
        vertex_array = np.zeros(len(self.positions), dtype=dtypes)
        for array, data_type in zip(data, dtypes):
            vertex_array[data_type[0]] = array

        vertex_byte_array = vertex_array.tobytes()

        self.len_vertex_array = len(vertex_byte_array)
        self.vertex_array = (c_ubyte * self.len_vertex_array).from_buffer_copy(vertex_byte_array)
    
    
class VirtualMesh:
    def __init__(self, vertex_weighted: bool, scene: 'VirtualScene', bone_bindings: list[str], ob: bpy.types.Object, render_mesh: bool, proxies: list, props: dict, negative_scaling: bool, bones: list[str], materials: tuple[bpy.types.Material]):
        self.name = ob.data.name
        self.mesh = ob.data
        self.proxies = proxies
        self.positions: np.ndarray = None
        self.normals: np.ndarray = None
        self.bone_weights: np.ndarray = None
        self.bone_indices: np.ndarray = None
        self.texcoords: list[np.ndarray] = [] # Up to 4 uv layers
        self.lighting_texcoords: np.ndarray = None
        self.vertex_colors: list[np.ndarray] = [] # Up to two sets of vert colors
        self.vertex_ids: np.ndarray = None # Corinth only
        self.tension: np.ndarray = None # Corinth only
        self.pca_mask: np.ndarray = None # Corinth only
        self.indices: np.ndarray = None
        self.num_indices = 0
        self.groups: list[VirtualMaterial, int, int] = []
        self.materials = {}
        self.bpy_materials = materials
        self.face_properties: dict = {}
        self.bone_bindings = bone_bindings
        self.vertex_weighted = vertex_weighted
        self.num_vertices = 0
        self.invalid = False
        self.granny_tri_topology = None
        self.siblings = [ob.name]
        self.new_indices = None
        self.pca_new_indices = None
        self.pca_indices = None
        self.pca_granny_tri_topology = None
        self.pca_num_vertices = 0
        self.pca_vertex_component_names = None
        self.pca_vertex_component_name_count = 0
        self.pca_vertex_type = None
        self.pca_len_vertex_array = 0
        self.pca_vertex_array = None
        self._pca_vertex_component_names_array = None
        self._pca_vertex_type_array = None
        self.pca_enabled = bool(getattr(ob, "for_pca", False))
        self.bone_parent = ""
        self._setup(ob, scene, render_mesh, props, bones)
            
        if not self.invalid:
            self.to_granny_data(scene)
            if negative_scaling:
                scene.granny.invert_tri_topology_winding(self.granny_tri_topology)
                if self.pca_granny_tri_topology is not None:
                    scene.granny.invert_tri_topology_winding(self.pca_granny_tri_topology)
        
    def to_granny_data(self, scene: 'VirtualScene'):
        self._granny_tri_topology()
        if self.pca_indices is not None:
            self.pca_granny_tri_topology = self._granny_tri_topology(self.pca_indices)
        self._granny_vertex_data(scene)
        
    def _granny_tri_topology(self, indices_override: np.ndarray | None = None):
        source_indices = self.indices if indices_override is None else indices_override
        indices = (c_int * len(source_indices)).from_buffer_copy(source_indices.astype(np.int32).tobytes())

        granny_tri_topology = GrannyTriTopology()

        num_groups = len(self.groups)
        groups = (GrannyTriMaterialGroup * num_groups)()

        material_data = [(material[1], material[2][0], material[2][1]) for material in self.groups]
        for i, (material_index, tri_first, tri_count) in enumerate(material_data):
            groups[i].material_index = material_index
            groups[i].tri_first = tri_first
            groups[i].tri_count = tri_count

        granny_tri_topology.group_count = num_groups
        granny_tri_topology.groups = cast(groups, POINTER(GrannyTriMaterialGroup))
        granny_tri_topology.index_count = len(source_indices)
        granny_tri_topology.indices = cast(indices, POINTER(c_int))

        # Handle Tri Annotation Sets
        if self.face_properties:
            num_tri_annotation_sets = len(self.face_properties)
            tri_annotation_sets = (GrannyTriAnnotationSet * num_tri_annotation_sets)()

            for i, (name, face_set) in enumerate(self.face_properties.items()):
                granny_tri_annotation_set = tri_annotation_sets[i]
                granny_tri_annotation_set.name = name.encode()
                granny_tri_annotation_set.indices_map_from_tri_to_annotation = 1
                        
                granny_tri_annotation_set.tri_annotation_type = face_set.annotation_type
                
                num_tri_annotations = len(face_set.array)
                annotation_byte_array = face_set.array.tobytes()
                annotation_array = (c_ubyte * len(annotation_byte_array)).from_buffer_copy(annotation_byte_array)
                
                granny_tri_annotation_set.tri_annotation_count = num_tri_annotations
                granny_tri_annotation_set.tri_annotations = cast(annotation_array, POINTER(c_ubyte))

            granny_tri_topology.tri_annotation_set_count = num_tri_annotation_sets
            granny_tri_topology.tri_annotation_sets = cast(tri_annotation_sets, POINTER(GrannyTriAnnotationSet))

        topology = pointer(granny_tri_topology)
        if indices_override is None:
            self.granny_tri_topology = topology
            return self.granny_tri_topology
        
        return topology
        
    def _vertex_data_arrays(self, scene: 'VirtualScene', position_override=None, normal_override=None, tension_override=None):
        positions = self.positions if position_override is None else position_override
        normals = self.normals if normal_override is None else normal_override
        tension = self.tension if tension_override is None else tension_override

        data = [positions]
        types = [GrannyDataTypeDefinition(GrannyMemberType.granny_real32_member.value, b"Position", None, 3)]
        type_names = [b"Position"]
        dtypes = [('Position', np.single, (3,))]
        
        if self.normals is not None:
            data.append(normals)
            types.append(GrannyDataTypeDefinition(GrannyMemberType.granny_real32_member.value, b"Normal", None, 3))
            type_names.append(b"Normal")
            dtypes.append(('Normal', np.single, (3,)))
        
        if self.bone_weights is not None:
            data.extend([self.bone_weights, self.bone_indices])
            types.extend([
                GrannyDataTypeDefinition(GrannyMemberType.granny_normal_u_int8_member.value, b"BoneWeights", None, 4),
                GrannyDataTypeDefinition(GrannyMemberType.granny_uint8_member.value, b"BoneIndices", None, 4)
            ])
            type_names.extend([b"BoneWeights", b"BoneIndices"])
            dtypes.append(('BoneWeights', np.uint8, (4,)))
            dtypes.append(('BoneIndices', np.uint8, (4,)))
        
        for idx, uvs in enumerate(self.texcoords):
            name = f"TextureCoordinates{idx}"
            name_encoded = name.encode()
            data.append(uvs)
            types.append(GrannyDataTypeDefinition(GrannyMemberType.granny_real32_member.value, name_encoded, None, 3))
            type_names.append(name_encoded)
            dtypes.append((name, np.single, (3,)))
            
        if self.lighting_texcoords is not None:
            data.append(self.lighting_texcoords)
            types.append(GrannyDataTypeDefinition(GrannyMemberType.granny_real32_member.value, b"TextureCoordinateslighting", None, 3))
            type_names.append(b"lighting")
            dtypes.append((f'TextureCoordinateslighting{len(self.texcoords)}', np.single, (3,)))
            
        for idx, vcolors in enumerate(self.vertex_colors):
            name = f"colorSet{idx + 1}" if scene.corinth else f"DiffuseColor{idx}"
            data.append(vcolors)
            types.append(GrannyDataTypeDefinition(GrannyMemberType.granny_real32_member.value, f"DiffuseColor{idx}".encode(), None, 3))
            type_names.append(name.encode())
            dtypes.append((name, np.single, (3,)))
            
        if self.tension is not None:
            data.append(tension)
            types.append(GrannyDataTypeDefinition(GrannyMemberType.granny_real32_member.value, f"DiffuseColor{len(self.vertex_colors)}".encode(), None, 3))
            type_names.append(b"tension")
            dtypes.append(("tension", np.single, (3,)))
            
        if self.pca_mask is not None:
            data.append(self.pca_mask)
            types.append(GrannyDataTypeDefinition(GrannyMemberType.granny_real32_member.value, f"DiffuseColor{len(self.vertex_colors) + int(self.tension is not None)}".encode(), None, 3))
            type_names.append(b"pca_mask")
            dtypes.append(("pca_mask", np.single, (3,)))

        if self.vertex_ids is not None:
            data.append(self.vertex_ids)
            types.append(GrannyDataTypeDefinition(GrannyMemberType.granny_real32_member.value, f"TextureCoordinates{len(self.texcoords)}".encode(), None, 2))
            type_names.append(b"vertex_id")
            dtypes.append(('vertex_id', np.single, (2,)))

        types.append((GrannyMemberType.granny_end_member.value, None, None, 0))
        return data, types, type_names, dtypes

    def _make_vertex_array(self, scene: 'VirtualScene', position_override=None, normal_override=None, tension_override=None):
        data, types, type_names, dtypes = self._vertex_data_arrays(scene, position_override, normal_override, tension_override)
        
        num_types = len(type_names)
        names_array = (c_char_p * num_types)(*type_names)
        
        type_info_array = (GrannyDataTypeDefinition * (num_types + 1))(*types)
        
        vertex_array = np.zeros(len(data[0]), dtype=dtypes)
        for array, data_type in zip(data, dtypes):
            vertex_array[data_type[0]] = array

        vertex_byte_array = vertex_array.tobytes()
        return names_array, type_info_array, (c_ubyte * len(vertex_byte_array)).from_buffer_copy(vertex_byte_array), len(vertex_byte_array), num_types

    def _granny_vertex_data(self, scene: 'VirtualScene'):
        names_array, type_info_array, vertex_array, len_vertex_array, num_types = self._make_vertex_array(scene)

        self._vertex_component_names_array = names_array
        self._vertex_type_array = type_info_array
        self.vertex_component_names = cast(names_array, POINTER(c_char_p))
        self.vertex_component_name_count = num_types
        self.vertex_type = cast(type_info_array, POINTER(GrannyDataTypeDefinition))

        self.len_vertex_array = len_vertex_array
        self.vertex_array = vertex_array

    def _stable_unique_rows_with_epsilon(self, arrays: list[np.ndarray], epsilon: float) -> tuple[np.ndarray, np.ndarray]:
        loop_data = arrays[0] if len(arrays) == 1 else np.hstack(arrays)

        quantized = np.rint(loop_data / epsilon).astype(np.int64)
        _, first_indices, inverse = np.unique(quantized, axis=0, return_index=True, return_inverse=True)
        order = np.argsort(first_indices)
        new_indices = first_indices[order].astype(np.int32)

        remap = np.empty(order.size, dtype=np.int32)
        remap[order] = np.arange(order.size, dtype=np.int32)
        face_indices = remap[inverse].astype(np.int32)

        return new_indices, face_indices
        
    def _setup(self, ob: bpy.types.Object, scene: 'VirtualScene', render_mesh: bool, props: dict, bones: list[str]):
        mesh_type_value = props.get("bungie_mesh_type")
        
        if ob.parent_type == 'BONE' and ob.parent_bone:
            self.bone_parent = ob.parent_bone
                
        eval_ob = ob.eval_ob
        
        true_mesh = ob.type == 'MESH'
            
        evaluated = eval_ob is not None
            
        if evaluated:
            for mod in eval_ob.modifiers:
                if mod.type == 'NODES':
                    if utils.uses_array_mod(eval_ob):
                        mod.show_viewport = False

            if true_mesh:
                add_triangle_mod(scene, eval_ob)

            mesh = eval_ob.to_mesh(preserve_all_data_layers=True, depsgraph=scene.depsgraph)
        else:
            mesh = ob.data
            
        if props.get("foundry_simplify"):
            simplify_water_physics_mesh(mesh, scene)
            
        if ob.transform is not None:
            mesh.transform(ob.transform)
        
        self.name = mesh.name
        if not mesh.polygons:
            if true_mesh:
                scene.warnings.append(f"Mesh data [{self.name}] of object [{ob.name}] has no faces. {ob.name} removed from geometry tree")
            self.invalid = True
            return
        
        indices = np.empty(len(mesh.polygons))
        mesh.polygons.foreach_get("loop_total", indices)
        unique_indices = np.unique(indices)

        if len(unique_indices) > 1 or unique_indices[0] != 3:
            # Only if we couldn't triangulate the mesh earlier
            bm = bmesh.new()
            bm.from_mesh(mesh)
            bmesh.ops.triangulate(bm, faces=bm.faces, quad_method=utils.tri_mod_to_bmesh_tri(scene.quad_method), ngon_method=utils.tri_mod_to_bmesh_tri(scene.ngon_method))
            bm.to_mesh(mesh)
            bm.free()
            
            if not mesh.polygons:
                if true_mesh:
                    scene.warnings.append(f"Mesh data [{self.name}] of object [{ob.name}] has no faces. {ob.name} removed from geometry tree")
                self.invalid = True
                return
        
        is_object_instance = mesh_type_value == MeshType.object_instance.value
                    
        num_loops = len(mesh.loops)
        num_vertices = len(mesh.vertices)
        num_polygons = len(mesh.polygons)

        num_materials = len(self.bpy_materials)
        special_mats_dict = defaultdict(list)
        prop_mats_dict = defaultdict(list)
        
        material_override = props.get("material_override")
        
        valid_materials_count = 0
        if material_override is None:
            for idx, mat in enumerate(self.bpy_materials):
                if mat is not None:
                    if mat.nwo.SpecialMaterial:
                        special_mats_dict[mat].append(idx)
                    elif mat.nwo.material_props:
                        prop_mats_dict[mat].append(idx)
                        
                    valid_materials_count += 1

        sorted_order = None
        
        vertex_positions = np.empty((num_vertices, 3), dtype=np.single)
        loop_vertex_indices = np.empty(num_loops, dtype=np.int32)
        
        mesh.vertices.foreach_get("co", vertex_positions.ravel())
        mesh.loops.foreach_get("vertex_index", loop_vertex_indices)
        
        self.positions = vertex_positions[loop_vertex_indices]
        
        def remap(i):
            return vgroup_remap.get(i, 0)

        is_collision = props.get("bungie_mesh_type") == MeshType.collision.value
        is_physics = props.get("bungie_mesh_type") == MeshType.physics.value

        if self.vertex_weighted:
            default_bone_index = 0
            if ob.parent_type == 'BONE' and ob.parent_bone in bones:
                default_bone_index = bones.index(ob.parent_bone)

            vgroup_bone_names = {vg.name: idx for idx, vg in enumerate(ob.vertex_groups)}

            bone_weights = np.zeros((num_vertices, 4), dtype=np.uint8)
            bone_indices = np.zeros((num_vertices, 4), dtype=np.int32)
            vgroup_remap = {}
            unique_bone_indices = set()
            bone_use_counter = {}

            for idx, bone in enumerate(bones):
                vg_bone_index = vgroup_bone_names.get(bone)
                if vg_bone_index is not None:
                    vgroup_remap[vg_bone_index] = idx

            def remap(vg_idx):
                return vgroup_remap.get(int(vg_idx), -1)

            def quantize_weights(weights: np.ndarray) -> np.ndarray:
                scaled = weights * 255.0
                quantized = np.floor(scaled).astype(np.int32)
                remainder = 255 - int(quantized.sum())
                if remainder > 0:
                    fractions = scaled - quantized
                    for idx in np.argsort(-fractions)[:remainder]:
                        quantized[idx] += 1
                elif remainder < 0:
                    for idx in np.argsort(weights):
                        if remainder == 0:
                            break
                        amount = min(int(quantized[idx]), -remainder)
                        quantized[idx] -= amount
                        remainder += amount
                return np.clip(quantized, 0, 255).astype(np.uint8)

            for v_idx, vertex in enumerate(mesh.vertices):
                groups = vertex.groups
                if not groups:
                    bone_ids = np.array([default_bone_index], dtype=np.int32)
                    weights = np.array([1.0], dtype=np.single)
                else:
                    weights = np.zeros(len(groups), dtype=np.single)
                    indices = np.zeros(len(groups), dtype=np.int32)

                    groups.foreach_get("weight", weights)
                    groups.foreach_get("group", indices)

                    bone_ids = np.array([remap(g) for g in indices], dtype=np.int32)

                    valid_mask = bone_ids >= 0
                    bone_ids = bone_ids[valid_mask]
                    weights = weights[valid_mask]

                    if len(weights) == 0:
                        bone_ids = np.array([default_bone_index], dtype=np.int32)
                        weights = np.array([1.0], dtype=np.single)
                    else:
                        order = np.argsort(-weights)
                        bone_ids = bone_ids[order]
                        weights = weights[order]

                        if is_collision:
                            bone_ids = bone_ids[:1]
                            weights = weights[:1]
                        else:
                            bone_ids = bone_ids[:4]
                            weights = weights[:4]

                        total = weights.sum()
                        if total > 0:
                            weights = weights / total
                        else:
                            bone_ids = np.array([default_bone_index], dtype=np.int32)
                            weights = np.array([1.0], dtype=np.single)

                # pad to 4
                pad = 4 - len(weights)
                if pad > 0:
                    bone_ids = np.pad(bone_ids, (0, pad), constant_values=default_bone_index)
                    weights = np.pad(weights, (0, pad), constant_values=0.0)

                bone_weights[v_idx] = quantize_weights(weights)
                bone_indices[v_idx] = bone_ids

                # track used bones
                positive_mask = weights > 0.0
                if positive_mask.any():
                    unique_bone_indices.update(bone_ids[positive_mask])
                    for b in bone_ids[positive_mask]:
                        bone_use_counter[b] = bone_use_counter.get(b, 0) + 1

            if is_physics:
                if bone_use_counter:
                    most_used_bone = max(bone_use_counter, key=bone_use_counter.get)
                else:
                    most_used_bone = default_bone_index

                bone_weights[:, :] = 255
                bone_indices[:, :] = most_used_bone
                unique_bone_indices = {most_used_bone}

            used_bones = sorted(unique_bone_indices)

            if not used_bones:
                used_bones = [default_bone_index]
                bone_weights[:, :] = 255
                bone_indices[:, :] = default_bone_index

            max_bone_index = len(bones) - 1
            used_bones = [i for i in used_bones if 0 <= i <= max_bone_index]
            if not used_bones:
                used_bones = [default_bone_index]
                bone_weights[:, :] = 255
                bone_indices[:, :] = default_bone_index

            bone_index_remap = {orig_idx: new_idx for new_idx, orig_idx in enumerate(used_bones)}

            remapped_indices = np.zeros_like(bone_indices, dtype=np.int32)
            for orig_idx, new_idx in bone_index_remap.items():
                remapped_indices[bone_indices == orig_idx] = new_idx

            self.bone_bindings = [bones[i] for i in used_bones]
            self.bone_weights = bone_weights[loop_vertex_indices]
            self.bone_indices = np.clip(remapped_indices, 0, 255).astype(np.uint8)[loop_vertex_indices]
        
        if render_mesh:
            # We only care about writing this data if the in game mesh will have a render definition
            self.normals = np.empty((num_loops, 3), dtype=np.single)
            mesh.corner_normals.foreach_get("vector", self.normals.ravel())

            if mesh.has_custom_normals:
                # Build per-vertex normals from split normals so custom data that is effectively
                # vertex-based doesn't force unnecessary loop splits at export.
                vertex_normals = np.zeros((num_vertices, 3), dtype=np.single)
                vertex_counts = np.bincount(loop_vertex_indices, minlength=num_vertices)
                np.add.at(vertex_normals, loop_vertex_indices, self.normals)

                valid_counts = vertex_counts > 0
                vertex_normals[valid_counts] /= vertex_counts[valid_counts, None]

                lengths = np.linalg.norm(vertex_normals, axis=1)
                valid_lengths = lengths > 0.0
                vertex_normals[valid_lengths] /= lengths[valid_lengths, None]

                # if ob.data.nwo.from_vert_normals:
                #     # For meshes imported as custom vertex normals, always export vertex-style normals.
                #     self.normals = vertex_normals[loop_vertex_indices]
                # else:
                # Otherwise, only collapse vertices whose loop normals are already consistent.
                diff = np.linalg.norm(self.normals - vertex_normals[loop_vertex_indices], axis=1)
                max_diff_per_vertex = np.zeros(num_vertices, dtype=np.single)
                np.maximum.at(max_diff_per_vertex, loop_vertex_indices, diff)
                consistent_vertices = max_diff_per_vertex <= 1.0e-4
                if consistent_vertices.any():
                    consistent_loops = consistent_vertices[loop_vertex_indices]
                    self.normals[consistent_loops] = vertex_normals[loop_vertex_indices[consistent_loops]]

            for idx, layer in enumerate(mesh.uv_layers):
                if len(self.texcoords) >= 4:
                    break
                
                loop_uvs = np.zeros((num_loops, 2), dtype=np.single)
                layer.uv.foreach_get("vector", loop_uvs.ravel())
                loop_uvs[:, 1] = 1-loop_uvs[:, 1]
                zeros_column = np.zeros((num_loops, 1), dtype=np.single)
                combined_uvs = np.hstack((loop_uvs, zeros_column))
                if layer.name.lower() == "lighting":
                    self.lighting_texcoords = combined_uvs
                else:
                    self.texcoords.append(combined_uvs)
            
            for idx, layer in enumerate(mesh.color_attributes):
                if len(self.vertex_colors) >= 2:
                    break
                
                colors = np.empty((num_vertices, 4) if layer.domain == 'POINT' else (num_loops, 4), dtype=np.single)
                layer.data.foreach_get("color", colors.ravel())
                is_tension = scene.corinth and layer.name.lower() == "tension"
                is_pca_mask = scene.corinth and layer.name.lower() == "pca_mask"
                
                #if not is_tension:
                colors = colors[:, :3]
                if layer.domain == 'POINT':
                    colors = colors[loop_vertex_indices]
    
                if is_tension:
                    self.tension = colors #np.concatenate((colors[:, 3:4], colors[:, :3]), axis=1)
                elif is_pca_mask:
                    self.pca_mask = colors #np.concatenate((colors[:, 3:4], colors[:, :3]), axis=1)
                else:
                    self.vertex_colors.append(colors)
                    
            if scene.corinth and self.tension is None and ob.data.shape_keys:
                self.tension = np.zeros((num_loops, 3), dtype=np.single)
                
        if scene.corinth:
            loop_starts = np.empty(num_polygons, dtype=np.int32)
            loop_totals = np.empty(num_polygons, dtype=np.int32)
            mesh.polygons.foreach_get("loop_start", loop_starts)
            mesh.polygons.foreach_get("loop_total", loop_totals)
            face_indices_per_loop = np.repeat(np.arange(num_polygons, dtype=np.int32), loop_totals)
            loop_in_face = np.arange(num_loops, dtype=np.int32) - np.repeat(loop_starts, loop_totals)
            self.vertex_ids = np.column_stack((face_indices_per_loop, loop_in_face)).astype(np.single)

        if self.pca_enabled:
            # PCA animation export should keep fully split (per-loop) vertices, unlike render export.
            self.pca_new_indices = np.arange(num_loops, dtype=np.int32)
            self.pca_indices = self.pca_new_indices.copy()
            pca_names_array, pca_type_info_array, pca_vertex_array, pca_len_vertex_array, pca_num_types = self._make_vertex_array(scene)
            self._pca_vertex_component_names_array = pca_names_array
            self._pca_vertex_type_array = pca_type_info_array
            self.pca_vertex_component_names = cast(pca_names_array, POINTER(c_char_p))
            self.pca_vertex_component_name_count = pca_num_types
            self.pca_vertex_type = cast(pca_type_info_array, POINTER(GrannyDataTypeDefinition))
            self.pca_len_vertex_array = pca_len_vertex_array
            self.pca_vertex_array = pca_vertex_array
            self.pca_num_vertices = num_loops

        # Remove duplicate vertex data.
        # Render meshes: emulate fbx-to-gr2 weld key (position + normal + UVs + color0) with
        # k_real_epsilon tolerance (1e-4) and stable first-seen ordering.
        if render_mesh:
            weld_components = [self.positions]
            if self.normals is not None:
                weld_components.append(self.normals)
            if self.texcoords is not None:
                weld_components.extend(self.texcoords)
            if self.lighting_texcoords is not None:
                weld_components.append(self.lighting_texcoords)
            if self.vertex_colors is not None:
                weld_components.extend(self.vertex_colors)
            new_indices, face_indices = self._stable_unique_rows_with_epsilon(weld_components, 1.0e-4)
        else:
            weld_components = [self.positions]
            # if self.normals is not None:
            #     weld_components.append(self.normals)
            new_indices, face_indices = self._stable_unique_rows_with_epsilon(weld_components, 1.0e-4)

        self.indices = face_indices.astype(np.int32)
        new_indices = tuple(new_indices)
        
        self.new_indices = new_indices

        self.positions = self.positions[new_indices, :]
        
        if self.normals is not None:
            self.normals = self.normals[new_indices, :]

        if self.texcoords is not None:
            for idx, texcoord in enumerate(self.texcoords):
                self.texcoords[idx] = texcoord[new_indices, :]

        if self.lighting_texcoords is not None:
            self.lighting_texcoords = self.lighting_texcoords[new_indices, :]

        if self.vertex_colors is not None:
            for idx, vcolor in enumerate(self.vertex_colors):
                self.vertex_colors[idx] = vcolor[new_indices, :]
                
        if self.tension is not None:
            self.tension = self.tension[new_indices, :]

        if self.pca_mask is not None:
            self.pca_mask = self.pca_mask[new_indices, :]

        if self.bone_weights is not None:
            self.bone_weights = self.bone_weights[new_indices, :]
            self.bone_indices = self.bone_indices[new_indices, :]
            
        if self.vertex_ids is not None:
            self.vertex_ids = self.vertex_ids[new_indices, :]
            
        self.num_indices = len(self.indices)
        self.num_vertices = len(self.positions)
        
        # check if this mesh should be structure
        # if not scene.corinth and props.get("bungie_mesh_type") == MeshType.poop.value and not props.get("bungie_face_mode") in (FaceMode.render_only, FaceMode.lightmap_only, FaceMode.shadow_only):
        #     bm = bmesh.new()
        #     bm.from_mesh(mesh)
        #     vol = bm.calc_volume(signed=True)
        #     bm.free()
        #     if vol < 0:
        #         scene.warnings.append("blah")
        #         props["bungie_mesh_type"] = MeshType.default.value
        
        if material_override is not None:
            virtual_mat = scene.materials.get("Invisible")
            if virtual_mat is None:
                virtual_mat = VirtualMaterial('Invisible', scene, material_override)
            self.materials[virtual_mat] = None
            self.groups.append((virtual_mat, 0, (0, num_polygons))) # default material
            
        elif num_materials > 1 and scene.supports_multiple_materials(ob, props, mesh_type_value):
            material_indices = np.empty(num_polygons, dtype=np.int32)
            mesh.polygons.foreach_get("material_index", material_indices)
            sorted_order = np.argsort(material_indices)
            sorted_polygons = self.indices.reshape((-1, 3))[sorted_order]
            self.indices = sorted_polygons.ravel()
            if self.pca_indices is not None:
                sorted_pca_polygons = self.pca_indices.reshape((-1, 3))[sorted_order]
                self.pca_indices = sorted_pca_polygons.ravel()
                
            unique_indices = np.concatenate(([0], np.where(np.diff(material_indices[sorted_order]) != 0)[0] + 1))
            counts = np.diff(np.concatenate((unique_indices, [len(material_indices)])))
            mat_index_counts = list(zip(unique_indices, counts))
            used_materials = [self.bpy_materials[i] for i in np.unique(material_indices) if i < len(self.bpy_materials)]
            unique_materials = list(dict.fromkeys([m for m in used_materials]))
            for idx, mat in enumerate(used_materials):
                virtual_mat = scene._get_material(mat, scene)
                self.materials[virtual_mat] = None
                self.groups.append((virtual_mat, unique_materials.index(mat), mat_index_counts[idx]))
                
        elif num_materials >= 1:
            virtual_mat = scene._get_material(self.bpy_materials[0], scene)
            self.materials[virtual_mat] = None
            self.groups.append((virtual_mat, 0, (0, num_polygons)))
        else:
            virtual_mat = scene.materials["invalid"]
            self.materials[virtual_mat] = None
            self.groups.append((virtual_mat, 0, (0, num_polygons))) # default material
            
        if material_override is not None:
            props.pop("material_override")
            
        force_render_only = False
        if not scene.corinth and mesh_type_value == MeshType.poop.value:
            mask = np.asarray(scene.poop_obs[ob.data])
            if mask.all(): # Checks if all instances of a mesh use the poop_render_only flag, in which case it sets render only at face level
                force_render_only = True
                
        bungie_attributes = [attr for attr in mesh.attributes if attr.domain == 'FACE' and attr.name.lower().startswith("bungie_")]
        
        if (bungie_attributes or force_render_only or ob.data.nwo.face_props or (valid_materials_count > 1 and (special_mats_dict or prop_mats_dict))) and mesh_type_value in FACE_PROP_TYPES:
            self.face_properties = gather_face_props(ob.data.nwo, mesh, num_polygons, scene, sorted_order, special_mats_dict, prop_mats_dict, props, force_render_only, bungie_attributes)
            # if changed_materials:
            #     self.bpy_materials = list(self.bpy_materials)
            #     self.bpy_materials.append(mesh.materials[-1])
            #     self.bpy_materials = tuple(self.bpy_materials)
            #     num_materials = len(self.bpy_materials)
            
            if is_object_instance:
                for prop_name, face_set in self.face_properties.items():
                    new_array = face_set.array.copy()
                    values, counts = np.unique(new_array, return_counts=True)
                    mode = values[counts.argmax()]
                    new_array[...] = mode
                    if not np.array_equal(face_set.array, new_array):
                        scene.warnings.append(f"Object '{ob.name}' has different mesh properties per face, this is not allowed for instanced objects. Forcing {prop_name} to {face_set.array[0]}")
                        face_set.array = new_array
        
        if evaluated:
            eval_ob.to_mesh_clear()
    
class VirtualNode:
    def __init__(self, id: utils.ExportObject | bpy.types.PoseBone, props: dict, region: str = None, permutation: str = None, scene: 'VirtualScene' = None, proxies = [], template_node: 'VirtualNode' = None, bones: list[str] = [], parent_matrix: Matrix = IDENTITY_MATRIX, animation_owner=None):
        self.name: str = "world" if (not isinstance(id, bpy.types.PoseBone) and id.type == 'ARMATURE') else id.name
        self.ob = id
        self.matrix_world: Matrix = IDENTITY_MATRIX
        self.matrix_local: Matrix = IDENTITY_MATRIX
        self.mesh: VirtualMesh | None = None
        self.new_mesh = False
        self.skeleton: VirtualSkeleton = None
        self.region = region
        self.permutation = permutation
        self.props = props
        self.group: str = "default"
        self.tag_type: str = "render"
        self.invalid = False
        self.for_animation = animation_owner is not None
        self._set_group(scene, animation_owner)
        self.parent: VirtualNode = None
        self.bone_bindings: list[str] = []
        self.granny_vertex_data = None
        self.granny_vertex_data_copies = {}
        self.granny_vertex_data_copy_buffers = {}
        self.negative_scaling = False
        self.mod_stack = None
        
        self.for_pca = isinstance(id, utils.ExportObject) and id.for_pca
        
        if not self.invalid and (self.tag_type in scene.export_tag_types or self.for_pca):
            # Skip writing mesh data for non-selected bsps/permutations
            if scene.limit_bsps and region not in scene.selected_bsps: return
            if scene.limit_permutations and permutation not in scene.selected_permutations: return
            self._setup(id, scene, proxies, template_node, bones, parent_matrix)
        
    def _setup(self, id: utils.ExportObject | bpy.types.PoseBone, scene: 'VirtualScene', proxies: list, template_node: 'VirtualNode', bones: list[str], parent_matrix: Matrix):
        if isinstance(id, utils.ExportObject):
            if template_node is None:
                if id.type == 'ARMATURE' and not id.parent:
                    self.matrix_world = IDENTITY_MATRIX
                    self.matrix_local = IDENTITY_MATRIX
                else:
                    if self._should_apply_marker_axis(scene):
                        self.matrix_world = scene.rotation_matrix @ id.matrix_world @ scene.marker_rotation_matrix
                    else:
                        self.matrix_world = scene.rotation_matrix @ id.matrix_world
                        
                    self.matrix_local = parent_matrix @ self.matrix_world
            else:
                self.matrix_world = template_node.matrix_world.copy()
                # self.matrix_local = IDENTITY_MATRIX
                if template_node.negative_scaling:
                    id.invert_topology = not id.invert_topology
                
            if id.type in VALID_MESHES:
                default_bone_bindings = [self.name]
                self.negative_scaling = id.matrix_world.is_negative
                if id.invert_topology:
                    self.negative_scaling = not self.negative_scaling

                materials = tuple(slot.material for slot in id.material_slots)
                bone_parent = ""
                if id.parent_type == 'BONE' and id.parent_bone:
                    bone_parent = id.parent_bone
                
                existing_mesh = scene.meshes.get((id.data, self.negative_scaling, materials))
                existing_linked_mesh = scene.meshes_linked.get(id.data)

                can_reuse_existing_mesh = existing_mesh and not id.modifiers and not bone_parent
                if can_reuse_existing_mesh and (not self.for_pca or existing_mesh.pca_indices is not None):
                    self.mesh = existing_mesh
                    self.mesh.siblings.append(self.name)
                else:
                    vertex_weighted = id.vertex_groups and id.parent and id.parent.type == 'ARMATURE' and has_armature_deform_mod(id)
                    mesh = VirtualMesh(vertex_weighted, scene, default_bone_bindings, id, is_rendered(self.props), proxies if existing_linked_mesh is None else existing_linked_mesh.proxies, self.props, self.negative_scaling, bones, materials)
                    self.mesh = mesh
                    self.new_mesh = True
                    
                self.bone_bindings = self.mesh.bone_bindings
                if self.mesh.vertex_weighted and not (id.parent_type == 'BONE' and id.parent_bone):
                    self.matrix_local = IDENTITY_MATRIX
                    
                if self.mesh.invalid:
                    self.invalid = True
                    return
                    
                self.granny_vertex_data = GrannyVertexData()
                self.granny_vertex_data.vertex_component_names = self.mesh.vertex_component_names
                self.granny_vertex_data.vertex_component_name_count = self.mesh.vertex_component_name_count
                self.granny_vertex_data.vertex_type = self.mesh.vertex_type
                
                if self.matrix_world == IDENTITY_MATRIX:
                    vertex_array = self.mesh.vertex_array
                else:
                    vertex_array = (c_ubyte * self.mesh.len_vertex_array)()
                    memmove(vertex_array, self.mesh.vertex_array, self.mesh.len_vertex_array)
                    affine3, linear3x3, inverse_linear3x3 = calc_transforms(self.matrix_world)
                    scene.granny.transform_vertices(self.mesh.num_vertices,
                                                    self.granny_vertex_data.vertex_type,
                                                    vertex_array,
                                                    affine3,
                                                    linear3x3,
                                                    inverse_linear3x3,
                                                    True,
                                                    False,
                                                    )
                
                if self.for_pca:
                    pca_vertex_component_names = self.mesh.vertex_component_names
                    pca_vertex_component_name_count = self.mesh.vertex_component_name_count
                    pca_vertex_type = self.mesh.vertex_type
                    pca_len_vertex_array = self.mesh.len_vertex_array
                    pca_vertex_count = self.mesh.num_vertices
                    if self.mesh.pca_vertex_array is not None:
                        pca_vertex_component_names = self.mesh.pca_vertex_component_names
                        pca_vertex_component_name_count = self.mesh.pca_vertex_component_name_count
                        pca_vertex_type = self.mesh.pca_vertex_type
                        pca_len_vertex_array = self.mesh.pca_len_vertex_array
                        pca_vertex_count = self.mesh.pca_num_vertices
                        pca_vertex_array = self.mesh.pca_vertex_array
                    else:
                        pca_vertex_array = self.mesh.vertex_array

                    if self.matrix_world == IDENTITY_MATRIX:
                        transformed_pca_vertex_array = pca_vertex_array
                    else:
                        transformed_pca_vertex_array = (c_ubyte * pca_len_vertex_array)()
                        memmove(transformed_pca_vertex_array, pca_vertex_array, pca_len_vertex_array)
                        affine3, linear3x3, inverse_linear3x3 = calc_transforms(self.matrix_world)
                        scene.granny.transform_vertices(
                            pca_vertex_count,
                            pca_vertex_type,
                            transformed_pca_vertex_array,
                            affine3,
                            linear3x3,
                            inverse_linear3x3,
                            True,
                            False,
                        )

                    for animation in id.pca_animations:
                        granny_vertex_data_copy = GrannyVertexData()
                        granny_vertex_data_copy.vertex_component_names = pca_vertex_component_names
                        granny_vertex_data_copy.vertex_component_name_count = pca_vertex_component_name_count
                        granny_vertex_data_copy.vertex_type = pca_vertex_type
                        
                        vertex_array_copy = (c_ubyte * pca_len_vertex_array)()
                        memmove(vertex_array_copy, transformed_pca_vertex_array, pca_len_vertex_array)
                        granny_vertex_data_copy.vertices = cast(vertex_array_copy, POINTER(c_ubyte))
                        granny_vertex_data_copy.vertex_count = pca_vertex_count
                        
                        self.granny_vertex_data_copy_buffers[animation] = (granny_vertex_data_copy, vertex_array_copy)
                        self.granny_vertex_data_copies[animation] = pointer(granny_vertex_data_copy)
                
                self.granny_vertex_data.vertices = cast(vertex_array, POINTER(c_ubyte))
                self.granny_vertex_data.vertex_count = self.mesh.num_vertices
                self.granny_vertex_data = pointer(self.granny_vertex_data)   

    def set_pca_vertex_data_copy(self, animation, scene: 'VirtualScene', morph_target: VirtualMorphTargetData):
        if self.mesh is None or morph_target.invalid:
            return

        if morph_target.num_vertices != self.mesh.num_vertices:
            scene.warnings.append(
                f"PCA animation [{getattr(animation, 'name', '')}] could not use the first frame as the rest mesh for [{self.name}]: "
                f"expected {self.mesh.num_vertices} vertices, got {morph_target.num_vertices}"
            )
            return

        names_array, type_info_array, vertex_array, _, num_types = self.mesh._make_vertex_array(
            scene,
            position_override=morph_target.positions,
            normal_override=morph_target.normals,
            tension_override=morph_target.tension,
        )
        vertex_type = cast(type_info_array, POINTER(GrannyDataTypeDefinition))

        if self.matrix_world != IDENTITY_MATRIX:
            affine3, linear3x3, inverse_linear3x3 = calc_transforms(self.matrix_world)
            scene.granny.transform_vertices(self.mesh.num_vertices,
                                            vertex_type,
                                            vertex_array,
                                            affine3,
                                            linear3x3,
                                            inverse_linear3x3,
                                            True,
                                            False,
                                            )

        granny_vertex_data_copy = GrannyVertexData()
        granny_vertex_data_copy.vertex_component_names = cast(names_array, POINTER(c_char_p))
        granny_vertex_data_copy.vertex_component_name_count = num_types
        granny_vertex_data_copy.vertex_type = vertex_type
        granny_vertex_data_copy.vertices = cast(vertex_array, POINTER(c_ubyte))
        granny_vertex_data_copy.vertex_count = self.mesh.num_vertices
        self.granny_vertex_data_copy_buffers[animation] = (granny_vertex_data_copy, vertex_array, names_array, type_info_array)
        self.granny_vertex_data_copies[animation] = pointer(granny_vertex_data_copy)


    def _should_apply_marker_axis(self, scene: 'VirtualScene') -> bool:
        if not scene.maintain_marker_axis:
            return False
        if self.props.get("bungie_object_type") != ObjectType.marker.value:
            return False

        return True

    def _set_group(self, scene: 'VirtualScene', animation: str | None):
        if animation is None:
            match scene.asset_type:
                case AssetType.MODEL | AssetType.ANIMATION | AssetType.SKY | AssetType.MULTI_MODEL:
                    mesh_type = self.props.get("bungie_mesh_type")
                    if mesh_type:
                        match mesh_type:
                            case MeshType.default.value | MeshType.object_instance.value:
                                self.tag_type = 'render'
                            case MeshType.collision.value:
                                self.tag_type = 'collision'
                            case MeshType.physics.value:
                                self.tag_type = 'physics'
                        
                        self.group = f'{self.tag_type}_{self.permutation}'
                        
                    else:
                        object_type = self.props.get("bungie_object_type")
                        if object_type is None:
                            self.invalid = True
                            scene.warnings.append(f"Object [{self.name}] has no Halo object type")
                            return
                        
                        match object_type:
                            case ObjectType.marker.value:
                                self.tag_type = 'markers'
                            case ObjectType.frame.value:
                                self.tag_type = 'skeleton'
                                
                        self.group = self.tag_type
                
                case AssetType.SCENARIO:
                    mesh_type = self.props.get("bungie_mesh_type")
                    if mesh_type in DESIGN_MESH_TYPES:
                        self.tag_type = 'design'
                        scene.design.add(self.region)
                    elif self.region == 'shared':
                        self.tag_type = 'shared'
                    else:
                        self.tag_type = 'structure'
                        scene.structure.add(self.region)
                        if mesh_type == MeshType.default.value:
                            scene.bsps_with_structure.add(self.region)
                        
                    self.group = f'{self.tag_type}_{self.region}_{self.permutation}'
                    
                case AssetType.PREFAB | AssetType.MULTI_PREFAB:
                    self.tag_type = 'structure'
                    self.group = f'{self.tag_type}_{self.permutation}'
                    
                case _:
                    self.tag_type = 'render'
                    self.group = 'default'
        else:
            self.tag_type = 'animation'
            self.group = animation
                
    
    def props_encoded(self):
        '''Returns a dict of encoded properties'''
        encoded_props = {key: value.encode() for key, value in self.props.items()}
        return encoded_props
    
def granny_transform_parts(matrix_local: Matrix):
    loc = matrix_local.to_translation()
    position = (c_float * 3)(loc[0], loc[1], loc[2])
    quaternion = matrix_local.to_quaternion()
    orientation = (c_float * 4)(quaternion[1], quaternion[2], quaternion[3], quaternion[0])
    scale = matrix_local.to_scale()

    scale_shear = (c_float * 3 * 3)((scale[0], 0.0, 0.0), (0.0, scale[1], 0.0), (0.0, 0.0, scale[2]))
    
    return position, orientation, scale_shear
    
class VirtualBone:
    '''Describes an blender object/bone which is a child'''
    def __init__(self, id: bpy.types.Object | bpy.types.PoseBone, name, is_proxy=False):
        self.name: str = name
        self.bone = id
        self.parent_index: int = -1
        self.node: VirtualNode = None
        self.matrix_local: Matrix = IDENTITY_MATRIX
        self.matrix_world: Matrix = IDENTITY_MATRIX
        self.props = {}
        self.animation_props = {}
        self.physics_subshapes = []
        self.granny_bone = GrannyBone()
        self.is_proxy = is_proxy
        
    def create_bone_props(self, frame_ids):
        self.props["bungie_frame_ID1"] = int(frame_ids[0])
        self.props["bungie_frame_ID2"] = int(frame_ids[1])
        self.props["bungie_object_animates"] = 1
        self.props["bungie_object_type"] = ObjectType.frame.value
        
    def to_granny_data(self, scene: 'VirtualScene'):
        self.granny_bone.name = self.name.encode()
        self.granny_bone.parent_index = self.parent_index
        self.granny_bone.local_transform = GrannyTransform(7, *granny_transform_parts(self.matrix_local))
        self.granny_bone.inverse_world_4x4 = self._granny_world_transform()
        # 24-02-2026 Now creating extended data at granny export (to support animation nodes)
        # if self.props:
        #     scene.granny.create_extended_data(self.props, self.granny_bone)
        
    def _granny_world_transform(self):
        inverse_matrix = self.matrix_world.inverted_safe()
        inverse_transform = (c_float * 4 * 4)((tuple(inverse_matrix.col[0])), (tuple(inverse_matrix.col[1])), (tuple(inverse_matrix.col[2])), (tuple(inverse_matrix.col[3])))
        return inverse_transform
    
class AnimatedBone:
    def __init__(self, ob: utils.ExportObject, pbone, parent_override=None, is_aim_bone=False):
        self.name = pbone.name
        self.ob = ob
        self.parent_matrix_rest_inverted = ob.matrix_world.inverted_safe()
        self.pbone: bpy.types.PoseBone = pbone
        self.parent = None
        self.is_object = False
        self.is_aim_bone = is_aim_bone
        if isinstance(pbone, bpy.types.Object):
            self.is_object = True
        else:
            if parent_override is None:
                self.parent = pbone.parent
            else:
                self.parent = parent_override

class FakeBone:
    __slots__ = ("name", "ob", "parent", "direct_parent", "_pending_parent", "bone", "export", "matrix")

    def __init__(self, ob: bpy.types.Object, bone: bpy.types.PoseBone, special_bone_names=[], parent_ob: bpy.types.Object = None):
        self.name = bone.name
        self.ob = ob
        self.parent: 'FakeBone | None' = None
        self.direct_parent: 'FakeBone | None' = None
        self._pending_parent: 'FakeBone | None' = None
        self.bone = bone
        self.export = ob.data.bones[bone.name].use_deform or self.name in special_bone_names
        self.matrix = bone.matrix
        # if parent_ob is None:
        #     self.matrix = bone.matrix
        # else:
        #     self.matrix = ob.matrix_world @ bone.matrix
        
def sort_bones_by_hierarchy(fake_bones: list[FakeBone]):
    bone_depths = {}

    def get_depth(fake_bone: FakeBone):
        depth = bone_depths.get(fake_bone)
        if depth is not None:
            return depth

        if fake_bone.parent is None:
            depth = 0
        else:
            depth = get_depth(fake_bone.parent) + 1

        bone_depths[fake_bone] = depth
        return depth

    return sorted(fake_bones, key=get_depth)
        
class VirtualSkeleton:
    '''Describes a list of bones'''
    def __init__(self, ob: bpy.types.Object, scene: 'VirtualScene', node: VirtualNode, is_main_armature = False):
        self.name: str = "world" if ob.type == 'ARMATURE' else ob.name
        self.ob = ob
        self.node = node
        self.pbones = {}
        self.animated_bones = []
        own_bone = VirtualBone(ob, self.name)
        own_bone.node = node
        if ob.type == 'ARMATURE':
            scene.armature_matrix = ob.matrix_world.copy()
            own_bone.props = {
                    "bungie_frame_world": 1,
                    "bungie_frame_ID1": 8078,
                    "bungie_frame_ID2": 378163771,
                    "bungie_object_type": ObjectType.frame.value,
                }
        elif own_bone.node and not own_bone.node.mesh:
            own_bone.props = own_bone.node.props
            
        own_bone.matrix_world = own_bone.node.matrix_world
        own_bone.matrix_local = IDENTITY_MATRIX
        
        own_bone.to_granny_data(scene)
        self.bones: list[VirtualBone] = [own_bone]
        self._get_bones(ob, scene, is_main_armature)
        
    def _get_bones(self, ob, scene: 'VirtualScene', is_main_armature: bool):
        if ob.type == 'ARMATURE':
            main_arm = ob
            scene_nwo = scene.scene_nwo
            support_parent_map = {}
            aim_bone_names = {scene_nwo.node_usage_pose_blend_pitch, scene_nwo.node_usage_pose_blend_yaw}
            special_bone_names = {scene_nwo.node_usage_pedestal, scene_nwo.node_usage_pose_blend_pitch, scene_nwo.node_usage_pose_blend_yaw}

            export_bone_names = set()
            root = None

            if is_main_armature:
                export_bones = [
                    b for b in main_arm.data.bones
                    if b.use_deform or b.name in special_bone_names
                ]

                export_bone_names = {b.name for b in export_bones}

                root_bones = [
                    b.name for b in export_bones
                    if b.parent is None or b.parent.name not in export_bone_names
                ]
                if root_bones:
                    root = root_bones[0]

            start_bones_dict = {}
            fbs = []

            def resolve_export_parent(fake_bone: FakeBone):
                parent = fake_bone.direct_parent
                while parent is not None and not parent.export:
                    parent = parent.direct_parent
                return parent

            def resolve_export_parent_from_pose_bone(arm, pose_bone: bpy.types.PoseBone | None):
                current = pose_bone
                while current is not None:
                    parent_fb = start_bones_dict.get((arm, current.name))
                    if parent_fb is None:
                        raise RuntimeError(f"Missing parent bone mapping: {current.name}")
                    if parent_fb.export:
                        return parent_fb
                    current = current.parent
                return None

            def register_armature(arm, parent_arm=None, attach_to_fb=None):
                for pb in arm.pose.bones:
                    fb = FakeBone(arm, pb, special_bone_names, parent_arm)

                    key = (arm, pb.name)
                    start_bones_dict[key] = fb
                    fbs.append(fb)

                    # Only root bones of support armatures get attached
                    if pb.parent is None and attach_to_fb is not None:
                        fb._pending_parent = attach_to_fb
                    else:
                        fb._pending_parent = None

            # Main armature first
            register_armature(main_arm)

            support_parent_map = {}

            if is_main_armature and root:
                for child in scene.support_armatures:
                    parent_pb = None
                    if child.parent_type == 'BONE':
                        parent_pb = main_arm.pose.bones.get(child.parent_bone)

                    if parent_pb is None:
                        parent_pb = main_arm.pose.bones.get(root)

                    if parent_pb is None:
                        continue

                    parent_fb = resolve_export_parent_from_pose_bone(main_arm, parent_pb)
                    if parent_fb is None:
                        raise RuntimeError(
                            f"Could not resolve an exported parent bone for support armature {child.name}"
                        )

                    support_parent_map[child] = parent_fb

            for child, parent_fb in support_parent_map.items():
                register_armature(child, parent_arm=main_arm, attach_to_fb=parent_fb)

            root_fb = None

            for (arm, bone_name), fb in start_bones_dict.items():
                pb = fb.bone

                if pb.parent:
                    parent_key = (arm, pb.parent.name)
                    fb.direct_parent = start_bones_dict.get(parent_key)

                elif fb._pending_parent:
                    fb.direct_parent = fb._pending_parent

                else:
                    fb.direct_parent = None

                fb.parent = resolve_export_parent(fb)

                if fb.parent is None and root_fb is None:
                    root_fb = fb

            # if len(set(fb_names)) != len(fb_names):
            #     error_str = [f"{fb.ob.name} --> {fb.name}" for fb in fbs]
            #     raise RuntimeError(f"Duplicate bone names found. Ensure that all exported armatures have unique bone names. Armature Bones list:\n{error_str}\n")
                
            start_bones = list(start_bones_dict.values())
            
            # Sort bones by hierarchy i.e. all bones in a certain depth level in the child-parent relationship come before the next depth level
            sorted_bones = sort_bones_by_hierarchy(start_bones)
            valid_bones = [fb for fb in sorted_bones if fb.export]

            list_bones = [fb.name for fb in valid_bones]
            dict_bones = {v: i for i, v in enumerate(list_bones)}
            self.pbones = {fb.name: fb.bone for fb in valid_bones}

            root_bone = None
            root_bone_found = False
            bone_inverse_matrices = {}
            rotation_matrix = scene.rotation_matrix
            frame_ids = scene.frame_ids
            frame_ids_len = len(frame_ids)
            actor_node_order = None
            template_node_order = None

            if scene.is_cinematic:
                actor = scene.actors.get(ob)
                if actor and actor.node_order:
                    actor_node_order = actor.node_order
            else:
                template_node_order = scene.template_node_order

            requested_indices = {}
            for idx, fb in enumerate(valid_bones):
                if actor_node_order is not None:
                    requested_index = actor_node_order.get(fb.name)
                elif template_node_order is not None:
                    requested_index = template_node_order.get(fb.name)
                else:
                    requested_index = None

                requested_indices[fb.name] = idx if requested_index is None else requested_index

            used_indices = set()
            max_needed = max(requested_indices.values()) + len(valid_bones)

            free_indices = iter(i for i in range(max_needed))
            
            def allocate_index(preferred):
                if preferred not in used_indices:
                    used_indices.add(preferred)
                    return preferred

                for i in free_indices:
                    if i not in used_indices:
                        used_indices.add(i)
                        return i
            
            for idx, fb in enumerate(valid_bones):
                b = VirtualBone(fb.bone, fb.name)

                preferred = requested_indices[b.name]
                frame_ids_index = allocate_index(preferred)

                if frame_ids_index is None or frame_ids_index >= frame_ids_len:
                    b.create_bone_props([0, 0])
                else:
                    b.create_bone_props(frame_ids[frame_ids_index])
                    
                if fb.parent:
                    # Add one to this since the root is the armature
                    b.parent_index = dict_bones[fb.parent.name] + 1
                    b.matrix_world = rotation_matrix @ fb.matrix
                    bone_inverse_matrices[fb.bone] = b.matrix_world.inverted_safe()
                    b.matrix_local = bone_inverse_matrices[fb.parent.bone] @ b.matrix_world
                else:
                    if root_bone_found:
                        raise RuntimeError(f"Armature {ob.name} has multiple root bones: {[bone.name for bone in valid_bones if not bone.parent]}. Halo requires that models have a single root bone. If one of the root bones is a control bone, ensure the deform checkbox is toggled off")
                    root_bone_found = True
                    root_bone = fb.bone
                    b.parent_index = 0
                    b.matrix_world = rotation_matrix @ fb.matrix
                    b.matrix_local = b.matrix_world
                    bone_inverse_matrices[fb.bone] = b.matrix_world.inverted_safe()
                    scene.root_bone = root_bone
                
                b.to_granny_data(scene)
                self.bones.append(b)
                if is_main_armature or scene.is_cinematic:
                    self.animated_bones.append(AnimatedBone(fb.ob, fb.bone, is_aim_bone=fb.name in aim_bone_names, parent_override=fb.parent.bone if fb.parent else None))
                
            child_index = 0
            for child in scene.get_immediate_children(ob):
                bone_parented = child.parent_type == 'BONE' and child.parent_bone
                parent_matrix = IDENTITY_MATRIX
                parent_index = 0
                if bone_parented:
                    bone_index = dict_bones.get(child.parent_bone)
                    if bone_index is None:
                        scene.warnings.append(f"{child.name} is parented to non-existent or non-deform bone: {child.parent_bone}. Parenting to {list_bones[0]}")
                        bone_index = 0
                    parent_bone = valid_bones[bone_index]
                    parent_index = bone_index + 1
                    parent_matrix = bone_inverse_matrices[parent_bone.bone]

                node = scene.add(child, *scene.object_halo_data[child], bones=list_bones, parent_matrix=parent_matrix)
                if not node: continue
                child_index += 1
                if not node or node.invalid: continue
                if not bone_parented and not (node.mesh and node.mesh.vertex_weighted):
                    parent_index = 1
                    
                b = VirtualBone(child, node.name)
                b.node = node
                if child.type != 'MESH':
                    b.props = b.node.props
                b.matrix_world = node.matrix_world
                b.matrix_local = node.matrix_local
                b.parent_index = parent_index

                b.to_granny_data(scene)
                self.bones.append(b)
                self.find_children(child, scene, child_index)
                    
        else:
            self.find_children(ob, scene)
                    
    def find_children(self, ob: bpy.types.Object, scene: 'VirtualScene', parent_index=0):
        child_index = parent_index
        for child in scene.get_immediate_children(ob):
            parent_node = scene.nodes.get(ob)
            if parent_node is None:
                continue
            node = scene.add(child, *scene.object_halo_data[child], parent_matrix=parent_node.matrix_world.inverted_safe())
            if not node or node.invalid: continue
            child_index += 1
            b = VirtualBone(child, node.name)
            b.parent_index = parent_index
            b.node = node
            if child.type != 'MESH':
                b.props = b.node.props
            b.matrix_world = node.matrix_world
            b.matrix_local = node.matrix_local
            b.to_granny_data(scene)
            self.bones.append(b)
            self.find_children(child, scene, child_index)
            
        if self.node.mesh:
            for proxy in self.node.mesh.proxies:
                node = scene.add(proxy, *scene.object_halo_data[proxy], self.node)
                if not node or node.invalid: continue
                b = VirtualBone(proxy, node.name, True)
                b.parent_index = parent_index
                b.node = node
                b.matrix_world = b.node.matrix_world
                b.matrix_local = b.node.matrix_local
                b.to_granny_data(scene)
                self.bones.append(b)
                
    def append_animation_control(self, ob: bpy.types.Object, node: VirtualNode, scene: 'VirtualScene', parent_index=1):
        b = VirtualBone(ob, node.name)
        b.parent_index = parent_index
        b.node = node
        b.matrix_world = b.node.matrix_world
        b.matrix_local = b.node.matrix_local
        b.props = node.props
        b.to_granny_data(scene)
        self.bones.append(b)
    
class VirtualModel:
    '''Describes a blender object which has no parent'''
    def __init__(self, ob: bpy.types.Object, scene: 'VirtualScene', props=None, region=None, permutation=None, animation_owner=None):
        self.name: str = "world" if ob.type == 'ARMATURE' else ob.name
        self.ob = ob
        self.node = None
        self.skeleton = None
        is_main_armature = False
        if props is None:
            node = scene.add(ob, *scene.object_halo_data[ob])
        else:
            node = scene.add(ob, props, region, permutation, animation_owner=animation_owner)
        if node and not node.invalid:
            self.node = node
            if ob.type == 'ARMATURE' and scene.has_main_skeleton:
                if not scene.skeleton_node or scene.scene_nwo.main_armature == ob:
                    scene.skeleton_node = self.node
                    scene.skeleton_model = self
                    scene.skeleton_object = ob
                    is_main_armature = True

            self.skeleton: VirtualSkeleton = VirtualSkeleton(ob, scene, self.node, is_main_armature)
            self.matrix: Matrix = ob.matrix_world.copy()
            
class VirtualScene:
    def __init__(self, asset_type: AssetType, depsgraph: bpy.types.Depsgraph, corinth: bool, tags_dir: Path, granny: Granny, export_settings, time_step: float, animation_compression: str, rotation: float, maintain_marker_axis: bool, granny_textures: bool, project, light_scale: float, unit_factor: float, atten_scalar: int, context: bpy.types.Context, halo_transform_scale: float = None, scene_nwo=None):
        self.nodes: dict[VirtualNode] = {}
        self.meshes: dict[VirtualMesh] = {}
        self.meshes_linked: dict[VirtualMesh] = {}
        self.materials: dict[VirtualMaterial] = {}
        self.models: dict[VirtualModel] = {}
        self.root: VirtualNode = None
        self.uses_textures = granny_textures
        self.quad_method = export_settings.triangulate_quad_method
        self.ngon_method = export_settings.triangulate_ngon_method
        self.asset_type = asset_type
        self.depsgraph = depsgraph
        self.tags_dir = tags_dir
        self.granny = granny
        self.regions: dict = {}
        self.regions_set = set()
        self.permutations: list = []
        self.global_materials: dict = {}
        self.global_materials_set = set()
        self.skeleton_node: VirtualNode = None
        self.skeleton_model: VirtualModel = None
        self.skeleton_object: bpy.types.Object
        self.time_step = time_step
        # self.time_step = 1.0010000467300415 / 30
        self.corinth = corinth
        self.export_info: ExportInfo = None
        self.valid_bones = []
        self.frame_ids = read_frame_id_list()
        self.structure = set()
        self.design = set()
        self.bsps_with_structure = set()
        self.warnings = []
        self.animations = []
        self.composite_blend_axis_values = {}
        self.shots = []
        self.default_animation_compression = animation_compression
        
        self.object_parent_dict: dict[bpy.types.Object: bpy.types.Object] = {}
        self.object_halo_data: dict[bpy.types.Object: tuple[dict, str, str, list]] = {}
        self.mesh_object_map: dict[tuple[bpy.types.Mesh, bool]: list[bpy.types.Object]] = {}
        
        self.material_extended_data_type = self._create_material_extended_data_type()
        self.correction_matrix = IDENTITY_MATRIX
        self.root_bone = None
        self.aim_pitch = None
        self.aim_yaw = None
        self.root_bone_inverse_matrix = IDENTITY_MATRIX
        self.aim_pitch_matrix_inverse = IDENTITY_MATRIX
        self.aim_yaw_matrix_inverse = IDENTITY_MATRIX

        self.rotation_matrix = Matrix.Rotation(rotation, 4, Vector((0, 0, 1)))
        self.halo_rotation = rotation
        self.halo_transform_scale = halo_transform_scale
        self.marker_rotation_matrix = Matrix.Rotation(-rotation, 4, 'Z')
        self.maintain_marker_axis = maintain_marker_axis
        self.armature_matrix = IDENTITY_MATRIX
        
        self.export_tag_types = set()
        self.support_armatures = []
        
        self.light_scale = light_scale
        self.unit_factor = unit_factor
        self.atten_scalar = atten_scalar
        
        self.selected_bsps = set()
        self.selected_permutations = set()
        self.limit_bsps = False
        self.limit_permutations = False
        
        self.context = context
        self.scene_nwo = scene_nwo or utils.get_scene_props()
        self.actors = []
        self.selected_actors = set()
        self.selected_cinematic_objects_only = False
        self.cinematic_scope = 'BOTH'
        
        self.poop_obs = {}
        self.no_structure_export = not export_settings.export_structure
        
        self.morph_vertex_data = defaultdict(list)
        
        spath = "shaders\\invalid"
        stype = "material" if corinth else "shader"
        if project and project.default_material:
            relative_default_shader = utils.relative_path(project.default_material)
            if Path(tags_dir, relative_default_shader).exists():
                spath, _, stype = relative_default_shader.rpartition('.')
        
        self.default_shader_path = spath
        self.default_shader_type = stype
        
        # Create default material
        default_material = VirtualMaterial("invalid", self, f"{self.default_shader_path}.{self.default_shader_type}")
            
        self.materials["invalid"] = default_material

        self.template_node_order = {}
        
        self.has_main_skeleton = asset_type in {AssetType.MODEL, AssetType.SKY, AssetType.ANIMATION, AssetType.SINGLE_ANIMATION}
        self.is_cinematic = asset_type == AssetType.CINEMATIC
        
        self.disable_automatic_suspension_computation = export_settings.disable_automatic_suspension_computation
        
    def _create_material_extended_data_type(self):
        material_extended_data_type = (GrannyDataTypeDefinition * 3)(
            GrannyDataTypeDefinition(member_type=GrannyMemberType.granny_string_member, name=b"bungie_shader_path"),
            GrannyDataTypeDefinition(member_type=GrannyMemberType.granny_string_member, name=b"bungie_shader_type"),
            GrannyDataTypeDefinition(GrannyMemberType.granny_end_member.value)
        )
        
        return material_extended_data_type
    
    def _create_curve_data_type(self):
        pass
        
    def add(self, id: bpy.types.Object, props: dict, region: str = None, permutation: str = None, proxies: list = [], template_node: VirtualNode = None, bones: list[str] = [], parent_matrix: Matrix = IDENTITY_MATRIX, animation_owner=None) -> VirtualNode:
        '''Creates a new node with the given parameters and appends it to the virtual scene'''
        node = VirtualNode(id, props, region, permutation, self, proxies, template_node, bones, parent_matrix, animation_owner)
        if not node.invalid:
            self.nodes[node.ob] = node
            if node.new_mesh:
                # This is a tuple containing whether the object has a negative scale. This because we need to create separate mesh data for negatively scaled objects
                negative_scaling = id.matrix_world.is_negative
                if id.invert_topology:
                    negative_scaling = not negative_scaling
                self.meshes[(node.mesh.mesh, negative_scaling, node.mesh.bpy_materials)] = node.mesh
                self.meshes_linked[node.mesh.mesh] = node.mesh
            
        return node
            
    def get_immediate_children(self, parent):
        children = [ob for ob, ob_parent in self.object_parent_dict.items() if ob_parent == parent]
        return children
        
    def add_model(self, ob):
        model = VirtualModel(ob, self)
        if model.node:
            self.models[ob] = model
            
    def add_model_for_animation(self, ob, props, animation_owner):
        model = VirtualModel(ob, self, props=props, animation_owner=animation_owner)
        if model.node:
            self.models[ob] = model
            return model.node

    def _raw_object(self, export_id):
        if isinstance(export_id, utils.ExportObject):
            return export_id.ob
        return export_id

    def _export_matrix_world(self, node: VirtualNode) -> Matrix:
        export_id = node.ob
        if isinstance(export_id, utils.ExportObject):
            if export_id.type == 'ARMATURE' and not export_id.parent:
                return IDENTITY_MATRIX.copy()
            matrix_world = export_id.matrix_world
        else:
            matrix_world = export_id.matrix_world

        if (
            self.maintain_marker_axis
            and node.props.get("bungie_object_type") == ObjectType.marker.value
            and getattr(export_id, "parent", None) is None
        ):
            return self.rotation_matrix @ matrix_world @ self.marker_rotation_matrix

        return self.rotation_matrix @ matrix_world

    def _find_virtual_bone(self, bone_name: str) -> VirtualBone | None:
        for model in self.models.values():
            skeleton = model.skeleton
            if skeleton is None:
                continue

            for bone in skeleton.bones:
                if bone.name == bone_name:
                    return bone

        return None

    def _physics_distance_scale(self):
        return self.light_scale / 10 if self.corinth else self.light_scale

    def _constraint_space_props(self, matrix: Matrix, prefix: str) -> dict:
        translation = matrix.to_translation() * self._physics_distance_scale()
        havok_rotation = matrix.to_3x3().normalized() @ HAVOK_MAYA_COORDINATE_MATRIX_INV

        y_rotation = asin(min(1.0, max(-1.0, -havok_rotation[0][1])))
        if abs(abs(havok_rotation[0][1]) - 1.0) < 1e-6:
            x_rotation = atan2(-havok_rotation[2][0], havok_rotation[2][2])
            z_rotation = 0.0
        else:
            x_rotation = atan2(havok_rotation[0][2], havok_rotation[0][0])
            z_rotation = atan2(havok_rotation[2][1], havok_rotation[1][1])

        return {
            f"{prefix}TranslationX": translation.y,
            f"{prefix}TranslationY": translation.z,
            f"{prefix}TranslationZ": translation.x,
            f"{prefix}RotationX": x_rotation,
            f"{prefix}RotationY": y_rotation,
            f"{prefix}RotationZ": z_rotation,
        }

    def _corinth_shape_type(self, node: VirtualNode):
        primitive_type = node.props.get("bungie_mesh_primitive_type", "_connected_geometry_primitive_type_none")
        return {
            "_connected_geometry_primitive_type_box": 2,
            "_connected_geometry_primitive_type_sphere": 3,
            "_connected_geometry_primitive_type_pill": 5,
            "_connected_geometry_primitive_type_mopp": 6,
        }.get(primitive_type, 4)

    def _build_corinth_body_subshapes(self, node: VirtualNode) -> list[dict]:
        nwo = node.ob.nwo
        body_props = {
            "typeName": "hkNodeRigidBody",
            "changeMass": int(nwo.havok_change_mass),
            "mass": nwo.havok_mass,
            "changeCenterOfMass": int(nwo.havok_change_center_of_mass),
            "centerOfMassX": nwo.havok_center_of_mass.x * WU_SCALAR,
            "centerOfMassY": nwo.havok_center_of_mass.y * WU_SCALAR,
            "centerOfMassZ": nwo.havok_center_of_mass.z * WU_SCALAR,
            "changeInertiaTensor": int(nwo.havok_change_inertia_tensor),
            "inertiaTensorX": nwo.havok_inertia_tensor.x,
            "inertiaTensorY": nwo.havok_inertia_tensor.y,
            "inertiaTensorZ": nwo.havok_inertia_tensor.z,
            "scaleInertiaTensor": int(nwo.havok_scale_inertia_tensor),
            "inertiaTensorScale": nwo.havok_inertia_tensor_scale,
            "friction": nwo.havok_friction,
            "restitution": nwo.havok_restitution,
            "changeLinearDamping": int(nwo.havok_change_linear_damping),
            "linearDamping": nwo.havok_linear_damping,
            "changeAngularDamping": int(nwo.havok_change_angular_damping),
            "angularDamping": nwo.havok_angular_damping,
        }

        return [
            {
                "typeName": "hkNodeShape",
                "shapeType": self._corinth_shape_type(node),
            },
            body_props,
        ]

    def _build_corinth_physics_body_records(self):
        bodies_by_binding = {}
        bodies_by_raw_object = defaultdict(list)
        bodies_by_parent_bone = {}

        for node in self.nodes.values():
            if node.tag_type != 'physics':
                continue
            if node.props.get("bungie_object_type") != ObjectType.mesh.value:
                continue
            if node.props.get("bungie_mesh_type") != MeshType.physics.value:
                continue
            if node.ob.nwo.rigid_body_type != 'HAVOK':
                continue

            raw_object = self._raw_object(node.ob)
            if not node.bone_bindings:
                self.warnings.append(f"Physics object [{raw_object.name}] has no bone bindings. Skipping rigid body export")
                continue

            binding_name = node.bone_bindings[0]
            binding_bone = self._find_virtual_bone(binding_name)
            if binding_bone is None:
                self.warnings.append(f"Physics object [{raw_object.name}] is bound to [{binding_name}], but that bone was not found in the export skeleton")
                continue

            existing = bodies_by_binding.get(binding_name)
            if existing is not None and existing["raw_object"] != raw_object:
                self.warnings.append(
                    f"Physics objects [{existing['raw_object'].name}] and [{raw_object.name}] both resolve to bone [{binding_name}]. "
                    "Rigid-body export only supports one physics body per bound bone"
                )
                continue

            body_info = {
                "binding_name": binding_name,
                "binding_bone": binding_bone,
                "node": node,
                "raw_object": raw_object,
                "parent_bone_name": raw_object.parent_bone.strip() if raw_object.parent_type == 'BONE' and raw_object.parent_bone else "",
            }
            bodies_by_binding[binding_name] = body_info
            bodies_by_raw_object[raw_object].append(body_info)

            parent_bone_name = body_info["parent_bone_name"]
            if parent_bone_name:
                existing = bodies_by_parent_bone.get(parent_bone_name)
                if existing is not None and existing["raw_object"] != raw_object:
                    self.warnings.append(
                        f"Physics objects [{existing['raw_object'].name}] and [{raw_object.name}] are both parented to bone [{parent_bone_name}]. "
                        "Rigid-body export only supports one physics body per source armature bone"
                    )
                else:
                    bodies_by_parent_bone[parent_bone_name] = body_info

        return bodies_by_binding, bodies_by_raw_object, bodies_by_parent_bone

    def _resolve_constraint_body(self, marker_node: VirtualNode, target, target_bone_name: str, bodies_by_binding: dict, bodies_by_raw_object: dict, bodies_by_parent_bone: dict, label: str):
        marker_name = self._raw_object(marker_node.ob).name
        if target is None:
            return None

        if target.type == 'ARMATURE':
            binding_name = target_bone_name.strip()
            if not binding_name:
                self.warnings.append(f"Physics constraint [{marker_name}] has no {label} bone selected")
                return None

            body_info = bodies_by_binding.get(binding_name) or bodies_by_parent_bone.get(binding_name)
            if body_info is None:
                self.warnings.append(f"Physics constraint [{marker_name}] targets bone [{binding_name}] as its {label}, but no exported Corinth physics body is bound to it")
            return body_info

        candidates = bodies_by_raw_object.get(target, [])
        if len(candidates) == 1:
            return candidates[0]

        if len(candidates) > 1:
            matching = [
                info for info in candidates
                if info["node"].region == marker_node.region and info["node"].permutation == marker_node.permutation
            ]
            if len(matching) == 1:
                return matching[0]

            self.warnings.append(f"Physics constraint [{marker_name}] resolves to multiple Corinth physics bodies for [{target.name}]. Leaving it on the legacy marker pipeline")
            return None

        binding_name = target.parent_bone.strip()
        if binding_name:
            body_info = bodies_by_binding.get(binding_name) or bodies_by_parent_bone.get(binding_name)
            if body_info is not None:
                return body_info

        self.warnings.append(f"Physics constraint [{marker_name}] targets [{target.name}] as its {label}, but that object is not part of the exported Corinth physics set")
        return None

    def _build_corinth_constraint_subshape(self, raw_marker: bpy.types.Object, child_space: Matrix, parent_space: Matrix, parent_binding_name: str):
        nwo = raw_marker.nwo
        props = {
            "constraint_parent": parent_binding_name,
            "parentSpaceTranslationLocked": 0,
            "parentSpaceRotationLocked": 0,
            "maxFrictionTorque": 0.0,
        }
        props.update(self._constraint_space_props(child_space, "childSpace"))
        props.update(self._constraint_space_props(parent_space, "parentSpace"))
        
        if nwo.rigid_body_type != 'HAVOK':
            constraint_type = 'hkNodeHingeConstraint' if nwo.physics_constraint_type == "_connected_geometry_marker_type_physics_hinge_constraint" else 'hkNodeRagDollConstraint'
        else:
            constraint_type = nwo.havok_constraint_type

        props["typeName"] = constraint_type
        match constraint_type:
            case 'hkNodeHingeConstraint':
                props["isLimited"] = int(nwo.physics_constraint_uses_limits)
                if nwo.physics_constraint_uses_limits:
                    props["limitMin"] = nwo.hinge_constraint_minimum
                    props["limitMax"] = nwo.hinge_constraint_maximum
                else:
                    props["limitMin"] = -pi
                    props["limitMax"] = pi
            case 'hkNodeRagDollConstraint':
                if nwo.physics_constraint_uses_limits:
                    props["twistMin"] = nwo.twist_constraint_start
                    props["twistMax"] = nwo.twist_constraint_end
                    props["planeAngleMin"] = nwo.plane_constraint_minimum
                    props["planeAngleMax"] = nwo.plane_constraint_maximum
                    props["coneAngle"] = nwo.cone_angle
                else:
                    props["twistMin"] = -pi
                    props["twistMax"] = pi
                    props["planeAngleMin"] = -(pi / 2)
                    props["planeAngleMax"] = pi / 2
                    props["coneAngle"] = pi
            case 'hkNodeBallAndSocketConstraint':
                props["changeRestLength"] = int(nwo.point_change_rest_length)
                props["restLength"] = nwo.point_rest_length
            case 'hkNodeStiffSpringConstraint':
                props["changeRestLength"] = 1
                props["restLength"] = nwo.point_rest_length
            case 'hkNodePrismaticConstraint':
                props["changeMinLinearLimit"] = int(nwo.prismatic_change_min)
                props["changeMaxLinearLimit"] = int(nwo.prismatic_change_max)
                props["minLinearLimit"] = nwo.prismatic_limit_min
                props["maxLinearLimit"] = nwo.prismatic_limit_max
                props["maxFrictionTorque"] = nwo.prismatic_limit_friction

        return props

    def _select_constraint_owner(self, raw_marker: bpy.types.Object, child_info, parent_info, bodies_by_binding: dict, bodies_by_parent_bone: dict):
        owner_info = child_info
        reference_info = parent_info

        marker_parent_bone = raw_marker.parent_bone.strip() if raw_marker.parent_type == 'BONE' and raw_marker.parent_bone else ""
        if not marker_parent_bone:
            return owner_info, reference_info

        marker_owner = bodies_by_binding.get(marker_parent_bone) or bodies_by_parent_bone.get(marker_parent_bone)
        if marker_owner is None:
            return owner_info, reference_info

        if marker_owner is parent_info:
            return parent_info, child_info

        if marker_owner is child_info:
            return child_info, parent_info

        return owner_info, reference_info

    def build_corinth_physics_subshapes(self):
        if not self.corinth or 'physics' not in self.export_tag_types:
            return

        bodies_by_binding, bodies_by_raw_object, bodies_by_parent_bone = self._build_corinth_physics_body_records()
        if not bodies_by_binding:
            return

        for body_info in bodies_by_binding.values():
            binding_bone = body_info["binding_bone"]
            binding_bone.physics_subshapes.clear()
            binding_bone.physics_subshapes.extend(self._build_corinth_body_subshapes(body_info["node"]))

        converted_constraint_keys = []
        for node_key, node in list(self.nodes.items()):
            if node.props.get("bungie_object_type") != ObjectType.marker.value:
                continue
            if node.props.get("bungie_marker_type") not in LEGACY_CONSTRAINT_MARKER_TYPES:
                continue

            raw_marker = self._raw_object(node.ob)
            marker_matrix = self._export_matrix_world(node)

            child_info = self._resolve_constraint_body(
                node,
                raw_marker.nwo.physics_constraint_child,
                raw_marker.nwo.physics_constraint_child_bone,
                bodies_by_binding,
                bodies_by_raw_object,
                bodies_by_parent_bone,
                "child",
            )
            if child_info is None:
                continue

            target_parent_info = None
            if raw_marker.nwo.physics_constraint_parent is not None:
                target_parent_info = self._resolve_constraint_body(
                    node,
                    raw_marker.nwo.physics_constraint_parent,
                    raw_marker.nwo.physics_constraint_parent_bone,
                    bodies_by_binding,
                    bodies_by_raw_object,
                    bodies_by_parent_bone,
                    "parent",
                )
                if target_parent_info is None:
                    continue

            owner_info, reference_info = self._select_constraint_owner(
                raw_marker,
                child_info,
                target_parent_info,
                bodies_by_binding,
                bodies_by_parent_bone,
            )

            child_space = owner_info["binding_bone"].matrix_world.inverted_safe() @ marker_matrix
            if reference_info is None:
                parent_space = marker_matrix.copy()
                parent_binding_name = ""
            else:
                parent_space = reference_info["binding_bone"].matrix_world.inverted_safe() @ marker_matrix
                parent_binding_name = reference_info["binding_name"]

            owner_info["binding_bone"].physics_subshapes.append(
                self._build_corinth_constraint_subshape(raw_marker, child_space, parent_space, parent_binding_name)
            )
            converted_constraint_keys.append(node_key)

        for node_key in converted_constraint_keys:
            self.nodes.pop(node_key, None)
            
    def add_animation(self, anim, sample=True, controls=[], shape_key_objects=[], vector_events=[]):
        animation = VirtualAnimation(anim, self, sample, controls, shape_key_objects, vector_events)
        self.animations.append(animation)
        return animation.name

    def add_composite_blend_axis_values(self, animation_name: str, values: dict[str, float]):
        for name in (animation_name, animation_name.replace(":", " "), animation_name.replace(" ", ":")):
            key = name.strip().lower()
            if key:
                self.composite_blend_axis_values[key] = values
    
    def add_shot(self, frame_start: int, frame_end: int, actors: list[bpy.types.Object], camera: bpy.types.Object, index: int, in_scope: bool, film_aperture: float):
        shot = VirtualShot(frame_start, frame_end, actors, camera, index, self, in_scope=in_scope)
        shot.perform(self, film_aperture)
        self.shots.append(shot)
        
    def _get_material(self, material: bpy.types.Material, scene: 'VirtualScene'):
        if material is None:
            return scene.materials['invalid']
        virtual_mat = self.materials.get(material.name)
        if virtual_mat: return virtual_mat
        mat_name = material.name
        if mat_name[0] == "+":
            virtual_mat = VirtualMaterial(material.name, scene)
        else:
            shader_path = material.nwo.shader_path
            if not shader_path.strip():
                virtual_mat = VirtualMaterial(material.name, scene, "")
            else:
                relative = utils.relative_path(shader_path)
                virtual_mat = VirtualMaterial(material.name, scene, relative)
                
        self.materials[virtual_mat.name] = virtual_mat
        return virtual_mat
        
    def add_automatic_structure(self, default_region, default_permutation, scalar):
        obs = set()
        def wrap_bounding_box(nodes, padding):
            min_x, min_y, min_z, max_x, max_y, max_z = (i * scalar for i in (-10, -10, 0, 10, 10, 30))
            for node in nodes:
                # inverse the rotation matrix otherwise this will be rotated incorrectly
                if node.ob.type == 'MESH':
                    bbox = node.ob.ob.bound_box
                    for co in bbox:
                        bounds = self.rotation_matrix.inverted_safe() @ node.matrix_world @ Vector((co[0], co[1], co[2]))
                        min_x = min(min_x, bounds.x - padding)
                        min_y = min(min_y, bounds.y - padding)
                        min_z = min(min_z, bounds.z - padding)
                        max_x = max(max_x, bounds.x + padding)
                        max_y = max(max_y, bounds.y + padding)
                        max_z = max(max_z, bounds.z + padding)
                else:
                    bounds = self.rotation_matrix.inverted_safe() @ node.matrix_world.to_translation()
                    min_x = min(min_x, bounds.x - padding)
                    min_y = min(min_y, bounds.y - padding)
                    min_z = min(min_z, bounds.z - padding)
                    max_x = max(max_x, bounds.x + padding)
                    max_y = max(max_y, bounds.y + padding)
                    max_z = max(max_z, bounds.z + padding)
        
            # Create the box with bmesh
            bm = bmesh.new()
            xyz = bm.verts.new(Vector((min_x, min_y, min_z)))
            xyz = bm.verts.new(Vector((min_x, min_y, min_z)))
            xYz = bm.verts.new(Vector((min_x, max_y, min_z)))
            xYZ = bm.verts.new(Vector((min_x, max_y, max_z)))
            xyZ = bm.verts.new(Vector((min_x, min_y, max_z)))
            
            Xyz = bm.verts.new(Vector((max_x, min_y, min_z)))
            XYz = bm.verts.new(Vector((max_x, max_y, min_z)))
            XYZ = bm.verts.new(Vector((max_x, max_y, max_z)))
            XyZ = bm.verts.new(Vector((max_x, min_y, max_z)))
            
            bm.faces.new([xyz, xYz, xYZ, xyZ]) # Create the minimum x face
            bm.faces.new([Xyz, XYz, XYZ, XyZ]) # Create the maximum x face
            
            bm.faces.new([xyz, Xyz, XyZ, xyZ]) # Create the minimum y face
            bm.faces.new([xYz, xYZ, XYZ, XYz]) # Create the maximum y face
            
            bottom_face = bm.faces.new([xyz, xYz, XYz, Xyz]) # Create the minimum z face
            bm.faces.new([xyZ, xYZ, XYZ, XyZ]) # Create the maximum z face
            
            bottom_face.material_index = 1
            
            # Calculate consistent faces
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
            # Flip em since bmesh by default calculates outside normals
            bmesh.ops.reverse_faces(bm, faces=bm.faces)
            bmesh.ops.triangulate(bm, faces=bm.faces, quad_method='FIXED')

            props = {}
            props["bungie_object_type"] = ObjectType.mesh.value
            props["bungie_mesh_type"] = MeshType.default.value
            
            # Create the mesh and object
            structure_mesh = bpy.data.meshes.new('autogenerated_structure')
            if self.corinth:
                props["bungie_face_type"] = FaceType.sky.value
            else:
                sky = bpy.data.materials.get("+sky")
                if sky is None:
                    sky = bpy.data.materials.new("+sky")
                    
                invisible = bpy.data.materials.get("Invisible")
                if invisible is None:
                    invisible = bpy.data.materials.new("Invisible")
                    invisible.nwo.shader_path = r'objects\levels\shared\shaders\invisible.shader'
                    
                structure_mesh.materials.append(sky)
                structure_mesh.materials.append(invisible)
                
            bm.to_mesh(structure_mesh)
            real_structure_ob = bpy.data.objects.new(structure_mesh.name, structure_mesh)
            structure_ob = utils.ExportObject()
            structure_ob.name = 'autogenerated_structure'
            structure_ob.data = structure_mesh
            structure_ob.matrix_world = Matrix.Identity(4)
            structure_ob.ob = real_structure_ob
            structure_ob.eval_ob = real_structure_ob.evaluated_get(self.depsgraph)
            structure_ob.material_slots = real_structure_ob.material_slots
            structure_ob.type = 'MESH'
            structure_ob.nwo = real_structure_ob.nwo
            
            return structure_ob, props
        
        if not self.structure:
            self.structure.add(default_region)

        if self.no_structure_export or self.structure == self.bsps_with_structure:
            return obs
        no_bsp_structure = self.structure.difference(self.bsps_with_structure)
        print(f"--- Adding Structure Geometry For BSPs: {[bsp for bsp in no_bsp_structure]}")
        
        for bsp in no_bsp_structure:
            ob, props = wrap_bounding_box([node for node in self.nodes.values() if node.region == bsp], 0 if self.corinth else 1 * scalar)
            obs.add(ob.ob)
            self.models[ob] = VirtualModel(ob, self, props, bsp, default_permutation)
            
        return obs

    def supports_multiple_materials(self, ob: bpy.types.Object, props: dict, mesh_type: int) -> bool:
        if mesh_type in {
            MeshType.default.value,
            MeshType.poop.value,
            MeshType.poop_collision.value,
            MeshType.poop_physics.value,
            MeshType.water_surface.value,
        }:
            return True
        
        if mesh_type == MeshType.object_instance.value:
            self.warnings.append(f"'{ob.name}' has more than one material. Instanced Objects only support a single material. Ignoring materials after {ob.data.materials[0].name}")

        return False
    
    # def __del__(self):
    #     for animation in self.animations:
    #         del animation

    #     for node in self.nodes.values():
    #         del node

    #     for mesh in self.meshes.values():
    #         del mesh

    #     for material in self.materials.values():
    #         del material

    #     for model in self.models:
    #         del model
                
def has_armature_deform_mod(ob: utils.ExportObject):
    for mod in ob.ob.modifiers:
        if mod.type == 'ARMATURE' and mod.object and mod.use_vertex_groups:
            return True
            
    return False

class FaceSet:
    __slots__ = ("array", "annotation_type")
    _material_index_cache: dict[tuple[int, int], np.ndarray] = {}
    _attribute_mask_cache: dict[tuple[int, int, str], np.ndarray] = {}

    def __init__(self, array: np.ndarray):
        self.array = array
        self.annotation_type = None
        self._set_tri_annotation_type()
        
    def update(self, mesh: bpy.types.Mesh, prop, value: object, additive=False):
        attribute_name = prop.attribute_name
        if not attribute_name:
            return

        cache_key = (mesh.as_pointer(), len(mesh.polygons), attribute_name)
        mask = self._attribute_mask_cache.get(cache_key)
        if mask is None:
            attribute = mesh.attributes.get(attribute_name)
            if attribute is None:
                return

            values_array = np.zeros(len(mesh.polygons), dtype=np.int8)
            attribute.data.foreach_get("value", values_array)
            mask = values_array.astype(bool)
            self._attribute_mask_cache[cache_key] = mask

        if additive:
            self.array[mask] += value
        else:
            self.array[mask] = value
             
    def update_from_material(self, mesh: bpy.types.Mesh, material_indices: set[int], value: object, additive=False):
        cache_key = (mesh.as_pointer(), len(mesh.polygons))
        values_array = self._material_index_cache.get(cache_key)
        if values_array is None:
            values_array = np.empty(len(mesh.polygons), dtype=np.int32)
            mesh.polygons.foreach_get("material_index", values_array)
            self._material_index_cache[cache_key] = values_array

        mask = np.isin(values_array, material_indices)
        if additive:
            self.array[mask] += value
        else:
            self.array[mask] = value
            
    def _set_tri_annotation_type(self):
        annotation_type = []
        if len(self.array.shape) == 1:
            size = 1
        else:
            size = self.array.shape[1]
        match self.array.dtype:
            case np.single:
                annotation_type.append(GrannyDataTypeDefinition(GrannyMemberType.granny_real32_member.value, b"Real32", None, size))
            case np.int32:
                annotation_type.append(GrannyDataTypeDefinition(GrannyMemberType.granny_int32_member.value, b"Int32", None, size))
            case np.byte:
                annotation_type.append(GrannyDataTypeDefinition(GrannyMemberType.granny_string_member.value, b"Char", None, size))
            # case np.uint8:
            #     annotation_type.append(GrannyDataTypeDefinition(GrannyMemberType.granny_uint8_member.value, b"Uint8", None, size))
            case _:
                raise(f"Unimplemented numpy data type: {self.array.dtype}")
            
        annotation_type.append(GrannyDataTypeDefinition(0, None, None, 0))
        
        type_info_array = (GrannyDataTypeDefinition * 2)(*annotation_type)
        self.annotation_type = cast(type_info_array, POINTER(GrannyDataTypeDefinition))
            

def gather_face_props(mesh_props: NWO_MeshPropertiesGroup, mesh: bpy.types.Mesh, num_faces: int, scene: VirtualScene, sorted_order, special_mats_dict: dict, prop_mats_dict: dict, props: dict, force_render_only: bool, bungie_attributes: list[bpy.types.Attribute]) -> dict:
    is_structure = props.get("bungie_mesh_type") == MeshType.default.value
    face_properties = {}
    deferred_transparencies = []
    deferred_opaques = []
    mesh_cache_key = (mesh.as_pointer(), num_faces)
    FaceSet._material_index_cache.pop(mesh_cache_key, None)

    attribute_cache_keys = [
        key for key in FaceSet._attribute_mask_cache
        if key[0] == mesh_cache_key[0] and key[1] == mesh_cache_key[1]
    ]
    for key in attribute_cache_keys:
        FaceSet._attribute_mask_cache.pop(key, None)
    
    poop_collision = props.get("bungie_mesh_type") == MeshType.poop_collision.value
    
    # changed_materials = False
    
    # Do material probs first to ensure they can be overriden by face props
    
    # def set_lightmap_only_mat() -> int:
    #     invis_mat = bpy.data.materials.get("Invisible")
    #     if invis_mat is None:
    #         invis_mat = bpy.data.materials.new("Invisible")
    #         invis_mat.diffuse_color = [0.4, 1.0, 0.4, 0.6]
    #         bsdf = invis_mat.node_tree.nodes[0]
    #         bsdf.inputs[0].default_value = invis_mat.diffuse_color
    #         bsdf.inputs[4].default_value = invis_mat.diffuse_color[3]
    #         invis_mat.blend_method = 'BLEND'
    #         invis_mat.nwo.shader_path = 'levels\shared\shaders\simple\invis.material'
            
    #     invis_index = mesh.materials.find("Invisible")
    #     if invis_index == -1:
    #         invis_index = len(mesh.materials)
    #         mesh.materials.append(invis_mat)
    #         return invis_index, True
        
    #     return invis_index, False
    
    for material, material_indices in prop_mats_dict.items():
        for prop in material.nwo.material_props:
            match prop.type:
                case 'collision_type':
                    if scene.corinth and not poop_collision:
                        if props.get("bungie_mesh_poop_collision_type") is None:
                            face_properties.setdefault("bungie_mesh_poop_collision_type", FaceSet(np.full(num_faces, face_prop_defaults["bungie_mesh_poop_collision_type"], dtype=np.int32))).update_from_material(mesh, material_indices, PoopCollisionType[prop.collision_type].value)
                case 'face_mode':
                    if props.get("bungie_face_mode") is None:
                        face_mode = FaceMode[prop.face_mode]
                        if scene.corinth:
                            if face_mode == FaceMode.breakable:
                                continue
                            elif face_mode == FaceMode.lightmap_only:
                                # print("lightmap only material!!!!!!!!")
                                # bungie_mesh_poop_collision_type does not appear to work at face level, so we're just setting the faces to render only instead of lightmap only
                                face_properties.setdefault("bungie_face_mode", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_mode"], dtype=np.int32))).update_from_material(mesh, material_indices, FaceMode.render_only.value)
                                # invis_index, changed_materials = set_lightmap_only_mat()
                                # indices = np.empty(num_faces, dtype=np.int32)
                                # mesh.polygons.foreach_get("material_index", indices)
                                # indices[np.isin(indices, material_indices)] = invis_index
                                # mesh.polygons.foreach_set("material_index", indices)
                                continue
                            
                        face_properties.setdefault("bungie_face_mode", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_mode"], dtype=np.int32))).update_from_material(mesh, material_indices, face_mode.value)
                        
                case 'face_sides':
                    if props.get("bungie_face_sides") is None:
                        side_value = 2 if prop.two_sided else 0
                        if prop.two_sided and scene.corinth and prop.face_sides_type != "two_sided":
                            side_value = 4 if prop.face_sides_type == 'mirror' else 6
                        face_properties.setdefault("bungie_face_sides", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_sides"], dtype=np.int32))).update_from_material(mesh, material_indices, side_value)
                case 'transparent':
                    if props.get("bungie_face_sides") is None and prop.transparent:
                        deferred_transparencies.append(material_indices)
                            
                        # face_properties.setdefault("bungie_face_sides", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_sides"], dtype=np.int32))).update_from_material(mesh, material_indices, 1, additive=True)
                case 'region':
                    if scene.asset_type.supports_regions and props.get("bungie_face_region") is None:
                        rv = scene.regions.get(face_prop_defaults["bungie_face_region"], 0)
                        face_rv = scene.regions.get(prop.region)
                        if face_rv is not None:
                            face_properties.setdefault("bungie_face_region", FaceSet(np.full(num_faces, rv, dtype=np.int32))).update_from_material(mesh, material_indices, face_rv)
                case 'draw_distance':
                    if props.get("bungie_face_draw_distance") is None:
                        face_properties.setdefault("bungie_face_draw_distance", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_draw_distance"], dtype=np.int32))).update_from_material(mesh, material_indices, FaceDrawDistance[prop.draw_distance].value)
                case 'global_material':
                    if props.get("bungie_face_global_material") is None:
                        gmv = scene.global_materials.get(face_prop_defaults["bungie_face_global_material"], 0)
                        face_gmv = scene.global_materials.get(prop.global_material.strip().replace(' ', "_"))
                        if face_gmv is not None:
                            if scene.corinth and props.get("bungie_mesh_type") in {MeshType.poop.value, MeshType.poop_collision.value}:
                                face_properties.setdefault("bungie_mesh_global_material", FaceSet(np.full(num_faces, gmv, dtype=np.int32))).update_from_material(mesh, material_indices, face_gmv)
                                face_properties.setdefault("bungie_mesh_poop_collision_override_global_material", FaceSet(np.full(num_faces, 0, dtype=np.int32))).update_from_material(mesh, material_indices, 1)
                            else:
                                face_properties.setdefault("bungie_face_global_material", FaceSet(np.full(num_faces, gmv, dtype=np.int32))).update_from_material(mesh, material_indices, face_gmv)
                case 'ladder':
                    if props.get("bungie_ladder") is None:
                        face_properties.setdefault("bungie_ladder", FaceSet(np.full(num_faces, face_prop_defaults["bungie_ladder"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.ladder))
                case 'slip_surface':
                    if props.get("bungie_slip_surface") is None:
                        face_properties.setdefault("bungie_slip_surface", FaceSet(np.full(num_faces, face_prop_defaults["bungie_slip_surface"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.slip_surface))
                case 'decal_offset':
                    if props.get("bungie_decal_offset") is None:
                        face_properties.setdefault("bungie_decal_offset", FaceSet(np.full(num_faces, face_prop_defaults["bungie_decal_offset"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.decal_offset))
                case 'no_shadow':
                    if props.get("bungie_no_shadow") is None:
                        face_properties.setdefault("bungie_no_shadow", FaceSet(np.full(num_faces, face_prop_defaults["bungie_no_shadow"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.no_shadow))
                case 'precise_position':
                    if props.get("bungie_precise_position") is None:
                        face_properties.setdefault("bungie_precise_position", FaceSet(np.full(num_faces, face_prop_defaults["bungie_precise_position"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.precise_position))
                case 'uncompressed':
                    if props.get("bungie_mesh_use_uncompressed_verts") is None:
                        face_properties.setdefault("bungie_mesh_use_uncompressed_verts", FaceSet(np.full(num_faces, face_prop_defaults["bungie_mesh_use_uncompressed_verts"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.uncompressed))
                case 'additional_compression':
                    if props.get("bungie_mesh_additional_compression") is None:
                        face_properties.setdefault("bungie_mesh_additional_compression", FaceSet(np.full(num_faces, face_prop_defaults["bungie_mesh_additional_compression"], dtype=np.int32))).update_from_material(mesh, material_indices, AdditionalCompression[prop.additional_compression].value)
                case 'no_lightmap':
                    if props.get("bungie_no_lightmap") is None:
                        face_properties.setdefault("bungie_no_lightmap", FaceSet(np.full(num_faces, face_prop_defaults["bungie_no_lightmap"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.no_lightmap))
                case 'no_pvs':
                    if props.get("bungie_invisible_to_pvs") is None:
                        face_properties.setdefault("bungie_invisible_to_pvs", FaceSet(np.full(num_faces, face_prop_defaults["bungie_invisible_to_pvs"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.no_pvs))
                case 'mesh_tessellation_density':
                    if props.get("bungie_mesh_tessellation_density") is None:
                        face_properties.setdefault("bungie_mesh_tessellation_density", FaceSet(np.full(num_faces, face_prop_defaults["bungie_mesh_tessellation_density"], dtype=np.int32))).update_from_material(mesh, material_indices, MeshTessellationDensity[prop.mesh_tessellation_density].value)
                case 'lightmap_resolution_scale':
                    if props.get("bungie_lightmap_resolution_scale") is None:
                        face_properties.setdefault("bungie_lightmap_resolution_scale", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_resolution_scale"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.lightmap_resolution_scale))
                case 'lightmap_ignore_default_resolution_scale':
                    if props.get("bungie_lightmap_ignore_default_resolution_scale") is None:
                        face_properties.setdefault("bungie_lightmap_ignore_default_resolution_scale", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_ignore_default_resolution_scale"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.lightmap_ignore_default_resolution_scale))
                case 'lightmap_chart_group':
                    if props.get("bungie_lightmap_chart_group") is None:
                        face_properties.setdefault("bungie_lightmap_chart_group", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_chart_group"], dtype=np.int32))).update_from_material(mesh, material_indices, prop.lightmap_chart_group)
                case 'lightmap_type':
                    if props.get("bungie_lightmap_type") is None:
                        face_properties.setdefault("bungie_lightmap_type", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_type"], dtype=np.int32))).update_from_material(mesh, material_indices, LightmapType[prop.lightmap_type].value)
                case 'lightmap_additive_transparency':
                    if props.get("bungie_lightmap_additive_transparency") is None:
                        face_properties.setdefault("bungie_lightmap_additive_transparency", FaceSet(np.full((num_faces, 3), face_prop_defaults["bungie_lightmap_additive_transparency"], dtype=np.single))).update_from_material(mesh, material_indices, utils.color_3p_int(prop.lightmap_additive_transparency))
                case 'lightmap_transparency_override':
                    if props.get("bungie_lightmap_transparency_override") is None:
                        face_properties.setdefault("bungie_lightmap_transparency_override", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_transparency_override"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.lightmap_transparency_override))
                case 'lightmap_analytical_bounce_modifier':
                    if props.get("bungie_lightmap_analytical_bounce_modifier") is None:
                        face_properties.setdefault("bungie_lightmap_analytical_bounce_modifier", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_analytical_bounce_modifier"], dtype=np.single))).update_from_material(mesh, material_indices, prop.lightmap_analytical_bounce_modifier)
                case 'lightmap_general_bounce_modifier':
                    if props.get("bungie_lightmap_general_bounce_modifier") is None:
                        face_properties.setdefault("bungie_lightmap_general_bounce_modifier", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_general_bounce_modifier"], dtype=np.single))).update_from_material(mesh, material_indices, prop.lightmap_general_bounce_modifier)
                case 'lightmap_translucency_tint_color':
                    if props.get("bungie_lightmap_translucency_tint_color") is None:
                        face_properties.setdefault("bungie_lightmap_translucency_tint_color", FaceSet(np.full((num_faces, 3), face_prop_defaults["bungie_lightmap_translucency_tint_color"], dtype=np.single))).update_from_material(mesh, material_indices, utils.color_3p_int(prop.lightmap_translucency_tint_color))
                case 'lightmap_lighting_from_both_sides':
                    if props.get("bungie_lightmap_lighting_from_both_sides") is None:
                        face_properties.setdefault("bungie_lightmap_lighting_from_both_sides", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_lighting_from_both_sides"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.lightmap_lighting_from_both_sides))
                case 'emissive':
                    if props.get("bungie_lighting_emissive_power") is None and prop.material_lighting_emissive_power > 0:
                        color, power = utils.get_light_final_color_and_intensity(prop.material_lighting_emissive_color, prop.material_lighting_emissive_power, True, True)
                        falloff = prop.material_lighting_attenuation_falloff
                        cutoff = prop.material_lighting_attenuation_cutoff
                        face_properties.setdefault("bungie_lighting_emissive_power", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_emissive_power"], np.single))).update_from_material(mesh, material_indices, power)
                        face_properties.setdefault("bungie_lighting_emissive_color", FaceSet(np.full((num_faces, 4), face_prop_defaults["bungie_lighting_emissive_color"], np.single))).update_from_material(mesh, material_indices, color)
                        face_properties.setdefault("bungie_lighting_emissive_per_unit", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_emissive_per_unit"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.material_lighting_emissive_per_unit))
                        face_properties.setdefault("bungie_lighting_emissive_quality", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_emissive_quality"], np.single))).update_from_material(mesh, material_indices, prop.material_lighting_emissive_quality)
                        face_properties.setdefault("bungie_lighting_use_shader_gel", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_use_shader_gel"], dtype=np.int32))).update_from_material(mesh, material_indices, int(prop.material_lighting_use_shader_gel))
                        face_properties.setdefault("bungie_lighting_bounce_ratio", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_bounce_ratio"], np.single))).update_from_material(mesh, material_indices, prop.material_lighting_bounce_ratio)
                        face_properties.setdefault("bungie_lighting_attenuation_enabled", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_attenuation_enabled"], dtype=np.int32))).update_from_material(mesh, material_indices, 1)
                        face_properties.setdefault("bungie_lighting_attenuation_cutoff", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_attenuation_cutoff"], np.single))).update_from_material(mesh, material_indices, cutoff * scene.atten_scalar * WU_SCALAR)
                        face_properties.setdefault("bungie_lighting_attenuation_falloff", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_attenuation_falloff"], np.single))).update_from_material(mesh, material_indices, falloff * scene.atten_scalar * WU_SCALAR)
                        face_properties.setdefault("bungie_lighting_emissive_focus", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_emissive_focus"], np.single))).update_from_material(mesh, material_indices, 1 - degrees(prop.material_lighting_emissive_focus) / 180)
        
    
    for prop in mesh_props.face_props:
        match prop.type:
            case 'collision_type':
                if scene.corinth and not poop_collision:
                    if props.get("bungie_mesh_poop_collision_type") is None:
                        face_properties.setdefault("bungie_mesh_poop_collision_type", FaceSet(np.full(num_faces, face_prop_defaults["bungie_mesh_poop_collision_type"], dtype=np.int32))).update(mesh, prop, PoopCollisionType[prop.collision_type].value)
            case 'face_mode':
                if props.get("bungie_face_mode") is None:
                    face_mode = FaceMode[prop.face_mode]
                    if scene.corinth:
                        if face_mode == FaceMode.breakable:
                            continue
                        elif face_mode == FaceMode.lightmap_only:
                            face_properties.setdefault("bungie_face_mode", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_mode"], dtype=np.int32))).update(mesh, prop, FaceMode.render_only.value)
                            # attribute = mesh.attributes.get(prop.attribute_name)
                            # if attribute is not None:
                            #     values_array = np.zeros(num_faces, dtype=np.int8)
                            #     attribute.data.foreach_get("value", values_array)
                            #     mask = values_array.astype(bool)
                            #     invis_index, changed_materials = set_lightmap_only_mat()
                            #     indices = np.empty(num_faces, dtype=np.int32)
                            #     mesh.polygons.foreach_get("material_index", indices)
                            #     indices[mask] = invis_index
                            #     mesh.polygons.foreach_set("material_index", indices)
                            continue
                        
                    face_properties.setdefault("bungie_face_mode", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_mode"], dtype=np.int32))).update(mesh, prop, face_mode.value)
            case 'face_sides':
                if props.get("bungie_face_sides") is None:
                    side_value = 2 if prop.two_sided else 0
                    if prop.two_sided and scene.corinth and prop.face_sides_type != "two_sided":
                        side_value = 4 if prop.face_sides_type == 'mirror' else 6
                    face_properties.setdefault("bungie_face_sides", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_sides"], dtype=np.int32))).update(mesh, prop, side_value)
            case 'transparent':
                if props.get("bungie_face_sides") is None:
                    attribute = mesh.attributes.get(prop.attribute_name)
                    if attribute is not None:
                        prop_face_indices = np.zeros(len(mesh.polygons), dtype=np.int8)
                        attribute.data.foreach_get("value", prop_face_indices)
                        if prop.transparent:
                            deferred_transparencies.append(np.nonzero(prop_face_indices)[0])
                        else:
                            deferred_opaques.append(np.nonzero(prop_face_indices)[0])
                    # face_properties.setdefault("bungie_face_sides", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_sides"], dtype=np.int32))).update(mesh, prop, 1, additive=True)
            case 'region':
                if scene.asset_type.supports_regions and props.get("bungie_face_region") is None:
                    rv = scene.regions.get(face_prop_defaults["bungie_face_region"], 0)
                    face_rv = scene.regions.get(prop.region)
                    if face_rv is not None:
                        face_properties.setdefault("bungie_face_region", FaceSet(np.full(num_faces, rv, dtype=np.int32))).update(mesh, prop, face_rv)
            case 'draw_distance':
                if props.get("bungie_face_draw_distance") is None:
                    face_properties.setdefault("bungie_face_draw_distance", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_draw_distance"], dtype=np.int32))).update(mesh, prop, FaceDrawDistance[prop.draw_distance].value)
            case 'global_material':
                if props.get("bungie_face_global_material") is None:
                    gmv = scene.global_materials.get(face_prop_defaults["bungie_face_global_material"], 0)
                    face_gmv = scene.global_materials.get(prop.global_material.strip().replace(' ', "_"))
                    if face_gmv is not None:
                        if scene.corinth and props.get("bungie_mesh_type") in {MeshType.poop.value, MeshType.poop_collision.value}:
                            face_properties.setdefault("bungie_mesh_global_material", FaceSet(np.full(num_faces, gmv, dtype=np.int32))).update(mesh, prop, face_gmv)
                            face_properties.setdefault("bungie_mesh_poop_collision_override_global_material", FaceSet(np.full(num_faces, 0, dtype=np.int32))).update(mesh, prop, 1)
                        else:
                            face_properties.setdefault("bungie_face_global_material", FaceSet(np.full(num_faces, gmv, dtype=np.int32))).update(mesh, prop, face_gmv)
            case 'ladder':
                if props.get("bungie_ladder") is None:
                    face_properties.setdefault("bungie_ladder", FaceSet(np.full(num_faces, face_prop_defaults["bungie_ladder"], dtype=np.int32))).update(mesh, prop, int(prop.ladder))
            case 'slip_surface':
                if props.get("bungie_slip_surface") is None:
                    face_properties.setdefault("bungie_slip_surface", FaceSet(np.full(num_faces, face_prop_defaults["bungie_slip_surface"], dtype=np.int32))).update(mesh, prop, int(prop.slip_surface))
            case 'decal_offset':
                if props.get("bungie_decal_offset") is None:
                    face_properties.setdefault("bungie_decal_offset", FaceSet(np.full(num_faces, face_prop_defaults["bungie_decal_offset"], dtype=np.int32))).update(mesh, prop, int(prop.decal_offset))
            case 'no_shadow':
                if props.get("bungie_no_shadow") is None:
                    face_properties.setdefault("bungie_no_shadow", FaceSet(np.full(num_faces, face_prop_defaults["bungie_no_shadow"], dtype=np.int32))).update(mesh, prop, int(prop.no_shadow))
            case 'precise_position':
                if props.get("bungie_precise_position") is None:
                    face_properties.setdefault("bungie_precise_position", FaceSet(np.full(num_faces, face_prop_defaults["bungie_precise_position"], dtype=np.int32))).update(mesh, prop, int(prop.precise_position))
            case 'uncompressed':
                if props.get("bungie_mesh_use_uncompressed_verts") is None:
                    face_properties.setdefault("bungie_mesh_use_uncompressed_verts", FaceSet(np.full(num_faces, face_prop_defaults["bungie_mesh_use_uncompressed_verts"], dtype=np.int32))).update(mesh, prop, int(prop.uncompressed))
            case 'additional_compression':
                if props.get("bungie_mesh_additional_compression") is None:
                    face_properties.setdefault("bungie_mesh_additional_compression", FaceSet(np.full(num_faces, face_prop_defaults["bungie_mesh_additional_compression"], dtype=np.int32))).update(mesh, prop, AdditionalCompression[prop.additional_compression].value)
            case 'no_lightmap':
                if props.get("bungie_no_lightmap") is None:
                    face_properties.setdefault("bungie_no_lightmap", FaceSet(np.full(num_faces, face_prop_defaults["bungie_no_lightmap"], dtype=np.int32))).update(mesh, prop, int(prop.no_lightmap))
            case 'no_pvs':
                if props.get("bungie_invisible_to_pvs") is None:
                    face_properties.setdefault("bungie_invisible_to_pvs", FaceSet(np.full(num_faces, face_prop_defaults["bungie_invisible_to_pvs"], dtype=np.int32))).update(mesh, prop, int(prop.no_pvs))
            case 'mesh_tessellation_density':
                if props.get("bungie_mesh_tessellation_density") is None:
                    face_properties.setdefault("bungie_mesh_tessellation_density", FaceSet(np.full(num_faces, face_prop_defaults["bungie_mesh_tessellation_density"], dtype=np.int32))).update(mesh, prop, MeshTessellationDensity[prop.mesh_tessellation_density].value)
            case 'lightmap_resolution_scale':
                if props.get("bungie_lightmap_resolution_scale") is None:
                    face_properties.setdefault("bungie_lightmap_resolution_scale", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_resolution_scale"], dtype=np.int32))).update(mesh, prop, int(prop.lightmap_resolution_scale))
            case 'lightmap_ignore_default_resolution_scale':
                if props.get("bungie_lightmap_ignore_default_resolution_scale") is None and prop.lightmap_ignore_default_resolution_scale:
                    face_properties.setdefault("bungie_lightmap_ignore_default_resolution_scale", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_ignore_default_resolution_scale"], dtype=np.int32))).update(mesh, prop, 1)
            case 'lightmap_chart_group':
                if props.get("bungie_lightmap_chart_group") is None:
                    face_properties.setdefault("bungie_lightmap_chart_group", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_chart_group"], dtype=np.int32))).update(mesh, prop, prop.lightmap_chart_group)
            case 'lightmap_type':
                if props.get("bungie_lightmap_type") is None:
                    face_properties.setdefault("bungie_lightmap_type", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_type"], dtype=np.int32))).update(mesh, prop, LightmapType[prop.lightmap_type].value)
            case 'lightmap_additive_transparency':
                if props.get("bungie_lightmap_additive_transparency") is None:
                    face_properties.setdefault("bungie_lightmap_additive_transparency", FaceSet(np.full((num_faces, 3), face_prop_defaults["bungie_lightmap_additive_transparency"], dtype=np.single))).update(mesh, prop, utils.color_3p_int(prop.lightmap_additive_transparency))
            case 'lightmap_transparency_override':
                if props.get("bungie_lightmap_transparency_override") is None:
                    face_properties.setdefault("bungie_lightmap_transparency_override", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_transparency_override"], dtype=np.int32))).update(mesh, prop, int(prop.lightmap_transparency_override))
            case 'lightmap_analytical_bounce_modifier':
                if props.get("bungie_lightmap_analytical_bounce_modifier") is None:
                    face_properties.setdefault("bungie_lightmap_analytical_bounce_modifier", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_analytical_bounce_modifier"], dtype=np.single))).update(mesh, prop, prop.lightmap_analytical_bounce_modifier)
            case 'lightmap_general_bounce_modifier':
                if props.get("bungie_lightmap_general_bounce_modifier") is None:
                    face_properties.setdefault("bungie_lightmap_general_bounce_modifier", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_general_bounce_modifier"], dtype=np.single))).update(mesh, prop, prop.lightmap_general_bounce_modifier)
            case 'lightmap_translucency_tint_color':
                if props.get("bungie_lightmap_translucency_tint_color") is None:
                    face_properties.setdefault("bungie_lightmap_translucency_tint_color", FaceSet(np.full((num_faces, 3), face_prop_defaults["bungie_lightmap_translucency_tint_color"], dtype=np.single))).update(mesh, prop, utils.color_3p_int(prop.lightmap_translucency_tint_color))
            case 'lightmap_lighting_from_both_sides':
                if props.get("bungie_lightmap_lighting_from_both_sides") is None:
                    face_properties.setdefault("bungie_lightmap_lighting_from_both_sides", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lightmap_lighting_from_both_sides"], dtype=np.int32))).update(mesh, prop, int(prop.lightmap_lighting_from_both_sides))
            case 'emissive':
                if props.get("bungie_lighting_emissive_power") is None and prop.material_lighting_emissive_power > 0:
                    color, power = utils.get_light_final_color_and_intensity(prop.material_lighting_emissive_color, prop.material_lighting_emissive_power, True, True)
                    falloff = prop.material_lighting_attenuation_falloff
                    cutoff = prop.material_lighting_attenuation_cutoff
                    face_properties.setdefault("bungie_lighting_emissive_power", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_emissive_power"], np.single))).update(mesh, prop, power)
                    face_properties.setdefault("bungie_lighting_emissive_color", FaceSet(np.full((num_faces, 4), face_prop_defaults["bungie_lighting_emissive_color"], np.single))).update(mesh, prop, color)
                    face_properties.setdefault("bungie_lighting_emissive_per_unit", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_emissive_per_unit"], dtype=np.int32))).update(mesh, prop, int(prop.material_lighting_emissive_per_unit))
                    face_properties.setdefault("bungie_lighting_emissive_quality", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_emissive_quality"], np.single))).update(mesh, prop, prop.material_lighting_emissive_quality)
                    face_properties.setdefault("bungie_lighting_use_shader_gel", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_use_shader_gel"], dtype=np.int32))).update(mesh, prop, int(prop.material_lighting_use_shader_gel))
                    face_properties.setdefault("bungie_lighting_bounce_ratio", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_bounce_ratio"], np.single))).update(mesh, prop, prop.material_lighting_bounce_ratio)
                    face_properties.setdefault("bungie_lighting_attenuation_enabled", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_attenuation_enabled"], dtype=np.int32))).update(mesh, prop, 1)
                    face_properties.setdefault("bungie_lighting_attenuation_cutoff", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_attenuation_cutoff"], np.single))).update(mesh, prop, cutoff * scene.atten_scalar * WU_SCALAR)
                    face_properties.setdefault("bungie_lighting_attenuation_falloff", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_attenuation_falloff"], np.single))).update(mesh, prop, falloff * scene.atten_scalar * WU_SCALAR)
                    face_properties.setdefault("bungie_lighting_emissive_focus", FaceSet(np.full(num_faces, face_prop_defaults["bungie_lighting_emissive_focus"], np.single))).update(mesh, prop, 1 - degrees(prop.material_lighting_emissive_focus) / 180)
                    
    if deferred_transparencies:
        transparent_indices = np.unique(np.concatenate([a for a in deferred_transparencies]))
        if deferred_opaques:
            opaque_indices = np.unique(np.concatenate([a for a in deferred_opaques]))
            mask = ~np.isin(transparent_indices, opaque_indices)
            transparent_indices = transparent_indices[mask]
            
        face_properties.setdefault("bungie_face_sides", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_sides"], dtype=np.int32))).update_from_material(mesh, transparent_indices, 1, additive=True)
                    
    for material, material_indices in special_mats_dict.items():
        if material.name.lower().startswith('+seamsealer') and props.get("bungie_face_type") is None:
            if scene.corinth:
                if not poop_collision:
                    face_properties.setdefault("bungie_face_mode", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_mode"], dtype=np.int32))).update_from_material(mesh, material_indices, FaceMode.collision_only.value)
                    face_properties.setdefault("bungie_mesh_poop_collision_type", FaceSet(np.full(num_faces, face_prop_defaults["bungie_mesh_poop_collision_type"], dtype=np.int32))).update_from_material(mesh, material_indices, PoopCollisionType.invisible_wall.value)
            else:
                face_properties.setdefault("bungie_face_type", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_type"], dtype=np.int32))).update_from_material(mesh, material_indices, FaceType.seam_sealer.value)
        elif is_structure and material.name.lower().startswith('+seam') and props.get("bungie_mesh_type") != MeshType.seam.value:
            props.pop("bungie_mesh_type")
            face_properties.setdefault("bungie_mesh_type", FaceSet(np.full(num_faces, face_prop_defaults["bungie_mesh_type"], dtype=np.int32))).update_from_material(mesh, material_indices, MeshType.seam.value)
        elif material.name.lower().startswith('+'):
            if not is_structure and scene.corinth:
                if not poop_collision:
                    face_properties.setdefault("bungie_face_mode", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_mode"], dtype=np.int32))).update_from_material(mesh, material_indices, FaceMode.collision_only.value)
                    face_properties.setdefault("bungie_mesh_poop_collision_type", FaceSet(np.full(num_faces, face_prop_defaults["bungie_mesh_poop_collision_type"], dtype=np.int32))).update_from_material(mesh, material_indices, PoopCollisionType.invisible_wall.value)
            else:
                enum_val = FaceType.sky.value if (is_structure and scene.asset_type == AssetType.SCENARIO) else FaceType.seam_sealer.value
                if props.get("bungie_face_type") is None:
                    face_properties.setdefault("bungie_face_type", FaceSet(np.full(num_faces, face_prop_defaults["bungie_face_type"], dtype=np.int32))).update_from_material(mesh, material_indices, enum_val)
                
                if not scene.corinth and enum_val == FaceType.sky.value:
                    if len(material.name) > 4 and material.name[4].isdigit():
                        if len(material.name) > 5 and material.name[5].isdigit():
                            sky_index = int("".join(material.name[4:5]))
                        else:
                            sky_index = int(material.name[4])
                        if sky_index > 0 and props.get("bungie_sky_permutation_index") is None:
                            face_properties.setdefault("bungie_sky_permutation_index", FaceSet(np.zeros(num_faces, dtype=np.int32))).update_from_material(mesh, material_indices, sky_index)
                        
    for attribute in bungie_attributes:
        match attribute.data_type:
            case 'FLOAT':
                array = np.zeros(num_faces, dtype=np.single)
                attribute.data.foreach_get("value", array)
                face_properties[attribute.name] = FaceSet(array)
            case 'INT' | 'INT8':
                array = np.zeros(num_faces, dtype=np.int32)
                attribute.data.foreach_get("value", array)
                face_properties[attribute.name] = FaceSet(array)
            case 'FLOAT_VECTOR':
                array = np.zeros(num_faces * 3, dtype=np.single)
                attribute.data.foreach_get("vector", array)
                face_properties[attribute.name] = FaceSet(array.reshape(-1, 3))
            case 'FLOAT_COLOR' | 'BYTE_COLOR':
                array = np.zeros(num_faces * 4, dtype=np.single)
                attribute.data.foreach_get("color", array)
                array = array.reshape(-1, 4)
                array[:, [0, 3]] = array[:, [3, 0]] # RGBA -> ARGB
                face_properties[attribute.name] = FaceSet(array)
            case 'STRING':
                # TODO lookup string value in enums
                array = np.zeros(num_faces, dtype=np.byte)
                attribute.data.foreach_get("value", array)
                # array = np.array([lookup_enum(scene, b) for b in array], dtype=np.int32)
                face_properties[attribute.name] = FaceSet(array)
            case 'BOOLEAN':
                array = np.zeros(num_faces, dtype=np.int32)
                attribute.data.foreach_get("value", array)
                face_properties[attribute.name] = FaceSet(array)
            case 'FLOAT2':
                array = np.zeros((num_faces, 2), dtype=np.int32)
                attribute.data.foreach_get("vector", array)
                face_properties[attribute.name] = FaceSet(array)
            case 'INT16_2D' | 'INT32_2D':
                array = np.zeros((num_faces, 2), dtype=np.int32)
                attribute.data.foreach_get("vector", array)
                face_properties[attribute.name] = FaceSet(array)
            # case 'QUATERNION':
            #     array = np.zeros((num_faces, 4), dtype=np.int32)
            #     attribute.data.foreach_get("value", array)
            #     array[:, [0, 3]] = array[:, [3, 0]] # WXYZ Quaternion to IJKW
            #     face_properties[attribute.name] = FaceSet(array)
            # case 'FLOAT4X4':
            #     array = np.zeros((num_faces, 16), dtype=np.int32)
            #     attribute.data.foreach_get("value", array)
            #     face_properties[attribute.name] = FaceSet(array)
    
                        
    if force_render_only:
        existing_face_face_mode = face_properties.get("bungie_face_mode")
        if existing_face_face_mode is None:
            existing_mesh_face_mode = props.get("bungie_face_mode")
            if existing_mesh_face_mode is None or existing_mesh_face_mode in COLLISION_FACE_MODES:
                face_properties["bungie_face_mode"] = FaceSet(np.full(num_faces, FaceMode.render_only.value, np.int32))
        else:
            existing_face_face_mode.array = np.where(np.isin(existing_face_face_mode.array, COLLISION_FACE_MODES), FaceMode.render_only.value, existing_face_face_mode.array)

    if sorted_order is not None:
        for v in face_properties.values():
            v.array = v.array[sorted_order]
            
    
    return face_properties

def lookup_enum(scene: VirtualScene, name: str):
    return 0
    
def calc_transforms(matrix: Matrix) -> tuple[Array, Array, Array]:
    '''Gets the affine3, linear3x3, and inverse_linear3x3 from a matrix'''
    matrix3x3 = matrix.to_3x3()
    affine3 = (c_float * 3)(*matrix.translation.to_tuple())
    linear3x3 = (c_float * 9)(*[f for row in matrix3x3 for f in row])
    inverse_linear3x3 = (c_float * 9)(*[f for row in matrix3x3.inverted(Matrix.Identity(4).to_3x3()) for f in row])
    
    return affine3, linear3x3, inverse_linear3x3

def is_rendered(props: dict) -> bool:
    mesh_type = props.get("bungie_mesh_type", None)
    if mesh_type is None:
        # returning true since the absence of a mesh type means the game will use the default mesh type - _connected_geometry_mesh_type_default
        return True 
    
    return mesh_type in {MeshType.default.value, MeshType.poop.value, MeshType.object_instance.value, MeshType.water_surface.value, MeshType.decorator.value}

def deep_copy_granny_tri_topology(original):
    copy = GrannyTriTopology()
    copy.group_count = original.contents.group_count
    copy.index_count = original.contents.index_count
    copy.tri_annotation_set_count = original.contents.tri_annotation_set_count

    if original.contents.groups:
        num_groups = original.contents.group_count
        groups = (GrannyTriMaterialGroup * num_groups)()
        memmove(groups, original.contents.groups, sizeof(GrannyTriMaterialGroup) * num_groups)
        copy.groups = cast(groups, POINTER(GrannyTriMaterialGroup))

    if original.contents.indices:
        indices = (c_int * original.contents.index_count)()
        memmove(indices, original.contents.indices, sizeof(c_int) * original.contents.index_count)
        copy.indices = cast(indices, POINTER(c_int))

    if original.contents.tri_annotation_sets:
        num_sets = original.contents.tri_annotation_set_count
        tri_annotation_sets = (GrannyTriAnnotationSet * num_sets)()
        
        for i in range(num_sets):
            tri_annotation_sets[i].name = create_string_buffer(original.contents.tri_annotation_sets[i].name).raw
            tri_annotation_sets[i].indices_map_from_tri_to_annotation = original.contents.tri_annotation_sets[i].indices_map_from_tri_to_annotation
            tri_annotation_sets[i].tri_annotation_type = original.contents.tri_annotation_sets[i].tri_annotation_type
            tri_annotation_sets[i].tri_annotation_count = original.contents.tri_annotation_sets[i].tri_annotation_count

            annotation_size = original.contents.tri_annotation_sets[i].tri_annotation_count
            annotations = (c_ubyte * annotation_size)()
            memmove(annotations, original.contents.tri_annotation_sets[i].tri_annotations, sizeof(c_ubyte) * annotation_size)
            tri_annotation_sets[i].tri_annotations = cast(annotations, POINTER(c_ubyte))
        
        copy.tri_annotation_sets = cast(tri_annotation_sets, POINTER(GrannyTriAnnotationSet))

    return pointer(copy)

# class ModifierStack:
#     __slots__ = ("stack", "_hash")

#     def __init__(self, obj: bpy.types.Object):
#         self.stack = tuple(self._serialize_modifier(m) for m in obj.modifiers)
#         self._hash = hash(self.stack)

#     def _serialize_modifier(self, mod: bpy.types.Modifier):

#         if mod.type == "NODES":
#             return self._serialize_nodes_modifier(mod)

#         props = []

#         for prop in mod.bl_rna.properties:
#             ident = prop.identifier

#             if ident in {"rna_type", "name"}:
#                 continue
#             if prop.is_hidden or prop.is_readonly:
#                 continue

#             try:
#                 value = getattr(mod, ident)
#             except AttributeError:
#                 continue

#             value = self._serialize_value(value)
#             props.append((ident, value))

#         props.sort()

#         return (mod.type, tuple(props))

#     def _serialize_nodes_modifier(self, mod: bpy.types.NodesModifier):

#         props = []

#         for prop in mod.bl_rna.properties:
#             ident = prop.identifier

#             if ident in {"rna_type", "name"}:
#                 continue
#             if prop.is_hidden or prop.is_readonly:
#                 continue

#             try:
#                 value = getattr(mod, ident)
#             except AttributeError:
#                 continue

#             value = self._serialize_value(value)
#             props.append((ident, value))

#         group = mod.node_group

#         if group:
#             for item in group.interface.items_tree:

#                 if item.item_type != "SOCKET":
#                     continue

#                 if item.in_out != "INPUT":
#                     continue

#                 identifier = item.identifier

#                 if identifier in mod:
#                     value = mod[identifier]
#                     value = self._serialize_value(value)

#                     props.append((f"socket:{identifier}", value))

#         props.sort()

#         return ("NODES", tuple(props))

#     def _serialize_value(self, value):

#         if value is None:
#             return None

#         if isinstance(value, bpy.types.ID):
#             return value.name

#         if isinstance(value, Vector):
#             return tuple(value)

#         if isinstance(value, Color):
#             return tuple(value)

#         if isinstance(value, Quaternion):
#             return tuple(value)

#         if isinstance(value, Euler):
#             return (value.x, value.y, value.z, value.order)

#         if isinstance(value, Matrix):
#             return tuple(tuple(row) for row in value)

#         if type(value).__name__ == "IDPropertyArray":
#             return tuple(value)

#         if isinstance(value, set):
#             return tuple(sorted(self._serialize_value(v) for v in value))

#         if isinstance(value, (list, tuple)):
#             return tuple(self._serialize_value(v) for v in value)

#         if isinstance(value, dict):
#             return tuple(sorted((k, self._serialize_value(v)) for k, v in value.items()))

#         return value

#     def __eq__(self, other):
#         if not isinstance(other, ModifierStack):
#             return NotImplemented
#         return self.stack == other.stack

#     def __hash__(self):
#         return self._hash

#     def __repr__(self):
#         return f"ModifierStack({self.stack})"
